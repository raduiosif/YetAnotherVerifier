/*
 * SizeOf.java - A global repository of native size constants.
 *
 */

package yav.jsuif.ionative;


public class SizeOf
{
  public static int VOID_PTR;
  public static native int getVoidPointerSize();

  public static int LONG;
  public static native int getLongSize();

  public static int INT; 
  public static native int getIntSize();

  public static int SHORT;
  public static native int getShortSize();

  public static int CHAR;
  public static native int getCharSize();

  public static int DOUBLE;
  public static native int getDoubleSize();

  public static int FLOAT;
  public static native int getFloatSize();

  public static int BOOL;
  public static native int getBoolSize();

  public static int SIZE_T;
  public static native int getSizeTSize();

  public static int GENERIC_OBJECT;
  public static native int getGenericObjectSize();

  public static int META_CLASS;
  public static native int getMetaClassSize();

  public static int INTEGER_META_CLASS;
  public static native int getIntegerMetaClassSize();

  public static int POINTER_META_CLASS;
  public static native int getPointerMetaClassSize();

  public static int LIST_META_CLASS;
  public static native int getListMetaClassSize();

  public static int GENERIC_LIST;
  public static native int getGenericListSize();

  public static int FIELD_DESCRIPTION;
  public static native int getFieldDescriptionSize();

  public static int OBJECT_FACTORY;
  public static native int getObjectFactorySize();

  public static int AGGREGATE_META_CLASS;
  public static native int getAggregateMetaClassSize();

  public static int OBJECT_AGGREGATE_META_CLASS;
  public static native int getObjectAggregateMetaClassSize();

  public static int UNION_META_CLASS;
  public static native int getUnionMetaClassSize();

  public static int SUIF_OBJECT;
  public static native int getSuifObjectSize();

  public static int I_INTEGER;
  public static native int getIIntegerSize();

  public static int STRING;
  public static native int getStringSize();

  public static int LSTRING;
  public static native int getLStringSize();

  public static int INDEXED_LIST;
  public static native int getIndexedListSize();

  public static int LIST;
  public static native int getListSize();

  public static int SEARCHABLE_LIST;
  public static native int getSearchableListSize();

  public static int HASH_MAP;
  public static native int getHashMapSize();

  public static int MAP;
  public static native int getMapSize();

  public static int VECTOR;
  public static native int getVectorSize();

  static {
    System.loadLibrary("jsuif");

    VOID_PTR = getVoidPointerSize();
    LONG = getLongSize();
    INT = getIntSize();
    SHORT = getShortSize();
    CHAR = getCharSize();
    DOUBLE = getDoubleSize();
    FLOAT = getFloatSize();
    BOOL = getBoolSize();
    SIZE_T = getSizeTSize();

    GENERIC_OBJECT = getGenericObjectSize();
    META_CLASS = getMetaClassSize();
    INTEGER_META_CLASS = getIntegerMetaClassSize();
    POINTER_META_CLASS = getPointerMetaClassSize();
    LIST_META_CLASS = getListMetaClassSize();
    GENERIC_LIST = getGenericListSize();
    FIELD_DESCRIPTION = getFieldDescriptionSize();
    OBJECT_FACTORY = getObjectFactorySize();
    AGGREGATE_META_CLASS = getAggregateMetaClassSize();
    OBJECT_AGGREGATE_META_CLASS = getObjectAggregateMetaClassSize();
    UNION_META_CLASS = getUnionMetaClassSize();
    
    SUIF_OBJECT = getSuifObjectSize();

    I_INTEGER = getIIntegerSize();
    STRING = getStringSize();
    LSTRING = getLStringSize();

    INDEXED_LIST = getIndexedListSize();
    LIST = getListSize();
    SEARCHABLE_LIST = getSearchableListSize();
    HASH_MAP = getHashMapSize();
    MAP = getMapSize();
    VECTOR = getVectorSize();
  }
}
