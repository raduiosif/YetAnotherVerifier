/*
 * AlignmentOf.cpp - a native counterpart for AlignmentOf.java
 *
 */

#include <jni.h>
#include <suifclasses.h>

#include "AlignmentOf.h"

struct __long {
  char x;
  long field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getLongAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__long, field);
}

struct __int {
  char x;
  int field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getIntAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__int, field);
}

struct __short {
  char x;
  short field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getShortAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__short, field);
}

struct __char {
  char x;
  char field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getCharAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__char, field);
}

struct __double {
  char x;
  double field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getDoubleAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__double, field);
}

struct __bool {
  char x;
  bool field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getBoolAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__bool, field);
}

struct __size_t {
  char x;
  size_t field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getSizeTAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__size_t, field);
}

struct __void_pointer {
  char x;
  void * field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getVoidPointerAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__void_pointer, field);
}

struct __Object {
  char x;
  Object field;
};

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_AlignmentOf_getGenericObjectAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__Object, field);
}

struct __GenericList {
  char x;
  GenericList field;
};

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_AlignmentOf_getGenericListAlignment
  (JNIEnv *, jclass)
{
  return OFFSETOF(__GenericList, field);
}

struct __IInteger {
  char x;
  IInteger field;
};

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_AlignmentOf_getIIntegerAlignment
  (JNIEnv *, jclass)
{
  return OFFSETOF(__IInteger, field);
}

struct __indexed_list { 
  char x; 
  indexed_list<int, int> field; 
}; 

JNIEXPORT jint JNICALL  
  Java_yav_jsuif_ionative_AlignmentOf_getIndexedListAlignment 
  (JNIEnv *, jclass) 
{
  return (jint) OFFSETOF(__indexed_list, field);
} 

struct __list { 
  char x;
  list<int> field; 
}; 

JNIEXPORT jint JNICALL  
  Java_yav_jsuif_ionative_AlignmentOf_getListAlignment
  (JNIEnv *, jclass)
{ 
  return (jint) OFFSETOF(__list, field);
} 

struct __searchable_list { 
  char x;
  searchable_list<int> field;
};

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_AlignmentOf_getSearchableListAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__searchable_list, field);
}

struct __suif_hash_map {
  char x;
  suif_hash_map<int, int> field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getHashMapAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__suif_hash_map, field);
}

struct __suif_map {
  char x;
  suif_map<int, int> field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getMapAlignment
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(__suif_map, field);
}

struct __suif_vector {
  char x;
  suif_vector<int> field;
};

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_AlignmentOf_getVectorAlignment
  (JNIEnv *, jclass)
{ 
  return (jint) OFFSETOF(__suif_vector, field);
}

