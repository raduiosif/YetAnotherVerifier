/*
 * SizeOf.c - a native counterpart for SizeOf.java
 *
 */

#include <jni.h>
#include <suifclasses.h>

#include "SizeOf.h"

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getBoolSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( bool );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getCharSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( char );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getDoubleSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( double );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getIntSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( int );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getLongSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( long );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getShortSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( short );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getSizeTSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( size_t );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getVoidPointerSize
  (JNIEnv *env, jclass cls)
{
  return (jint) sizeof( void * );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getGenericObjectSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( Object );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( MetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getIntegerMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( IntegerMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getPointerMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( PointerMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getListMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( ListMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getGenericListSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( GenericList );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getFieldDescriptionSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( FieldDescription );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getObjectFactorySize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( ObjectFactory );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getAggregateMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( AggregateMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getObjectAggregateMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( ObjectAggregateMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getUnionMetaClassSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( UnionMetaClass );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getSuifObjectSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( SuifObject );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getIIntegerSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( IInteger );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getStringSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( String );
}

JNIEXPORT jint JNICALL 
  Java_yav_jsuif_ionative_SizeOf_getLStringSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( LString );
}

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_SizeOf_getIndexedListSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( indexed_list<int, int> );
}

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_SizeOf_getListSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( list<int> );
}

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_SizeOf_getSearchableListSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( searchable_list<int> );
}

JNIEXPORT jint JNICALL
  Java_yav_jsuif_ionative_SizeOf_getHashMapSize
  (JNIEnv *, jclass)
{
  return (jint) sizeof( suif_hash_map<int, int> );
}

JNIEXPORT jint JNICALL  
  Java_yav_jsuif_ionative_SizeOf_getMapSize 
  (JNIEnv *, jclass) 
{ 
  return (jint) sizeof( suif_map<int, int> );
} 

JNIEXPORT jint JNICALL  
  Java_yav_jsuif_ionative_SizeOf_getVectorSize 
  (JNIEnv *, jclass) 
{ 
  return (jint) sizeof( suif_vector<int> );
} 

