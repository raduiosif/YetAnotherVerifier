import yav.jsuif.common.*;
import yav.jsuif.kernel.*;
import yav.jsuif.ionative.*;
import yav.jsuif.typebuilder.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.nodes.suif.*;


class HelloWorld
{
  private final static String _STR = "Hello World";
  private final static int _LEN = _STR.length();

  public static void main(String[] args)
  {
    SuifEnv suif = new SuifEnv();
    suif.init();
    buildTree(suif);
    suif.write("HelloWorld.suif");
  }

  private static void buildTree(SuifEnv suif)
  {
    BasicModule.init(suif);
    SuifModule.init(suif);
    TypeBuilderModule.init(suif);
    
    BasicObjectFactory basic_of = 
      (BasicObjectFactory) suif.getObjectFactory("BasicObjectFactory");

    Assert.condition(basic_of != null);

    SuifObjectFactory suif_of =
      (SuifObjectFactory) suif.getObjectFactory("SuifObjectFactory");

    Assert.condition(suif_of != null);

    TypeBuilder tb =
      (TypeBuilder) suif.getObjectFactory("TypeBuilder");

    Assert.condition(tb != null);

    BasicSymbolTable external_symbol_table = 
      basic_of.createBasicSymbolTable(null);
    
    BasicSymbolTable file_symbol_table =
      basic_of.createBasicSymbolTable(null);

    BasicSymbolTable file_set_symbol_table =
      basic_of.createBasicSymbolTable(null);

    FileSetBlock the_file_set_block =
      basic_of.createFileSetBlock(external_symbol_table,
				  file_set_symbol_table);

    suif.setFileSetBlock(the_file_set_block);

    DefinitionBlock file_def_block = basic_of.createDefinitionBlock();
    FileBlock the_file_block = basic_of.createFileBlock("HelloWorld.java",
							file_symbol_table,
							file_def_block);

    the_file_set_block.appendFileBlock(the_file_block);

    IntegerType int_type = 
      tb.getIntegerType(new IInteger(SizeOf.INT*8), SizeOf.INT*8, true);

    QualifiedType q_argc_type = tb.getQualifiedType(int_type);

    IntegerType char_type =
      tb.getIntegerType(new IInteger(SizeOf.CHAR*8), SizeOf.CHAR*8, true);
    
    QualifiedType q_char_type = tb.getQualifiedType(char_type);

    PointerType char_ptr_type = tb.getPointerType(q_char_type);
    QualifiedType q_char_ptr_type = tb.getQualifiedType(char_ptr_type);

    PointerType argv_type = tb.getPointerType(q_char_ptr_type);
    QualifiedType q_argv_type = tb.getQualifiedType(argv_type);

    List ql = new List();
    ql.pushBack(q_argc_type);
    ql.pushBack(q_argv_type);
    
    CProcedureType main_type =
      tb.getCProcedureType(int_type, ql, false, true);

    ProcedureSymbol main_symbol =
      basic_of.createProcedureSymbol(main_type, "main", true, null);

    the_file_set_block.getExternalSymbolTable().addSymbol(main_symbol);

    StatementList main_body = basic_of.createStatementList();

    BasicSymbolTable main_symbol_table =
      basic_of.createBasicSymbolTable(file_symbol_table);

    DefinitionBlock main_def_block =
      basic_of.createDefinitionBlock();

    ProcedureDefinition main_definition =
      basic_of.createProcedureDefinition(main_symbol, 
					 main_body,
					 main_symbol_table,
					 main_def_block);

    ParameterSymbol argc_symbol =
      basic_of.createParameterSymbol(q_argc_type, "argc", true);

    main_definition.getSymbolTable().addSymbol(argc_symbol);
    main_definition.appendFormalParameter(argc_symbol);

    ParameterSymbol argv_symbol =
      basic_of.createParameterSymbol(q_argv_type, "argv", false);

    main_definition.getSymbolTable().addSymbol(argv_symbol);
    main_definition.appendFormalParameter(argv_symbol);

    List arg_list = new List();
    arg_list.pushBack(q_char_ptr_type);
    
    CProcedureType printf_type =
      tb.getCProcedureType(int_type, arg_list, false, true, SizeOf.INT*8);

    ProcedureSymbol printf_symbol =
      basic_of.createProcedureSymbol(printf_type, "printf", true, null);

    the_file_set_block.getExternalSymbolTable().addSymbol(printf_symbol);

    FloatingPointType fpt = tb.getFloatingPointType(new IInteger(64), 64);
    QualifiedType q_fpt = tb.getQualifiedType(fpt);

    VariableSymbol float_literal_symbol =
      basic_of.createVariableSymbol(q_fpt, "", true);
    
    MultiValueBlock float_literal_initialization =
      suif_of.createMultiValueBlock(fpt);

    FloatConstant fc = basic_of.createFloatConstant(fpt, "7.0");
    ExpressionValueBlock evb = suif_of.createExpressionValueBlock(fc);

    float_literal_initialization.addSubBlock(new IInteger(0), evb);

    VariableDefinition float_literal_definition =
      basic_of.createVariableDefinition(float_literal_symbol, SizeOf.FLOAT*8,
					float_literal_initialization, true);

    main_definition.getDefinitionBlock().
      appendVariableDefinition(float_literal_definition);

    Expression i0 = basic_of.createIntConstant(int_type, new IInteger(0));
    Expression i1 = basic_of.createIntConstant(int_type, new IInteger(_LEN));

    ArrayType string_literal_type =
      tb.getArrayType(new IInteger(_LEN).mul(SizeOf.CHAR),
		      SizeOf.CHAR*8, q_char_type, i0, i1);

    QualifiedType q_string_literal_type =
      tb.getQualifiedType(string_literal_type);

    VariableSymbol string_literal_symbol =
      basic_of.createVariableSymbol(q_string_literal_type, "", true);

    main_definition.getSymbolTable().
      appendSymbolTableObject(string_literal_symbol);

    MultiValueBlock string_literal_initialization = 
      suif_of.createMultiValueBlock(string_literal_type);

    for (int n = 0; n < _LEN; n ++)
      {
	IntConstant c = 
	  basic_of.createIntConstant(char_type, new IInteger(_STR.charAt(n)));

	ExpressionValueBlock e =
	  suif_of.createExpressionValueBlock(c);

	string_literal_initialization.addSubBlock(new IInteger(n), e);
      }

    VariableDefinition string_literal_definition =
      basic_of.createVariableDefinition(string_literal_symbol, SizeOf.CHAR*8,
					string_literal_initialization, true);

    main_definition.getDefinitionBlock().
      appendVariableDefinition(string_literal_definition);

    Expression printf_address_op =
      suif_of.createSymbolAddressExpression(tb.getPointerType(printf_type),
					    printf_symbol);

    Expression printf_argument_op =
      suif_of.createSymbolAddressExpression(char_ptr_type, 
					    string_literal_symbol);

    CallStatement printf_call =
      suif_of.createCallStatement(null, printf_address_op);
    
    printf_call.appendArgument(printf_argument_op);

    main_body.appendStatement(printf_call);

    the_file_block.getDefinitionBlock().
      appendProcedureDefinition(main_definition);

    suif.setFileSetBlock(the_file_set_block);
    
    FormattedText fd = new FormattedText();
    the_file_set_block.print(fd);
    System.out.println(fd.getValue());
  }
}
