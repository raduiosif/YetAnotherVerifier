import yav.jsuif.common.*;
import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.nodes.suif.*;


class CascadingMapSample
{
  public static void main(String[] args)
  {
    SuifEnv suif = new SuifEnv();

    suif.init();
    BasicModule.init(suif);
    SuifModule.init(suif);

    BasicObjectFactory basic_of =
      (BasicObjectFactory) suif.getObjectFactory("BasicObjectFactory");
    Assert.condition(basic_of != null);

    SuifObjectFactory suif_of =
      (SuifObjectFactory) suif.getObjectFactory("SuifObjectFactory");
    Assert.condition(suif_of != null);

    CascadingMap map = new CascadingMap(suif);
    String info1 = "procedure";
    String info2 = "statement";
   
    map.assign(ProcedureDefinition.getClassName(), info1);
    map.assign(Statement.getClassName(), info2);

    SuifObject so1 = basic_of.createProcedureDefinition(null, null, null, null);
    SuifObject so2 = suif_of.createCallStatement(null, null);

    System.out.println(map.lookup(so1));
    System.out.println(map.lookup(so2));
  }
}
