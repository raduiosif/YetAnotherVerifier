import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.common.Assert;


class MyVisitorInfo 
{
  static void doStaticProcedureDefinition(MyVisitorInfo info,
					  ProcedureDefinition obj) 
  {
    info.doProcedureDefinition(obj);
  }
  
  void doProcedureDefinition(ProcedureDefinition proc_def) 
  {
    System.out.println("PROCEDURE DEFINITION");
  }
}


class VisitorMapSample
{
  public static void main(String[] args)
  {
    SuifEnv suif = new SuifEnv();

    suif.init();
    BasicModule.init(suif);

    BasicObjectFactory basic_of =
      (BasicObjectFactory) suif.getObjectFactory("BasicObjectFactory");
    Assert.condition(basic_of != null);

    VisitorMap map = new VisitorMap(suif);
    MyVisitorInfo info = new MyVisitorInfo();
    map.registerVisitMethod(info, 
			    new VisitMethod() {
      public void invoke(Object state, 
			 SuifObject object) {
	MyVisitorInfo.doStaticProcedureDefinition((MyVisitorInfo) state, 
						  (ProcedureDefinition) object);
      }
    },
      ProcedureDefinition.getClassName());

    SuifObject so = basic_of.createProcedureDefinition(null, null, null, null);
    map.apply(so);
  }
}
