import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;


class ProcedureSymbolSelectiveWalker extends SelectiveWalker
{
  public ProcedureSymbolSelectiveWalker(SuifEnv suif)
  {
    super(suif, ProcedureSymbol.getClassName());
  }

  public int apply(SuifObject x)
  {
    System.out.println("PROCEDURE [" + ((Symbol) x).getName() + "]");
    return CONTINUE;
  }
}


class VariableSymbolSelectiveWalker extends SelectiveWalker
{
  public VariableSymbolSelectiveWalker(SuifEnv suif)
  {
    super(suif, VariableSymbol.getClassName());
  }

  public int apply(SuifObject x)
  {
    System.out.println("VARIABLE [" + ((Symbol) x).getName() + "]");
    return CONTINUE;
  }
}


class SymbolGroupWalker extends GroupWalker
{
  public SymbolGroupWalker(SuifEnv suif)
  {
    super(suif);

    appendWalker(new ProcedureSymbolSelectiveWalker(suif));
    appendWalker(new VariableSymbolSelectiveWalker(suif));
  }
}


public class GroupWalkerSample
{
  public static void main(String[] args)
  {
    if (args.length != 1)
      {
	System.out.println("Usage: java GroupWalkerSample file-name");
	return;
      }

    SuifEnv suif = new SuifEnv();

    suif.init();
    suif.read(args[0]);

    FileSetBlock fsb = suif.getFileSetBlock();
    SuifWalker w = new SymbolGroupWalker(suif);

    fsb.walk(w);
  }
}
