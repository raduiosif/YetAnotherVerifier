import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;


class SymbolSelectiveWalker extends SelectiveWalker
{
  public SymbolSelectiveWalker(SuifEnv suif) 
  { 
    super(suif, Symbol.getClassName()); 
  }
  
  public int apply(SuifObject x)
  {
    System.out.println("[" + ((Symbol) x).getName() + "]");
    return CONTINUE;
  }
}


public class SelectiveWalkerSample
{
  public static void main(String[] args)
  {
    if (args.length != 1)
      {
	System.out.println("Usage: java SelectiveWalkerSample file-name");
	return;
      }

    SuifEnv suif = new SuifEnv();

    suif.init();
    suif.read(args[0]);

    FileSetBlock fsb = suif.getFileSetBlock();
    SuifWalker w = new SymbolSelectiveWalker(suif);

    fsb.walk(w);
  }
}
