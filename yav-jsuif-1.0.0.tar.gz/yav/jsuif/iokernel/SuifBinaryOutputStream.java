/*
 * SuifBinaryOutputStream.java - A port of basesuif/iokernel/binary_streams.h
 *                               to Java.
 *
 */

package yav.jsuif.iokernel;

import java.io.OutputStream;
import java.io.IOException;


public class SuifBinaryOutputStream extends SuifOutputStream
{
  private OutputStream _output_stream;

  public SuifBinaryOutputStream(OutputStream o) { _output_stream = o; }

  public void writeByte(int b)
  {
    try {
      _output_stream.write(b);
    } catch (IOException e) { 
      throw new RuntimeException(e.getMessage());
    }

    _bytes_written ++;
  }
}
