/*
 * IIntegerMetaClass.java - A port of basesuif/iokernel/i_integer_meta_class.h
 *                          to Java
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.IInteger;
import yav.jsuif.ionative.SizeOf;
import yav.jsuif.ionative.AlignmentOf;


public class IIntegerMetaClass extends MetaClass
{
  private static final int BITSPERBYTE = 8;

  private static final int LONG_IINT_BIT = 1 << (BITSPERBYTE-1);
  private static final int STRING_IINT_BIT = 1 << (BITSPERBYTE-2);
  private static final int LONG_STRING_IINT_BIT = 1 << (BITSPERBYTE-3);
  private static final int LONG_IINT_SIGN_BIT = 1 << (BITSPERBYTE-3);

  private static final int SHORT_IINT_LENGTH_MASK = (1 << (BITSPERBYTE-1)) - 1;
  private static final int STRING_LENGTH_MASK = 1 << (BITSPERBYTE-3) - 1;
  private static final int LONG_IINT_LENGTH_MASK = 1 << (BITSPERBYTE-3) - 1;

  private static final int BYTE_MASK = (1<< (BITSPERBYTE)) - 1;
  private static final int SIGNED_BYTE_FILL = (1<<(BITSPERBYTE)) - 1;
  private static final int IS_BYTE_SIGNED_BIT = 1 << (BITSPERBYTE-1);


  private static final String _className = "IIntegerMetaClass";
  
  public static String getClassName() { return _className; }

  public void write(ObjectWrapper obj, OutputStreamer stream)
  { 
    Assert.condition(obj.getMetaClass() == this);
    Object instance = obj.get();
    IInteger iint = (IInteger) instance;

    if (iint.isCLong()) {
      long val = iint.cLong();
      if ((val & SHORT_IINT_LENGTH_MASK) == val)
	{
	  stream.writeByte((int) val);
	  return;
	}

      boolean is_signed = val < 0;
      int num_bytes = 0;
      long final_val = is_signed ? -1 : 0;
      for (long val_copy = val; val_copy != final_val;
	   num_bytes ++, val_copy >>= BITSPERBYTE);

      Assert.condition(num_bytes <= SizeOf.LONG);
      if ((num_bytes & LONG_IINT_LENGTH_MASK) == num_bytes)
	{
	  int length_encode = num_bytes | LONG_IINT_BIT;
	  if (is_signed)
	    {
	      length_encode |= LONG_IINT_SIGN_BIT;
	    }
	  
	  stream.writeByte(length_encode);
	  for (int i = 0; i < num_bytes; i ++)
	    {
	      long bval = BYTE_MASK & (val >> ((num_bytes-i-1)*BITSPERBYTE));
	      stream.writeByte((int) bval);
	    }

	  return;
	}
    }

    String str = iint.write(10);
    int len = str.length();
    if ((len & STRING_LENGTH_MASK) == len)
      {
	int length_encode = len | LONG_IINT_BIT | STRING_IINT_BIT;
	stream.writeByte(length_encode);
      }
    else
      {
	int code = LONG_IINT_BIT | STRING_IINT_BIT | LONG_STRING_IINT_BIT;
	stream.writeByte(code);
	stream.writeUnsignedInt(len);
      }
    
    byte[] bv = str.getBytes();
    int[] iv = new int[bv.length];
    for (int i = 0; i < bv.length; i ++, iv[i] = bv[i]);
    stream.writeByteArray(iv, len);
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    
    int b = stream.readByte();
    if ((b & LONG_IINT_BIT) == 0)
      {
	obj.set(new IInteger(b));
	return;
      }

    if ((b & STRING_IINT_BIT) == 0)
      {
	boolean is_signed = (b & LONG_IINT_SIGN_BIT) != 0;
	int num_bytes = b & LONG_IINT_LENGTH_MASK;
	if (num_bytes > SizeOf.LONG)
	  {
	    IInteger new_val = is_signed ? new IInteger(-1) : new IInteger(0);
	    for (int i = 0; i < num_bytes; i ++)
	      {
		int next_b = stream.readByte();
		new_val = new_val.shl(BITSPERBYTE);
		new_val = new_val.or(next_b);
	      }

	    obj.set(new_val);
	    return;
	  }
	else
	  {
	    long new_val = is_signed ? -1 : 0;
	    for (int i = 0; i < num_bytes; i ++)
	      {
		int next_b = stream.readByte();
		new_val = new_val << BITSPERBYTE;
		new_val |= next_b;
	      }

	    obj.set(new IInteger(new_val));
	    return;
	  }
      }

    int len;
    if ((b & LONG_STRING_IINT_BIT) == 0)
      {
	len = b & STRING_LENGTH_MASK;
      }
    else
      {
	len = stream.readUnsignedInt();
      }

    int[] iv = new int[len + 1];
    stream.readByteArray(iv, len);
    char[] cv = new char[iv.length];
    for (int i = 0; i < iv.length; i ++, cv[i] = (char) iv[i]);
    obj.set(new IInteger(cv));
  }

  public int walk(Object address, Walker walk)
  {
    return Walker.CONTINUE;
  }


  public IIntegerMetaClass() { this(""); }
  
  public IIntegerMetaClass(String metaClassName)
  {
    super(metaClassName);

    _size = SizeOf.I_INTEGER;
    setAlignment(AlignmentOf.I_INTEGER);
  }
}
