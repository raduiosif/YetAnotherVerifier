/*
 * TypeLessSTLDescriptor.java - A port of basesuif/iokernel/stl_meta_class.h 
 *                              to Java.
 *
 */

package yav.jsuif.iokernel;


abstract class TypeLessSTLDescriptor
{
  protected MetaClass _element_meta_class;

  public MetaClass getElementMetaClass() { return _element_meta_class; }

  protected int _size;

  public int getSizeOfInstance() { return _size; }

  public abstract Iterator getIterator(Object address);

  
  protected TypeLessSTLDescriptor(MetaClass element_meta_class, int size)
  {
    _element_meta_class = element_meta_class;
    _size = size;
  }
}
