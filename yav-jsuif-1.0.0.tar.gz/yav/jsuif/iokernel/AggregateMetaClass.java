/*
 * AggregateMetaClass.java - A port of basesuif/iokernel/aggregate_meta_class.h
 *                           to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.PString;
import yav.jsuif.common.Vector;
import yav.jsuif.common.Map;


class LocalAggregateIterator extends Iterator
{
  private int _current_index;
  private boolean _is_valid;
  private Object _address;
  private AggregateMetaClass _meta_class;
  

  protected LocalAggregateIterator()
  {
    _current_index = 0;
    _is_valid = false;
    _address = null;
    _meta_class = null;
  }

  public LocalAggregateIterator(LocalAggregateIterator other)
  {
    _current_index = other._current_index;
    _is_valid = other._is_valid;
    _address = other._address;
    _meta_class = other._meta_class;
  }


  public static LocalAggregateIterator create(Object address, 
					      AggregateMetaClass mc)
  {
    LocalAggregateIterator it = new LocalAggregateIterator();
    it._address = address;
    it._meta_class = mc;
    it.first();
    return it;
  }

  public MetaClass currentMetaClass()
  {
    if (!_is_valid)
      {
	return null;
      }

    FieldDescription fd = 
      (FieldDescription) _meta_class._fields.at(_current_index);

    return fd.getMemberMetaClass();
  }

  public String currentName()
  {
    if (!_is_valid)
      {
	return null;
      }

    FieldDescription fd = 
      (FieldDescription) _meta_class._fields.at(_current_index);

    return fd.getMemberName();
  }

  public Object current()
  {
    if (!_is_valid)
      {
	return null;
      }

    FieldDescription fd = 
      (FieldDescription) _meta_class._fields.at(_current_index);
    AggregateWrapper agg_obj = new AggregateWrapper(_address, _meta_class);
    ObjectWrapper obj = fd.buildObject(agg_obj);
    
    return obj.get();
  }

  public void setCurrent(Object x)
  {
    if (!_is_valid)
      {
	return;
      }

    FieldDescription fd = 
      (FieldDescription) _meta_class._fields.at(_current_index);
    AggregateWrapper agg_obj = new AggregateWrapper(_address, _meta_class);
    ObjectWrapper obj = fd.buildObject(agg_obj);
    
    obj.set(x);
  }

  public boolean isValid() { return _is_valid; }

  public void next()
  {
    if (!_is_valid)
      {
	return;
      }

    _current_index ++;
    _is_valid = _current_index < _meta_class._fields.length();
  }

  public void previous()
  {
    if (!_is_valid)
      {
	return;
      }

    _current_index --;
    _is_valid = (_current_index >= 0) && (_meta_class._fields.length() > 0);
  }

  public void first()
  {
    _current_index = 0;
    _is_valid = _meta_class._fields.length() > 0;
  }

  public int length() { return _meta_class._fields.length(); }

  public Object clone() { return new LocalAggregateIterator(this); }
}


class AggregateIterator extends Iterator
{
  private Object _address;
  private AggregateMetaClass _start_meta_class;
  private Vector _base_types;
  private int _start_offset;
  private int _end_offset;
  private int _current_class_index;
  private int _current_field_index;
  private boolean _is_valid;
  private Iterator _current_iterator;
  

  public AggregateIterator(Object address,
			   Vector base_types)
  {
    _address = address;
    _start_meta_class = null;
    _base_types = base_types;
    _start_offset = 0;
    _end_offset = 0;
    _current_class_index = 0;
    _current_field_index = 0;
    _is_valid = false;
    _current_iterator = null;
  }

  public AggregateIterator(AggregateIterator other)
  {
    _address = other._address;
    _start_meta_class = other._start_meta_class;
    _base_types = other._base_types;
    _start_offset = other._start_offset;
    _current_class_index = other._current_class_index;
    _current_field_index = other._current_field_index;
    _is_valid = other._is_valid;
    _current_iterator = (Iterator) other._current_iterator.clone();
  }


  public static AggregateIterator create(Object address,
					 Vector base_types,
					 MetaClass start_class,
					 MetaClass end_class)
  {
    int i;
    AggregateIterator it = new AggregateIterator(address, base_types);
    // adjust _start_offset
    if (start_class != null)
      {
	for (i = 0; i < it._base_types.length(); i ++)
	  {
	    if (start_class == (MetaClass) it._base_types.at(i))
	      {
		it._start_offset = i;
		break;
	      }
	  }

	Assert.condition(i != it._base_types.length());
      }

    it._end_offset = it._base_types.length() - 1;
    // adjust _end_offset
    if (end_class != null)
      {
	for (i = 0; i < it._base_types.length(); i ++)
	  {
	    if (end_class == (MetaClass) it._base_types.at(i))
	      {
		it._end_offset = i;
		break;
	      }
	  }

	Assert.condition(i != it._base_types.length());
      }

    it.first();
    return it;
  }

  public MetaClass currentMetaClass()
  {
    return _is_valid ? _current_iterator.currentMetaClass() : null;
  }

  public String currentName()
  {
    return _is_valid ? _current_iterator.currentName() : null;
  }

  public Object current()
  {
    return _is_valid ? _current_iterator.current() : null;
  }

  public void setCurrent(Object x)
  {
    if (_is_valid)
      {
	_current_iterator.setCurrent(x);
      }
  }

  public boolean isValid() { return _is_valid; }

  public void next()
  {
    AggregateMetaClass mc;
    if (!_is_valid)
      {
	return;
      }

    _current_iterator.next();
    _is_valid = _current_iterator.isValid();
    if (!_is_valid)
      {
	_current_iterator = null;
	while (!_is_valid && _current_class_index < _end_offset)
	  {
	    _current_class_index ++;
	    mc = (AggregateMetaClass) _base_types.at(_current_class_index);
	    _current_iterator = mc.getLocalIterator(_address);
	    _is_valid = _current_iterator.isValid();
	  }
      }
  }

  public void previous() { Assert.fatal(); }

  public void first()
  {
    AggregateMetaClass mc;

    _is_valid = _address != null;
    if (!_is_valid)
      {
	return;
      }

    _is_valid = false;
    _current_class_index = _start_offset - 1; 
    while (!_is_valid && _current_class_index < _end_offset)
      {
	_current_class_index ++;
	mc = (AggregateMetaClass) _base_types.at(_current_class_index);
	_current_iterator = mc.getLocalIterator(_address);
	_is_valid = _current_iterator.isValid();	
      }
  }

  public Object clone() { return new AggregateIterator(this); }
}


public class AggregateMetaClass extends MetaClass
{
  private static final String _className = "AggregateMetaClass";

  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public AggregateMetaClass _base_class;

  public static native int get__base_class_offset();

  // FieldDescription.buildObject() needs public access to this field
  public Vector _fields;

  public static native int get__fields_offset();

  protected Vector _base_types;
  protected int _number_of_base_classes;
  protected Map _virtual_nodes;

  // FieldDescription.buildObject() needs public access to this field
  public Map _virtual_field_description;

  public static native int get__virtual_field_description_offset();

  static {
    System.loadLibrary("jsuif");
  }


  public AggregateMetaClass() { this(""); }

  public AggregateMetaClass(String metaClassName)
  {
    super(metaClassName);

    _base_class = null;
    _fields = new Vector();
    _base_types = null;
    _number_of_base_classes = 0;
    _virtual_nodes = null;
    _virtual_field_description = new Map();
  }

  protected AggregateMetaClass(AggregateMetaClass other)
  {
    super(other.getInstanceName());

    _base_class = other._base_class;
    _fields = other._fields;
    _base_types = other._base_types;
    _number_of_base_classes = other._number_of_base_classes;
    _virtual_nodes = other._virtual_nodes;
    _virtual_field_description = other._virtual_field_description;
  }


  /**
   * Create and add a new field description.
   * @param name field name 
   * @param metaClass field meta class
   * @param offset field offset
   */
  public FieldDescription addFieldDescription(String name,
					      MetaClass metaClass,
					      MetaClass fieldType,
					      int offset)
  {
    FieldDescription field = new FieldDescription(offset, fieldType, name);
    field.setMetaClass(metaClass);
    _fields.pushBack(field);
    return field;
  }

  /**
   * Returns the number of fields.
   */
  public int getFieldCount()
  {
    int count = _fields.length();
    if (_base_class != null)
      {
	count += _base_class.getFieldCount();
      }

    return count;
  }

  /**
   * Search field description by name.
   * Returns null if none was found.
   * @param name field name
   */
  public FieldDescription getFieldDescription(String name)
  {
    Vector.Iterator current = _fields.begin();
    Vector.Iterator end = _fields.end();

    for (; current.notEqual(end); current.inc())
      {
	if (((FieldDescription) current.get()).getMemberName().equals(name))
	  {
	    return (FieldDescription) current.get();
	  }
      }

    if (_base_class != null)
      {
	return _base_class.getFieldDescription(name);
      }

    return null;
  }

  /**
   * Returns the field in position.
   * @param i field position
   */
  public FieldDescription getFieldDescription(int i)
  {
    if (i < 0)
      {
	return null;
      }

    if (i < _fields.length())
      {
	return (FieldDescription) _fields.at(i);
      }

    if (_base_class != null)
      {
	return _base_class.getFieldDescription(i - _fields.length());
      }

    return null;
  }

  /**
   * Set up the base class.
   * @param metaClass base class
   */
  public void inheritsFrom(AggregateMetaClass metaClass)
  {
    _base_class = metaClass;
  }

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    
//      System.out.println("BEGIN WRITING: " + getInstanceName());

    if (_base_class != null)
      {
	ObjectWrapper base_obj = new ObjectWrapper(obj);
	base_obj.setMetaClass(_base_class);
	_base_class.write(base_obj, stream);
      }

    Vector.Iterator current = _fields.begin();
    Vector.Iterator end = _fields.end();
    FieldDescription fieldDescription;
    while (current.notEqual(end))
      {
	fieldDescription = (FieldDescription) current.get();
	ObjectWrapper field = fieldDescription.buildObject(obj);

//    	System.out.println("FIELD: " + getInstanceName() + "."
//    			   + fieldDescription.getMemberName() + " "
//  			   + fieldDescription.getMemberMetaClass().getInstanceName());
	
	stream.write(field, false);
	current.inc();
      }

//      System.out.println("END WRITING: " + getInstanceName());
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

//      System.out.println("BEGIN READING: " + getInstanceName());

    if (_base_class != null)
      {
	ObjectWrapper base_obj = new ObjectWrapper(obj);
	base_obj.setMetaClass(_base_class);
	_base_class.read(base_obj, stream);
      }

    Vector.Iterator current = _fields.begin();
    Vector.Iterator end = _fields.end();
    FieldDescription fieldDescription;
    while (current.notEqual(end))
      {
	fieldDescription = (FieldDescription) current.get();
	ObjectWrapper field = fieldDescription.buildObject(obj);

//  	System.out.println("FIELD: " + getInstanceName() + "."
//    			   + fieldDescription.getMemberName() + " "
//  			   + fieldDescription.getMemberMetaClass().getInstanceName());

	stream.read(field, false);
	current.inc();
      }

//      System.out.println("END READING: " + getInstanceName());
  }

  public Iterator getIterator(Object instance) 
  { 
    return getIterator(instance, Iterator.ALL);
  }

  public Iterator getIterator(Object instance, int contents)
  {
    if (contents != Iterator.REFERENCED)
      {
	return getAggregateIterator(instance);
      }

    return null;
  }

  public Iterator getAggregateIterator(Object instance, 
				       String startClass)
  {
    return getAggregateIterator(instance, startClass, null);
  }

  public Iterator getAggregateIterator(Object instance,
				       String startClass,
				       String endClass)
  {
    MetaClass startMeta = null;
    MetaClass endMeta = null;

    if (startClass != null)
      {
	startMeta = _owning_factory.findMetaClass(startClass);
      }

    if (endClass != null)
      {
	endMeta = _owning_factory.findMetaClass(endClass);
      }

    return getAggregateIterator(instance, startMeta, endMeta);
  }

  public Iterator getAggregateIterator(Object instance)
  {
    return getAggregateIterator(instance, (MetaClass) null, (MetaClass) null);
  }

  public Iterator getAggregateIterator(Object instance,
				       MetaClass startClass)
  {
    return getAggregateIterator(instance, startClass, (MetaClass) null);
  }

  public Iterator getAggregateIterator(Object instance,
				       MetaClass start_class,
				       MetaClass end_class)
  {
    initializeBaseTypes();
    return AggregateIterator.create(instance, _base_types, 
				    start_class, end_class);
  }

  public Iterator getLocalIterator(Object instance)
  {
    return LocalAggregateIterator.create(instance, this);
  }

  public boolean isElementary() { return false; }

  public void initialize(ObjectWrapper obj, SuifInputStream stream)
  {
    Assert.condition(obj.getMetaClass() == this);

//      System.out.println("BEGIN INIT: " + getInstanceName());

    if (_base_class != null)
      {
	ObjectWrapper base_obj = new ObjectWrapper(obj);
	base_obj.setMetaClass(_base_class);
	_base_class.initialize(base_obj, stream);
      }

    Vector.Iterator current = _fields.begin();
    Vector.Iterator end = _fields.end();
    FieldDescription fieldDescription;
    for (; current.notEqual(end); current.inc())
      {
	fieldDescription = (FieldDescription) current.get();
	ObjectWrapper field = fieldDescription.buildObject(obj);

//  	System.out.println("FIELD: " + getInstanceName() + "."
//  			   + fieldDescription.getMemberName() + " "
//  			   + fieldDescription.getMemberMetaClass().getInstanceName());

	field.initialize(stream);
      }

//      System.out.println("END INIT: " + getInstanceName());
  }

  public MetaClass getLinkMetaClass() { return _base_class; }
  public AggregateMetaClass getBaseClass() { return _base_class; }

  public void addVirtualField(String name, String description)
  {
    if (_virtual_nodes == null)
      {
	initVirtualNodes();
      }

    _virtual_field_description.enterValueAt(name, description);
    VirtualNode node = getVirtualNode(name, description);
    _virtual_nodes.enterValueAt(name, node);
  }

  public Iterator getVirtualIterator(Object address, String name)
  {
    VirtualNode node = null;
    for (AggregateMetaClass m = this; m != null; m = m._base_class)
      {
	Map virtual_nodes = m._virtual_nodes;
	if (virtual_nodes == null)
	  {
	    m.initVirtualNodes();
	    virtual_nodes = m._virtual_nodes;
	  }

	Map.Iterator iter = virtual_nodes.find(name);
	if (iter.notEqual(virtual_nodes.end()))
	  {
	    node = (VirtualNode) iter.get().second;
	    break;
	  }
      }

    return new VirtualIterator(address, node);
  }
  
  public VirtualNode getVirtualNode(String name, String what)
  {
    if (what.length() == 0)
      {
	return null;
      }

    Vector members = new Vector();
    PString spec = new PString(what);
    String current_element;
    while (spec.get().length() != 0)
      {
	current_element = cutOff(spec, ';');
	if (current_element.equals("^"))
	  {
	    for (AggregateMetaClass m = _base_class; 
		 m != null; m = m._base_class)
	      {
		Map virtual_nodes = m._virtual_nodes;
		if (virtual_nodes == null)
		  {
		    m.initVirtualNodes();
		    virtual_nodes = m._virtual_nodes;
		  }

		Map.Iterator iter = virtual_nodes.find(name);
		if (iter.notEqual(virtual_nodes.end()))
		  {
		    AggregateElement element = 
		      new AggregateElement(null, "",
					   (VirtualNode) iter.get().second,
					   false);

		    members.pushBack(element);
		    break;
		  }
	      }
	    
	    continue;
	  }

	PString pcurrent = new PString(current_element);
	String current_member = cutOff(pcurrent, '/');
	FieldDescription field = getFieldDescription(current_member);
	VirtualNode continuation = null;
	if (pcurrent.get().length() != 0)
	  {
	    continuation = 
	      field.getMemberMetaClass().getVirtualNode(name, pcurrent.get()); 
	  }

	members.pushBack(new AggregateElement(field, continuation, true));
      }

    return new AggregateVirtualNode(members);
  }

  public int walk(Object address, Walker w)
  {
    Object instance = address;
    int status = Walker.CONTINUE;
    if (w.getIsPreOrder() && w.isVisitable(address, this))
      {
	w.setAddress(null);
	int s = w.apply(instance, this); 
	switch(s)
	  {
	  case Walker.CONTINUE: 
	    break;

	  case Walker.STOP:
	  case Walker.ABORT:
	    return s;

	  case Walker.TRUNCATE:
	    return Walker.CONTINUE;

	  case Walker.REPLACED:
	    instance = w.getAddress();
	    Assert.condition(instance != null);
	    break;
	  }
      }

    status = walkFields(address, w);
    switch (status)
      {
      case Walker.CONTINUE:
	break;

      case Walker.STOP:
      case Walker.ABORT:
	return status;

      case Walker.TRUNCATE:
	return Walker.CONTINUE;

      case Walker.REPLACED:
	Assert.fatal();
	break;
      }

    if (!w.getIsPreOrder() && w.isVisitable(address, this))
      {
	return w.apply(instance, this);
      }

    return status;
  }

  protected int walkFields(Object address, Walker w)
  {
    AggregateMetaClass current = this;
    AggregateWrapper agg_obj = new AggregateWrapper(address, current);
    while (current != null)
      {
	Vector.Iterator it = current._fields.begin();
	Vector.Iterator end = current._fields.end();
	while (it.notEqual(end))
	  {
	    FieldDescription field = (FieldDescription) it.get();
	    Object old_parent = w.getParent();

	    w.setParent(address);
	    ObjectWrapper obj = field.buildObject(agg_obj);
	    int status = field.getMemberMetaClass().walk(obj.get(), w);
	    w.setParent(old_parent);

	    switch (status)
	      {
	      case Walker.CONTINUE:
		break;

	      case Walker.STOP:
	      case Walker.ABORT:
		return status;

	      case Walker.TRUNCATE:
		return Walker.CONTINUE;
		
	      case Walker.REPLACED:
		Assert.fatal();
		break;
	      }

	    it.inc();
	  }

	current = current.getBaseClass();
      }

    return Walker.CONTINUE;
  }

  public void walkReferencedMetaClasses(MetaClassApplier x)
  {
    if (_base_class != null)
      {
	x.apply(_base_class);
      }

    Vector.Iterator it = _fields.begin();
    Vector.Iterator end = _fields.end();
    FieldDescription fieldDescription;
    for (; it.notEqual(end); it.inc())
      {
	fieldDescription = (FieldDescription) it.get();
	MetaClass currentType = fieldDescription.getMemberMetaClass();
	x.apply(currentType);
      }
  }

  protected void initVirtualNodes()
  {
    Assert.condition(_virtual_nodes == null);

    _virtual_nodes = new Map();
    Map.Iterator current = _virtual_field_description.begin();
    Map.Iterator end = _virtual_field_description.end();
    while (current.notEqual(end))
      {
	addVirtualField((String) current.get().first,
			(String) current.get().second);
	current.inc();
      }
  }

  protected void initializeBaseTypes()
  {
    if (_base_types == null)
      {
	_base_types = new Vector();
	Vector temp = new Vector();
	AggregateMetaClass current = this;
	while (current != null)
	  {
	    temp.pushBack(current);
	    current = current._base_class;
	  }

	for (int i = temp.length(); i != 0; i --)
	  {
	    _base_types.pushBack(temp.at(i - 1));
	  }

	_number_of_base_classes = _base_types.length();
      }
  }
}
