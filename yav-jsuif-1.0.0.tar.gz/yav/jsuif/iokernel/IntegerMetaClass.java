/*
 * IntegerMetaClass.java - A port of basesuif/iokernel/integer_meta_class.h
 *                         to Java
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class IntegerMetaClass extends MetaClass
{
  private static final String _className = "IntegerMetaClass";
  
  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public boolean _is_signed;

  protected boolean isSigned() { return _is_signed; }
  public void setIsSigned(boolean is_signed) { _is_signed = is_signed; }
  public static native int get__is_signed_offset();

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    
    int value = ((Integer) obj.get()).intValue();
    stream.writeSizedInt(value, getSizeOfInstance(), isSigned());
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    int value = stream.readSizedInt(getSizeOfInstance(), isSigned());
    obj.set(new Integer(value));
  }

  public int walk(Object address, Walker walk)
  {
    return Walker.CONTINUE;
  }

  static {
    System.loadLibrary("jsuif");
  }


  protected IntegerMetaClass() { this(""); }

  protected IntegerMetaClass(String metaClassName)
  {
    super(metaClassName);

    _is_signed = false;
  }
}
