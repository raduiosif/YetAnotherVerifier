/*
 * EmptyIterator.java - A port of basesuif/iokernel/meta_class_iter.h to Java.
 *
 */

package yav.jsuif.iokernel;


class EmptyIterator extends Iterator
{
  public MetaClass currentMetaClass() { return null; }
  public String currentName() { return ""; }
  public Object current() { return null; }
  public void setCurrent(Object x) {}
  public boolean isValid() { return false; }

  public void next() {}
  public void previous() {}
  public void first() {}
  public int length() { return 0; }
}
