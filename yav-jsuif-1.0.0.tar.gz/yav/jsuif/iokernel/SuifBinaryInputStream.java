/*
 * SuifBinaryInputStream.java - A port of basesuif/iokernel/binary_streams.h
 *                              to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import java.io.InputStream;
import java.io.IOException;


public class SuifBinaryInputStream extends SuifInputStream
{
  private InputStream _input_stream;

  public SuifBinaryInputStream(ObjectFactory of, InputStream i)
  {
    super(of);
    _input_stream = i;
  }

  public int readByte()
  {
    int b;

    try {
      b = _input_stream.read();
    } catch(IOException e) {
      throw new RuntimeException(e.getMessage());
    }

    // System.out.println("readByte --> " + b);

    Assert.condition(b != -1, "End of file found");
    return b;
  }
}
