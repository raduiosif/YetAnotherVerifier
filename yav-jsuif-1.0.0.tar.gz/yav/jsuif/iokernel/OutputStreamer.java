/*
 * OutputStreamer.java - An OutputStream interface.
 *
 */

package yav.jsuif.iokernel;


public interface OutputStreamer
{
  void writeByte(int b);
  void writeSizedInt(int value, int size, boolean is_signed);
  void writeUnsignedInt(int value);

  void write(ObjectWrapper obj, boolean addressable);
  void writeStaticPointer(PointerWrapper ptr_obj);
  void writeOwningPointer(PointerWrapper ptr_obj);
  void writeDefiningPointer(PointerWrapper ptr_obj);
  void writeReference(PointerWrapper ptr_obj);
  void writeByteArray(int[] start, int len);
}
