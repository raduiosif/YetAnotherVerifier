/*
 * BaseListIterator.java - A port of basesuif/iokernel/list_meta_class.h 
 *                         to Java.
 *  
 */

package yav.jsuif.iokernel;


abstract class BaseListIterator extends Iterator
{
  protected boolean _is_valid;

  public boolean isValid() { return _is_valid; }

  protected MetaClass _element_meta_class;

  public MetaClass currentMetaClass()
  {
    return _is_valid ? _element_meta_class : null;
  }

  public String currentName() { return ""; }

  
  public BaseListIterator(MetaClass element_meta_class)
  {
    _is_valid = false;
    _element_meta_class = element_meta_class;
  }
}
