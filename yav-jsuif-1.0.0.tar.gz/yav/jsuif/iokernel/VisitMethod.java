/*
 * VisitMethod.java
 *
 */

package yav.jsuif.iokernel;


public interface VisitMethod
{
  void invoke(Object state, Object object);
}
