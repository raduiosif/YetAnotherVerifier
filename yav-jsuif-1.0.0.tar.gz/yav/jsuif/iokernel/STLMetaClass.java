/*
 * STLMetaClass.java - A port of basesuif/iokernel/stl_meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.STLType;


public class STLMetaClass extends ListMetaClass
{
  public static String getClassName() { return ListMetaClass.getClassName(); }

  private TypeLessSTLDescriptor _stl_descriptor;

  public void setDescriptor(TypeLessSTLDescriptor stl_descriptor)
  {
    _stl_descriptor = stl_descriptor;
    _element_meta_class = stl_descriptor.getElementMetaClass();    
    setSize(stl_descriptor.getSizeOfInstance());
  }


  public STLMetaClass() { this(""); }

  public STLMetaClass(String metaClassName)
  {
    super(metaClassName);
    _stl_descriptor = null;
  }


  public Object cloneObject(Object address)
  {
    return ((STLType) address).clone();
  }

  public Iterator getIterator(Object instance)
  {
    return getIterator(instance, Iterator.OWNED);
  }

  public Iterator getIterator(Object instance, int contents)
  {
    if ((instance != null) && (contents == Iterator.OWNED))
      {
	return _stl_descriptor.getIterator(instance);
      }

    return null;
  }

  protected void copyOver(Object target, GenericList source)
  {
    Object space[] = source._space;
    Iterator iterator = getIterator(target);
    for (int i = 0; i < source._count; i ++)
      {
	iterator.add(space[i]);
      }
  }
}
