/*
 * CompatibleNames - A global repository of compatible names.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.nodes.basic.BasicObjectFactory;
import yav.jsuif.nodes.suif.SuifObjectFactory;


public class CompatibleNames
{
  private static final HashMap _map = new HashMap();

  public static void addCompatibleName(String suifName, String realName)
  {
    String other = getRealName(suifName);
    if (other != null)
      {
	if (other.equals(realName))
	  {
	    return;
	  }

	Assert.fatal(suifName + " already mapped to " + other);
      }

    _map.enterValueAt(suifName, realName);
  }

  public static String getRealName(String suifName)
  {
    HashMap.Iterator iter = _map.find(suifName);
    if (iter.notEqual(_map.end()))
      {
	return (String) iter.get().second;
      }

    return null;
  }

  static {
    BasicObjectFactory.addCompatibleNames();
    SuifObjectFactory.addCompatibleNames();

    addCompatibleName("AggregateMetaClass::FieldDescription", 
		      "FieldDescription");

    addCompatibleName("VirtualFieldDescription::mapField", 
		      "Map$Pair");

    addCompatibleName("ObjectFactory::mapField", 
		      "HashMap$Pair");
  }
}
