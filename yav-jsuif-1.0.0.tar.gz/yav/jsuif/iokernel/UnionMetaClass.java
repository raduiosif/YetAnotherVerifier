/*
 * UnionMetaClass.java - A port of basesuif/iokernel/union_meta_class.h
 *                       to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;


interface UnionSelector
{
  int invoke(Object address);
}


class UnionIterator extends Iterator
{
  private int _current_field_index;
  private boolean _is_valid;
  private Object _address;
  private UnionMetaClass _meta_class;
  private FieldDescription _current_field_description;

  public static UnionIterator create(Object address, UnionMetaClass mc)
  {
    UnionIterator it = new UnionIterator();
    it._address = address;
    it._meta_class = mc;
    it.first();
    return it;
  }

  public MetaClass currentMetaClass()
  {
    return (_is_valid ? _current_field_description.getMemberMetaClass():null);
  }

  public String currentName()
  {
    return (_is_valid ? _current_field_description.getMemberName() : null);
  }

  public Object current()
  {
    if (!_is_valid)
      {
	return null;
      }

    AggregateWrapper agg_obj = new AggregateWrapper(_address, _meta_class);
    ObjectWrapper obj = _current_field_description.buildObject(agg_obj);
    return obj.get();
  }

  public void setCurrent(Object x)
  {
    if (!_is_valid)
      {
	return;
      }

    AggregateWrapper agg_obj = new AggregateWrapper(_address, _meta_class);
    ObjectWrapper obj = _current_field_description.buildObject(agg_obj);
    obj.set(x);
  }

  public boolean isValid() { return _is_valid; }

  public void next()
  {
    if (!_is_valid) return;

    _current_field_index ++;
    int num_aggregate_fields = _meta_class._fields.length();
    if (_current_field_index < num_aggregate_fields)
      {
	_current_field_description = 
	  (FieldDescription) _meta_class._fields.at(_current_field_index);
      }
    else
      {
	if (_current_field_index == num_aggregate_fields)
	  {
	    int tag = _meta_class.getTagNum(_address);
	    if (tag >= 0)
	      {
		_current_field_description =
		  (FieldDescription) _meta_class.getFields().at(tag);
	      }
	    else
	      {
		_is_valid = false;
	      }
	  }
	else
	  {
	    _is_valid = false;
	  }
      }
  }

  public void previous()
  {
    if (!_is_valid) return;
    Assert.fatal();
  }

  public void first()
  {
    _current_field_index = 0;
    _is_valid = (_meta_class._fields.length() > 0);
    if (_is_valid)
      {
	_current_field_description =
	  (FieldDescription) _meta_class._fields.at(_current_field_index);
      }
    else
      {
	int tag = _meta_class.getTagNum(_address);
	_is_valid = (tag >= 0);
	if (_is_valid)
	  {
	    _current_field_description = 
	      (FieldDescription) _meta_class.getFields().at(tag);
	  }
      }
  }

  public int length()
  {
    int tag = _meta_class.getTagNum(_address);
    return _meta_class._fields.length() + ((tag >= 0) ? 1 : 0);
  }

  public Object clone() { return new UnionIterator(this); }


  protected UnionIterator()
  {
    _current_field_index = 0;
    _is_valid = false;
    _address = null;
    _meta_class = null;
    _current_field_description = null;
  }

  private UnionIterator(UnionIterator other)
  {
    _current_field_index = other._current_field_index;
    _is_valid = other._is_valid;
    _address = other._address;
    _meta_class = other._meta_class;
    _current_field_description = other._current_field_description;
  }
}


public class UnionMetaClass extends AggregateMetaClass
{
  private static String _className = "UnionMetaClass";

  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public Vector _union_fields;

  public Vector getFields() { return _union_fields; }
  public static native int get__union_fields_offset();

  // FieldDescription.buildObject() needs public access to this field
  public int _tag_offset;

  public static native int get__tag_offset_offset();

  private UnionSelector _union_selector;

  static {
    System.loadLibrary("jsuif");
  }


  public UnionMetaClass() { this(""); }

  public UnionMetaClass(String metaClassName)
  {
    super(metaClassName);

    _union_fields = new Vector();
    _tag_offset = -1;
    _union_selector = null;
  }


  public FieldDescription addUnionField(String name, 
					MetaClass metaClass,
					MetaClass fieldType,
					int offset)
  {
    FieldDescription field = new FieldDescription(offset, fieldType, name);
    field.setMetaClass(metaClass);
    _union_fields.pushBack(field);
    return field;
  }

  public void setUnionSelector(UnionSelector union_selector)
  {
    _union_selector = union_selector;
    _tag_offset = -1;
  }

  public void setOffset(int offset)
  {
    _tag_offset = offset;
    _union_selector = null;
  }
  
  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    super.write(obj, stream);
    int index = getTagNum(obj.get());
    if (_tag_offset == -1)
      {
	stream.writeUnsignedInt(index);
      }

    if (index >= 0)
      {
	FieldDescription fd = (FieldDescription) _union_fields.at(index);
	ObjectWrapper field = fd.buildObject(obj);
	stream.write(field, false);
      }
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    super.read(obj, stream);
    int index = 0;
    if (_tag_offset != -1)
      {
	Assert.fatal("TODO");
      }
    else
      {
	index = stream.readUnsignedInt();
      }

    if (index >= 0)
      {
	FieldDescription fd = (FieldDescription) _union_fields.at(index);
	ObjectWrapper field = fd.buildObject(obj);
	stream.read(field, false);
      }
    else
      {
	Assert.fatal("TODO");
      }
  }

  public void initialize(ObjectWrapper obj, SuifInputStream stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    super.initialize(obj, stream);
    int index = getTagNum(obj.get());
    if (index < 0)
      {
	Assert.fatal("TODO");
      }
    else
      {
	FieldDescription fd = (FieldDescription) _union_fields.at(index);
	ObjectWrapper field = fd.buildObject(obj);
	field.initialize(stream);
      }
  }

  public Iterator getLocalIterator(Object instance)
  {
    return UnionIterator.create(instance, this);
  }

  public MetaClass getMetaClass(Object address) { return (MetaClass) this; }
  public void setMetaClassOfObject(Object address) {}
  
  public int walk(Object address, Walker walk)
  {
    AggregateWrapper agg_obj = new AggregateWrapper(address, this);
    super.walkFields(address, walk);
    int index = getTagNum(address);
    if (index == -1)
      {
	return Walker.CONTINUE;
      }

    FieldDescription fd = (FieldDescription) _union_fields.at(index);
    ObjectWrapper obj = fd.buildObject(agg_obj);
    return fd.getMemberMetaClass().walk(obj.get(), walk);
  }

  public int getFieldCount(Object address)
  {
    int index = getTagNum(address);
    int fields = 0;
    if (index >= 0)
      {
	fields ++;
      }
    
    if (_base_class != null)
      {
	fields += _base_class.getFieldCount();
      }

    return fields;
  }

  public FieldDescription getFieldDescription(Object address, int i)
  {
    if (i < 0)
      {
	return null;
      }

    int index = getTagNum(address);
    if (index > 0)
      {
	if (i == 0)
	  {
	    return (FieldDescription) _union_fields.at(index);
	  }

	i --;
      }

    if (_base_class != null)
      {
	return _base_class.getFieldDescription(i);
      }

    return null;
  }

  public FieldDescription getFieldDescription(Object address, String n)
  {
    int i = getTagNum(address);
    if ((i >= 0) && 
	(((FieldDescription) _union_fields.at(i)).getMemberName().equals(n)))
      {
	return (FieldDescription) _union_fields.at(i);
      }

    if (_base_class != null)
      {
	return _base_class.getFieldDescription(n);
      }

    return null;
  }

  public void walkReferencedMetaClasses(MetaClassApplier x)
  {
    super.walkReferencedMetaClasses(x);

    Vector.Iterator it = _union_fields.begin();
    Vector.Iterator end = _union_fields.end();
    FieldDescription fieldDescription;
    for (; it.notEqual(end); it.inc())
      {
	fieldDescription = (FieldDescription) it.get();
	MetaClass currentType = fieldDescription.getMemberMetaClass();
	x.apply(currentType);
      }
  }

  protected int getTagNum(Object instance)
  {
    int index;
    if (_tag_offset != -1)
      {
	index = 0; 
	Assert.fatal("TODO");
      }
    else
      {
	index = _union_selector.invoke(instance);
      }

    return index;
  }
}

