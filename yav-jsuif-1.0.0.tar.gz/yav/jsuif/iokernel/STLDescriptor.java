/*
 * STLDescriptor.java - A port of basesuif/iokernel/stl_meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class STLDescriptor extends TypeLessSTLDescriptor
{
  public STLDescriptor(MetaClass element_meta_class, int size)
  {
    super(element_meta_class, size);
  }

  public Iterator getIterator(Object address)
  {
    return new STLIterator(address, _element_meta_class);
  }
}
