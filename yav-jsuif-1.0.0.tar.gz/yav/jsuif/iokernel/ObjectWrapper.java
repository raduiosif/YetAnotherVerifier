/*
 * ObjectWrapper.java - A port of basesuif/iokernel/object_wrapper.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import java.lang.reflect.Field;
import java.lang.reflect.Array;


public class ObjectWrapper
{
  protected Object _address;

  public Object getAddress() { return _address; }
  public void setAddress(Object address) { _address = address; }

  protected MetaClass _meta_class;

  public MetaClass getMetaClass() { return _meta_class; }
  public void setMetaClass(MetaClass meta_class) { _meta_class = meta_class; }

  protected Field _field;
  protected int _index;

  public Object get()
  {
    if (_index != -1)
      {
	try {
	  return Array.get(_address, _index);
	}
	catch (IllegalArgumentException e)
	  {
	    Assert.fatal(e.getMessage() + ": " + _address);
	  }
	catch (ArrayIndexOutOfBoundsException e)
	  {
	    Assert.fatal(e.getMessage() + ": " + _index);
	  }
      }

    if (_field != null)
      {
	try {
	  // return value is automatically wrapped if field is primitive
	  return _field.get(_address);
	}
	catch (IllegalArgumentException e) 
	  {
	    Assert.fatal(e.getMessage() + ": " + _address + " " 
			 + _field.getDeclaringClass().getName());
	  }
	catch (IllegalAccessException e) 
	  { 
	    Assert.fatal(e.getMessage()); 
	  }
      }

    return _address;
  }

  public void set(Object value)
  {
    if (_index != -1)
      {
	try {
	  Array.set(_address, _index, value);
	  return;
	}
	catch (IllegalArgumentException e)
	  {
	    Assert.fatal(e.getMessage() + ": " + _address + " given " + value);
	  }
	catch (ArrayIndexOutOfBoundsException e)
	  {
	    Assert.fatal(e.getMessage() + ": " + _index);
	  }
      }

    if (_field != null)
      {
	try {
	  // value is automatically unwrapped if field is primitive
	  _field.set(_address, value);
	  return;
	}
	catch (IllegalArgumentException e) 
	  {
	    Assert.fatal(e.getMessage() + ": " + value 
			 + " expected " + _field.getType().getName());
	  }
	catch (IllegalAccessException e) 
	  { 
	    Assert.fatal(e.getMessage()); 
	  }
      }

    _address = value;
  }

  public boolean equals(ObjectWrapper o)
  {
    return (_address == o._address && _meta_class == o._meta_class);
  }

  public GenericObject getGenericObject()
  {
    MetaClass mc = _meta_class;
    while (mc != null)
      {
	if (mc.getInstanceName().equals(GenericObject.getClassName()))
	  {
	    return (GenericObject) _address;
	  }

	mc = mc.getLinkMetaClass();
      }

    return null;
  }

  public void initialize(SuifInputStream inputStream)
  {
    Assert.condition(_meta_class != null, "null meta class");
    getMetaClass().initialize(this, inputStream);
  }

  public boolean isNull() { return (_address == null); }


  public ObjectWrapper() { this(null, null, null, -1); }

  public ObjectWrapper(Object address, MetaClass meta_class) 
  {
    this(address, meta_class, null, -1);
  }

  public ObjectWrapper(Object address, MetaClass meta_class, Field field)
  {
    this(address, meta_class, field, -1);
  }

  public ObjectWrapper(Object address, MetaClass meta_class, int index)
  {
    this(address, meta_class, null, index);
  }

  public ObjectWrapper(Object address, 
		       MetaClass meta_class, 
		       Field field,
		       int index)
  {
    _address = address;
    _meta_class = meta_class;
    _field = field;
    _index = index;
  }

  public ObjectWrapper(GenericObject o)
  {
    Assert.condition(o != null, "null object passed to wrapper");
    
    _address = o;
    _meta_class = o.getMetaClass();
    _field = null;
    _index = -1;
  }

  public ObjectWrapper(ObjectWrapper other)
  {
    _address = other._address;
    _meta_class = other._meta_class;
    _field = other._field;
    _index = other._index;
  }
}
