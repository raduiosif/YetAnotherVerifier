/*
 * StringMetaClass.java - A port of basesuif/iokernel/string_meta_class.h
 *                        to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.common.Vector;
import yav.jsuif.ionative.SizeOf;


class StringOutputCache
{
  private HashMap _string_map = new HashMap();
  private Vector _strings = new Vector();
  
  public void write(String s, OutputStreamer stream)
  {
    int id;
    HashMap.Iterator iter = _string_map.find(s);
    if (iter.notEqual(_string_map.end()))
      {
	id = ((Integer) iter.get().second).intValue();
	stream.writeUnsignedInt(id);
      }
    else
      {
	id = _string_map.length();
	stream.writeUnsignedInt(id);
	_string_map.enterValue(s, new Integer(id));
	_strings.pushBack(s);

	int len = s.length();
	stream.writeUnsignedInt(len);
	
	byte bv[] = s.getBytes();
	int iv[] = new int [len];
	for (int i = 0; i < len; i ++)
	  {
	    iv[i] = bv[i];
	  }

	stream.writeByteArray(iv, len);
      }

//      System.out.println("write string> " + s);
  }
}


class StringInputCache
{
  private Vector _is_read = new Vector();
  private Vector _value = new Vector();

  public String read(InputStreamer stream)
  {
    int id = stream.readUnsignedInt();

    while (id >= _is_read.length()) { _is_read.pushBack(new Boolean(false)); }
    while (id >= _value.length()) { _value.pushBack(""); }

    if (((Boolean) _is_read.at(id)).booleanValue())
      {
//  	System.out.println("read string> " + (String) _value.at(id));
	return new String((String) _value.at(id));
      }

    _is_read.enter(id, new Boolean(true));
    
    int len = stream.readUnsignedInt();
    int iv[] = new int [len];
    stream.readByteArray(iv, len);

    char cv[] = new char [len];
    for (int i = 0; i < len; i ++)
      {
	cv[i] = (char) iv[i];
      }
    
    String str = new String(cv);
    _value.enter(id, str);

//      System.out.println("read string> " + str + len);

    return str;
  }
}


public class StringMetaClass extends MetaClass
{
  private static final String _className = "StringMetaClass";

  public static String getClassName() { return _className; }

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    write("String", obj, stream);
  }

  protected void write(String key, ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    Assert.condition(stream instanceof SuifOutputStream);

    StringOutputCache cache = 
      (StringOutputCache) ((SuifOutputStream) stream).getTempStorage(key);
    if (cache == null)
      {
	cache = new StringOutputCache();
	((SuifOutputStream) stream).setTempStorage(key, cache);
      }

    cache.write((String) obj.get(), stream);
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    read("String", obj, stream);
  }

  protected void read(String key, ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    Assert.condition(stream instanceof SuifInputStream);

    StringInputCache cache = 
      (StringInputCache) ((SuifInputStream) stream).getTempStorage(key);
    if (cache == null)
      {
	cache = new StringInputCache();
	((SuifInputStream) stream).setTempStorage(key, cache);
      }

    obj.set(cache.read(stream));
  }

  public int walk(Object address, Walker walk)
  {
    return Walker.CONTINUE;
  }

  
  public StringMetaClass() { this("", SizeOf.STRING); }
  public StringMetaClass(String name) { this(name, SizeOf.STRING); }

  protected StringMetaClass(String name, int size)
  {
    super(name);
    _size = size;
  }
}
