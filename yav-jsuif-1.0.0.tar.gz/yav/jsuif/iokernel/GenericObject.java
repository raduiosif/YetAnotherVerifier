/*
 * GenericObject.java - A port of basesuif/iokernel/object.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


/**
 * A generic object class.
 */

public abstract class GenericObject
{
  public static final String _className = "GenericObject";

  public static String getClassName() { return _className; }
  
  protected AggregateMetaClass _meta_class;

  /**
   * Get the meta class object of this object.
   */
  public MetaClass getMetaClass() { return _meta_class; }

  /**
   * Get the aggregate meta class object of this object.
   */
  public AggregateMetaClass getAggregateMetaClass() { return _meta_class; }

  /**
   * Sets the object meta class. For internal use only.
   */
  public void setMetaClass(MetaClass meta_class)
  {
    _meta_class = (AggregateMetaClass) meta_class;
  }
  
  /**
   * Get the name of the class of which this object is instance.
   * Returns the name of the actual dynamic instance.
   */
  public String getInstanceName() 
  {
    Assert.condition(_meta_class != null, "null meta class for " + this);
    return _meta_class.getInstanceName(); 
  }

  /**
   * Returns true if this object is an instance of the class given by name.
   * @param className name of the class
   */
  public boolean isA(String className) 
  { 
    Assert.condition(_meta_class != null, "null meta class for " + this);
    return className.equals(_meta_class.getInstanceName());
  }

  /**
   * Returns true if this object is an instance of the 
   * class given by name or of one of its subclasses.
   * @param className name of the class
   */
  public boolean isKindOf(String className)
  {
    for (MetaClass m = getMetaClass(); m != null; m = m.getLinkMetaClass())
      {
	if (m.getInstanceName().equals(className))
	  {
	    return true;
	  }
      }

    return false;
  }


  protected GenericObject()
  {
    _meta_class = null;
  }
}
