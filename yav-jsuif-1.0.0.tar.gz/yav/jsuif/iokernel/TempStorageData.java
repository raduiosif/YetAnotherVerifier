/*
 * TempStorageData.java - A port of basesuif/iokernel/object_stream.h to Java.
 *
 */

package yav.jsuif.iokernel;


class TempStorageData
{
  public Object _address;
  public boolean _already_visited;


  public TempStorageData(Object address, boolean already_visited)
  {
    _address = address;
    _already_visited = already_visited;
  }
}
