/*
 * FieldDescription.java - A port of basesuif/iokernel/field_description.h
 *                         to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import java.lang.reflect.Field;

// We need to (artificially) declare this class as subtype
// of yav.jsuif.iokernel.GenericObject in order to be able
// to create a meta class and read/write FieldDescription objects.
public class FieldDescription extends GenericObject
{
  // FieldDescription.buildObject() needs public access to this field
  public int offset;

  public int getOffset() { return offset; }
  public static native int get_offset_offset();
  
  // FieldDescription.buildObject() needs public access to this field
  public MetaClass metaClass;

  public MetaClass getMemberMetaClass() { return metaClass; }
  public static native int get_metaClass_offset();

  // FieldDescription.buildObject() needs public access to this field
  public String memberName;

  public String getMemberName() { return memberName; }
  public static native int get_memberName_offset();

  public ObjectWrapper buildObject(GenericObject obj)
  {
    return buildObject(new ObjectWrapper(obj));
  }

  public ObjectWrapper buildObject(ObjectWrapper obj)
  {
    return buildObject(obj.getAddress(), obj.getMetaClass());
  }

  public ObjectWrapper buildObject(AggregateWrapper obj)
  {
    return buildObject(obj.getAddress(), obj.getMetaClass());
  }

  public ObjectWrapper buildObject(Object address, MetaClass mc)
  {
    Assert.condition(address != null, "received null address");

    // Fix the meta class
    MetaClass realMC = mc;
    if (!(mc instanceof ObjectAggregateMetaClass)
	&& (mc instanceof AggregateMetaClass))
      {
	String name = mc.getInstanceName();
	String realName = CompatibleNames.getRealName(name);
	if (realName != null)
	  {
	    realMC = new ObjectAggregateMetaClass((AggregateMetaClass) mc,
						  realName);
	  }
      }

    Assert.condition(realMC instanceof ObjectAggregateMetaClass, 
		     "bad meta class " + realMC.getClass().getName());

    // Fix some SUIF awkwardness: 
    //   1. IndexedList.Pair.first calls itself _first
    //   2. IndexedList.Pair.second calls itself _second

    String realMemberName = memberName;
    String instanceName = realMC.getInstanceName();
    String realName = CompatibleNames.getRealName(instanceName);
    if (instanceName.equals("IndexedList$Pair") 
	|| (realName != null && realName.equals("IndexedList$Pair")))
      {
	if (memberName.equals("_first"))
	  {
	    realMemberName = "first";
	  }

	if (memberName.equals("_second"))
	  {
	    realMemberName = "second";
	  }
      }

    Field field = null;
    Class base_class = ((ObjectAggregateMetaClass) realMC).getClassFile();

    try {
      field = base_class.getField(realMemberName);
    }
    catch (NoSuchFieldException e) 
      { 
	Assert.fatal("no such field " + realMemberName + " in " 
		     + base_class); 
      }
    catch (SecurityException e) 
      { 
	Assert.fatal("field " + realMemberName + " in " 
		     + base_class + " not accessible"); 
      }    

    return new ObjectWrapper(address, metaClass, field);
  }

  static {
    System.loadLibrary("jsuif");
  }


  public FieldDescription() { this(0, null, ""); }

  public FieldDescription(int off, MetaClass mc, String name)
  {
    offset = off;
    metaClass = mc;
    memberName = name;
  }
}
