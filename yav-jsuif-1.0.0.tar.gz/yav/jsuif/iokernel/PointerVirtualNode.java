/*
 * PointerVirtualNode.java -
 *
 *
 */

package yav.jsuif.iokernel;


class PointerVirtualNode extends VirtualNode
{
  private VirtualNode _target;


  public PointerVirtualNode(VirtualNode target)
  {
    _target = target;
  }

  public boolean first(VirtualIterator state, Object address)
  {
    if (address == null)
      {
	return false;
      }

    return _target.first(state, address);
  }
}
