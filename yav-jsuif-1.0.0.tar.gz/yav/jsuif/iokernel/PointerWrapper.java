/*
 * PointerWrapper.java - A port of basesuif/iokernel/pointer_wrapper.h
 *                       to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import java.lang.reflect.Field;


public class PointerWrapper extends ObjectWrapper
{
  public PointerWrapper _next_address;


  public PointerWrapper(ObjectWrapper obj)
  {
    Assert.condition(obj._meta_class instanceof PointerMetaClass);

    _address = obj._address;
    _meta_class = obj._meta_class;
    _field = obj._field;
    _index = obj._index;
    _next_address = null;
  }

  public PointerWrapper(PointerWrapper other)
  {
    Assert.condition(other._meta_class instanceof PointerMetaClass);

    _address = other._address;
    _meta_class = other._meta_class;
    _field = other._field;
    _index = other._index;
    _next_address = null;
  }


  public ObjectWrapper dereference()
  {
    Assert.condition(!isNull(), "null pointer dereference");

    MetaClass base_mc = ((PointerMetaClass) _meta_class).getBaseType();   
    return new ObjectWrapper(_address, base_mc);
  }

  public boolean isNull() { return (_address == null); }
  
  public static boolean isPointer(ObjectWrapper obj)
  {
    return obj.getMetaClass().isKindOf(PointerMetaClass.getClassName());
  }
}
