/*
 * CloneStreamObjectInstance.java - A port of 
 *                                  basesuif/iokernel/clone_stream.cpp to Java.
 *
 */

package yav.jsuif.iokernel;


class CloneStreamObjectInstance
{
  private Object _old_address;

  public Object getOldAddress() { return _old_address; }

  private Object _new_address;

  public Object getNewAddress() { return _new_address; }
  public void setNewAddress(Object addr) { _new_address = addr; }

  private MetaClass _meta_class;

  public MetaClass getMetaClass() { return _meta_class; }

  private int _ref_kind;

  public int getRefKind() { return _ref_kind; }
  public void setRefKind(int ref_kind) { _ref_kind = ref_kind; }

  public void advanceRefKind(int ref_kind)
  {
    if (ref_kind > _ref_kind)
      {
	_ref_kind = ref_kind;
	if (ref_kind == CloneStream.CLONE_PTR)
	  {
	    _new_address = null;
	  }
	else
	  if (ref_kind == CloneStream.COPY_PTR)
	    {
	      _new_address = _old_address;
	    }
      }
  }

  private boolean _is_orphan;

  public boolean getIsOrphan() { return _is_orphan; }
  public void clearIsOrphan() { _is_orphan = false; }

  private boolean _is_written;

  public boolean getIsWritten() { return _is_written; }
  public void setIsWritten() { _is_written = true; }

  private boolean _already_visited;

  public boolean getIsVisited() { return _already_visited; }
  public void setIsVisited() { _already_visited = true; }

  private int _ptr_type;

  public int getPtrType() { return _ptr_type; }

  public void advancePtrType(int ptr_type)
  {
    if (_ptr_type < ptr_type)
      {
	_ptr_type = ptr_type;
      }
  }

  private int _id;

  public int getId() { return _id; }


  public CloneStreamObjectInstance(Object a, MetaClass m, int id)
  {
    _old_address = a;
    _new_address = null;
    _meta_class = m;
    _ref_kind = CloneStream.ENQUIRE_PTR;
    _is_orphan = true;
    _is_written = false;
    _already_visited = false;
    _ptr_type = CloneStream.NO_PTR;
    _id = id;
  }

  public CloneStreamObjectInstance(CloneStreamObjectInstance x)
  {
    _old_address = x._old_address;
    _new_address = x._new_address;
    _meta_class = x._meta_class;
    _ref_kind = x._ref_kind;
    _is_orphan = x._is_orphan;
    _is_written = x._is_written;
    _already_visited = x._already_visited;
    _ptr_type = x._ptr_type;
    _id = x._id;
  }
}
