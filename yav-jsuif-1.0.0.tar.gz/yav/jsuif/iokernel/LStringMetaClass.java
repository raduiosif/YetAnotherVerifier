/*
 * LStringMetaClass.java - Introduced for compatibility.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.ionative.SizeOf;


public class LStringMetaClass extends StringMetaClass
{
  private static final String _className = "LStringMetaClass";
  
  public static String getClassName() { return _className; }

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    write("LString", obj, stream);
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    read("LString", obj, stream);
  }


  public LStringMetaClass() { super("", SizeOf.LSTRING); }
  public LStringMetaClass(String name) { super(name, SizeOf.LSTRING); }
}
