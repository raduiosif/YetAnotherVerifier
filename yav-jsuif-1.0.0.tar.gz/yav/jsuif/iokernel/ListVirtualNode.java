/*
 * ListVirtualNode.java - A port of basesuif/iokernel/virtual_iterator.cpp
 *                        to Java.
 *
 */

package yav.jsuif.iokernel;


class ListVirtualNode extends VirtualNode
{
  private ListMetaClass _list_meta_class;
  private VirtualNode _start_node;
  
  public ListVirtualNode(ListMetaClass list_meta_class,
			 VirtualNode start_node)
  {
    _list_meta_class = list_meta_class;
    _start_node = start_node;
  }

  public boolean first(VirtualIterator state, Object address)
  {
    Iterator iter = _list_meta_class.getIterator(address);
    if (iter == null)
      {
	return false;
      }

    if (!iter.isValid())
      {
	return false;
      }

    state.push(new IteratorState(this, address, iter));
    boolean is_valid = _start_node.first(state, iter.current());
    if (!is_valid)
      {
	is_valid = next(state);
      }
    
    return is_valid;
  }

  public boolean next(VirtualIterator state)
  {
    Iterator iter = state.top().getIterator();
    iter.next();
    boolean is_valid = iter.isValid();
    if (!is_valid)
      {
	state.pop();
      }
    else
      {
	return _start_node.first(state, iter.current());
      }

    return false;
  }
}
