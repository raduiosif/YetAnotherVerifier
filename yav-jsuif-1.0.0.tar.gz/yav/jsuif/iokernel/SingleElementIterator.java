/*
 * SingleElementIterator.java - A port of basesuif/iokernel/meta_class_iter.h 
 *                              to Java.
 *
 */

package yav.jsuif.iokernel;


class SingleElementIterator extends Iterator
{
  private boolean _is_valid;
  private Object address;
  private MetaClass metaClass;


  public SingleElementIterator(Object addr, MetaClass mc)
  {
    _is_valid = true;
    address = addr;
    metaClass = mc;
  }

  public SingleElementIterator(ObjectWrapper obj)
  {
    _is_valid = true;
    address = obj.get();
    metaClass = obj.getMetaClass();
  }


  public MetaClass currentMetaClass() { return _is_valid ? metaClass : null; }
  public String currentName() { return ""; }
  public Object current() { return address; }
  public void setCurrent(Object x) { address = x; }
  public boolean isValid() { return _is_valid; }

  public void next() { _is_valid = false; }
  public void previous() { _is_valid = false; }
  public void first() { _is_valid = true; }
  public int length() { return 1; }
}

