/*
 * VirtualNode.java - A port of basesuif/iokernel/virtual_iterator.h 
 *                    to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


abstract class VirtualNode
{
  public MetaClass currentMetaClass(VirtualIterator state)
  {
    Assert.fatal();
    return null;
  }

  public String currentName(VirtualIterator state)
  {
    Assert.fatal();
    return null;
  }

  public Object current(VirtualIterator state)
  {
    Assert.fatal();
    return null;
  }

  public void setCurrent(VirtualIterator state, Object x)
  {
    Assert.fatal();
    return;
  }

  public abstract boolean first(VirtualIterator state, Object address);

  public boolean next(VirtualIterator state)
  {
    Assert.fatal();
    return false;
  }
}
