/*
 * SuifInputStream.java - A port of basesuif/iokernel/object_stream.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.common.List;
import yav.jsuif.ionative.SizeOf;


class InputStreamFixUp
{
  public static final int REFERENCED_ONLY = 0;
  public static final int READ_IN = 1;

  public int _state;
  public PointerWrapper _start_of_fixup_list;
  public Object _target_address;
}


/**
 * A SuifInputStream reads in SUIF files.
 */
public abstract class SuifInputStream 
  extends SuifObjectStream implements InputStreamer
{
  protected ObjectFactory _of;
  protected HashMap _data;
  protected HashMap _address_map;
  protected List _root_objects;
  protected int _last_id;


  public SuifInputStream(ObjectFactory of)
  {
    _of = of;
    _data = new HashMap();
    _address_map = new HashMap();
    _root_objects = new List();
    _last_id = 1;
  }


  public MetaClass readMetaClass()
  {
    int id = readAddressId();
    HashMap.Iterator it = _address_map.find(new Integer(id));
    Assert.condition((id != 0) && (it.notEqual(_address_map.end())));
    return (MetaClass) ((InputStreamFixUp) it.get().second)._target_address;
  }

  public Object readObject(MetaClass mc)
  {
    Object instance = null;
    if (mc instanceof AggregateMetaClass)
      {
	instance = createEmptyObject(mc);
      }

    ObjectWrapper root = new ObjectWrapper(instance, mc);
    read(root, true);
    _root_objects.pushBack(root);
    return root.get();
  }

  public void read(ObjectWrapper obj) { read(obj, false); }

  public void read(ObjectWrapper obj, boolean addressable)
  {
    Object instance = obj.get();
    MetaClass mc = obj.getMetaClass();
    if (addressable)
      {
	int id = readAddressId();
	if (mc instanceof PointerMetaClass)
	  {
	    mapIdToAddress(id, obj);	    
	  }
	else
	  {
	    mapIdToAddress(id, instance);
	  }
      }

    mc.read(obj, this);
  }

  public void readClose()
  {
    while (!_root_objects.empty())
      {
	ObjectWrapper root = (ObjectWrapper) _root_objects.front();
	_root_objects.popFront();
	MetaClass mc = root.getMetaClass();
	if (mc instanceof PointerMetaClass)
	  {
	    setAlreadyVisited(root);
	  }
	else
	  {
	    setAlreadyVisited(root.get());
	  }

	mc.initialize(root, this);
      }
  }

  public void readStaticPointer(PointerWrapper ptr_obj)
  {
    Object instance = ptr_obj.get();
    PointerMetaClass pointerMC = (PointerMetaClass) ptr_obj.getMetaClass();
    MetaClass _base_type = pointerMC.getBaseType();
    int read_an_object = readByte();
    if (read_an_object != 0)
      {
	if (instance == null)
	  {
	    instance = createEmptyNonAddressableObject(_base_type);
	    ptr_obj.set(instance);
	  }
	
	read(new ObjectWrapper(instance, _base_type), false);
      }
  }

  public void readDefiningPointer(PointerWrapper ptr_obj)
  {
    readOwningPointer(ptr_obj);
  }

  public void readOwningPointer(PointerWrapper ptr_obj)
  {
    int id = readAddressId();
    if (!isAlreadyRead(id))
      {
	MetaClass realMC = readMetaClass();
	if (realMC != null)
	  {
	    Object instance = createEmptyObject(realMC);
	    mapIdToAddress(id, instance);
	    read(new ObjectWrapper(instance, realMC), false);
	  }
	else
	  {
	    id = 0;
	  }
      }

    fixupAddress(ptr_obj, id);
  }

  public void readReference(PointerWrapper ptr_obj)
  {
    readOwningPointer(ptr_obj);
  }

  public int readAddressId()
  {
    int id = readUnsignedInt();
    if (id == 1)
      {
	id = ++ _last_id;
      }
    else
      {
	if (id > _last_id)
	  {
	    _last_id = id;
	  }
      }

    return id;
  }
  
  public int readUnsignedInt() 
  { 
    return readSizedInt(SizeOf.INT, false);
  }

  // TODO: come up with something to do unsigned stuff
  public int readSizedInt(int instanceSize, boolean is_signed)
  {
//      System.out.println("readSizedInt(" + instanceSize 
//  		       + "," + is_signed + ")");

    /*
     * Reading is done in network order.
     * The less significant byte is read
     * from the biggest file offset.
     */
    int b = readByte();    
    if ((b & NORMAL_INT_BIT) == 0)
      {
//  	System.out.println("readSizedInt --> " + b);

	return b;
      }
    else
      {
	int returnValue = 0;
	int currentIntSize = b & NORMAL_INT_LENGTH_MASK;
	int remainingBytes = instanceSize - currentIntSize;
	boolean isCurrentIntSigned = ((b & NORMAL_INT_SIGN_BIT) != 0);

	Assert.condition(is_signed || !isCurrentIntSigned);
	Assert.condition(currentIntSize <= instanceSize);

	for (int i = currentIntSize - 1; i >= 0; i --)
	  {
	    returnValue += readByte() << (i * 8);
	  }

	int fillByte = isCurrentIntSigned ? SIGNED_BYTE_FILL : 0;
	for (int i = 0; i < remainingBytes; i ++)
	  {
	    returnValue += fillByte << ((i + currentIntSize) * 8);
	  }

//  	System.out.println("readSizedInt --> " + returnValue);

	return returnValue;
      }
  }

  public void readByteArray(int[] address, int len)
  {
    for (int i = 0; i < len; i ++)
      {
	address[i] = readByte();
      }
  }

  public Object createEmptyNonAddressableObject(MetaClass mc)
  {
    return _of.createEmptyObject(mc);
  }

  public Object createEmptyObject(MetaClass mc)
  {
    Object objectAddress = _of.createEmptyObject(mc);
    TempStorageData tempData = new TempStorageData(null, false);

//      System.out.println("createEmptyObject(" + mc.getInstanceName() 
//  		       + ") enter: " + objectAddress);
    
    _data.enterValueAt(objectAddress, tempData);
    return objectAddress;
  }

  public void fixupAddress(PointerWrapper addressOfPointer, int id)
  {
    if (id == 0)
      {
	addressOfPointer.set(null);
	return;
      }

    HashMap.Iterator it = _address_map.find(new Integer(id));
    if (it.notEqual(_address_map.end()))
      {
	InputStreamFixUp info = (InputStreamFixUp) it.get().second;
	switch (info._state)
	  {
	  case InputStreamFixUp.REFERENCED_ONLY:
	    addressOfPointer._next_address = info._start_of_fixup_list;
	    info._start_of_fixup_list = addressOfPointer;
	    break;

	  case InputStreamFixUp.READ_IN:

//  	    System.out.println("<-- fixup " 
//  			       + info._target_address 
//  			       + " at " + id);

	    addressOfPointer.set(info._target_address);
	    break;
	  }
      }
    else
      {
	InputStreamFixUp info = new InputStreamFixUp();
	info._state = InputStreamFixUp.REFERENCED_ONLY;
	info._start_of_fixup_list = addressOfPointer;
	addressOfPointer.set(null);
	_address_map.enterValueAt(new Integer(id), info);
      }
  }

  public boolean isAlreadyRead(int id)
  {
    if (id == 0)
      {
	return true;
      }

    HashMap.Iterator it = _address_map.find(new Integer(id));
    return it.notEqual(_address_map.end());
  }

  public boolean existsInInputStream(Object objectAddress)
  {
    HashMap.Iterator it = _data.find(objectAddress);
    return it.notEqual(_data.end());
  }

  public void setAlreadyVisited(Object objectAddress)
  {
    HashMap.Iterator it = _data.find(objectAddress);
    if (it.isEqual(_data.end()))
      {
	return;
      }

    ((TempStorageData) it.get().second)._already_visited = true;
  }

  public boolean wasAlreadyVisited(Object objectAddress)
  {
    HashMap.Iterator it = _data.find(objectAddress);
    if (it.isEqual(_data.end()))
      {
	return true;
      }

    return ((TempStorageData) it.get().second)._already_visited;
  }

  public void storeData(Object objectAddress, Object someData)
  {
    TempStorageData tempData = new TempStorageData(someData, false);

//      System.out.println("(storeData) enter: " + objectAddress);

    _data.enterValueAt(objectAddress, tempData);
  }

  public Object retrieveData(Object objectAddress)
  {
    HashMap.Iterator it = _data.find(objectAddress);
    if (it.equals(_data.end()))
      {
	return null;
      }

    return ((TempStorageData) it.get().second)._address;
  }

  public void remapAddress(Object old_address, Object new_address)
  {
    HashMap.Iterator it = _address_map.begin();
    HashMap.Iterator end = _address_map.end();
    for (; it.notEqual(end); it.inc())
      {
	InputStreamFixUp info = (InputStreamFixUp) it.get().second;
	if ((info._state == InputStreamFixUp.READ_IN) &&
	    (info._target_address == old_address))
	  {
	    info._target_address = new_address;
	    return;
	  }
      }

    Assert.fatal("no address to fix");
  }

  public ObjectFactory getObjectFactory() { return _of; }

  public void addAddressPair(int id, Object address)
  {
    Assert.condition((id != 0) && (id != 1), "invalid id (" + id + ")");
    mapIdToAddress(id, address);
  }

  protected void mapIdToAddress(int id, Object address)
  {
    Assert.condition(address != null, "null address to map");

//      System.out.println("--> map " + address + " at " + id);

    HashMap.Iterator it = _address_map.find(new Integer(id));
    if (it.notEqual(_address_map.end()))
      {
	InputStreamFixUp info = (InputStreamFixUp) it.get().second;
	Assert.condition(info._state == InputStreamFixUp.REFERENCED_ONLY);     
	
	PointerWrapper start_of_fixup_list = info._start_of_fixup_list;
	while (start_of_fixup_list != null)
	  {
	    start_of_fixup_list.set(address);
	    start_of_fixup_list = start_of_fixup_list._next_address;
	  }

	info._state = InputStreamFixUp.READ_IN;
	info._target_address = address;
      }
    else
      {
	InputStreamFixUp info = new InputStreamFixUp();	
	info._state = InputStreamFixUp.READ_IN;
	info._target_address = address;
	_address_map.enterValue(new Integer(id), info);
      }
  }

  protected Object getAddress(int id)
  {
    HashMap.Iterator it = _address_map.find(new Integer(id));
    Assert.condition(it.notEqual(_address_map.end()));
    
    InputStreamFixUp info = (InputStreamFixUp) it.get().second;
    Assert.condition(info._state == InputStreamFixUp.READ_IN);

    return info._target_address;
  }
}
