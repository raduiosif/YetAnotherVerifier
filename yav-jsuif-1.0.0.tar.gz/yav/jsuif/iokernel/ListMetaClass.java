/*
 * ListMetaClass.java - A port of basesuif/iokernel/list_meta_class.h
 *                      to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.PString;
import yav.jsuif.common.List;
import yav.jsuif.common.STLType;
import yav.jsuif.common.Vector;


public class ListMetaClass extends MetaClass
{
  private static final String _className = "ListMetaClass";

  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public MetaClass _element_meta_class;

  public void setElementMetaClass(MetaClass mc) { _element_meta_class = mc; }
  public MetaClass getElementMetaClass() { return _element_meta_class; }
  public static native int get__element_meta_class_offset();

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    Assert.condition(_element_meta_class != null);

    Object instance = obj.get();
    Iterator it = getIterator(instance);
    int len = it.length(), count = 0;
    ObjectWrapper elem_obj;

//      System.out.println("LIST::write " + len);

    stream.writeUnsignedInt(len);    
    while (it.isValid())
      {
	count ++;
	Assert.condition(_element_meta_class == it.currentMetaClass());	
	elem_obj = new ObjectWrapper(it.current(), it.currentMetaClass());

//  	System.out.println(instance + ":write elem#" + count + ">");

	stream.write(elem_obj, false);
	it.next();
      }

    Assert.condition(count == len);
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    Assert.condition(_element_meta_class != null);

    Object instance = obj.get();
    int size = stream.readUnsignedInt(), i = 0;
    int instanceSize = _element_meta_class.getSizeOfInstance();

//      System.out.println("LIST::read " + size + " of " 
//  		       + _element_meta_class.getInstanceName()
//  		       + " (" + _element_meta_class.getSize() + ")");
    
    GenericList genericList = new GenericList(size);
    ((SuifInputStream) stream).storeData(instance, genericList);
    Object space[] = genericList._space;

    ObjectFactory of = ((SuifInputStream) stream).getObjectFactory();
    ObjectWrapper elem;
    while (size -- != 0)
      {
//  	System.out.println(instance + ":read elem#" + size);

	if (_element_meta_class instanceof AggregateMetaClass)
	  {
	    space[i] = of.createEmptyObject(_element_meta_class);
	    elem = new ObjectWrapper(space[i], _element_meta_class);
	  }
	else
	  {
	    elem = new ObjectWrapper(space, _element_meta_class, i);
	  }

	stream.read(elem, false);
	i ++;
      }
  }

  public Iterator getIterator(Object instance) 
  { 
    return getIterator(instance, Iterator.OWNED);
  }

  public Iterator getIterator(Object address, int contents)
  {    
    Assert.condition(address instanceof STLType, "non-STL object " + address);
    if (contents == Iterator.OWNED)
      {

//  	System.out.println("list iterator> " 
//  			   + address + " " 
//  			   + _element_meta_class);

	return new STLIterator(address, _element_meta_class);
      }

    return null;
  }

  public boolean isElementary() { return false; }

  public void initialize(ObjectWrapper obj, SuifInputStream stream)
  {
    Assert.condition(obj.getMetaClass() == this);
    Assert.condition(_element_meta_class != null);

    Object instance = obj.get();
    GenericList genericList = (GenericList) stream.retrieveData(instance);
    int instanceSize = _element_meta_class.getSizeOfInstance();
    int size = genericList._count, i = 0;
    Object[] space = genericList._space;

//      System.out.println("LIST::initialize " + size + " of "
//  		       + _element_meta_class.getInstanceName());

    while (size -- != 0) 
      {
//  	System.out.println(instance + ":init elem#" + size + ">");

	ObjectWrapper elem = new ObjectWrapper(space [i], _element_meta_class);
	_element_meta_class.initialize(elem, stream);
	i ++;
      }

    copyOver(instance, genericList);
  }

  public VirtualNode getVirtualNode(String name, String what)
  {
    PString spec = new PString(what);
    if (spec.get().length() != 0)
      {
	String current_member = cutOff(spec, '/');
	Assert.condition(current_member.equals("*"));
	MetaClass elementMC = getElementMetaClass();
	VirtualNode element = elementMC.getVirtualNode(name, spec.get());
	if (element == null)
	  {
	    Vector members = new Vector();
	    members.pushBack(new AggregateElement(this, ""));
	    element = new AggregateVirtualNode(members);
	  }

	return new ListVirtualNode(this, element);
      }

    return null;
  }

  public int walk(Object address, Walker walk)
  {
    Iterator iterator = getIterator(address);
    if (walk.getMakesChanges())
      {
	List elements = new List();
	while (iterator.isValid())
	  {
	    elements.pushBack(iterator.current());
	    iterator.next();
	  }

	List.Iterator iter = elements.begin();
	List.Iterator end = elements.end();
	while (iter.notEqual(end))
	  {
	    Object current = iter.get();
	    int status = _element_meta_class.walk(current, walk);
	    switch (status)
	      {
	      case Walker.CONTINUE:
	      case Walker.TRUNCATE:
	      case Walker.REPLACED:
		break;

	      case Walker.STOP:
	      case Walker.ABORT:
		return status;
	      }

	    iter.inc();
	  }
      }
    else
      {
	while (iterator.isValid())
	  {
	    Object current = iterator.current();
	    int status = _element_meta_class.walk(current, walk);
	    switch (status)
	      {
	      case Walker.CONTINUE:
	      case Walker.TRUNCATE:
	      case Walker.REPLACED:
		break;

	      case Walker.STOP:
	      case Walker.ABORT:
		return status;
	      }

	    iterator.next();
	  }
      }

    return Walker.CONTINUE;
  }

  public void walkReferencedMetaClasses(MetaClassApplier x)
  {
    x.apply(_element_meta_class);
  }

  protected void copyOver(Object target, GenericList source)
  {
    Assert.condition(target instanceof STLType, "non-STL object " + target);

    Object space[] = source._space;
    Iterator iterator = new STLIterator(target, _element_meta_class);
    for (int i = 0; i < source._count; i ++)
      {
	iterator.add(space[i]);
      }
  }

  static {
    System.loadLibrary("jsuif");
  }


  public ListMetaClass() { this(""); }

  public ListMetaClass(String name)
  {
    super(name);
    _element_meta_class = null;
  }
}

