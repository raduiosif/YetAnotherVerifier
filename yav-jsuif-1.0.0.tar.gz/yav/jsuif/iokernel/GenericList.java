/*
 * GenericList.java - A port of basesuif/iokernel/list_meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;


class GenericList
{
  public int _count;
  public Object[] _space;

  public GenericList(int count)
  {
    _count = count;
    _space = (count == 0) ? null : new Object [count];
  }
}



