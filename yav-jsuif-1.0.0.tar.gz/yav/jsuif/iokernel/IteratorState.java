/*
 * IteratorState.java - A port of basesuif/iokernel/virtual_iterator.cpp
 *                      to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class IteratorState
{
  private VirtualNode _node;

  public VirtualNode getNode() { return _node; }

  private Object _address;

  public Object getAddress() { return _address; } 

  private boolean _is_iterator;

  public boolean isIterator() { return _is_iterator; }

  private Iterator _iterator;

  public Iterator getIterator()
  {
    Assert.condition(_is_iterator);
    return _iterator;
  }

  private int _iteration_num;

  public void increment()
  {
    Assert.condition(!_is_iterator);
    _iteration_num ++;
  }

  public int getIterationNum()
  {
    Assert.condition(!_is_iterator);
    return _iteration_num;
  }

  public IteratorState()
  {
    _node = null;
    _address = null;
    _is_iterator = false;
    _iterator = null;
    _iteration_num = 0;
  }

  public IteratorState(VirtualNode node, Object address)
  {
    _node = node;
    _address = address;
    _is_iterator = false;
    _iteration_num = 0;
  }

  public IteratorState(VirtualNode node, Object address, Iterator iter)
  {
    _node = node;
    _address = address;
    _is_iterator = true;
    _iterator = iter;
    _iteration_num = 0;
  }

  public IteratorState(IteratorState other)
  {
    _node = other._node;
    _address = other._address;
    _is_iterator = other._is_iterator;
    if (other.isIterator())
      {
	_iterator = other._iterator;
	_iteration_num = 0;
      }
    else
      {
	_iterator = null;
	_iteration_num = other._iteration_num;
      }
  }
}
