/*
 * VirtualIterator.java - A port of basesuif/iokernel/virtual_iterator.h 
 *                        to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;


public class VirtualIterator extends Iterator
{
  protected boolean _is_valid;
  protected Vector _state;
  protected VirtualNode _start_node;


  public VirtualIterator(Object address, VirtualNode start_node)
  {
    _state = new Vector();
    _start_node = start_node;
    _is_valid = (_start_node != null) && _start_node.first(this, address);
  }

 
  public MetaClass currentMetaClass()
  {
    if (!_is_valid) return null;
    return currentNode().currentMetaClass(this);
  }

  public String currentName() { return ""; }

  public Object current()
  {
    if (!_is_valid) 
      {
	return null;
      }

    return currentNode().current(this);
  }

  public void setCurrent(Object x)
  {
    if (!_is_valid)
      {
	return;
      }

    currentNode().setCurrent(this, x);
  }

  public boolean isValid() { return _is_valid; }

  public void next()
  {
    if (!_is_valid) return;
    _is_valid = currentNode().next(this);
  }

  public void previous()
  {
    if (!_is_valid) 
      {
	return;
      }

    Assert.fatal();
  }

  public void first()
  {
    Assert.condition(_state.length() > 0);
    
    VirtualNode n = currentNode();
    if (n == null)
      {
	_is_valid = false;
      }
    else
      {
	_is_valid = n.first(this, ((IteratorState) _state.at(0)).getAddress());
      }
  }

  public IteratorState top()
  {
    return (IteratorState) _state.at(_state.length() - 1);
  }

  public void push(IteratorState state)
  {
    _state.pushBack(state);
  }

  public boolean pop()
  {
    if (_state.length() > 2)
      {
	_state.popBack();
	return true;
      }
    
    return false;
  }

  public VirtualNode currentNode() { return top().getNode(); }

  public Object clone()
  {
    VirtualIterator n;
    n = new VirtualIterator(((IteratorState) _state.at(0)).getAddress(), 
			    _start_node);

    Assert.condition(n._state.length() == 0);

    for (int i = 1; i < _state.length(); i ++)
      {
	IteratorState iter = (IteratorState) _state.at(i);
	if (iter.isIterator())
	  {
	    iter = new IteratorState(iter.getNode(), iter.getAddress(),
				     (Iterator) iter.getIterator().clone());
	  }
	n._state.pushBack(iter);
      }

    n._is_valid = _is_valid;
    return n;
  }
}
