/*
 * ObjectFactory.java - A port of basesuif/iokernel/object_factory.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.*;
import yav.jsuif.kernel.SuifEnv;
import yav.jsuif.ionative.SizeOf;
import yav.jsuif.ionative.AlignmentOf;

import java.io.ByteArrayOutputStream;


class VirtualFieldDescription
{
  public static native int value_type_size();
  public static native int get_first_offset();
  public static native int get_second_offset();
}


class MetaClassDictionary
{
  public static native int value_type_size();
  public static native int get_first_offset();
  public static native int get_second_offset();
}


/**
 * An ObjectFactory serves the following purposes:
 * <ul>
 * <li> creates suif objects,
 * <li> managing meta classes,
 * <li> helps in reading and writing of suif objects to output stream,
 * <li> report error, warning, and informational messages.
 * </ul>
 *
 */


public class ObjectFactory extends GenericObject
{
  private int _last_id;
  private AddressMap _rudimentary_address_map;
  private AggregateMetaClass _aggregate_meta_class_mc;
  private AggregateMetaClass _object_aggregate_meta_class_mc;
  private AggregateMetaClass _pointer_meta_class_mc;
  private AggregateMetaClass _union_meta_class_mc;
  private AggregateMetaClass _integer_meta_class_mc;
  private AggregateMetaClass _list_meta_class_mc;
  private AggregateMetaClass _field_mc;
  private SuifEnv _suif_env;
  
  // FieldDescription.buildObject() needs public access to this field
  public HashMap _meta_class_dictionary;

  public static native int get__meta_class_dictionary_offset();
  
  static {
    System.loadLibrary("jsuif");
  }


  public ObjectFactory()
  {
    _last_id = 0;
    _rudimentary_address_map = null;
    _meta_class_dictionary = new HashMap();
    _aggregate_meta_class_mc = null;
    _object_aggregate_meta_class_mc = null;
    _pointer_meta_class_mc = null;
    _union_meta_class_mc = null;
    _integer_meta_class_mc = null;
    _list_meta_class_mc = null;
    _field_mc = null;
    _suif_env = null;
  }


  public IntegerMetaClass getIntegerMetaClass(String name,
					      int size,
					      boolean is_signed,
					      int align)
  {
    Assert.condition(size != 0);
    Assert.condition(_integer_meta_class_mc != null);

    IntegerMetaClass intMC;
    MetaClass mc = lookupMetaClass(name);
    if (mc != null)
      {
	if (mc.isA(IntegerMetaClass.getClassName()))
	  {
	    intMC = (IntegerMetaClass) mc;
	    if ((intMC.getSizeOfInstance() == size) &&
		(intMC.getAlignmentOfInstance() == align) &&
		(intMC.isSigned() == is_signed))
	      {
		return intMC;
	      }
	  }

	Assert.fatal("registered with different parameters");
      }

    intMC = new IntegerMetaClass(name);
    intMC.setSize(size);
    intMC.setAlignment(align);
    intMC.setIsSigned(is_signed);
    intMC.setMetaClass(_integer_meta_class_mc);

    enterMetaClass(intMC);
    return intMC;
  }

  public BooleanMetaClass getBooleanMetaClass(String name)
  {
    Assert.condition(_integer_meta_class_mc != null);
    
    BooleanMetaClass boolMC;
    MetaClass mc = lookupMetaClass(name);
    if (mc != null)
      {
	Assert.fatal("registered with different parameters");
      }

    boolMC = new BooleanMetaClass(name);
    boolMC.setSize(SizeOf.BOOL);
    boolMC.setAlignment(AlignmentOf.BOOL);
    boolMC.setMetaClass(_integer_meta_class_mc);

    enterMetaClass(boolMC);
    return boolMC;
  }

  public PointerMetaClass getPointerMetaClass(MetaClass base_type)
  {
    return getPointerMetaClass(base_type, true, false, false);
  }

  public PointerMetaClass getPointerMetaClass(MetaClass base_type,
					      boolean pointer_owns_object)
  {
    return getPointerMetaClass(base_type, pointer_owns_object, false, false);
  }

  public PointerMetaClass getPointerMetaClass(MetaClass base_type,
					      boolean pointer_owns_object,
					      boolean is_static)
  {
    return getPointerMetaClass(base_type, pointer_owns_object, 
			       is_static, false);
  }

  public PointerMetaClass getPointerMetaClass(MetaClass base_type,
					      boolean pointer_owns_object,
					      boolean is_static,
					      boolean must_be_cloned)
  {
    String name = ("PTR:" + 
		   (pointer_owns_object ? "O:" : "R:") +
		   (is_static ? "S:" : ":") + 
		   (must_be_cloned ? "C:" : ":") +
		   base_type.getInstanceName());

    PointerMetaClass pointerMC;
    MetaClass mc = lookupMetaClass(name);
    if (mc != null)
      {
	if (mc.isA(PointerMetaClass.getClassName()))
	  {
	    pointerMC = (PointerMetaClass) mc;
	    if ((pointerMC.isOwningPointer() == pointer_owns_object) &&
		(pointerMC.getBaseType() == base_type))
	      {
		return pointerMC;
	      }
	  }

	Assert.fatal("registered with different parameters");
      }

    pointerMC = new PointerMetaClass(name, base_type, 
				     pointer_owns_object,
				     is_static, must_be_cloned);

    pointerMC.setSize(SizeOf.VOID_PTR);
    pointerMC.setAlignment(AlignmentOf.VOID_PTR); 
    pointerMC.setMetaClass(_pointer_meta_class_mc);
    
    enterMetaClass(pointerMC);
    return pointerMC;
  }

  public ListMetaClass getListMetaClass(MetaClass element_type, 
					String real_type)
  {
    ListMetaClass list_meta_class;
    String name = real_type;
    if (!name.endsWith(":GENERIC"))
      {
	name += ":GENERIC";
      }

    MetaClass mc = lookupMetaClass(name);
    if (mc != null)
      {
	if (mc.isA(ListMetaClass.getClassName()))
	  {
	    list_meta_class = (ListMetaClass) mc;
	    if (list_meta_class.getElementMetaClass() == element_type)
	      {
		return list_meta_class;
	      }
	  }

	Assert.fatal("registered with different parameters");
      }

    list_meta_class = new ListMetaClass(name);
    list_meta_class.setMetaClass(_list_meta_class_mc);
    list_meta_class.setElementMetaClass(element_type);
    list_meta_class.setSize(SizeOf.GENERIC_LIST);
    list_meta_class.setAlignment(AlignmentOf.GENERIC_LIST);

    String lname = real_type;
    if (lname.startsWith("LIST:"))
      {
	lname = lname.substring(5, lname.indexOf("<"));
      }

    if (lname.equals("indexed_list"))
      {
	list_meta_class.setSize(SizeOf.INDEXED_LIST);
	list_meta_class.setAlignment(AlignmentOf.INDEXED_LIST);
      }
    else if (lname.equals("list"))
      {
	list_meta_class.setSize(SizeOf.LIST);
	list_meta_class.setAlignment(AlignmentOf.LIST);
      }
    else if (lname.equals("searchable_list"))
      {
	list_meta_class.setSize(SizeOf.SEARCHABLE_LIST);
	list_meta_class.setAlignment(AlignmentOf.SEARCHABLE_LIST);
      }
    else if (lname.equals("suif_hash_map"))
      {
	list_meta_class.setSize(SizeOf.HASH_MAP);
	list_meta_class.setAlignment(AlignmentOf.HASH_MAP);
      }
    else if (lname.equals("suif_map"))
      {
	list_meta_class.setSize(SizeOf.MAP);
	list_meta_class.setAlignment(AlignmentOf.MAP);
      }
    else if (lname.equals("suif_vector"))
      {
	list_meta_class.setSize(SizeOf.VECTOR);
	list_meta_class.setAlignment(AlignmentOf.VECTOR);
      }
    else if (lname.equals("vector"))
      {
	list_meta_class.setSize(SizeOf.VECTOR);
	list_meta_class.setAlignment(AlignmentOf.VECTOR);
      }

    enterMetaClass(list_meta_class);
    return list_meta_class;
  }

  public STLMetaClass getSTLMetaClass(String name,
				      TypeLessSTLDescriptor stl_descriptor)
  {
    STLMetaClass stl_meta_class;
    MetaClass mc = lookupMetaClass(name);
    if (mc != null)
      {
	if (mc.isA(STLMetaClass.getClassName()))
	  {
	    stl_meta_class = (STLMetaClass) mc;
	    if (stl_meta_class.getInstanceName().equals(name))
	      {
		return stl_meta_class;
	      }	    
	  }

	Assert.fatal("registered with different parameters");
      }

    Assert.condition(stl_descriptor != null);

    stl_meta_class = new STLMetaClass(name);
    stl_meta_class.setMetaClass(_list_meta_class_mc);
    stl_meta_class.setDescriptor(stl_descriptor);
    
    enterMetaClass(stl_meta_class);
    return stl_meta_class;
  }

  public AggregateMetaClass createAggregateMetaClass(String name)
  {
    return createAggregateMetaClass(name, 0, null, true);
  }

  public AggregateMetaClass createAggregateMetaClass(String name,
						     int size)
  {
    return createAggregateMetaClass(name, size, null, true);
  }

  public AggregateMetaClass createAggregateMetaClass(String name,
						     int size,
						     AggregateMetaClass base)
  {
    return createAggregateMetaClass(name, size, base, true);
  }

  public AggregateMetaClass createAggregateMetaClass(String name,
						     int size,
						     AggregateMetaClass base,
						     boolean register)
  {
    Assert.condition((name != null) && (name.length() != 0));
    Assert.condition(_aggregate_meta_class_mc != null);

    Assert.condition(lookupMetaClass(name) == null,
		     "Attempt to create MetaClass '" + name + "' " +
		     "that has already been loaded. Try to import all " +
		     "needed nodes before loading any files");

    AggregateMetaClass aggregate_mc;
    String realName = CompatibleNames.getRealName(name);
    if (realName != null)
      {
	aggregate_mc = new ObjectAggregateMetaClass(name, realName);
      }
    else
      {
	aggregate_mc = new AggregateMetaClass(name);
      }

    aggregate_mc.setMetaClass(_aggregate_meta_class_mc);
    aggregate_mc.inheritsFrom(base);
    if (base != null)
      {
	aggregate_mc.setAlignment(base.getAlignmentOfInstance());
      }
    else
      {
	aggregate_mc.setAlignment(AlignmentOf.VOID_PTR);
      }

    aggregate_mc.setSize(size);
    if (register)
      {
	enterMetaClass(aggregate_mc);
      }

    return aggregate_mc;
  }

  public ObjectAggregateMetaClass createObjectMetaClass(String name)
  {
    return createObjectMetaClass(name, 0, null);
  }

  public ObjectAggregateMetaClass createObjectMetaClass(String name,
							int size)
  {
    return createObjectMetaClass(name, size, null);
  }

  public ObjectAggregateMetaClass createObjectMetaClass(String name,
							int size,
							AggregateMetaClass mc)
  {
    Assert.condition((name != null) && (name.length() != 0));
    Assert.condition(lookupMetaClass(name) == null,
		     "Attempt to create MetaClass '" + name + "' " +
		     "that has already been loaded. Try to import all " +
		     "needed nodes before loading any files");

    ObjectAggregateMetaClass object_mc;
    String realName = CompatibleNames.getRealName(name);
    if (realName != null)
      {
	object_mc = new ObjectAggregateMetaClass(name, realName);
      }
    else
      {
	object_mc = new ObjectAggregateMetaClass(name);
      }

    AggregateMetaClass object_meta_class_mc;
    if (_object_aggregate_meta_class_mc == null)
      {
	object_meta_class_mc = object_mc;
      }
    else
      {
	object_meta_class_mc = _object_aggregate_meta_class_mc;
      }

    object_mc.setMetaClass(object_meta_class_mc);
    object_mc.setSize(size);
    object_mc.inheritsFrom(mc);
    if (mc != null)
      {
	object_meta_class_mc.setAlignment(mc.getAlignmentOfInstance());
      }
    else
      {
	object_meta_class_mc.setAlignment(AlignmentOf.VOID_PTR);
      }

    enterMetaClass(object_mc);
    return object_mc;
  }

  public UnionMetaClass createUnionMetaClass(String name)
  {
    return createUnionMetaClass(name, 0, null);
  }

  public UnionMetaClass createUnionMetaClass(String name,
					     int size)
  {
    return createUnionMetaClass(name, size, null);
  }

  public UnionMetaClass createUnionMetaClass(String name,
					     int size,
					     AggregateMetaClass base)
  {
    Assert.condition(lookupMetaClass(name) == null,
		     "Attempt to create MetaClass '" + name + "' " +
		     "that has already been loaded. Try to import all " +
		     "needed nodes before loading any files");

    UnionMetaClass union_mc = new UnionMetaClass(name);

    union_mc.setMetaClass(_union_meta_class_mc);
    union_mc.setSize(size);
    union_mc.inheritsFrom(base);
    if (base != null)
      {
	union_mc.setAlignment(base.getAlignmentOfInstance());
      }
    else
      {
	union_mc.setAlignment(AlignmentOf.VOID_PTR);
      }

    enterMetaClass(union_mc);
    return union_mc;
  }

  /**
   * Find a meta class by name.
   * Return a null pointer if not found.
   * @param metaClassName the name of the meta class
   */
  public MetaClass findMetaClass(String metaClassName)
  {
    return lookupMetaClass(metaClassName);
  }

  public MetaClass lookupMetaClass(String name)
  {
    MetaClass metaClass = null;
    HashMap.Iterator iter = _meta_class_dictionary.find(name);
    HashMap.Iterator end = _meta_class_dictionary.end();
    if (iter.notEqual(end))
      {
	HashMap.Pair p = (HashMap.Pair) _meta_class_dictionary.at(name);
	metaClass = (MetaClass) p.second;
      }

    return metaClass;
  }

  /**
   * Find an aggregate meta class by name.
   * @param metaClassName the name of the meta class
   */
  public AggregateMetaClass findAggregateMetaClass(String metaClassName)
  {
    MetaClass mc = findMetaClass(metaClassName);   
    if (mc != null)
      {
	Assert.condition(mc.isKindOf(AggregateMetaClass.getClassName()));
      }

    return (AggregateMetaClass) mc;
  }

  /**
   * Find an union meta class by name.
   * @param metaClassName the name of the meta class
   */
  public UnionMetaClass findUnionMetaClass(String metaClassName)
  {
    MetaClass mc = findMetaClass(metaClassName);
    if (mc != null)
      {
	Assert.condition(mc.isKindOf(UnionMetaClass.getClassName()));
      }

    return (UnionMetaClass) mc;
  }

  /**
   * Creates an object instance of the meta class given by name.
   * @param metaClassName the name of the meta class
   */
  public Object createEmptyObjectByName(String metaClassName)
  {
    return createEmptyObject(findMetaClass(metaClassName));
  }

  /**
   * Creates an object instance of the meta class.
   * @param metaClass the meta class object
   */
  public Object createEmptyObject(MetaClass mc)
  {
    // Fix the meta class
    MetaClass realMC = mc;
    if (!(mc instanceof ObjectAggregateMetaClass)
	&& (mc instanceof AggregateMetaClass))
      {
	String name = mc.getInstanceName();
	String realName = CompatibleNames.getRealName(name);
	if (realName != null)
	  {
	    realMC = new ObjectAggregateMetaClass((AggregateMetaClass) mc, 
						  realName);
	  }
      }

    return createEmptyObjectInSpace(realMC, realMC.newInstance());
  }

  public Object createEmptyObjectInSpace(MetaClass mc, Object space)
  {
    if (space != null)
      {
	mc.setMetaClassOfObject(space);
      }

    return space;
  }

  public void addField(AggregateMetaClass mc, String name, MetaClass type)
  {
    addField(mc, name, type, 0);
  }

  public void addField(AggregateMetaClass mc, String name, 
		       MetaClass type, int offset)
  {
    Assert.condition(_field_mc != null);
    mc.addFieldDescription(name, _field_mc, type, offset);
  }

  public void addUnion(UnionMetaClass mc, String name, MetaClass type)
  {
    addUnion(mc, name, type);
  }

  public void addUnion(UnionMetaClass mc, String name, 
		       MetaClass type, int offset)
  {
    Assert.condition(_field_mc != null);
    mc.addUnionField(name, _field_mc, type, offset);
  }

  /**
   * Register a meta class to this object factory.
   * A unique id will be assigned to the meta class.
   * @param mc the meta class object
   */
  public void enterMetaClass(MetaClass mc)
  {
    String name = mc.getInstanceName();
    Assert.condition((name != null) && (name.length() != 0));

    int id = ++ _last_id;
    Assert.condition(id != 0);

    mc.setMetaClassId(id);
    mc.setOwningFactory(this);
    _meta_class_dictionary.enterValueAt(name, mc);
  }

  public AddressMap getRudimentaryAddressMap() 
  {
    return _rudimentary_address_map;
  }

  public int getLastId() { return _last_id; }
  public SuifEnv getSuifEnv() { return _suif_env; }
  
  public void applyToMetaClasses(MetaClassApplier applier)
  {
    HashMap.Iterator it = _meta_class_dictionary.begin();
    HashMap.Iterator end = _meta_class_dictionary.end();
    for (; it.notEqual(end); it.inc())
      {
	MetaClass m = (MetaClass) it.get().second;
	if (!applier.apply(m))
	  {
	    break;
	  }
      }
  }

  /**
   * Generic error handling.
   * Should be overridden in subclasses.
   */
  public void error(String file_name,
		    int line_number,
		    String module_name,
		    String description)
  {
    System.err.println("ERROR IN:");
    System.err.println(" FILE: " + file_name + 
		       " LINE: " + line_number +
		       " MODULE: " + module_name);
    System.err.println(description);
    Runtime.getRuntime().exit(-1);
  }

  /**
   * Generic warning handling.
   * Should be overridden in subclasses.
   */
  public void warning(String file_name,
		      int line_number,
		      String module_name,
		      String description)
  {
    System.err.println("WARNING IN:");
    System.err.println(" FILE: " + file_name + 
		       " LINE: " + line_number +
		       " MODULE: " + module_name);
    System.err.println(description);
  } 

  /**
   * Generic information handling.
   * Should be overridden in subclasses.
   */
  public void information(String file_name,
			  int line_number,
			  String module_name,
			  String description)
  {
    System.err.println("INFORMATION:");
    System.err.println(" FILE: " + file_name + 
		       " LINE: " + line_number +
		       " MODULE: " + module_name);
    System.err.println(description);
  }   

  public static boolean isAList(MetaClass mc)
  {
    String instanceName = mc.getInstanceName();
    String magicStart = "LIST:";
    return instanceName.startsWith(magicStart);
  }

  // debugging stuff
  public void printContents()
  {
    HashMap.Iterator it = _meta_class_dictionary.begin();
    
    System.out.println("-------- MetaClass Dictionary -------");
    while (it.notEqual(_meta_class_dictionary.end()))
      {
	System.out.println(it.get().first + " " + it.get().second);
	it.inc();
      }

    System.out.println("-------------- end ------------------");
  }

  /**
   * Initialize the object factory.
   * @param suif_env the SUIF environment.
   */
  public void init(SuifEnv suif_env)
  {
    _suif_env = suif_env;

    // this is important since create_object_meta_class() uses it!!
    _object_aggregate_meta_class_mc = null;
    _object_aggregate_meta_class_mc = 
      createObjectMetaClass(ObjectAggregateMetaClass.getClassName(),
			    SizeOf.OBJECT_AGGREGATE_META_CLASS);
    
    _aggregate_meta_class_mc = 
      createObjectMetaClass(AggregateMetaClass.getClassName(),
			    SizeOf.AGGREGATE_META_CLASS);

    _object_aggregate_meta_class_mc.inheritsFrom(_aggregate_meta_class_mc);

    AggregateMetaClass metaClassMC =
      createObjectMetaClass(MetaClass.getClassName(),
			    SizeOf.META_CLASS);

    _aggregate_meta_class_mc.inheritsFrom(metaClassMC);

    _pointer_meta_class_mc = 
      createObjectMetaClass(PointerMetaClass.getClassName(),
			    SizeOf.POINTER_META_CLASS, metaClassMC);

    PointerMetaClass pointerToAggregateMetaClassMCReference =
      getPointerMetaClass(_aggregate_meta_class_mc, false);

    // make pointers to MetaClass meta class
    PointerMetaClass pointerToMetaClassMCOwning =
      getPointerMetaClass(metaClassMC);

    PointerMetaClass pointerToMetaClassMCReference =
      getPointerMetaClass(metaClassMC, false);

    // make the basic integer data types
    _integer_meta_class_mc =
      createObjectMetaClass(IntegerMetaClass.getClassName(),
			    SizeOf.INTEGER_META_CLASS, metaClassMC);

    getIntegerMetaClass("long", SizeOf.LONG, true, AlignmentOf.LONG);

    IntegerMetaClass intMC = 
      getIntegerMetaClass("int", SizeOf.INT, true, AlignmentOf.INT);

    getIntegerMetaClass("short", SizeOf.SHORT, true, AlignmentOf.SHORT);
    getIntegerMetaClass("char", SizeOf.CHAR, true, AlignmentOf.CHAR);
    getIntegerMetaClass("double", SizeOf.DOUBLE, true, AlignmentOf.DOUBLE);

    IntegerMetaClass boolMC = getBooleanMetaClass("bool");

    IntegerMetaClass sizeTMC = 
      getIntegerMetaClass("size_t", SizeOf.SIZE_T, false, AlignmentOf.SIZE_T);

    // meta class for IInteger
    IIntegerMetaClass IIntegerMC = new IIntegerMetaClass("IInteger");
    IIntegerMC.setMetaClass(metaClassMC);
    enterMetaClass(IIntegerMC);

    // make the string data types
    StringMetaClass stringMC = new StringMetaClass("String");
    stringMC.setMetaClass(metaClassMC);
    enterMetaClass(stringMC);

    LStringMetaClass lStringMC = new LStringMetaClass("LString");
    lStringMC.setMetaClass(metaClassMC);
    enterMetaClass(lStringMC);

    // make the generic object data type
    AggregateMetaClass objectMC =
      createObjectMetaClass(GenericObject.getClassName(),
			    SizeOf.GENERIC_OBJECT);

    objectMC.setAlignment(AlignmentOf.GENERIC_OBJECT);

    getPointerMetaClass(objectMC, true);
    getPointerMetaClass(objectMC, false);

    _field_mc = 
      createAggregateMetaClass("AggregateMetaClass::FieldDescription",
			       SizeOf.FIELD_DESCRIPTION, null, false);

    addField(_field_mc, "offset", intMC, 
	     FieldDescription.get_offset_offset());
    addField(_field_mc, "metaClass", pointerToMetaClassMCReference,
	     FieldDescription.get_metaClass_offset());
    addField(_field_mc, "memberName", lStringMC,
	     FieldDescription.get_memberName_offset());

    // make the MetaClass meta class
    metaClassMC.inheritsFrom(objectMC);

    addField(metaClassMC, "_meta_class_name", lStringMC, 
	     MetaClass.get__meta_class_name_offset());

    addField(metaClassMC, "_size", sizeTMC, 
	     MetaClass.get__size_offset());
    
    // make the list meta class 
    _list_meta_class_mc = 
      createObjectMetaClass(ListMetaClass.getClassName(),
			    SizeOf.LIST_META_CLASS, metaClassMC);

    addField(_list_meta_class_mc, "_element_meta_class", 
	     pointerToMetaClassMCReference, 
	     ListMetaClass.get__element_meta_class_offset());
    
    // preserve the original registration order
    enterMetaClass(_field_mc);

    // make the meta class for AggregateMetaClasses
    PointerMetaClass pointerToFieldDescriptionMCOwning = 
      getPointerMetaClass(_field_mc, true);

    STLMetaClass stlMetaClass =
      getSTLMetaClass("LIST:suif_vector<FieldDescription*>", 
		      new STLDescriptor(pointerToFieldDescriptionMCOwning,
					SizeOf.VECTOR));

    PointerMetaClass basePtr = pointerToAggregateMetaClassMCReference;
    PointerMetaClass fieldsPtr = getPointerMetaClass(stlMetaClass, true, true);

    addField(_aggregate_meta_class_mc, "_base_class", basePtr,
	     AggregateMetaClass.get__base_class_offset());
    addField(_aggregate_meta_class_mc, "_fields", fieldsPtr,
	     AggregateMetaClass.get__fields_offset());

    AggregateMetaClass lstring_pair_mc = 
      createAggregateMetaClass("VirtualFieldDescription::mapField", 
			       VirtualFieldDescription.value_type_size());

    addField(lstring_pair_mc, "first", lStringMC, 
	     VirtualFieldDescription.get_first_offset());
    addField(lstring_pair_mc, "second", lStringMC,
	     VirtualFieldDescription.get_second_offset());

    STLMetaClass virtual_field_description_mc =
      getSTLMetaClass("LIST:suif_map<LString, LString>", 
		      new STLDescriptor(lstring_pair_mc, SizeOf.MAP));

    PointerMetaClass virtualFieldDescrPtr = 
      getPointerMetaClass(virtual_field_description_mc, true, true);

    addField(_aggregate_meta_class_mc, 
	     "_virtual_field_description", virtualFieldDescrPtr, 
	     AggregateMetaClass.get__virtual_field_description_offset());
    
    // make the union meta class
    _union_meta_class_mc = 
      createObjectMetaClass(UnionMetaClass.getClassName(),
			    SizeOf.UNION_META_CLASS,
			    _aggregate_meta_class_mc);

    PointerMetaClass stlPtr = getPointerMetaClass(stlMetaClass, true, true);   

    addField(_union_meta_class_mc, "_tag_offset", intMC,
	     UnionMetaClass.get__tag_offset_offset());
    addField(_union_meta_class_mc, "_union_fields", stlPtr,
	     UnionMetaClass.get__union_fields_offset());

    // make the pointer meta class
    addField(_pointer_meta_class_mc, "_base_type",
	     pointerToMetaClassMCReference,
	     PointerMetaClass.get__base_type_offset());
    addField(_pointer_meta_class_mc, "_pointer_owns_object", 
	     boolMC, PointerMetaClass.get__pointer_owns_object_offset());
    addField(_pointer_meta_class_mc, "_is_static", 
	     boolMC, PointerMetaClass.get__is_static_offset());
    addField(_pointer_meta_class_mc, "_needs_cloning", 
	     boolMC, PointerMetaClass.get__needs_cloning_offset());

    // make the integer meta class
    addField(_integer_meta_class_mc, "_is_signed", 
	     boolMC, IntegerMetaClass.get__is_signed_offset());

    // make the object factory meta class
    AggregateMetaClass metaClassObjectFactory =
      createObjectMetaClass("ObjectFactory", SizeOf.OBJECT_FACTORY, objectMC);

    AggregateMetaClass mapMC = 
      createAggregateMetaClass("ObjectFactory::mapField", 
			       MetaClassDictionary.value_type_size());

    addField(mapMC, "first", lStringMC,
	     MetaClassDictionary.get_first_offset());
    addField(mapMC, "second", pointerToMetaClassMCOwning,
	     MetaClassDictionary.get_second_offset());

    STLMetaClass mapMetaClassMC =
      getSTLMetaClass("LIST:suif_hash_map<LString, MetaClass*>", 
		      new STLDescriptor(mapMC, SizeOf.HASH_MAP));

    PointerMetaClass mapMetaClassMCOwning =
      getPointerMetaClass(mapMetaClassMC, true, true);

    addField(metaClassObjectFactory,
	     "_meta_class_dictionary", mapMetaClassMCOwning, 
	     ObjectFactory.get__meta_class_dictionary_offset());
    
    setMetaClass(metaClassObjectFactory);

    // make the rudimentary address map
    SuifOutputStream o = 
      new SuifBinaryOutputStream(new ByteArrayOutputStream());

    o.write(new ObjectWrapper(this, getMetaClass()), false);
    o.writeClose();

    _rudimentary_address_map = o.getAddressMapOfOwnedObjects();
    _rudimentary_address_map.removeFromAddressMap(_meta_class_dictionary);

//      _rudimentary_address_map.print(System.out);
  }
}

