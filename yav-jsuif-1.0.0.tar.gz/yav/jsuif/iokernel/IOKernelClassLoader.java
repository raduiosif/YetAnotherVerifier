/*
 * IOKernelClassLoader.java - A restricted class loader used to find the 
 *                            java.lang.Class objects that correspond to
 *                            the JSUIF meta classes
 *
 */

package yav.jsuif.iokernel;


public class IOKernelClassLoader extends ClassLoader
{
  private static String[] _packageList = {
    "yav.jsuif.nodes.basic",
    "yav.jsuif.nodes.suif",
    "yav.jsuif.nodes.osuif",
    "yav.jsuif.iokernel",
    "yav.jsuif.kernel",
    "yav.jsuif.common"
  };

  protected Class loadClass(String name, boolean resolve)
    throws ClassNotFoundException
  {
    try {
      return super.loadClass(name, resolve);
    } catch (ClassNotFoundException e) {}

    for (int i = 0; i < _packageList.length; i ++)
      {
	try {
	  return super.loadClass(_packageList[i] + "." + name, resolve);
	} catch (ClassNotFoundException e) {}
      }

    throw new ClassNotFoundException(name);
  }
}
