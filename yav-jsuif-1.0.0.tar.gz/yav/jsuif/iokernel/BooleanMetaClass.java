/*
 * BooleanMetaClass.java - We need this because Java treats booleans 
 *                         different than integers
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class BooleanMetaClass extends IntegerMetaClass
{
  private static final String _className = "BooleanMetaClass";

  public static String getClassName() { return _className; }

  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    int value = ((Boolean) obj.get()).booleanValue() ? 1 : 0;
    stream.writeSizedInt(value, getSizeOfInstance(), isSigned());
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    int value = stream.readSizedInt(getSizeOfInstance(), isSigned());
    obj.set(new Boolean(value == 0 ? false : true));
  }

  public BooleanMetaClass() { this(""); }

  public BooleanMetaClass(String name) { super(name); }
}
