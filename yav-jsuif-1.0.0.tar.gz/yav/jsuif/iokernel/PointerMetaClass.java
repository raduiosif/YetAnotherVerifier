/*
 * PointerMetaClass.java - A port of basesuif/iokernel/pointer_meta_class.h
 *                         to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.PString;
import yav.jsuif.common.Vector;


public class PointerMetaClass extends MetaClass
{
  private static final String _className = "PointerMetaClass";

  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public MetaClass _base_type;

  public MetaClass getBaseType() { return _base_type; }
  public static native int get__base_type_offset();

  private MetaClass _ptr_to_base_type;

  // FieldDescription.buildObject() needs public access to this field
  public boolean _pointer_owns_object;

  public boolean isOwningPointer() { return _pointer_owns_object; }
  public static native int get__pointer_owns_object_offset();

  // FieldDescription.buildObject() needs public access to this field
  public boolean _is_static;

  public static native int get__is_static_offset();

  // FieldDescription.buildObject() needs public access to this field
  public boolean _needs_cloning;

  public boolean needsCloning() { return _needs_cloning; }
  public static native int get__needs_cloning_offset();

  public Object newInstance() { return null; }
  
  public void write(ObjectWrapper obj, OutputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    PointerWrapper ptr_obj = new PointerWrapper(obj);
    if (_pointer_owns_object)
      {
	if (_is_static)
	  {
	    stream.writeStaticPointer(ptr_obj);
	  }
	else
	  {
	    stream.writeOwningPointer(ptr_obj);
	  }
      }
    else
      {
	if (_needs_cloning)
	  {
	    stream.writeDefiningPointer(ptr_obj);
	  }
	else
	  {
	    stream.writeReference(ptr_obj);
	  }
      }
  }

  public void read(ObjectWrapper obj, InputStreamer stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    PointerWrapper ptr_obj = new PointerWrapper(obj);
    if (_needs_cloning)
      {
	stream.readDefiningPointer(ptr_obj);
      }
    else
      {
	if (_pointer_owns_object)
	  {
	    if (_is_static)
	      {
		stream.readStaticPointer(ptr_obj);
	      }
	    else
	      {
		stream.readOwningPointer(ptr_obj);
	      }
	  }
	else
	  {
	    stream.readReference(ptr_obj);
	  }
      }

    obj.set(ptr_obj.get());
  }

  public Iterator getIterator(Object instance)
  {
    return getIterator(instance, Iterator.ALL);
  }

  public Iterator getIterator(Object instance, int contents)
  {
    if ((_pointer_owns_object && (contents != Iterator.REFERENCED)) ||
	(!_pointer_owns_object && (contents == Iterator.REFERENCED)))
      {
	if (instance != null)
	  {
	    MetaClass metaClass = _base_type.getMetaClass(instance);
	    if (metaClass == null)
	      {
		metaClass = _base_type;
	      }

	    return new SingleElementIterator(instance, metaClass);
	  }
      }

    return null;
  }

  public void initialize(ObjectWrapper obj, SuifInputStream stream)
  {
    Assert.condition(obj.getMetaClass() == this);

    Object instance = obj.get();
    if (_pre_init != null)
      {
	_pre_init.invoke(obj, true, stream);
      }
    
//      System.out.print(instance + " ");
//      System.out.println("pointer init> "
//  		       + _is_static + " "
//  		       + _pointer_owns_object + " "
//  		       + stream.existsInInputStream(instance) + " "
//  		       + stream.wasAlreadyVisited(instance));

    if (_is_static ||
	(_pointer_owns_object && 
	 stream.existsInInputStream(instance) &&
	 (!stream.wasAlreadyVisited(instance))))
      {
	if (!_is_static)
	  {
	    stream.setAlreadyVisited(instance);
	  }

	MetaClass mc = getBaseType().getMetaClass(instance);
	mc.initialize(new ObjectWrapper(instance, mc), stream);
      }

    if (_post_init != null)
      {
	_post_init.invoke(obj, true, stream);
      }
  }

  public boolean isElementary() { return false; }

  public MetaClass getLinkMetaClass()
  {
    if (_ptr_to_base_type == null)
      {
	MetaClass lnk = _base_type.getLinkMetaClass();
	if (lnk != null)
	  {
	    _ptr_to_base_type = 
	      _owning_factory.getPointerMetaClass(lnk, _pointer_owns_object);
	  }
      }

    return _ptr_to_base_type;
  }

  public VirtualNode getVirtualNode(String name, String what)
  {
    if (what.length() == 0)
      {
	return null;
      }

    PString spec = new PString(what);
    String current_member = cutOff(spec, '/');
    if (current_member.equals("*"))
      {
	Vector members = new Vector();
	VirtualNode cont = _base_type.getVirtualNode(name, spec.get());
	members.pushBack(new AggregateElement(_base_type, "", cont));
	return new PointerVirtualNode(new AggregateVirtualNode(members));
      }

    return null;
  }

  public int walk(Object address, Walker walk)
  {
    MetaClass link = getBaseType();
    if (address == null || walk.isChanged(address))
      {
	return Walker.CONTINUE;
      }

    if (walk.isWalkable(address, _pointer_owns_object, link))
      {
	return link.walk(address, walk);
      }

    return Walker.CONTINUE;
  }

  public void walkReferencedMetaClasses(MetaClassApplier x)
  {
    if (_ptr_to_base_type != null)
      {
	x.apply(_ptr_to_base_type);
      }
  }

  static {
    System.loadLibrary("jsuif");
  }

  
  protected PointerMetaClass() { this("", null, false, false, false); }

  protected PointerMetaClass(String name) 
  { 
    this(name, null, false, false, false);
  }

  protected PointerMetaClass(String name, MetaClass baseType)
  {
    this(name, baseType, false, false, false);
  }

  protected PointerMetaClass(String name, 
			     MetaClass baseType, 
			     boolean pointerOwnsObject)
  {
    this(name, baseType, pointerOwnsObject, false, false);
  }

  protected PointerMetaClass(String name,
			     MetaClass baseType,
			     boolean pointerOwnsObject,
			     boolean isStatic)
  {
    this(name, baseType, pointerOwnsObject, isStatic, false);
  }

  protected PointerMetaClass(String name,
			     MetaClass baseType,
			     boolean pointerOwnsObject,
			     boolean isStatic,
			     boolean needsCloning)
  {
    super(name);
    
    _base_type = baseType;
    _ptr_to_base_type = null;
    _pointer_owns_object = pointerOwnsObject;
    _is_static = isStatic;
    _needs_cloning = needsCloning;

    Assert.condition(!_is_static || (_is_static && _pointer_owns_object));
  }
}
