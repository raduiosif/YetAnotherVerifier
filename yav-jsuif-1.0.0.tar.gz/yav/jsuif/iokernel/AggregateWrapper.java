/*
 * AggregateWrapper.java - A port of basesuif/iokernel/aggregate_wrapper.h
 *                         to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import java.lang.reflect.Field;


public class AggregateWrapper extends ObjectWrapper
{
  public AggregateWrapper(Object address, AggregateMetaClass mc)
  {
    super(address, mc);
  }

  public AggregateWrapper(ObjectWrapper obj)
  {
    Assert.condition(obj._meta_class instanceof AggregateMetaClass);

    _address = obj._address;
    _meta_class = obj._meta_class;
    _field = obj._field;
    _index = obj._index;
  }

  public AggregateWrapper(AggregateWrapper other)
  {
    Assert.condition(other._meta_class instanceof AggregateMetaClass);

    _address = other._address;
    _meta_class = other._meta_class;
    _field = other._field;
    _index = other._index;
  }


  public int getFieldCount()
  {
    if (isNull())
      {
	return 0;
      }

    if (_meta_class.isKindOf(UnionMetaClass.getClassName()))
      {
	return 1;
      }

    return ((AggregateMetaClass) _meta_class).getFieldCount();
  }

  public FieldDescription getFieldDescription(int id)
  {
    if (id >= getFieldCount())
      {
	return null;
      }

    if (_meta_class.isKindOf(UnionMetaClass.getClassName()) && (id != 0))
      {
	return null;
      }

    return ((AggregateMetaClass) _meta_class).getFieldDescription(id);
  }

  public FieldDescription getFieldDescription(String name)
  {
    return ((AggregateMetaClass) _meta_class).getFieldDescription(name);
  }

  public boolean hasField(String name)
  {
    return (getFieldDescription(name) != null);
  }

  public boolean isNull()
  {
    return (_address == null);
  }

  public static boolean isAggregate(ObjectWrapper obj)
  {
    MetaClass mc = obj.getMetaClass();
    return (mc.isKindOf(AggregateMetaClass.getClassName()));
  }
}
