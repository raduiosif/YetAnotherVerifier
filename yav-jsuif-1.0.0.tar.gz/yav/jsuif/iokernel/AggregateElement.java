/*
 * AggregateElement.java - 
 *
 *
 */

package yav.jsuif.iokernel;


class AggregateElement 
{
  public String _name;
  public MetaClass _meta_class;
  public VirtualNode _continuation;
  public boolean _cont_owned;

  public AggregateElement(MetaClass meta_class,
			  String name)
  {
    this(meta_class, name, null);
  }

  public AggregateElement(MetaClass meta_class,
			  String name,
			  VirtualNode continuation)
  {
    this(meta_class, name, null, true);
  }

  public AggregateElement(MetaClass meta_class,
			  String name,
			  VirtualNode continuation,
			  boolean cont_owned)
  {
    _name = name;
    _meta_class = meta_class;
    _continuation = continuation;
    _cont_owned = cont_owned;
  }


  private FieldDescription _field = null;

  public Object getObject(Object base)
  {
    if (_field == null)
      {
	return base;
      }
    
    return _field.buildObject(base, _meta_class).get();
  }

  public void setObject(Object base, Object x)
  {
    if (_field == null)
      {
	return;
      }

    _field.buildObject(base, _meta_class).set(x);
  }


  public AggregateElement(FieldDescription field)
  {
    this(field, null, true);
  }

  public AggregateElement(FieldDescription field,
			  VirtualNode continuation)
  {
    this(field, continuation, true);
  }

  public AggregateElement(FieldDescription field,
			  VirtualNode continuation,
			  boolean cont_owned)
  {
    _field = field;
    _name = field.getMemberName();
    _meta_class = field.getMemberMetaClass();
    _continuation = continuation;
    _cont_owned = cont_owned;
  }
}
