/*
 * InitializerFunction.java - A port of basesuif/iokernel/meta_class.h
 *                            to Java.
 *
 */

package yav.jsuif.iokernel;


interface InitializerFunction
{
  void invoke(ObjectWrapper obj, boolean is_owned, SuifInputStream stream);
}
