/*
 * CloneStream.java - A port of basesuif/iokernel/clone_stream.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.common.Vector;
import yav.jsuif.common.Map;


class IntStream 
{
  private final int QUANTA = 1024;

  private int[] _stream;

  private int _start;
  private int _end;
  private int _length;


  IntStream()
  {
    _stream = new int[QUANTA];
    _start = 0;
    _end = 0;
    _length = 0;
  }


  void put(int x)
  {
    if (_length == _stream.length)
      {
	int[] old = _stream;
	_stream = new int[_length + QUANTA];
	for (int i = 0; i < _length; i ++)
	  {
	    _stream[i] = old[_start + i];
	  }
      }

    _stream [_end ++] = x;
    _length ++;
  }

  int get()
  {
    if (_length == 0)
      {
	return -1;
      }

    if (_length == (_stream.length - QUANTA))
      {
	int[] old = _stream;
	_stream = new int[_length];
	for (int i = 0; i < _length; i ++)
	  {
	    _stream[i] = old[_start + i];
	  }

	_start = 0;
	_end = _length - 1;
      }

    _length --;
    return _stream [_start ++];
  }

  boolean end() { return (_length == 0); }
}


class CloneOutputStream extends SuifOutputStream
{
  private OutputStreamer _output_stream;

  // redirect some of the interface calls
  public void writeByte(int b) { _output_stream.writeByte(b); }

  public void writeStaticPointer(PointerWrapper ptr_obj) 
  { 
    _output_stream.writeStaticPointer(ptr_obj);
  }

  public void writeDefiningPointer(PointerWrapper ptr_obj)
  {
    _output_stream.writeDefiningPointer(ptr_obj);
  }

  public void writeOwningPointer(PointerWrapper ptr_obj)
  {
    _output_stream.writeOwningPointer(ptr_obj);
  }

  public void writeReference(PointerWrapper ptr_obj)
  {
    _output_stream.writeReference(ptr_obj);
  }
  

  public CloneOutputStream(OutputStreamer output_stream)
  {
    _output_stream = output_stream;
  }
}


public class CloneStream extends SuifInputStream implements OutputStreamer
{
  public static final int ENQUIRE_PTR = 0;
  public static final int NULL_PTR = 1;
  public static final int COPY_PTR = 2;
  public static final int CLONE_PTR = 3;
  
  public static final int NO_PTR = 4;
  public static final int REF_PTR = 5;
  public static final int DEFINE_PTR = 6;
  public static final int OWN_PTR = 7;

  private int _refed_objects;
  private int _defined_objects;
  private int _owned_objects;

  protected HashMap _clone_table;
  protected Vector _work_list;
  protected Map _id_map;
  protected int _last_id;

  private IntStream _object_buffer;
  private boolean _is_open;

  private ObjectFactory _of;
  private SuifOutputStream _output_stream;


  public CloneStream(ObjectFactory of)
  { 
    super(of);

    _clone_table = null;
    _work_list = null;
    _id_map = null;
    _last_id = 0;
    _object_buffer = null;
    _refed_objects = ENQUIRE_PTR;
    _defined_objects = ENQUIRE_PTR;
    _owned_objects = ENQUIRE_PTR;
    _is_open = false;
    _of = of;
    _output_stream = new CloneOutputStream(this);
  }


  public GenericObject clone(GenericObject object)
  {
    return (GenericObject) clone((Object) object, object.getMetaClass());    
  }

  public Object clone(Object instance, MetaClass mc)
  {
    open();
    pushForClone(instance, mc);
    performCloning();
    Object o = ((CloneStreamObjectInstance) _work_list.at(0)).getNewAddress();
    close();
    return o;
  }

  public void open()
  {
    if (!_is_open)
      {
	_clone_table = new HashMap();
	_work_list = new Vector();
	_id_map = new Map();
	_object_buffer = new IntStream();
      }

    _is_open = true;
  }

  public void close()
  {
    if (!_is_open)
      {
	return;
      }

    readClose();
   
    _work_list = null;
    _clone_table = null;
    _id_map = null;
    _object_buffer = null;
    _is_open = false;
  }

  public boolean getIsOpen() { return _is_open; }

  public void pushForClone(GenericObject object)
  {
    pushForClone((Object) object, object.getMetaClass());
  }

  public void pushForClone(Object instance, MetaClass mc)
  {
    CloneStreamObjectInstance ob = findOrAddObject(instance, mc);
    ob.setRefKind(CLONE_PTR);
    ob.clearIsOrphan();
  }

  public void pushForReplacement(GenericObject old_obj, GenericObject new_obj)
  {
    MetaClass meta_class = old_obj.getMetaClass();
    CloneStreamObjectInstance ob = findOrAddObject(old_obj, meta_class);
    ob.setNewAddress(new_obj);
    ob.setRefKind(COPY_PTR);
  }

  public void performCloning()
  {
    int pos = 0;

    // start by writing out all objects       
    boolean changed = true;
    while (changed)
      {
	pos = 0;
	changed = false;
	while (pos < _work_list.length())
	  {
	    CloneStreamObjectInstance next = 
	      (CloneStreamObjectInstance) _work_list.at(pos);

	    if (next.getRefKind() == ENQUIRE_PTR)
	      {
		objectEnquiry((GenericObject) next.getOldAddress(), 
			      next, next.getPtrType());
		Assert.condition(next.getRefKind() != ENQUIRE_PTR);
	      }

	    if ((next.getRefKind() == CLONE_PTR)
		&& !next.getIsWritten())
	      {
		MetaClass mc = next.getMetaClass();
		next.setIsWritten();
		mc.write(new ObjectWrapper(next.getOldAddress(), mc), this);
		changed = true;
	      }

	    pos ++;
	  }
      }

    // allocate memory
    pos = 0;
    while (pos < _work_list.length())
      {
	CloneStreamObjectInstance next =
	  (CloneStreamObjectInstance) _work_list.at(pos);

	if ((next.getRefKind() == CLONE_PTR)
	    && (next.getNewAddress() == null))
	  {
	    MetaClass mc = next.getMetaClass();
	    Object addr = mc.cloneObject(next.getOldAddress());

	    next.setNewAddress(addr);
	    _clone_table.enterValueAt(addr, next);	    
	  }
	else
	  if (next.getNewAddress() != null)
	    {
	      _clone_table.enterValueAt(next.getNewAddress(), next);
	    }

	pos ++;
      }

    // now read all the objects back in
    pos = 0;
    while (pos < _work_list.length())
      {
	CloneStreamObjectInstance next =
	  (CloneStreamObjectInstance) _work_list.at(pos);

	if (next.getIsWritten())
	  {
	    MetaClass mc = next.getMetaClass();
	    Object addr = next.getNewAddress();
	    MetaClass new_mc = (MetaClass) cloneAddress((Object) mc);
	    if (new_mc != null)
	      {
		mc = new_mc;
	      }
	    
	    mc.read(new ObjectWrapper(addr, mc), this);
	    if (!next.getIsVisited())
	      {
		ObjectWrapper root = new ObjectWrapper(addr, mc);
		_root_objects.pushBack(root);
	      }
	  }

	pos ++;
      }

    // finally, call the routine for orphans
    pos = 0;
    while (pos < _work_list.length())
      {
	CloneStreamObjectInstance next =
	  (CloneStreamObjectInstance) _work_list.at(pos);

	if (next.getIsOrphan() && next.getIsWritten())
	  {
	    finishOrphanObjectCloning(next.getOldAddress(),
				      next.getNewAddress(),
				      next.getMetaClass());
	  }

	pos ++;
      }
  }

  public boolean isCloned(Object addr)
  {
    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.notEqual(_clone_table.end()))
      {
	return !((CloneStreamObjectInstance) iter.get().second).getIsWritten();
      }

    return false;
  }

  public Object cloneAddress(Object addr)
  {
    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.isEqual(_clone_table.end()))
      {
	return null;
      }

    if (((CloneStreamObjectInstance)iter.get().second).getOldAddress() != addr)
      {
	return null;
      }
    
    return ((CloneStreamObjectInstance) iter.get().second).getNewAddress();
  }

  public boolean getIsCloned(Object addr)
  {
    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.isEqual(_clone_table.end()))
      {
	return false;
      }

    return (((CloneStreamObjectInstance) iter.get().second).getRefKind()
	    == CLONE_PTR);
  }

  public int getCloneCount()
  {
    return _work_list.length();
  }

  public Object getOldAddress(int n)
  {
    return ((CloneStreamObjectInstance) _work_list.at(n)).getOldAddress();
  }

  public Object getNewAddress(int n)
  {
    return ((CloneStreamObjectInstance) _work_list.at(n)).getNewAddress();
  }

  public MetaClass getMetaClass(int n)
  {
    return ((CloneStreamObjectInstance) _work_list.at(n)).getMetaClass();
  }

  public boolean getIsCloned(int n)
  {
    return (((CloneStreamObjectInstance) _work_list.at(n)).getRefKind()
	    == CLONE_PTR);
  }

  public boolean getIsOrphan(int n)
  {
    return ((CloneStreamObjectInstance) _work_list.at(n)).getIsOrphan();
  }

  public void finishOrphanObjectCloning(Object old_obj, 
					Object new_obj,
					MetaClass mc) 
  {}

  public void setPointerHandling(int refed_objects,
				 int defined_objects,
				 int owned_objects)
  {
    _refed_objects = refed_objects;
    _defined_objects = defined_objects;
    _owned_objects = owned_objects;
  }

  public void setRefedObjectHandling(int h) { _refed_objects = h; }
  public int getRefedObjectHandling() { return _refed_objects; }
  
  public void setDefinedObjectHandling(int h) { _defined_objects = h; }
  public int getDefinedObjectHandling() { return _defined_objects; }

  public void setOwnedObjectHandling(int h) { _owned_objects = h; }
  public int getOwnedObjectHandling() { return _owned_objects; }

  public void objectEnquiry(GenericObject x, 
			    CloneStreamObjectInstance o, 
			    int ptr_type)
  {
    setReference(o);
  }

  public void setCloneObject(CloneStreamObjectInstance o)
  {
    o.setRefKind(CLONE_PTR);
    o.setNewAddress(null);
  }

  public void setReference(CloneStreamObjectInstance o)
  {
    o.setRefKind(COPY_PTR);
    o.setNewAddress(o.getOldAddress());
  }

  public void setReplacement(CloneStreamObjectInstance o, Object x)
  {
    o.setRefKind(COPY_PTR);
    o.setNewAddress(x);
  }

  public void setDeepClone()
  {
    setPointerHandling(COPY_PTR, CLONE_PTR, CLONE_PTR);
  }

  public void setShallowClone()
  {
    setPointerHandling(NULL_PTR, NULL_PTR, NULL_PTR);
  }

  public void setAlreadyVisited(Object addr)
  {
    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.isEqual(_clone_table.end()))
      {
	return;
      }

    ((CloneStreamObjectInstance) iter.get().second).setIsVisited();
  }

  public boolean wasAlreadyVisited(Object addr)
  {
    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.isEqual(_clone_table.end()))
      {
	return true;
      }

    return ((CloneStreamObjectInstance) iter.get().second).getIsVisited();
  }

  protected CloneStreamObjectInstance findOrAddObject(Object addr, 
						      MetaClass mc)
  {
    Assert.condition((addr != null) && (mc != null));

    HashMap.Iterator iter = _clone_table.find(addr);
    if (iter.notEqual(_clone_table.end()))
      {
	return (CloneStreamObjectInstance) iter.get().second;
      }

    CloneStreamObjectInstance inst = 
      new CloneStreamObjectInstance(addr, mc, ++ _last_id);

    _clone_table.enterValueAt(addr, inst);
    _work_list.pushBack(inst);
    _id_map.enterValueAt(new Integer(_last_id), addr);

    return inst;
  }

  private CloneStreamObjectInstance writePtr(int handling,
					     int ptr_type,
					     PointerWrapper ptr_obj)
  {
    Object addr = ptr_obj.get();
    PointerMetaClass ptr_mc = (PointerMetaClass) ptr_obj.getMetaClass();

//      System.out.println("write ptr> " + addr);

    CloneStreamObjectInstance ob = null;
    if (addr != null)
      {
	ob = findOrAddObject(addr, ptr_mc.getBaseType().getMetaClass(addr));
	ob.advanceRefKind(handling);
	ob.advancePtrType(ptr_type);
	writeUnsignedInt(ob.getId());
      }
    else
      {
	writeUnsignedInt(0);
      }

    return ob;
  }

  private void readPtr(PointerWrapper ptr_obj)
  {
    Object addr = ptr_obj.get();
    int id = readUnsignedInt();

    Map.Iterator mapit = _id_map.find(new Integer(id));
    if (mapit.isEqual(_id_map.end()))
      {
	ptr_obj.set(null);
	return;
      }

    Object old_value = mapit.get().second;
    HashMap.Iterator iter = _clone_table.find(old_value);
    if (iter.isEqual(_clone_table.end()))
      {
	ptr_obj.set(old_value);
	return;
      }

    CloneStreamObjectInstance ob = 
      (CloneStreamObjectInstance) iter.get().second;
 
    switch(ob.getRefKind())
      {
      case ENQUIRE_PTR:
	Assert.fatal();

      case NULL_PTR:
	ptr_obj.set(null);
	break;

      case COPY_PTR:
      case CLONE_PTR:
	ptr_obj.set(ob.getNewAddress());
      }

//      System.out.println("read ptr> " + ptr_obj.get());
  }

  // Implementation of the InputStreamer interface
  public int readByte() 
  { 
    return _object_buffer.get(); 
  }

  public void readStaticPointer(PointerWrapper ptr_obj) { readPtr(ptr_obj); }
  public void readDefiningPointer(PointerWrapper ptr_obj) { readPtr(ptr_obj); }
  public void readReference(PointerWrapper ptr_obj) { readPtr(ptr_obj); }
  public void readOwningPointer(PointerWrapper ptr_obj) { readPtr(ptr_obj); }

  // Implementation of the OutputStreamer interface
  public void writeByte(int b) 
  { 
    _object_buffer.put(b); 
  }
  
  public void writeStaticPointer(PointerWrapper ptr_obj)
  {
    CloneStreamObjectInstance ob = writePtr(CLONE_PTR, OWN_PTR, ptr_obj);
    ob.setIsVisited();
  }

  public void writeDefiningPointer(PointerWrapper ptr_obj)
  {
    writePtr(getDefinedObjectHandling(), DEFINE_PTR, ptr_obj);
  }

  public void writeOwningPointer(PointerWrapper ptr_obj)
  {
    CloneStreamObjectInstance ob =
      writePtr(getOwnedObjectHandling(), OWN_PTR, ptr_obj);

    if (ob != null)
      {
	ob.clearIsOrphan();
      }
  }

  public void writeReference(PointerWrapper ptr_obj)
  {
    writePtr(getRefedObjectHandling(), REF_PTR, ptr_obj);
  }

  public void writeSizedInt(int number, int instanceSize, boolean is_signed)
  {
    _output_stream.writeSizedInt(number, instanceSize, is_signed);
  }

  public void write(ObjectWrapper obj, boolean addressable)
  {
    _output_stream.write(obj, addressable);
  }

  public void writeUnsignedInt(int number)
  {
    _output_stream.writeUnsignedInt(number);
  }

  public void writeByteArray(int[] start, int len)
  {
    _output_stream.writeByteArray(start, len);
  }
}

