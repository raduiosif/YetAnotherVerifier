/*
 * SuifOutputStream.java - A port of basesuif/iokernel/object_stream.h
 *                         to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.ionative.SizeOf;


class AddressInfo
{
  public int _id;
  public boolean _exists;


  public AddressInfo(int id, boolean exists)
  {
    _id = id;
    _exists = exists;
  }
}


public abstract class SuifOutputStream 
  extends SuifObjectStream implements OutputStreamer
{
  protected int _last_id;
  protected int _last_id_max;
  protected long _bytes_written;
  protected HashMap _address_map;


  public SuifOutputStream()
  {
    _last_id = 1;
    _last_id_max = 0;
    _bytes_written = 0;
    _address_map = new HashMap();
  }


  public void writeMetaClass(MetaClass mc)
  {
    writeAddressId(mc, false);
  }

  public void writeObject(ObjectWrapper obj) { write(obj, true); }
  public void write(ObjectWrapper obj) { write(obj, true); }

  public void write(ObjectWrapper obj, boolean addressable)
  {
    Object instance = obj.get();
    MetaClass mc = obj.getMetaClass();
    if (addressable)
      {
	if (isAlreadyWritten(instance))
	  {
	    writeAddressId(instance, false);
	    return;
	  }
	else
	  {
	    if (mc instanceof PointerMetaClass)
	      {
		writeAddressId(obj, true);
	      }
	    else
	      {
		writeAddressId(instance, true);
	      }
	  }
      }

    mc.write(obj, this);
  }

  public void writeClose()
  {
    int unresolved = 0;
    HashMap.Iterator it = _address_map.begin();
    HashMap.Iterator end = _address_map.end();
    for (; it.notEqual(end); it.inc())
      {
	if (!((AddressInfo) it.get().second)._exists)
	  {
	    writeUnsignedInt(((AddressInfo) it.get().second)._id);
	    writeUnsignedInt(((Integer) it.get().first).intValue());
	    ++ unresolved;
	  }
      }

    writeUnsignedInt(unresolved);
  }

  public void writeStaticPointer(PointerWrapper ptr_obj)
  {
    Object instance = ptr_obj.get();
    PointerMetaClass pointerMC = (PointerMetaClass) ptr_obj.getMetaClass();
    MetaClass _base_type = pointerMC.getBaseType();
    if (instance != null)
      {
	writeByte(1);
	write(new ObjectWrapper(instance, _base_type), false);
      }
    else
      {
	writeByte(0);
      }
  }

  public void writeDefiningPointer(PointerWrapper ptr_obj)
  {
    writeOwningPointer(ptr_obj);
  }

  public void writeOwningPointer(PointerWrapper ptr_obj)
  {
    Object instance = ptr_obj.get();
    PointerMetaClass pointerMC = (PointerMetaClass) ptr_obj.getMetaClass();

    boolean alreadyWritten = isAlreadyWritten(instance);
    writeAddressId(instance, !alreadyWritten);
    if (alreadyWritten)
      {
	return;
      }

    MetaClass realMC = pointerMC.getBaseType().getMetaClass(instance);
    writeMetaClass(realMC);
    if (instance != null)
      {
	write(new ObjectWrapper(instance, realMC), false);
      }
  }

  public void writeReference(PointerWrapper ptr_obj)
  {
    writeOwningPointer(ptr_obj);
  }

  public void writeAddressId(Object address, boolean input)
  {
    int id = mapAddressToId(address, input);
    if (id == _last_id)
      {
	if (_last_id_max == id - 1)
	  {
	    _last_id_max = id;
	    writeUnsignedInt(1);
	    return;
	  }

	_last_id_max = id;
      }

    writeUnsignedInt(id);
  }

  public void writeUnsignedInt(int number)
  {
    writeSizedInt(number, SizeOf.INT, false);
  }

  // TODO: come up with something to do unsigned int stuff
  public void writeSizedInt(int number, int instanceSize, boolean is_signed)
  {
//      System.out.println("writeSizedInt> " + number);

    /*
     * Writing is done in network order.
     * The less significant byte is written
     * at the biggest file offset.
     */
    int currentInstance = number;
    int sizeOfBytesToWrite = instanceSize;
    boolean isCurrentIntSigned = 
      is_signed && ((currentInstance & IS_BYTE_SIGNED_BIT) != 0);
    int fillByte = isCurrentIntSigned ? SIGNED_BYTE_FILL : 0;    
    for (;;)
      {
	int bitpos = (sizeOfBytesToWrite - 1) * 8;
	if (sizeOfBytesToWrite == 0 || 
	    (currentInstance & (0xff << bitpos)) != fillByte)
	  {
	    break;
	  }

	currentInstance &= ~(0xff << bitpos);
	sizeOfBytesToWrite --;
      }

    if ((sizeOfBytesToWrite == 0) && !isCurrentIntSigned)
      {
	writeByte(0);
	return;
      }

    if ((sizeOfBytesToWrite == 1) && !isCurrentIntSigned &&
	((currentInstance & IS_BYTE_SIGNED_BIT) == 0))
      {
	writeByte(currentInstance);
	return;
      }

    Assert.condition((sizeOfBytesToWrite & NORMAL_INT_LENGTH_MASK)
		     == sizeOfBytesToWrite, "write length exceeds");

    int size_val = sizeOfBytesToWrite | NORMAL_INT_BIT;
    if (isCurrentIntSigned)
      {
	size_val |= NORMAL_INT_SIGN_BIT;	
      }
    
    writeByte(size_val);
    while (sizeOfBytesToWrite != 0)
      {
	int bitpos = (sizeOfBytesToWrite - 1) * 8;
	writeByte((currentInstance & (0xff << bitpos)) >> bitpos);
	sizeOfBytesToWrite --;
      }
  }

  public void writeByteArray(int[] start, int len)
  {
    for (int i = 0; i < len; i ++)
      {
	writeByte(start[i]);
      }
  }

  public AddressMap getAddressMapOfOwnedObjects()
  {
    AddressMap m = new AddressMap();
    HashMap.Iterator current = _address_map.begin();
    HashMap.Iterator end = _address_map.end();
    while (current.notEqual(end))
      {
	if (((AddressInfo) current.get().second)._exists)
	  {
	    int id = ((AddressInfo) current.get().second)._id;
	    Object address = current.get().first;
	    m.add(id, address);
	  }

	current.inc();
      }

    return m;
  }

  public void addAddressPair(int id, Object address)
  {
    Assert.condition((id != 0) && (id != 1), "invalid id (" + id + ")");
    _address_map.enterValue(address, new AddressInfo(id, true));
    _last_id = (id > _last_id) ? id : _last_id;
  }

  public boolean isAlreadyWritten(Object address)
  {
    if (address == null)
      {
	return true;
      }

    HashMap.Iterator it = _address_map.find(address);
    if (it.isEqual(_address_map.end()))
      {
	return false;
      }

    return ((AddressInfo) it.get().second)._exists;
  }

  protected int mapAddressToId(Object address, boolean input)
  {
    if (address == null)
      {
	return 0;
      }

    HashMap.Iterator it = _address_map.find(address);
    if (it.isEqual(_address_map.end()))
      {
	AddressInfo info = new AddressInfo(++ _last_id, input);
	_address_map.enterValue(address, info);

//  	System.out.println("--> map " + address + " to " + _last_id);

	return info._id;
      }
    else
      {
	Assert.condition(!(((AddressInfo) it.get().second)._exists & input));
	((AddressInfo) it.get().second)._exists |= input;
	return ((AddressInfo) it.get().second)._id;
      }
  }
}
