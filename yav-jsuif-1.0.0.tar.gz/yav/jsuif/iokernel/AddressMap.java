/*
 * AddressMap.java - A port of basesuif/iokernel/object_stream.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Map;
import java.io.PrintStream;


public class AddressMap
{
  private Map _address_map;


  public AddressMap() 
  {
    _address_map = new Map();
  }


  public void add(int id, Object address) 
  {
    _address_map.enterValue(new Integer(id), address);
  }

  public void addToStream(SuifObjectStream object_stream)
  {
    Map.Iterator current = _address_map.begin();
    Map.Iterator end = _address_map.end();
    while (current.notEqual(end))
      {
	int id = ((Integer) current.get().first).intValue();
	Object address = current.get().second;
	object_stream.addAddressPair(id, address);
	current.inc();
      }
  }

  public void removeFromAddressMap(Object address)
  {
    Map.Iterator current = _address_map.begin();
    Map.Iterator end = _address_map.end();
    while (current.notEqual(end))
      {
	if (current.get().second == address)
	  {
	    _address_map.erase(current);
	    break;
	  }

	current.inc();
      }
  }

  public void print(PrintStream o)
  {
    Map.Iterator current = _address_map.begin();
    Map.Iterator end = _address_map.end();
    
    o.println("--- ADRESSMAP CONTENTS ---");
    while (current.notEqual(end))
      {
	o.println("ID: " + current.get().first +
		  " ADDRESS: " + current.get().second);
	current.inc();
      }
    o.println("--------- END -----------");
  }
}
