/*
 * InputStreamer.java - An InputStream interface.
 *
 */

package yav.jsuif.iokernel;


public interface InputStreamer
{
  int readByte();
  int readSizedInt(int size, boolean is_signed);
  int readUnsignedInt();

  void read(ObjectWrapper obj, boolean addressable);
  void readStaticPointer(PointerWrapper ptr_obj);
  void readDefiningPointer(PointerWrapper ptr_obj);
  void readOwningPointer(PointerWrapper ptr_obj);
  void readReference(PointerWrapper ptr_obj);
  void readByteArray(int[] start, int len);
}
