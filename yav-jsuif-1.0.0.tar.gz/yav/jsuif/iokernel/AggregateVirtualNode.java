/*
 * AggregateVirtualNode.java - 
 *
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;


class AggregateVirtualNode extends VirtualNode
{
  protected Vector _members;

  public AggregateVirtualNode(Vector members) { _members = members; }

  public MetaClass currentMetaClass(VirtualIterator state)
  {
    int i = state.top().getIterationNum();
    Assert.condition(((AggregateElement) _members.at(i))._continuation==null);
    return ((AggregateElement) _members.at(i))._meta_class;
  }

  public String currentName(VirtualIterator state)
  {
    int i = state.top().getIterationNum();
    Assert.condition(((AggregateElement) _members.at(i))._continuation==null);
    return ((AggregateElement) _members.at(i))._name;
  }

  public Object current(VirtualIterator state)
  {
    IteratorState is = state.top();
    AggregateElement el = (AggregateElement) _members.at(is.getIterationNum());
    return el.getObject(is.getAddress());
  }

  public void setCurrent(VirtualIterator state, Object x)
  {
    IteratorState is = state.top();
    AggregateElement el = (AggregateElement) _members.at(is.getIterationNum());
    el.setObject(is.getAddress(), x);
  }

  public boolean first(VirtualIterator state, Object address)
  {
    IteratorState is = new IteratorState(this, address);
    boolean is_valid = false;
    for (; is.getIterationNum() < _members.length(); is.increment())
      {
	AggregateElement el = 
	  (AggregateElement) _members.at(is.getIterationNum());

	state.push(is);
	is_valid = el._continuation == null;
	if (!is_valid)
	  {
	    is_valid = el._continuation.first(state, el.getObject(address));
	  }

	if (is_valid)
	  {
	    break;
	  }
	else
	  {
	    state.pop();
	  }
      }

    return is_valid;
  }

  public boolean next(VirtualIterator state)
  {
    IteratorState is = state.top();
    boolean is_valid = false;
    state.top().increment();
    
    for (int i; (i = is.getIterationNum()) < _members.length(); is.increment())
      {
	AggregateElement el = (AggregateElement) _members.at(i);
	
	is_valid = el._continuation == null;
	if (!is_valid)
	  {
	    is_valid = 
	      el._continuation.first(state, el.getObject(is.getAddress()));
	  }

	if (is_valid)
	  {
	    return true;
	  }
      }

    is_valid = state.pop();
    if (is_valid)
      {
	return state.top().getNode().next(state);
      }
    
    return is_valid;
  }

  public boolean previous(VirtualIterator state)
  {
    return false;
  }
}

