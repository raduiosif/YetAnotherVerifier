/*
 * MetaClass.java - A port of basesuif/iokernel/meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;
import yav.jsuif.common.PString;


public abstract class MetaClass extends GenericObject
{
  private static final String _className = "MetaClass";

  public static String getClassName() { return _className; }

  // FieldDescription.buildObject() needs public access to this field
  public String _meta_class_name;

  public String getInstanceName() { return _meta_class_name; }
  public static native int get__meta_class_name_offset();

  // FieldDescription.buildObject() needs public access to this field
  public int _size;

  public int getSize() { return _size; }
  public int getSizeOfInstance() { return _size; }
  public void setSize(int size) { _size = size; }
  public static native int get__size_offset();

  protected int _alignment;

  public int getAlignment() { return _alignment; }
  public int getAlignmentOfInstance() { return _alignment; }
  public void setAlignment(int alignment) { _alignment = alignment; }

  public abstract void read(ObjectWrapper o, InputStreamer inputStream);
  public abstract void write(ObjectWrapper o, OutputStreamer outputStream);

  public Object newInstance() 
  { 
    Assert.fatal(getInstanceName() + ": invoke abstract method newInstance(" 
		 + this + ")");
    return null; // never reached
  }

  public Object cloneObject(Object address) 
  { 
    Assert.fatal(getInstanceName() + ": invoke abstract method cloneObject(" 
		 + this + ", " + address + ")");
    return null; // never reached
  }

  public Iterator getIterator(Object instance)
  {
    return getIterator(instance, Iterator.OWNED);
  }

  public Iterator getIterator(Object instance, int contents)
  {
    return null;
  }

  public Iterator getIterator(ObjectWrapper o)
  {
    return getIterator(o.get());
  }

  public boolean isElementary() { return true; }

  public MetaClass getMetaClass(Object address) { return (MetaClass) this; }

  public void setMetaClassOfObject(Object instance) {}

  public MetaClass getLinkMetaClass() { return null; }

  public void walkReferencedMetaClasses(MetaClassApplier x) {}

  protected int _meta_class_id;

  protected void setMetaClassId(int id) { _meta_class_id = id; }
  public int getMetaClassId() { return _meta_class_id; }  

  protected String cutOff(PString ps, char c)
  {
    String s = ps.get();
    int indentation = 0;
    int pos = 0;
    int len = s.length();
   
    for (; pos < len; pos ++)
      {
	char current_char = s.charAt(pos);
	if (current_char == c && indentation == 0)
	  {
	    break;
	  }

	if (current_char == '{')
	  {
	    indentation ++;
	  }
	
	if (current_char == '}')
	  {
	    indentation --;
	  }
      }

    String cut = s.substring(0, pos);
    if (pos < len && s.charAt(pos) == c)
      {
	pos ++;
      }

    ps.set(s.substring(pos));
	return cut;
  }

  public VirtualNode getVirtualNode(String name, String what)
  {
    Vector members = new Vector();
    if (what.length() == 0)
      {
	members.pushBack(new AggregateElement(this, ""));
      }
    else
      {
	Assert.condition(false, "expected empty what string");
      }

    return new AggregateVirtualNode(members);
  }

  public boolean definesASubTypeOf(MetaClass m)
  {
    for (MetaClass x = this; x != null; x = x.getLinkMetaClass())
      {
	if (x == m)
	  {
	    return true;
	  }
      }

    return false;
  }

  public boolean objectIsKindOf(String className)
  {
    MetaClass m = this;
    while (m != null && !m.getInstanceName().equals(className))
      {
	m = m.getLinkMetaClass();
      }

    return (m != null);
  }

  public int walk(ObjectWrapper o, Walker w)
  {
    return walk(o.get(), w);
  }

  public int walk(Object address, Walker w)
  {
    return Walker.CONTINUE;
  }

  protected ObjectFactory _owning_factory;

  public ObjectFactory getOwningFactory() { return _owning_factory; }
  protected void setOwningFactory(ObjectFactory o) { _owning_factory = o; }

  protected InitializerFunction _pre_init;
  protected InitializerFunction _post_init;

  public void initialize(ObjectWrapper o, SuifInputStream inputStream)
  {
    Assert.condition(o.getMetaClass() == this);

    if (_pre_init != null)
      {
	_pre_init.invoke(o, true, inputStream);
      }

    if (_post_init != null)
      {
	_post_init.invoke(o, true, inputStream);
      }
  }


  static {
    System.loadLibrary("jsuif");
  }


  public MetaClass() { this(""); }

  public MetaClass(String metaClassName)
  {
    _pre_init = null;
    _post_init = null;
    _meta_class_name = metaClassName;
    _size = 0;
    _alignment = 1;
    _meta_class_id = 0;
    _owning_factory = null;
  }
}

