/*
 * MetaClassApplier.java - A port of basesuif/iokernel/meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;


interface MetaClassApplier
{
  boolean apply(MetaClass mc);
}


