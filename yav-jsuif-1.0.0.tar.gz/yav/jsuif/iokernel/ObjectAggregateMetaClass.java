/*
 * ObjectAggregateMetaClass.java - A port of 
 *                                 basesuif/iokernel/aggregate_meta_class.h
 *                                 to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class ObjectAggregateMetaClass extends AggregateMetaClass
{
  private static final String _className = "ObjectAggregateMetaClass";

  public static String getClassName() { return _className; }

  private static final IOKernelClassLoader _ldr = new IOKernelClassLoader();

  protected String _real_name;
  protected Class _classFile;


  public ObjectAggregateMetaClass()
  { 
    super("");
    _classFile = null;
  }

  public ObjectAggregateMetaClass(String name) 
  { 
    super(name);
    _real_name = name;
    getClassFile();
  }

  public ObjectAggregateMetaClass(String name, String real_name)
  {
    super(name);
    _real_name = real_name;
    getClassFile();
  }

  public ObjectAggregateMetaClass(AggregateMetaClass other, String real_name)
  {
    super(other);
    _real_name = real_name;
    getClassFile();
  }


  public Class getClassFile() 
  { 
    if (_classFile == null)
      {
	if (_real_name == null)
	  {
	    _real_name = _meta_class_name;
	  }

	try {
	  _classFile = _ldr.loadClass(_real_name);
	} catch (ClassNotFoundException e) {
	  Assert.fatal("meta class " + _real_name + " not found");
	}
      }

    return _classFile; 
  }

  public Object newInstance() 
  { 
    getClassFile();

    Object newObj = null;
    try {
      newObj = _classFile.newInstance();
    } 
    catch(IllegalAccessException e) { Assert.fatal(e.toString()); }
    catch(InstantiationException e) { Assert.fatal(e.toString()); }

    return newObj;
  }

  public Object cloneObject(Object address) 
  { 
    Object instance = newInstance();
    setMetaClassOfObject(instance);
    return instance;
  }

  public void setMetaClassOfObject(Object instance)
  {
    Assert.condition(instance instanceof GenericObject,
		     "bad instance of class " + instance.getClass().getName());

    ((GenericObject) instance).setMetaClass(this);
  }

  public MetaClass getMetaClass(Object address)
  {
    if (address == null)
      {
  	return null;
      }

    Assert.condition(address instanceof GenericObject,
  		     "bad object of class " + address.getClass().getName());

    return ((GenericObject) address).getMetaClass();
  }

  public int walk(Object address, Walker w)
  {
    Object instance = address;
    ObjectAggregateMetaClass mc = 
      (ObjectAggregateMetaClass) getMetaClass(instance);
    int status = Walker.CONTINUE;
    if (w.getIsPreOrder() && w.isVisitable(address, mc))
      {
	w.setAddress(null);
	int s = w.apply(instance, this);
	switch (s)
	  {
	  case Walker.CONTINUE:
	    break;
	    
	  case Walker.STOP:
	  case Walker.ABORT:
	    return s;

	  case Walker.TRUNCATE:
	    return Walker.CONTINUE;

	  case Walker.REPLACED:
	    instance = w.getAddress();
	    Assert.condition(instance != null);
	    mc = (ObjectAggregateMetaClass) getMetaClass(instance);
	    break;
	  }
      }

    status = mc.walkFields(instance, w);
    switch (status)
      {
      case Walker.CONTINUE:
	break;

      case Walker.STOP:
      case Walker.ABORT:
	return status;

      case Walker.TRUNCATE:
	return Walker.CONTINUE;

      case Walker.REPLACED:
	Assert.fatal();
	break;
      }

    if (!w.getIsPreOrder() && w.isVisitable(address, mc))
      {
	return w.apply(instance, this);	
      }

    return status;
  }
}
