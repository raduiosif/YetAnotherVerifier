/*
 * Synchronizer.java - A port of basesuif/iokernel/synchronizer.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Map;


class SynchronizerApplier implements MetaClassApplier
{
  private Synchronizer _syn;

  public SynchronizerApplier(Synchronizer syn) { _syn = syn; }

  public boolean apply(MetaClass x)
  {
    MetaClass mc = x.getMetaClass();
    MetaClass new_class = _syn.getReplacement(x);
    if (new_class == null)
      {
	_syn.pushForClone(x, mc);
      }
    else
      if (new_class != x)
	{
	  _syn.pushForReplacement(x, new_class);
	}

    return true;
  }
}


class FixupOrderedList implements MetaClassApplier
{
  private Synchronizer _syn;
  private Map _visited = new Map();

  public FixupOrderedList(Synchronizer syn) { _syn = syn; }

  public boolean apply(MetaClass x)
  {
    if (_syn.getIsCloned(x))
      {
	Map.Iterator iter = _visited.find(x);
	if (iter.isEqual(_visited.end()))
	  {
	    _visited.enterValue(x, new Boolean(true));
	    x.walkReferencedMetaClasses(this);
	  }
      }

    return true;
  }
}


public class Synchronizer extends CloneStream
{
  private ObjectFactory _system_factory;

  public ObjectFactory getObjectFactory() { return _system_factory; }

  private ObjectFactory _new_object_factory;
  private SuifInputStream _input_stream;


  public Synchronizer(ObjectFactory factory)
  {
    super(factory);
    
    _system_factory = null;
    _new_object_factory = null;
    _input_stream = null;

    setPointerHandling(ENQUIRE_PTR, ENQUIRE_PTR, CLONE_PTR);
  }


  public void synchronize(ObjectFactory system_factory,
			  ObjectFactory new_object_factory,
			  SuifInputStream input_stream)
  {
    _system_factory = system_factory;
    _new_object_factory = new_object_factory;
    _input_stream = input_stream;

//      System.out.println("----- START SYNCHRONIZE -----");
//      System.out.println("========> NEW:");
//      _new_object_factory.printContents();
//      System.out.println("========> OLD:");
//      _system_factory.printContents();


    SynchronizerApplier synapp = new SynchronizerApplier(this);
    
    open();
    _new_object_factory.applyToMetaClasses(synapp);
    performCloning();
    
    int clone_count = getCloneCount();
    FixupOrderedList ordered = new FixupOrderedList(this);

    readClose();
    for (int i = 0; i < clone_count; i ++)
      {
	if (!(getNewAddress(i) instanceof MetaClass))
	  {
	    continue;
	  }

	MetaClass mc = (MetaClass) getNewAddress(i);
	MetaClass obj_mc = getMetaClass(i);
	if (obj_mc.objectIsKindOf(MetaClass.getClassName()) && getIsCloned(i))
	  {
	    _system_factory.enterMetaClass(mc);
	    _input_stream.remapAddress(getOldAddress(i), mc);
	    ordered.apply(mc);
	  }
	else
	  if (!getIsCloned(i) && (mc != null) && ObjectFactory.isAList(mc))
	    {
	      ListMetaClass list_mc = (ListMetaClass) mc;
	      MetaClass element_meta_class = list_mc.getElementMetaClass();
	      Object new_addr = cloneAddress(element_meta_class);
	      if (new_addr != null)
		{
		  element_meta_class = (MetaClass) new_addr;
		  ordered.apply(element_meta_class);
		  list_mc.setElementMetaClass(element_meta_class);
		}
	    }
      }
    
    close();
  }

  public MetaClass getReplacement(GenericObject x)
  {
    MetaClass mc = (MetaClass) x;
    MetaClass new_class = null;

    if (ObjectFactory.isAList(mc))
      {
	ListMetaClass list_mc = (ListMetaClass) mc;
	MetaClass element_mc = list_mc.getElementMetaClass();
	MetaClass new_element_mc = 
	  _system_factory.lookupMetaClass(element_mc.getInstanceName());

	if (new_element_mc != null)
	  {
	    element_mc = new_element_mc;
	  }

	int old_size = list_mc.getSize();
	list_mc = _system_factory.getListMetaClass(element_mc, 
						   list_mc.getInstanceName());
	if (old_size != list_mc.getSize())
	  {
	    System.err.println("List class became " + 
			       list_mc.getInstanceName() + ":" + 
			       list_mc.getSize() + " was of size " + old_size);
	  }

	new_class = list_mc;
      }
    else
      {
	new_class = _system_factory.lookupMetaClass(mc.getInstanceName());
      }

    if ((new_class != null) && (new_class != mc))
      {
	_input_stream.remapAddress(mc, new_class);
      }

    return new_class;
  }

  public void objectEnquiry(GenericObject x, 
			    CloneStreamObjectInstance o,
			    int ptr_type)
  {
    MetaClass new_class = getReplacement(x);
    if (new_class == null)
      {
	setCloneObject(o);
      }
    else
      if (new_class == x)
	{
	  setReference(o);
	}
      else
	{
	  setReplacement(o, new_class);
	}
  }
}

