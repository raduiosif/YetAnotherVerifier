#include <jni.h>
#include <suifclasses.h>


extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_iokernel_AggregateMetaClass_get_1_1base_1class_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(AggregateMetaClass, _base_class);
}

extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_iokernel_AggregateMetaClass_get_1_1fields_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(AggregateMetaClass, _fields);
}

extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_iokernel_AggregateMetaClass_get_1_1virtual_1field_1description_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(AggregateMetaClass, _virtual_field_description);
}

extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_iokernel_FieldDescription_get_1memberName_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(FieldDescription, memberName);
}

extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_iokernel_FieldDescription_get_1metaClass_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(FieldDescription, metaClass);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_FieldDescription_get_1offset_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(FieldDescription, offset);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_IntegerMetaClass_get_1_1is_1signed_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(IntegerMetaClass, _is_signed);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_ListMetaClass_get_1_1element_1meta_1class_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(ListMetaClass, _element_meta_class);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_MetaClass_get_1_1meta_1class_1name_1offset
  (JNIEnv *, jclass)
{
  return OFFSETOF(MetaClass, _meta_class_name);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_MetaClass_get_1_1size_1offset
  (JNIEnv *, jclass)
{
  return OFFSETOF(MetaClass, _size);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_ObjectFactory_get_1_1meta_1class_1dictionary_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(ObjectFactory, _meta_class_dictionary);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_PointerMetaClass_get_1_1base_1type_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(PointerMetaClass, _base_type);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_PointerMetaClass_get_1_1is_1static_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(PointerMetaClass, _is_static);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_PointerMetaClass_get_1_1needs_1cloning_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(PointerMetaClass, _needs_cloning);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_PointerMetaClass_get_1_1pointer_1owns_1object_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(PointerMetaClass, _pointer_owns_object);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_UnionMetaClass_get_1_1tag_1offset_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(UnionMetaClass, _tag_offset);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_UnionMetaClass_get_1_1union_1fields_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(UnionMetaClass, _union_fields);
}

typedef suif_map<LString, LString>::value_type VirtualFieldDescription_type;

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_VirtualFieldDescription_get_1first_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(VirtualFieldDescription_type, first);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_VirtualFieldDescription_get_1second_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(VirtualFieldDescription_type, second);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_VirtualFieldDescription_value_1type_1size
  (JNIEnv *, jclass)
{
  return (jint) sizeof( VirtualFieldDescription_type );
}

typedef suif_hash_map<LString, MetaClass *>::value_type MetaClassDictionary_type;

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_MetaClassDictionary_get_1first_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(MetaClassDictionary_type, first);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_MetaClassDictionary_get_1second_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(MetaClassDictionary_type, second);
}

extern "C" JNIEXPORT jint JNICALL 
  Java_yav_jsuif_iokernel_MetaClassDictionary_value_1type_1size
  (JNIEnv *, jclass)
{
  return (jint) sizeof( MetaClassDictionary_type );
}

