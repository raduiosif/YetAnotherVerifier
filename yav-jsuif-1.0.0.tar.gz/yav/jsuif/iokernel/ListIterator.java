/*
 * ListIterator.java - A port of basesuif/iokernel/list_meta_class.h to Java.
 *  
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public class ListIterator extends BaseListIterator
{
  private int currentIndex;
  private GenericList genericList;

  
  public ListIterator(GenericList list, MetaClass element_meta_class)
  {
    super(element_meta_class);
    
    currentIndex = 0;
    genericList = list;
    _is_valid = (list._count > 0);
  }

  private ListIterator(ListIterator other)
  {
    super(other._element_meta_class);

    currentIndex = other.currentIndex;
    genericList = other.genericList;
  }


  public Object current()
  {
    if (_is_valid)
      {
	return genericList._space [currentIndex];
      }

    return null;
  }

  public void setCurrent(Object x)
  {
    if (_is_valid)
      {
	genericList._space [currentIndex] = x;
      }
  }

  public void next()
  {
    if (!_is_valid)
      {
	return;
      }

    currentIndex ++;
    if (currentIndex >= genericList._count)
      {
	_is_valid = false;
      }
  }

  public void previous()
  {
    if (!_is_valid)
      {
	return;
      }

    currentIndex --;
    if (currentIndex < 0)
      {
	_is_valid = false;
      }
  }

  public void first()
  {
    currentIndex = 0;
    _is_valid = (genericList._count != 0);
  }

  public void setTo(int index)
  {
    currentIndex = index;
    if ((index < 0) || (index > genericList._count))
      {
	_is_valid = false;
      }
  }

  public int length() { return genericList._count; }

  public Object clone() { return new ListIterator(this); }
}
