/*
 * STLIterator.java - A port of basesuif/iokernel/stl_meta_class.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.STLType;


public class STLIterator extends BaseListIterator
{
  private STLType collectionObject;
  private STLType.Iterator it;


  public Object current()
  {
    if (_is_valid)
      {
	return (Object) it.STLget();
      }
    
    return null;
  }

  public void setCurrent(Object x)
  {
    if (_is_valid)
      {
	it.STLset(x);
      }
  }

  public void next()
  {
    if (!_is_valid)
      {
	return;
      }

    it.STLinc();
    _is_valid = it.STLnotEqual(collectionObject.STLend());
  }

  public void previous()
  {
    if (!_is_valid)
      {
	return;
      }

    if (_is_valid = !it.STLisEqual(collectionObject.STLbegin()))
      {
	it.STLdec();
      }
  }

  public void first()
  {
    it = collectionObject.STLbegin();
    _is_valid = it.STLnotEqual(collectionObject.STLend());
  }

  public int length() { return collectionObject.STLlength(); }

  public void add(Object object)
  {
    it = collectionObject.STLend();
    collectionObject.STLinsert(it, object);
    it = collectionObject.STLend();
  }

  public Object clone()
  {
    return new STLIterator(_element_meta_class, collectionObject, it);
  }


  private STLIterator(MetaClass element_meta_class,
		      STLType co,
		      STLType.Iterator i)
  {
    super(element_meta_class);

    collectionObject = co;
    it = i;
  }

  public STLIterator(Object address, MetaClass element_meta_class)
  {
    super(element_meta_class);

    collectionObject = (STLType) address;
    it = collectionObject.STLbegin();
    _is_valid = it.STLnotEqual(collectionObject.STLend());
  }
}
