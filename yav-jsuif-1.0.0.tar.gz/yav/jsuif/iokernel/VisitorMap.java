/*
 * VisitorMap - A port of basesuif/iokernel/visitor_map.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;
import yav.jsuif.kernel.SuifEnv;


class VisitorEntry
{
  public Object stateAddress;
  public VisitMethod visitMethod;

 
  public VisitorEntry(Object address, VisitMethod method)
  {
    stateAddress = address;
    visitMethod = method;
  }

  public VisitorEntry()
  {
    stateAddress = null;
    visitMethod = null;
  }

  public VisitorEntry(VisitorEntry other)
  {
    stateAddress = other.stateAddress;
    visitMethod = other.visitMethod;
  }
}


public class VisitorMap extends GenericObject
{
  private Vector entries;
  private SuifEnv suif;
  private Object unknownState;
  private VisitMethod unknownMethod;


  public VisitorMap(SuifEnv suif_env)
  {
    suif = suif_env;
    unknownState = null;
    unknownMethod = null;
    
    int num = suif.getObjectFactory().getLastId();
    entries = new Vector(num);
  }


  public void registerVisitMethod(Object state, 
				  VisitMethod visitMethod, 
				  String className)
  {
    registerVisitMethod(state, visitMethod, 
			suif.getObjectFactory().lookupMetaClass(className));
  }

  public void registerUnknownMethod(Object state,
				    VisitMethod visitMethod)
  {
    unknownState = state;
    unknownMethod = visitMethod;
  }

  public void apply(GenericObject object)
  {
    apply(object, object.getMetaClass());
  }

  public void apply(Object address, MetaClass mc)
  {
    while (mc != null)
      {
	int id = mc.getMetaClassId();
	while (id >= entries.length())
	  {
	    entries.pushBack(new VisitorEntry());
	  }

	VisitorEntry entry = (VisitorEntry) entries.at(id);
	if (entry.visitMethod != null)
	  {
	    entry.visitMethod.invoke(entry.stateAddress, address);
	    return;
	  }

	mc = mc.getLinkMetaClass();
      }

    unknownMethod.invoke(unknownState, address);    
  }

  public void registerVisitMethod(Object state,
				  VisitMethod visitMethod,
				  MetaClass mc)
  {
    Assert.condition(mc != null);
    int id = mc.getMetaClassId();

    while (id >= entries.length())
      {
	entries.pushBack(new VisitorEntry());
      }

    entries.enter(id, new VisitorEntry(state, visitMethod));
  }
}
