/*
 * SuifObjectStream.java - A port of basesuif/iokernel/object_stream.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Map;


/**
 * A SuifObjectStream is responsible for reading/writing to/from a SUIF file.
 * A super class for SuifInputStream and SuifOutputStream.
 */
public abstract class SuifObjectStream
{
  /**
   * Stream temporary storage class.
   */
  public static class TempStorage
  {
    public Object _address;

    public TempStorage(Object address)
    {
      _address = address;
    }
  }


  protected Map _temp_storage;

  
  protected SuifObjectStream()
  {
    _temp_storage = null;
  }


  public abstract void addAddressPair(int id, Object address);

  public void setTempStorage(String key, Object address)
  {
    if (_temp_storage == null)
      {
	_temp_storage = new Map();
      }

    _temp_storage.enterValueAt(key, new TempStorage(address));  
  }

  public Object getTempStorage(String key)
  {
    if (_temp_storage != null)
      {
	Map.Iterator elem = _temp_storage.find(key);
	if (elem.notEqual(_temp_storage.end()))
	  {
	    return ((TempStorage) elem.get().second)._address;
	  }
      }

    return null;
  }

  protected static final int NORMAL_INT_BIT = 1 << (8 - 1);
  protected static final int NORMAL_INT_SIGN_BIT = 1 << (8 - 2);
  protected static final int NORMAL_INT_LENGTH_MASK = (1 << (8 - 2)) - 1;

  protected static final int SIGNED_BYTE_FILL = (1 << 8) - 1;
  protected static final int IS_BYTE_SIGNED_BIT = 1 << (8 - 1);
}
