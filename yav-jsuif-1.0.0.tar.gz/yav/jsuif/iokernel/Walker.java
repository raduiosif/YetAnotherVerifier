/*
 * Walker.java - A port of basesuif/iokernel/walker.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;
import yav.jsuif.kernel.SuifEnv;


/**
 * This is the base class for all walkers.
 * Normally, user defined walkers are derived 
 * from yav.jsuif.kernel.SuifWalker .
 */

public abstract class Walker
{
  /** Continue iteration */
  public static final int CONTINUE = 0;

  /** Stop iteration, normal termination */
  public static final int STOP = 1;

  /** Stop with error condition */
  public static final int ABORT = 2;

  /** Do not walk sub-objects of this object (pre-order only) */
  public static final int TRUNCATE = 3;

  /** 
   * Object has been replaced with a new object.
   * You must set the address of the new object 
   * by calling set_address() before returning.
   */
  public static final int REPLACED = 4;


  private boolean _is_pre_order;
  private Object _address;
  private Object _parent;
  protected SuifEnv _env;

  public Walker(SuifEnv env)
  {
    _env = env;
    _is_pre_order = true;
    _address = null;
    _parent = null;
  }


 /** 
  * Called by the walker to perform action on the data in address.
  * Subclasses must overwrite this method.
  * @param address  address of the data to be applied on.
  * @param mc meta class of the data in address.
  */ 
  public abstract int apply(Object address, MetaClass mc);

  /** 
   * Determine if the tree rooted at the address should be walked
   * Default implementation returns true iff is_owned is true.
   * You can, for example, return false if you know that a node
   * of interest cannot be contained inside a given node.
   * Notice the difference to is_visitable. The latter determines
   * if the function operator should be called on a given node. 
   * This function controls walking of an entire subtree.
   * @param address a pointer.
   * @param is_owned true if the pointer pointed to by address 
   *                 is owned by this object.
   * @param mc the meta class of the pointer in address. This meta
   *           class will be a subclass of PointerMetaClass.
   */
  public boolean isWalkable(Object address,
			    boolean is_owned,
			    MetaClass mc)
  {
    return is_owned;
  }

  /** 
   * Determine if apply() should be called on the data in address.
   * Default implementation always true.
   * @param address points to the data.
   * @param mc the meta class of the data pointed to by address.
   */
  public boolean isVisitable(Object address,
			     MetaClass mc)
  {
    return true;
  }

  /**
   * Set the order of walking to postorder.
   * Default is preorder.
   */
  public void setPostOrder() { _is_pre_order = false; }
  
  /** 
   * Set the order of walking to preorder, which is the default.
   */
  public void setPreOrder() { _is_pre_order = true; }

  /**
   * Get the order of walking.
   * Returns true iff preorder.
   */
  public boolean getIsPreOrder() { return _is_pre_order; }

  public void setAddress(Object new_address) { _address = new_address; }
  public Object getAddress() { return _address; }
  
  public SuifEnv getEnv() { return _env; }
  
  public void setParent(Object new_parent) { _parent = new_parent; }
  public Object getParent() { return _parent; }

  /** 
   * Returns true if a walker changes the tree.
   * It is possible for nodes to be replaced during a walk. 
   * This is important when walking lists, as the contents of
   * the list can change while the list is being walked. 
   * So, if changes can occur, we must copy the list before
   * walking it.  
   */
  public boolean getMakesChanges() { return false; }

  /**
   * Should the node be ignored because it has been deleted or changed ?
   */
  public boolean isChanged(Object address) { return false; }
}
