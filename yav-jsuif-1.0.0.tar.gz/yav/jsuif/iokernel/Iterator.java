/*
 * Iterator.java - A port of basesuif/iokernel/meta_class_iter.h to Java.
 *
 */

package yav.jsuif.iokernel;

import yav.jsuif.common.Assert;


public abstract class Iterator implements Cloneable
{
  public static final int ALL = 0;
  public static final int REFERENCED = 1;
  public static final int OWNED = 2;

  public abstract MetaClass currentMetaClass();
  public abstract String currentName();
  public abstract Object current();
  public abstract void setCurrent(Object x);
  public abstract boolean isValid();  
  
  public abstract void next();
  public abstract void previous();

  public void setTo(int index)
  {
    first();
    while (index -- != 0 && isValid())
      {
	next();
      }
  }

  public int length()
  {
    int count = 0;
    Iterator n = (Iterator) clone();
    n.setTo(0);
    while (n.isValid())
      {
	count ++;
	n.next();
      }

    return count;
  }

  public abstract void first();

  public void add(Object object)
  { 
    Assert.fatal("invoke abstract method Iterator.add()"); 
  }

  public void printToDefault()
  {
    if (!isValid())
      {
	System.err.println("invalid");
	return;
      }

    Object address = current();
    MetaClass mc = currentMetaClass();
    String name = currentName();
    String mclass_name = mc.getInstanceName();
    System.err.println(name + " = " + mclass_name + " @" + address);
  }

  public Object clone()
  {
    try {
      return super.clone();
    } catch(CloneNotSupportedException e) { return null; }
  }
}
