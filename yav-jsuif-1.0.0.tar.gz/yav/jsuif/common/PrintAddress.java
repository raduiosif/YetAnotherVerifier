/*
 * PrintAddress.java - A port of common/formatted.h to Java
 *
 */

package yav.jsuif.common;


public abstract class PrintAddress
{
  public abstract String pointerToString(Object address);
}
