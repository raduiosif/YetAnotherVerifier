/*
 * Vector.java - A port of common/suif_vector.h to Java.
 *
 */

package yav.jsuif.common;


/**
 * Implements the hoof vector inbuilt type.
 */

public class Vector extends STLType
{
  public static class Iterator extends STLType.Iterator
  {
    private Object[] buff;
    private int pos;

    public int getPosition() { return pos; }

    public void set(Object x) { buff[pos] = x; }
    public Object get() { return buff[pos]; }

    public Iterator dec() { pos --; return this; }
    public Iterator inc() { pos ++; return this; }

    public Iterator add(int x)
    {
      Iterator i = new Iterator(this);
      i.pos += x;
      return i;      
    }

    public boolean isEqual(Iterator x) 
    { 
      return (pos == x.pos);
    }

    public boolean notEqual(Iterator x) { return !isEqual(x); }

    //
    // Implementation of the STLType.Iterator interface
    //

    public boolean STLisEqual(STLType.Iterator x)
    {
      return isEqual((Iterator) x);
    }

    public boolean STLnotEqual(STLType.Iterator x)
    {
      return notEqual((Iterator) x);
    }

    public STLType.Iterator STLinc() { return inc(); }
    public STLType.Iterator STLdec() { return dec(); }
    public Object STLget() { return get(); }
    public void STLset(Object x) { set(x); }


    Iterator(Object[] x) { this(x, 0); }
    
    Iterator(Object[] x, int y)
    {
      buff = x;
      pos = y;
    }

    Iterator (Iterator x)
    {
      buff = x.buff;
      pos = x.pos;
    }

    Iterator (Iterator x, int y)
    {
      buff = x.buff;
      pos = y;
    }
  }

  protected Object[] buff;

  protected int m_start;
  protected int m_finish;

  protected void allocateVector(int n)
  {
    if (n == 0) n ++;
    buff = new Object[n];
  }

  protected void vectorFill(Iterator start, Object val)
  {
    for (int tmp = start.getPosition(); tmp < m_finish; tmp ++)
      {
	buff[tmp] = val;
      }
  }

  protected Iterator copy(Iterator start, Iterator end, Iterator dest)
  {
    Iterator tmp = new Iterator(start);
    for (; tmp.notEqual(end); tmp.inc(), dest.inc())
      {
	dest.set(tmp.get());
      }
    
    return dest;
  }

  protected Iterator reverseCopy(Iterator start, Iterator end, Iterator dest)
  {
    int pos = dest.getPosition() + end.getPosition() - start.getPosition();
    Iterator it = new Iterator(start, pos);
    Iterator tmp = new Iterator(end);
    while (tmp.getPosition() >= start.getPosition())
      {
	it.set(tmp.get());
	it.dec();
	tmp.dec();
      }

    return it;
  }

  protected void insertAux(Iterator pos, Object x)
  {
    if (m_finish != buff.length)
      {
	reverseCopy(pos, end(), new Iterator(pos, pos.getPosition() + 1));
	pos.set(x);
	m_finish = end().getPosition() + 1;
      }
    else
      {
	int oldsize = length();
	int newsize = 2 * oldsize + 1;
	
	Iterator pOld = new Iterator(buff); 
	allocateVector(newsize);
	
	Iterator pPos = new Iterator(buff);
	pPos = copy(pOld, pos, pPos);
	Iterator y = copy(pos,end(), new Iterator(pPos, pPos.getPosition()+1));
	pPos.set(x);
	m_start = 0;
	m_finish = y.getPosition();
      }
  }

  /**
   * Creates an empty vector of size 1.
   */
  public Vector()
  {
    allocateVector(1);
    m_start = m_finish = 0;
  }

  /**
   * Creates an empty vector of size n.
   * @param n initial size
   */
  public Vector(int n) { this(n, new Object()); }

  /**
   * Creates a vector of size n filled with val.
   * @param n initial size
   * @param val default value for elements
   */
  public Vector(int n, Object val)
  {
    allocateVector(n);
    m_start = 0;
    m_finish = n;
    vectorFill(begin(), val);
  }

  /**
   * Copy constructor.
   * @param v copy source
   */
  public Vector(Vector v)
  {
    Iterator it = v.begin();
    Iterator end = v.end();
    int n = v.length();

    allocateVector(n);
    copy(it, end, new Iterator(buff));

    m_start = 0;
    m_finish = n;
  }

  /**
   * Return the beginning of vector data.
   */
  public Iterator begin() { return new Iterator(buff, m_start); }
  
  /**
   * Return the end of vector data.
   */
  public Iterator end() { return new Iterator(buff, m_finish); }

  /**
   * Return the size of vector.
   */
  public int length() { return m_finish - m_start; }

  /**
   * Emptiness test.
   */
  public boolean empty() { return length() == 0; }

  /**
   * Return the number of available entries.
   */
  public int capacity() { return buff.length - m_start; }

  /**
   * Insert at a given position. 
   * No bound adjustments.
   * @param pos insert position
   * @param x value to be inserted
   */
  public Iterator insert(Iterator pos, Object x)
  {
    if ((m_finish != buff.length) && pos.isEqual(end()))
      {
	buff[m_finish ++] = x;
      }
    else
      {
	insertAux(pos, x);
      }

    return pos;
  }

  /**
   * Insert at a given position. 
   * Adjust position if overlapping.
   * @param pos insert position
   * @param x value to be inserted
   */
  public void insert(int pos, Object x)
  {
    if (pos < 0)
      {
	insert(begin(), x);
      }
    else
      if (pos >= length())
	{
	  pushBack(x);
	}
      else
	{
	  insert(new Iterator(buff, m_start + pos), x);
	}
  }

  /**
   * Remove an element and return position of following.
   * No bound adjustments.
   * @param pos erase position
   */
  public Iterator erase(Iterator pos)
  {
    Iterator tmp = new Iterator(pos, pos.getPosition() + 1);
    if (tmp.notEqual(end()))
      {
	copy(tmp, end(), pos);
      }

    -- m_finish;
    return tmp;
  }

  /**
   * Remove entry in given position.
   * Adjust position if overlapping.
   * @param pos erase position
   */
  public void erase(int pos)
  {
    if (pos < 0)
      {
	pos = 0;
      }
    else
      if (pos >= length())
	{
	  pos = length() - 1;
	}

    if (pos >= 0)
      {
	erase(new Iterator(buff, m_start + pos));
      }
  }

  /**
   * Add a value at the end.
   * @param x value to add
   */
  public void pushBack(Object x)
  {
    if (m_finish != buff.length)
      {
	buff[m_finish ++] = x;
      }
    else
      {
	insertAux(end(), x);
      }
  }

  /**
   * Removes object at the end.
   */
  public void popBack() { m_finish --; }

  /**
   * Enters value at position.
   */
  public void enter(int n, Object x) { buff[n] = x; }

  /**
   * Returns value at position.
   * @param n position 
   */
  public Object at(int n) { return buff[n]; }

  /**
   * Returns value at first position.
   */
  public Object front() { return buff [m_start]; }

  /**
   * Returns value at last position.
   */
  public Object back() { return buff [m_finish - 1]; }

  /**
   * Membership test.
   * @param x value for which membership is tested.
   */
  public boolean isMember(Object x)
  {
    for (Iterator tmp = new Iterator(begin()); tmp.notEqual(end()); tmp.inc())
      {
	if (tmp.get() == x)
	  {
	    return true;
	  }
      }

    return false;
  }

  //
  // Implementation of the STLType interface
  //

  public STLType.Iterator STLbegin() { return begin(); }
  public STLType.Iterator STLend() { return end(); }

  public STLType.Iterator STLinsert(STLType.Iterator it, Object object)
  {
    return insert((Iterator) it, object);
  }

  public STLType.Iterator STLerase(STLType.Iterator it)
  {
    return erase((Iterator) it);
  }

  public int STLlength() { return length(); }

  public Object clone() { return new Vector(); }
}




