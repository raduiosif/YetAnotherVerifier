/*
 * PInputStream.java - A java.io.InputStream pointer class.
 *
 */

package yav.jsuif.common;

import java.io.InputStream;


public class PInputStream
{
  private InputStream _value;

  public PInputStream() { this(null); }
  public PInputStream(InputStream value) { _value = value; }

  public InputStream get() { return _value; }
  public void set(InputStream value) { _value = value; }
}
