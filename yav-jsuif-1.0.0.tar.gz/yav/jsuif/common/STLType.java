/*
 * STLType.java - An interface that must be implemented by all STL types.
 *
 */

package yav.jsuif.common;


public abstract class STLType implements Cloneable
{
  public static abstract class Iterator
  {
    public abstract boolean STLisEqual(Iterator x);
    public abstract boolean STLnotEqual(Iterator x);
    public abstract Iterator STLinc();
    public abstract Iterator STLdec();
    public abstract Object STLget();
    public abstract void STLset(Object x);
  }
  
  public abstract Iterator STLbegin();
  public abstract Iterator STLend();
  public abstract Iterator STLinsert(Iterator it, Object object);
  public abstract Iterator STLerase(Iterator it);
  public abstract int STLlength(); 

  public abstract Object clone();
}

