/*
 * RecoverableException.java - 
 *
 */

package yav.jsuif.common;


public class RecoverableException extends RuntimeException
{
  public RecoverableException() { super(); }
  public RecoverableException(String s) { super(s); }
}
