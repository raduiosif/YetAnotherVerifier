/*
 * PInteger.java - A pointer to integer class.
 *
 */

package yav.jsuif.common;


public class PInteger
{
  private int _value;

  public PInteger() { this(0); }
  public PInteger(int value) { _value = value; }
  
  public int get() { return _value; }
  public void set(int value) { _value = value; }       
}
