/*
 * Map.java - A port of common/suif_map.h to Java.
 *
 */

package yav.jsuif.common;

import yav.jsuif.iokernel.GenericObject;


abstract class MapInner extends STLType
{
  // We need to (artificially) declare this class as subtype
  // of yav.jsuif.iokernel.GenericObject in order to be able
  // to create a meta class and read/write Map.Pair objects.
  abstract static class PairInner 
    extends GenericObject implements Cloneable
  {
    public PairInner next;

    /**
     * Shallow clone.
     */
    public Object clone()
    {
      try {
	return super.clone();
      } catch (CloneNotSupportedException e) { return null; }
    }
  }

  abstract static class HelperInner 
  {
    public abstract void setRange(PairInner v, PairInner x);
  }

  abstract static class KeyInner
  {
    public abstract boolean equals(PairInner p);
  }

  static class IteratorInner extends STLType.Iterator
  {
    MapInner suif_map;
    PairInner current;

    public boolean isEqual(IteratorInner x) { return current == x.current; }
    public boolean notEqual(IteratorInner x) { return current != x.current; }
    public PairInner _get() { return current; }

    public IteratorInner inc()
    {
      if (current == null)
	{
	  return this;
	}

      current = current.next;
      return this;
    }

    public IteratorInner dec()
    {
      if (current == null)
	{
	  return this;
	}

      PairInner x = suif_map.table;
      PairInner y = null;
      while (x != current)
	{
	  y = x;
	  x = x.next;
	}

      current = y;
      return this;
    }

    //
    // Implementation of the STLType.Iterator interface
    //

    public boolean STLisEqual(STLType.Iterator x) 
    { 
      return isEqual((IteratorInner) x);
    }

    public boolean STLnotEqual(STLType.Iterator x)
    {
      return notEqual((IteratorInner) x);
    }

    public STLType.Iterator STLinc() { return inc(); }
    public STLType.Iterator STLdec() { return dec(); }
    public Object STLget() { return _get(); }
    public void STLset(Object x) { current = (PairInner) x; }


    public IteratorInner()
    {
      suif_map = null;
      current = null;
    }

    public IteratorInner(MapInner x, PairInner t)
    {
      suif_map = x;
      current = t;
    }

    public IteratorInner(IteratorInner other)
    {
      suif_map = other.suif_map;
      current = other.current;
    }
  }


  public PairInner table;
  public HelperInner help;
  public int m_nSize;

  /**
   * Insert an element before the iterator position.
   * If already inserted replace it.
   * Returns an iterator pointing to the inserted element.
   * @param x insert position
   * @param p pair object
   */
  public IteratorInner insert(IteratorInner x, PairInner p)
  {
    PairInner y = table;
    PairInner last = null;
    while ((y != null) && (x._get() != y))
      {
	last = y;
	y = y.next;
      }

    if (y == null)
      {
	m_nSize ++;
      }

    y = (PairInner) p.clone();
    if (last == null)
      {
	y.next = table;
	table = y;
      }
    else
      {
	y.next = last.next;
	last.next = y;
      }

    return new IteratorInner(this, y);
  }

  /**
   * Returns an iterator pointing to the 
   * element associated with a given key.
   * @param x search key
   */
  public IteratorInner find(KeyInner x)
  {
    PairInner y = table;
    while ((y != null) && !x.equals(y))
      {
	y = y.next;
      }

    return new IteratorInner(this, y);
  }

  /**
   * Erase the element in front of the iterator.
   * @param x erase position
   */
  public void erase(IteratorInner x)
  {
    PairInner y = table;
    PairInner last = null;
    while (y != null && (x._get() != y))
      {
	last = y;
	y = y.next;
      }

    if (y == null)
      {
	return;
      }

    if (last == null)
      {
	table = y.next;
      }
    else
      {
	last.next = y.next;
      }

    m_nSize --;
  }

  /**
   * Insert a value associated with a given key.
   * Returns the actual inserted value,   
   * which is a clone of the original.
   * Set range if value already exists.
   * @param x insert key
   * @param val insert value
   */
  public PairInner enterValue(KeyInner x, PairInner val)
  {
    PairInner y = table;
    while (y != null && !x.equals(y))
      {
	y = y.next;
      }

    if (y != null)
      {
	help.setRange(val, y);
	return y;
      }

    PairInner ny = (PairInner) val.clone();

    ny.next = table;
    table = ny;
    m_nSize ++;

    return ny;
  }

  /**
   * Insert a value associated with a given key.
   * Returns the actual inserted value,   
   * which is a clone of the original.
   * No range set if value already exists.
   * @param x insert key
   * @param val insert value
   */
  public PairInner enterValueNoChange(KeyInner x, PairInner val)
  {
    PairInner y = table;
    while (y != null && !x.equals(y))
      {
	y = y.next;
      }

    if (y != null)
      {
	return y;
      }

    PairInner ny = (PairInner) val.clone();

    ny.next = table;
    table = ny;
    m_nSize ++;

    return ny;
  }

  public IteratorInner _begin() { return new IteratorInner(this, table); }
  public IteratorInner _end() { return new IteratorInner(this, null); }

  private void dupList(MapInner x)
  {
    PairInner y = table;
    PairInner last = null;
    while (y != null)
      {
	PairInner ny = (PairInner) y.clone();
	if (last == null)
	  {
	    table = ny;
	  }
	else
	  {
	    last.next = ny;
	  }

	last = y;
	y = y.next;
      }
  }


  public MapInner(HelperInner x)
  {
    table = null;
    help = x;
    m_nSize = 0;
  }

  public MapInner(MapInner x)
  {
    this(x.help);
    dupList(x);
  }
}


public class Map extends MapInner
{
  public static class Pair extends PairInner
  {
    public Object first;
    public Object second;

    public Pair() { this(null, null); }
    public Pair(Object x) { this(x, null); }
    
    public Pair(Object x, Object y)
    {
      first = x;
      second = y;
    }
  }


  private static class Key extends KeyInner
  {
    private Object value;
    
    public Key(Object v) { value = v; }
    
    public boolean equals(PairInner p) 
    {
      return ((Pair) p).first.equals(value);
    }    
  }

  
  private static class Helper extends HelperInner
  {
    public void setRange(PairInner v, PairInner x)
    {
      ((Pair) x).second = ((Pair) v).second;
    }
  }

  
  public static class Iterator extends IteratorInner
  {
    public Iterator() {}
    public Iterator(IteratorInner x) { super(x); }
    public Pair get() { return (Pair) _get(); }
  }

  
  private Helper the_helper;
  
  public Map() 
  { 
    super(new Helper()); 
    the_helper = (Helper) help; 
  }

  public Map(Map other)
  {
    super(other);
    the_helper = (Helper) help;
  }

  /**
   * Enter a value into the table.
   * @param x key
   * @param y value
   */
  public Pair enterValue(Object x, Object y)
  {
    return (Pair) super.enterValue(new Key(x), new Pair(x, y));
  }

  /**
   * To be used for table subscript assignments.
   * @param x key
   * @param y value
   */
  public Pair enterValueAt(Object x, Object y)
  {
    return (Pair) super.enterValueNoChange(new Key(x), new Pair(x, y));
  }

  /**
   * Find an by entry by key.
   * Returns end() if not found.
   * @param x search key
   */
  public Iterator find(Object x) 
  { 
    return new Iterator(super.find(new Key(x))); 
  }

  /**
   * Get an iterator that iterates over all values.
   */
  public Iterator begin() { return new Iterator(_begin()); }

  /**
   * Get an iterator to the end of the table.
   */
  public Iterator end() { return new Iterator(_end()); }

  /**
   * Find a value in the table.
   * If none is found, a default entry is created.
   * @param x search key
   */
  Object at(Object x)
  {
    Pair p = (Pair) super.enterValueNoChange(new Key(x), new Pair(x));
    return p.second;
  }

  /**
   * Remove the entry at position before the iterator.
   * @param i position iterator
   */
  public void erase(Iterator i) { super.erase(i); }

  /**
   * Returns the number of entries in the table.
   */
  public int length() { return m_nSize; }

  /**
   * Insert pair into the table at a given position.
   * @param x position iterator
   * @param p pair to be inserted
   */
  public Iterator insert(Iterator x, Pair p) 
  { 
    return new Iterator(super.insert(x, p)); 
  }

  //
  // Implementation of the STLType interface
  //

  public STLType.Iterator STLbegin() { return begin(); }
  public STLType.Iterator STLend() { return end(); }

  public STLType.Iterator STLinsert(STLType.Iterator it, Object object)
  {
    return insert((Iterator) it, (Pair) object);
  }

  public STLType.Iterator STLerase(STLType.Iterator it)
  {
    Iterator newit = new Iterator((Iterator) it);
    newit.inc();
    erase((Iterator) it);
    return newit;
  }

  public int STLlength() { return length(); }

  public Object clone() { return new Map(); }
}
