/*
 * PString.java - A pointer to string class.
 *
 */

package yav.jsuif.common;


public class PString
{
  private String _value;

  public PString() { this(null); }
  public PString(String value) { _value = value; }

  public String get() { return _value; }
  public void set(String value) { _value = value; }
}
