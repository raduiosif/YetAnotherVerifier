/*
 * List.java - A port of common/suif_list.h to Java.
 *
 */

package yav.jsuif.common;

/**
 * Implements the hoof list inbuilt type.
 */

public class List extends STLType
{
  /**
   * List node class.
   */
  public static class Node
  {
    public Object data;
    public Node pvNext;
    public Node pvPrev;

    public Node(Object x) 
    { 
      data = x; 
      pvPrev = null;
      pvNext = null;
    }

    private Node(Node other)
    {
      data = other.data;
      pvPrev = other.pvPrev;
      pvNext = other.pvNext;
    }
  }


  /**
   * List iterator class.
   */
  public static class Iterator extends STLType.Iterator
  {
    protected Node node;

    public Iterator dec() { node = node.pvPrev; return this; }
    public Iterator inc() { node = node.pvNext; return this; }
    public Object get() { return node.data; }

    public boolean isEqual(Iterator iter) { return node == iter.node; }
    public boolean notEqual(Iterator iter) { return node != iter.node; }

    public Iterator() { node = null; }
    public Iterator(Iterator x) { node = x.node; }

    //
    // Implementation of the STLType.Iterator interface 
    //

    public boolean STLisEqual(STLType.Iterator x) 
    { 
      return isEqual((Iterator) x);
    }

    public boolean STLnotEqual(STLType.Iterator x)
    {
      return notEqual((Iterator) x);
    }

    public STLType.Iterator STLinc() { return inc(); }
    public STLType.Iterator STLdec() { return dec(); }
    public Object STLget() { return get(); }
    public void STLset(Object x) { node.data = x; }

    protected Iterator(Node x) { node = x; }
  }

  protected int m_nLength;
  protected Iterator m_begin;
  protected Iterator m_end;

  protected void cloneList(List x)
  {
    for (Iterator i = x.begin(); i.notEqual(x.end()); i.inc())
      {
	pushBack(i.get());
      }
  }

  protected void initList()
  {
    m_nLength = 0;
    m_begin = new Iterator((Node) null);
    m_end   = new Iterator((Node) null);
  }

  /**
   * Create an empty list.
   */
  public List() { initList(); }

  /**
   * Copy constructor.
   */

  public List(List other)
  {
    initList();
    cloneList(other);
  }

  /**
   * Emptiness test.
   */
  public boolean empty() { return m_nLength == 0; }

  /**
   * Return the number of elements in list.
   */
  public int length() { return m_nLength; }
  
  /**
   * Insert an element into the list at the iterator position.
   * @param pos insert position
   * @param x insert value
   */
  public Iterator insert(Iterator pos, Object x)
  {
    Node new_node = new Node(x);

    new_node.pvNext = pos.node;
    if (pos.node != null)
      {
	new_node.pvPrev  = pos.node.pvPrev;
	pos.node.pvPrev = new_node;
      }
    else
      {
	new_node.pvPrev = m_end.node;
	m_end.node = new_node;
      }

    if (new_node.pvPrev != null)
      {
	new_node.pvPrev.pvNext = new_node;
      }
    else
      {
	m_begin.node = new_node;
      }

    m_nLength ++;
    return new Iterator(new_node);
  }

  /**
   * Get the nth entry as an iterator.
   * Returns end() if not found.
   * The positions are zero-based. 
   * @param pos position in list
   */
  public Iterator getNth(int pos)
  {
    Iterator x = new Iterator(begin());
    while (x.notEqual(end()) && (pos > 0))
      {
	x.inc();
	pos --;
      }

    return x;
  }

  /**
   * Insert an element before the given position.
   * The front of the list has position 0.
   * @param pos insert position 
   */
  public Iterator insert(int pos, Object x)
  {
    return insert(getNth(pos), x);
  }

  /**
   * Return the beginning of list.
   */
  public Iterator begin() { return new Iterator(m_begin); }

  /**
   * Return the end of list.
   */
  public Iterator end() { return new Iterator((Node) null); }

  /**
   * Push to front of list.
   * @param x pushed value
   */
  public void pushFront(Object x) { insert(begin(), x); }

  /**
   * Pop from front of list.
   */
  public void popFront() { erase(begin()); }

  /**
   * Push to back of list.
   * @param x pushed value
   */
  public void pushBack(Object x) { insert(end(), x); }

  /**
   * Pop from back of list.
   */
  public void popBack() { erase(m_end); }

  /**
   * Returns value in the front of list.
   */
  public Object front() { return m_begin.node.data; }

  /**
   * Returns value in the back of list.
   */
  public Object back() { return m_end.node.data; }

  /**
   * Returns value at position.
   * @param i position
   */
  public Object at(int i)
  {
    return getNth(i).node.data;
  }

  /**
   * Remove the item at the given iterator position.
   * The parameter iterator is invalid upon return.
   * Use the returned iterator instead.
   * @param pos position
   */
  public Iterator erase(Iterator pos)
  {
    Iterator ret_iter = new Iterator(pos);
    Node the_node = pos.node;
    if (the_node == null)
      {
	return ret_iter;
      }

    ret_iter.inc();
    if (the_node.pvPrev != null)
      {
	the_node.pvPrev.pvNext = the_node.pvNext;
      }
    else
      {
	m_begin.node = the_node.pvNext;
      }

    if (the_node.pvNext != null)
      {
	the_node.pvNext.pvPrev = the_node.pvPrev;
      }
    else
      {
	m_end.node = the_node.pvPrev;
      }

    m_nLength --;
    return ret_iter;
  }

  /**
   * Erase item at position. 
   * Returns iterator pointing at the following item.
   * @param pos position
   */
  public Iterator erase(int pos)
  {
    return erase(getNth(pos));
  }

  //
  // Implementation of the STLType interface
  //

  public STLType.Iterator STLbegin() { return begin(); }
  public STLType.Iterator STLend() { return end(); }
  
  public STLType.Iterator STLinsert(STLType.Iterator it, Object object)
  {
    return insert((Iterator) it, object);
  }
  
  public STLType.Iterator STLerase(STLType.Iterator it)
  {
    return erase((Iterator) it);
  }

  public int STLlength() { return length(); }

  public Object clone() { return new List(this); }
}
