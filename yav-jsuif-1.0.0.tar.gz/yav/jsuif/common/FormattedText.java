/*
 * FormattedText.java - A port of common/formatted.h to Java
 *
 */


package yav.jsuif.common;


class TextBlock
{
  public TextBlock parent;
  public String title;
  public String value;
  public Vector children;

  
  public TextBlock(TextBlock p)
  {
    parent = p;
    title = "";
    value = "";
    children = new Vector();
  }
}


public class FormattedText
{
  private int max_line;
  private int indent;
  private boolean no_line_merge;
  private int max_header_len;
  private TextBlock root;
  private TextBlock current;
  private PrintAddress _pa;

  public FormattedText() { this(80, 4, false); }
  public FormattedText(int maxline) { this(maxline, 4, false); }

  public FormattedText(int maxline, int the_indent) 
  { 
    this(maxline, the_indent, false);
  }

  public FormattedText(int maxline, int the_indent, boolean nolinemerge)
  {
    max_line = maxline;
    indent = the_indent;
    no_line_merge = nolinemerge;
    max_header_len = 0;
    root = null;
    current = null;
    _pa = null;

    setUseDiffMode(getUseDiffMode());
    startBlock("");
  }


  public void startBlock(String title) 
  {
    TextBlock t = new TextBlock(current);
    if (current == null)
      {
	root = t;
      }
    else
      {
	current.children.pushBack(t);
      }

    current = t;
    t.title = title;
  }

  public void endBlock() { current = current.parent; }

  public int totalLength(TextBlock block)
  {
    int len = block.title.length();
    for (int i = 0; i < block.children.length(); i ++)
      {
	len += totalLength((TextBlock) block.children.at(i));
      }

    return len;
  }

  public int getIndent(int cur, TextBlock block)
  {
    if (!no_line_merge && (totalLength(block) < max_line))
      {
	return cur;
      }

    if (block.title.length() > cur)
      {
	cur = block.title.length();
      }

    for (int i = 0; i < block.children.length(); i ++)
      {
	cur = getIndent(cur, (TextBlock) block.children.at(i));
      }

    return cur;
  }

  public void setValue(int i) { setValue(Integer.toString(i)); }
  public void setValue(IInteger i) { setValue(i.toString()); }
  public void setValue(boolean b) { setValue(new Boolean(b).toString()); }
  public void setValue(long l) { setValue(Long.toString(l)); }
  public void setValue(double d) { setValue(Double.toString(d)); }
  public void setValue(char c) { setValue(new Character(c).toString()); }

  public void setValue(String x) 
  { 
    if (x == null)
      {
	current.value = "";
      }
    else
      {
	current.value = x;
      }
  }

  public void setValue(Object x) 
  { 
    if (x == null)
      {
	setValue("NULL");
      }
    else
      {
	setValue(x.toString());
      }
  }

  public String getValue() 
  {
    String ind_text = "";
    int ind = (indent >= 0) ? indent : getIndent(0, root);
    for (int i = 0; i < ind; i ++, ind_text += " ");
    return getValue(ind_text, ind_text, no_line_merge, root) + "\n";
  }

  public String getValue(String cur_pad,
			 String the_indent,
			 boolean no_newlines,
			 TextBlock block)
  {
    String val = block.title + "[";
    if (block.value.length() > 0)
      {
	val += block.value;
	return val + "]";
      }

    if (no_newlines || (!no_line_merge && (totalLength(block) < max_line)))
      {
	for (int i = 0; i < block.children.length(); i ++)
	  {
	    val += getValue("", "", true, (TextBlock) block.children.at(i));
	  }

	return val + "]";
      }

    val += "\n";
    String new_pad = cur_pad + the_indent;
    for (int i = 0; i < block.children.length(); i ++)
      {
	TextBlock t = (TextBlock) block.children.at(i);
	val += cur_pad + getValue(new_pad, the_indent, false, t) + "\n";
      }

    return val + cur_pad + "]";
  }

  public String pointerHeader(String x, Object p)
  {
    if (p == null)
      {
	return x + "[NULL]";
      }
    else
      {
	String pointer = _pa.pointerToString(p);
	return x + "[" + pointer + "]->";
      }    
  }

  public void setSpecialPrintMode(PrintAddress pa) { _pa = pa; }

  public boolean getUseDiffMode()
  {
    String suifdiff = System.getProperty("SUIFDIFF");
    if (suifdiff == null)
      {
	return false;
      }

    if (suifdiff.equalsIgnoreCase("true"))
      {
	return true;
      }

    if (suifdiff.equalsIgnoreCase("yes"))
      {
	return true;
      }

    return false;
  }

  public void setUseDiffMode(boolean diff)
  {
    if (diff)
      {
	setSpecialPrintMode(new PointerPrint());
      }
    else
      {
	setSpecialPrintMode(new LiteralPrint());
      }
  }
}
