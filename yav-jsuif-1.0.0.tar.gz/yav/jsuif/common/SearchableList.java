/*
 * SearchableList.java - A port of common/suif_indexed_list.h to Java.
 *
 */

package yav.jsuif.common;

/**
 * Implements the hoof searchable_list inbuilt type.
 */

public class SearchableList extends List
{
  /**
   * Find the entry that is equal with a given key.
   * Returns an iterator that points to the entry.
   * @param key search key
   */
  public Iterator find(Object key)
  {
    Iterator iter = new Iterator(begin());
    while (iter.notEqual(end()))
      {
	if (iter.get().equals(key))
	  {
	    break;
	  }

	iter.inc();
      }

    return iter;
  }

  /**
   * Membership test.
   * @param key test key
   */
  public boolean isMember(Object key) { return find(key).notEqual(end()); }

  /**
   * Remove the first entry with a given value.
   * @param key removed value 
   */
  public boolean remove(Object key)
  {
    Iterator iter = find(key);
    if (iter.isEqual(end()))
      {
	return false;
      }

    erase(iter);
    return true;
  }
}
