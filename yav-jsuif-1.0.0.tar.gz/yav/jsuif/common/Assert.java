package yav.jsuif.common;


public class Assert
{
  public static void condition(boolean x) { condition(x, ""); }

  public static void condition(boolean x, String s)
  {
    if (!x)
      {
	throw new RuntimeException(s);
      }
  }

  public static void recoverable(String s) { recoverable(false, s); }

  public static void recoverable(boolean x, String s)
  {
    if (!x)
      {
	throw new RecoverableException(s);
      }
  }

  public static void fatal() { condition(false); }
  
  public static void fatal(String s) { condition(false, s); }
}
