/*
 * LiteralPrint.java - A port of common/formatted.h to Java
 *
 */

package yav.jsuif.common;


public class LiteralPrint extends PrintAddress
{
  public String pointerToString(Object address)
  {
    if (address == null)
      {
	return "NULL";
      }
    else
      {
	return address.toString();
      }
  }
}
