/*
 * IInteger.java - A very simple port of common/i_integer.h to Java.
 *
 */

package yav.jsuif.common;

import yav.jsuif.ionative.SizeOf;

//
// TODO: Introduce the string representation for iintegers 
//       Is it really necessary for SUIF? Are we going to 
//       deal with numbers so large?
//

public class IInteger
{
  private static final int IIT_C_INT = 0;
  private static final int IIT_POS_INFINITY = 1;
  private static final int IIT_NEG_INFINITY = 2;
  private static final int IIT_SIGNLESS_INFINITY = 3;
  private static final int IIT_UNDETERMINED = 4;

  private int _tag;
  private long _long_val;

  private IInteger(String initial_value)
  {
    try {
      _long_val = Long.parseLong(initial_value);
    } 
    catch (NumberFormatException e) {
      _tag = IIT_UNDETERMINED;
      return;
    }  

    _tag = IIT_C_INT;
  }

  public IInteger() { _tag = IIT_UNDETERMINED; }

  public IInteger(char initial_value)
  {
    _tag = IIT_C_INT;
    _long_val = initial_value;
  }

  public IInteger(short initial_value)
  {
    _tag = IIT_C_INT;
    _long_val = initial_value;
  }

  public IInteger(int initial_value)
  {
    _tag = IIT_C_INT;
    _long_val = initial_value;
  }

  public IInteger(long initial_value)
  {
    _tag = IIT_C_INT;
    _long_val = initial_value;
  }

  public IInteger(IInteger initial_value)
  {
    _tag = IIT_UNDETERMINED;
    setInteger(initial_value);
  }

  public IInteger(char[] initial_string) { this(initial_string, 10); }

  public IInteger(char[] initial_string, int base)
  {
    _tag = IIT_UNDETERMINED;
    read(initial_string, base);
  }


  public boolean isUndetermined() { return _tag == IIT_UNDETERMINED; }
  public boolean isSignlessInfinity() { return _tag == IIT_SIGNLESS_INFINITY; }
  public boolean isFinite() { return _tag == IIT_C_INT; }

  public boolean isNegative()
  {
    switch (_tag)
      {
      case IIT_C_INT:
	return _long_val < 0;

      case IIT_NEG_INFINITY:
	return true;

      default:
	return false;
      }
  }

  public boolean isCChar()
  {
    return isFinite() && geq(Character.MIN_VALUE) && leq(Character.MAX_VALUE);
  }

  public boolean isCShort()
  {
    return isFinite() && geq(Short.MIN_VALUE) && leq(Short.MAX_VALUE);
  }

  public boolean isCInt()
  {
    return isFinite() && geq(Integer.MIN_VALUE) && leq(Integer.MAX_VALUE);
  }

  public boolean isCLong()
  {
    return _tag == IIT_C_INT;
  }

  public char cChar()
  {
    Assert.condition(isCChar());
    return (char) cLong();
  }

  public short cShort()
  {
    Assert.condition(isCShort());
    return (short) cLong();
  }

  public int cInt()
  {
    Assert.condition(isCInt());
    return (int) cLong();
  }

  public long cLong()
  {
    Assert.condition(_tag == IIT_C_INT);
    return _long_val;
  }

  public double cDouble()
  {
    Assert.condition(_tag == IIT_C_INT);
    return _long_val;
  }

  public void setCChar(char new_value) { setCLong(new_value); }
  public void setCShort(short new_value) { setCLong(new_value); }
  public void setCInt(int new_value) { setCLong(new_value); }
  
  public void setCLong(long new_value)
  {
    clear();
    _tag = IIT_C_INT;
    _long_val = new_value;
  }

  public void setInteger(IInteger new_value)
  {
    switch (new_value._tag)
      {
      case IIT_C_INT:
	clear();
	_long_val = new_value._long_val;
	break;

      default:
	break;
      }

    _tag = new_value._tag;
  }

  public void clear()
  {
    _tag = IIT_UNDETERMINED;
  }

  public String write(int base)
  {
    Assert.condition((base > 1) && (base <= 36));
    
    switch (_tag)
      {
      case IIT_C_INT:
	return Long.toString(_long_val, base);

      case IIT_POS_INFINITY:
	return "+Inf";
	
      case IIT_NEG_INFINITY:
	return "-Inf";

      case IIT_SIGNLESS_INFINITY:
	return "Inf";

      case IIT_UNDETERMINED:
	return "??";

      default:
	Assert.fatal();
	return null;
      }
  }

  public void read(String location, int base)
  {
    Assert.condition((base > 1) && (base <= 36));

    String remaining = new String(location).trim();
    if (remaining.regionMatches(0, "+Inf", 0, 4))
      {
	_tag = IIT_POS_INFINITY;
	return;
      }
    
    if (remaining.regionMatches(0, "-Inf", 0, 4))
      {
	_tag = IIT_NEG_INFINITY;
	return;
      }

    if (remaining.regionMatches(0, "Inf", 0, 3))
      {
	_tag = IIT_SIGNLESS_INFINITY;
	return;
      }

    if (remaining.regionMatches(0, "??", 0, 2))
      {
	_tag = IIT_UNDETERMINED;
	return;
      }
    
    try {
      _long_val = Long.parseLong(remaining, base);
    } 
    catch(NumberFormatException e) {
      _tag = IIT_UNDETERMINED;
      return;
    }

    _tag = IIT_C_INT;
  }

  public void read(char[] location, int base) 
  { 
    read(new String(location), base); 
  }
  
  public boolean eq(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	return ((other._tag == IIT_C_INT) && (_long_val == other._long_val));

      case IIT_POS_INFINITY:
	return (other._tag == IIT_POS_INFINITY);

      case IIT_NEG_INFINITY:
	return (other._tag == IIT_NEG_INFINITY);

      case IIT_SIGNLESS_INFINITY:
	return (other._tag == IIT_SIGNLESS_INFINITY);

      case IIT_UNDETERMINED:
	return false;

      default:
	Assert.fatal();
	return false;
      }
  }

  public boolean eq(long other) { return eq(new IInteger(other)); }

  public boolean lt(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    return (_long_val < other._long_val);

	  case IIT_POS_INFINITY:
	    return true;
	    
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return false;

	  default:
	    Assert.fatal();
	    return false;
	  }

      case IIT_POS_INFINITY:
	return false;

      case IIT_NEG_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	  case IIT_POS_INFINITY:
	    return true;
	    
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return false;
	    
	  default:
	    Assert.fatal();
	    return false;
	  }

      case IIT_SIGNLESS_INFINITY:
      case IIT_UNDETERMINED:
	return false;

      default:
	Assert.fatal();
	return false;
      }
  }

  public boolean lt(long other) { return lt(new IInteger(other)); }
  public boolean neq(IInteger other) { return !eq(other); }
  public boolean neq(long other) { return neq(new IInteger(other)); }
  
  public boolean gt(IInteger other) { return other.lt(this); }
  public boolean gt(long other) { return gt(new IInteger(other)); }

  public boolean leq(IInteger other) { return !gt(other); }
  public boolean leq(long other) { return leq(new IInteger(other)); }

  public boolean geq(IInteger other) { return !lt(other); }
  public boolean geq(long other) { return geq(new IInteger(other)); }
  
  public IInteger add(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;
	      if (this_long < 0)
		{
		  if (other_long < 0)
		    {
		      if (this_long >= Long.MIN_VALUE - other_long)
			{
			  return new IInteger(this_long + other_long);
			}
		    }
		  else
		    {
		      return new IInteger(this_long + other_long);
		    }
		}
	      else
		{
		  if (other_long < 0)
		    {
		      return new IInteger(this_long + other_long);
		    }
		  else
		    {
		      if (this_long <= Long.MAX_VALUE - other_long)
			{
			  return new IInteger(this_long + other_long);
			}
		    }
		}

	      Assert.fatal("overflow");
	      return null;
	    }
	    
	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	    return new IInteger(other);

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_POS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	  case IIT_POS_INFINITY:
	    return new IInteger(this);
	    
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_NEG_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	  case IIT_NEG_INFINITY:
	    return new IInteger(this);

	  case IIT_POS_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_SIGNLESS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    return new IInteger(this);

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger add(long other) { return add(new IInteger(other)); }

  public IInteger sub(IInteger other) { return add(other.neg()); }
  public IInteger sub(long other) { return sub(new IInteger(other)); }

  public IInteger mul(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;
	      if ((this_long == 0) || (other_long == 0))
		{
		  return new IInteger(0);
		}

	      if (this_long < 0)
		{
		  if (other_long < 0)
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) >= 0)
			{
			  if (- this_long <= (Long.MAX_VALUE / - other_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		      else
			{
			  if (this_long > (Long.MAX_VALUE / other_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		    }
		  else
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) >= 0)
			{
			  if (- this_long <= (Long.MIN_VALUE / other_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		      else
			{
			  if (this_long > (Long.MIN_VALUE / other_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		    }
		}
	      else
		{
		  if (other_long < 0)
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) >= 0)
			{
			  if (this_long <= (Long.MIN_VALUE / - other_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		      else
			{
			  if (other_long > (Long.MIN_VALUE / this_long))
			    {
			      return new IInteger(this_long * other_long);
			    }
			}
		    }
		  else
		    {
		      if (this_long <= (Long.MAX_VALUE / other_long))
			{
			  return new IInteger(this_long * other_long);
			}
		    }
		}
	      
	      Assert.fatal("overflow");
	      return null;
	    }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	    if (_long_val == 0)
	      {
		return new IInteger();
	      }
	    else if (_long_val < 0)
	      {
		return other.neg();
	      }
	    else
	      {
		return new IInteger(other);
	      }

	  case IIT_SIGNLESS_INFINITY:
	    return new IInteger(other);

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_POS_INFINITY:
      case IIT_NEG_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other._long_val == 0)
	      {
		return new IInteger();
	      }

	    if (other.isNegative())
	      {
		return neg();
	      }
	    else
	      {
		return new IInteger(this);
	      }

	  case IIT_POS_INFINITY:
	    return new IInteger(this);

	  case IIT_NEG_INFINITY:
	    return neg();

	  case IIT_SIGNLESS_INFINITY:
	    return new IInteger(other);

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_SIGNLESS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other._long_val == 0)
	      {
		return new IInteger();
	      }
	    
	    /* fall through */
	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	    return new IInteger(this);

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger mul(long other) { return mul(new IInteger(other)); }

  public IInteger div(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;
	      if (other_long == 0)
		{
		  if (this_long == 0)
		    {
		      return new IInteger();
		    }
		  else
		    {
		      IInteger result = new IInteger();
		      result._tag = IIT_SIGNLESS_INFINITY;
		      return result;
		    }
		}

	      if (this_long == 0)
		{
		  return new IInteger(0);
		}

	      if (other_long == 1)
		{
		  return new IInteger(this_long);
		}
	      
	      if (this_long < 0)
		{
		  if (other_long < 0)
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) >= 0)
			{
			  return new IInteger((-this_long) / (-other_long));
			}
		      else
			{
			  if ((this_long >= - Long.MAX_VALUE) &&
			      (other_long >= - Long.MAX_VALUE))
			    {
			      return new IInteger((-this_long) / 
						  (-other_long));
			    }
			}
		    }
		  else
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) == 0)
			{
			  return new IInteger(- ((-this_long) / other_long));
			}
		      else if ((Long.MAX_VALUE + Long.MIN_VALUE) > 0)
			{
			  if (((-this_long) / other_long) <= Long.MIN_VALUE)
			    {
			      return new IInteger(- ((-this_long) / 
						     other_long));
			    }
			}
		      else
			{
			  if (this_long >= - Long.MAX_VALUE)
			    {
			      return new IInteger(- ((-this_long) / 
						     other_long));
			    }
			}
		    }
		}
	      else
		{
		  if (other_long < 0)
		    {
		      if ((Long.MAX_VALUE + Long.MIN_VALUE) == 0)
			{
			  return new IInteger(- (this_long / (-other_long)));
			}
		      else if ((Long.MAX_VALUE + Long.MIN_VALUE) > 0)
			{
			  if ((this_long / (-other_long)) <= Long.MIN_VALUE)
			    {
			      return new IInteger(-(this_long / 
						    (-other_long)));
			    }
			}
		      else
			{
			  if (other_long >= - Long.MAX_VALUE)
			    {
			      return new IInteger(- (this_long / 
						     (-other_long)));
			    }
			}
		    }
		  else
		    {
		      return new IInteger(this_long / other_long);
		    }
		}

	      Assert.fatal("overflow");
	      return null;
	    }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	    return new IInteger(0);

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_POS_INFINITY:
      case IIT_NEG_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other._long_val == 0)
	      {
		return new IInteger();
	      }

	    if (other.isNegative())
	      {
		return neg();
	      }
	    else
	      {
		return new IInteger(this);
	      }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_SIGNLESS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other._long_val == 0)
	      {
		return new IInteger();
	      }
	    else
	      {
		return new IInteger(this);
	      }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger div(long other) { return div(new IInteger(other)); }

  public IInteger neg()
  {
    switch (_tag)
      {
      case IIT_C_INT:
	if ((Long.MAX_VALUE + Long.MIN_VALUE) == 0)
	  {
	    return new IInteger(- _long_val);
	  }
	else if ((Long.MAX_VALUE + Long.MIN_VALUE) > 0)
	  {
	    long this_long = _long_val;
	    if ((this_long < 0) || (this_long + Long.MIN_VALUE <= 0))
	      {
		return new IInteger(- this_long);
	      }

	    Assert.fatal("overflow");
	    return null;
	  }
	else
	  {
	    long this_long = _long_val;
	    if ((this_long > 0) || (this_long + Long.MAX_VALUE >= 0))
	      {
		return new IInteger(- this_long);
	      }

	    Assert.fatal("overflow");
	    return null;
	  }

      case IIT_POS_INFINITY:
	{
	  IInteger result = new IInteger();
	  result._tag = IIT_NEG_INFINITY;
	  return result;
	}

      case IIT_NEG_INFINITY:
	{
	  IInteger result = new IInteger();
	  result._tag = IIT_POS_INFINITY;
	  return result;
	}

      case IIT_SIGNLESS_INFINITY:
      case IIT_UNDETERMINED:
	return new IInteger(this);

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger and(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;
	      if ((this_long >= 0) && (other_long >= 0))
		{
		  return new IInteger(this_long & other_long);
		}

	      Assert.fatal("overflow");
	      return null;
	    }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	    if (isNegative())
	      {
		return new IInteger(other);
	      }
	    else
	      {
		return new IInteger();
	      }

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_POS_INFINITY:
      case IIT_NEG_INFINITY:
      case IIT_SIGNLESS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other.isNegative())
	      {
		return new IInteger(this);
	      }
	    else
	      {
		return new IInteger();
	      }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return new IInteger();
	  }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger and(long other) { return and(new IInteger(other)); }

  public IInteger or(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;
	      if ((this_long >= 0) && (other_long >= 0))
		{
		  return new IInteger(this_long | other_long);
		}
	      
	      Assert.fatal("overflow");
	      return null;
	    }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	    if (isNegative())
	      {
		return new IInteger();
	      }
	    else
	      {
		return new IInteger(other);
	      }

	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return null;
	  }

      case IIT_POS_INFINITY:
      case IIT_NEG_INFINITY:
      case IIT_SIGNLESS_INFINITY:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    if (other.isNegative())
	      {
		return new IInteger();
	      }
	    else
	      {
		return new IInteger(this);
	      }

	  case IIT_POS_INFINITY:
	  case IIT_NEG_INFINITY:
	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();
	  }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger or(long other) { return or(new IInteger(other)); }

  public IInteger not() { return add(1).neg(); }

  public IInteger shl(IInteger other) { return shr(other.neg()); }
  public IInteger shl(long other) { return shl(new IInteger(other)); }

  public IInteger shr(IInteger other)
  {
    switch (_tag)
      {
      case IIT_C_INT:
	switch (other._tag)
	  {
	  case IIT_C_INT:
	    {
	      long this_long = _long_val;
	      long other_long = other._long_val;

	      if (other_long == 0)
		{
		  return new IInteger(this);
		}
	      
	      if (other_long > 0)
		{
		  if (this_long < 0)
		    {
		      return ((this.neg()).shr(other)).neg();
		    }

		  if (other_long < (long)(SizeOf.LONG * 8))
		    {
		      return new IInteger(this_long >> other_long);
		    }
		  else
		    {
		      return new IInteger(0);
		    }
		}
	      else
		{
		  if ((this_long >= 0) && 
		      (other_long > - (long)(SizeOf.LONG * 8)))
		    {
		      long result = this_long << -other_long;
		      if ((result >> -other_long) == this_long)
			{
			  return new IInteger(result);
			}
		    }
		}

	      Assert.fatal("overflow");
	      return null;
	    }

	  case IIT_POS_INFINITY:
	    if (isNegative())
	      {
		return new IInteger(-1);
	      }
	    else
	      {
		return new IInteger(0);
	      }

	  case IIT_NEG_INFINITY:
	    if (_long_val == 0)
	      {
		return new IInteger(0);
	      }
	    else if (isNegative())
	      {
		return new IInteger(other);
	      }
	    else
	      {
		return other.neg();
	      }

	  case IIT_SIGNLESS_INFINITY:
	  case IIT_UNDETERMINED:
	    return new IInteger();

	  default:
	    Assert.fatal();
	    return new IInteger();
	  }

	case IIT_POS_INFINITY:
        case IIT_NEG_INFINITY:
        case IIT_SIGNLESS_INFINITY:
            switch (other._tag)
              {
	      case IIT_C_INT:
		return new IInteger(this);

	      case IIT_NEG_INFINITY:
		return new IInteger(this);

	      case IIT_POS_INFINITY:
	      case IIT_SIGNLESS_INFINITY:
	      case IIT_UNDETERMINED:
		return new IInteger();

	      default:
		Assert.fatal();
		return new IInteger();
	      }

      case IIT_UNDETERMINED:
	return new IInteger();

      default:
	Assert.fatal();
	return null;
      }
  }

  public IInteger shr(long other) { return shr(new IInteger(other)); }

  public String toString()
  {
    switch (_tag)
      {
      case IIT_C_INT:
	return Long.toString(_long_val);

      case IIT_POS_INFINITY:
	return "+Inf";

      case IIT_NEG_INFINITY:
	return "-Inf";

      case IIT_SIGNLESS_INFINITY:
	return "Inf";

      case IIT_UNDETERMINED:
	return "??";

      default:
	Assert.fatal();
	return null;
      }
  }
}

