/*
 * PointerPrint.java - A port of common/formatted.h to Java
 *
 */

package yav.jsuif.common;


public class PointerPrint extends PrintAddress
{
  private int count;
  private Map _sm = new Map();

  public PointerPrint() { count = 0; }

  public String pointerToString(Object address)
  {
    Map.Iterator iter = _sm.find(address);
    if (iter.notEqual(_sm.end()))
      {
	return (String) iter.get().second;
      }
    
    count ++;
    String result = "pointer" + count;
    _sm.enterValue(address, result);
    return result;
  }
}
