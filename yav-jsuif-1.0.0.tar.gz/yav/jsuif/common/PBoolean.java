/*
 * PBoolean.java - A pointer to boolean class.
 *
 */

package yav.jsuif.common;


public class PBoolean
{
  private boolean _value;

  public PBoolean() { this(false); }
  public PBoolean(boolean value) { _value = value; }

  public boolean get() { return _value; }
  public void set(boolean value) { _value = value; }
}
