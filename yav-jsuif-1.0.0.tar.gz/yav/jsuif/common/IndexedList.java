/*
 * IndexedList.java - A port of common/suif_indexed_list.h to Java.
 *
 */

package yav.jsuif.common;

import yav.jsuif.iokernel.GenericObject;


/**
 * Implements the hoof indexed_list inbuilt type.
 */

public class IndexedList extends STLType
{
  // We need to (artificially) declare this class as subtype
  // of yav.jsuif.iokernel.GenericObject in order to be able
  // to create a meta class and read/write IndexedList.Pair objects.
  public static class Pair extends GenericObject
  {
    public Object first;
    public Object second;

    public Pair(Object key, Object value) 
    { 
      first = key;
      second = value;
    }

    public Pair() { this(null, null); }
  }


  private List the_list;

  /**
   * Push pair to the end of list.
   * @param key pair key
   * @param value pair value
   */
  public void pushBack(Object key, Object value)
  {
    the_list.pushBack(new Pair(key, value));
  }

  /**
   * Returns the last element.
   */
  public Pair back() { return (Pair) the_list.back(); }

  /**
   * Insert after the iterator position.
   * @param pos insert position
   * @param x pair to insert
   */
  public List.Iterator insert(List.Iterator pos, Pair x)
  {
    return the_list.insert(pos, x);
  }

  /**
   * Find the entry with the given key.
   * Returns end() if not found.
   * @param key search key
   */
  public List.Iterator find(Object key)
  {
    List.Iterator iter = new List.Iterator(the_list.begin());
    while (iter.notEqual(the_list.end()))
      {
	if (((Pair) iter.get()).first.equals(key))
	  {
	    break;
	  }

	iter.inc();
      }
    
    return iter;
  }

  /**
   * Find the number of entries with the given key.
   * @param key search key
   */
  public int numWithKey(Object key)
  {
    int count = 0;
    List.Iterator iter = new List.Iterator(the_list.begin());
    while (iter.notEqual(the_list.end()))
      {
	if (((Pair) iter.get()).first.equals(key))
	  {
	    count ++;
	  }

	iter.inc();
      }

    return count;
  }

  /**
   * Find the nth entry with a given key.
   * @param key search key
   * @param no entry number
   */
  public List.Iterator find(Object key, int no)
  {
    List.Iterator iter = new List.Iterator(the_list.begin());
    while (iter.notEqual(the_list.end()))
      {
	if (((Pair) iter.get()).first.equals(key))
	  {
	    if (-- no <= 0)
	      {
		break;
	      }
	  }

	iter.inc();
      }

    return iter;
  }

  /**
   * Membership test for key.
   * @param key test key
   */
  public boolean isMember(Object key)
  {
    return find(key).notEqual(the_list.end());
  }

  /**
   * Remove the entry identified by the iterator.
   * @param iter position iterator
   */
  public Object remove(List.Iterator iter)
  {
    Object x = ((Pair) iter.get()).second;
    the_list.erase(iter);
    return x;
  }

  /**
   * Remove the first entry that matched the key.
   * Returns true if one was found and false otherwise.
   * @param key search key
   */
  public boolean remove(Object key)
  {
    List.Iterator iter = find(key);
    if (iter.isEqual(the_list.end()))
      {
	return false;
      }

    the_list.erase(iter);
    return true;
  }

  /**
   * Returns an iterator that points to the beginning of list.
   */
  public List.Iterator begin() { return the_list.begin(); }

  /**
   * Returns an iterator that points to the end of list.
   */
  public List.Iterator end() { return the_list.end(); }

  /**
   * Returns the number of list entries.
   */
  public int length() { return the_list.length(); }
  
  /**
   * Returns the pair found at position.
   * @param i position 
   */
  public Pair at(int i) { return (Pair) the_list.at(i); }


  /**
   * Default constructor.
   */
  public IndexedList() { the_list = new List(); }

  /**
   * Copy constructor.
   */
  public IndexedList(IndexedList other)
  {
    the_list = (List) other.the_list.clone();
  }

  //
  // Implementation of the STLType.Iterator interface 
  //

  public STLType.Iterator STLbegin() { return begin(); }
  public STLType.Iterator STLend() { return end(); }

  public STLType.Iterator STLinsert(STLType.Iterator it, Object object)
  {
    return insert((List.Iterator) it, (Pair) object);
  }

  public STLType.Iterator STLerase(STLType.Iterator it)
  {
    return the_list.erase((List.Iterator) it);
  }

  public int STLlength() { return length(); }

  public Object clone() { return new IndexedList(); }
}
