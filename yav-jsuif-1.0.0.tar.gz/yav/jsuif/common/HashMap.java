/*
 * HashMap.java - A port of common/suif_hash_map.h to Java.
 *
 */

package yav.jsuif.common;

import yav.jsuif.iokernel.GenericObject;


class HashMapTable
{
  int table_size;
  HashMapInner.PairInner[] table;
  long mask;
  HashMapTable parent;
  HashMapTable child;
  int entry_count;

  HashMapTable(int size, HashMapTable pred, int m)
  {
    table_size = size;
    table = new HashMapInner.PairInner [size];
    mask = m;
    parent = null;
    child = pred;
    entry_count = 0;

    if (pred != null)
      {
	pred.parent = this;
      }
  }

  void clear()
  {
    for (int i = 0; i < table_size; i ++)
      {
	table [i] = null;
      }
  }
}


abstract class HashMapInner extends STLType
{
  // We need to (artificially) declare this class as subtype
  // of yav.jsuif.iokernel.GenericObject in order to be able
  // to create a meta class and read/write HashMap.Pair objects.
  abstract static class PairInner 
    extends GenericObject implements Cloneable
  {
    public PairInner iter_prev;
    public PairInner iter_next;
    public PairInner the_clone;
    public PairInner next;

    public Object clone()
    {
      try {
	return (the_clone = (PairInner) super.clone());
      } catch (CloneNotSupportedException e) { return null; }
    }
  }


  abstract static class HelperInner
  {
    public abstract void setRange(PairInner v, PairInner x);
  }


  abstract static class KeyInner
  {
    public abstract boolean equals(PairInner p);
    public abstract int hash();
  }


  static class IteratorInner extends STLType.Iterator
  {
    private PairInner current;
    private HashMapTable hash;
    private int index;

    private void advance()
    {
      if (current == null)
	{
	  return;
	}

      current = current.iter_next;
    }

    private void retreat()
    {
      if (current == null)
	{
	  return;
	}

      current = current.iter_prev;
    }

    public boolean isEqual(IteratorInner x) { return current == x.current; }
    public boolean notEqual(IteratorInner x) { return current != x.current; }
    public PairInner _get() { return current; }

    public IteratorInner inc() { advance(); return this; }
    public IteratorInner dec() { retreat(); return this; }

    public int getIndex() { return index; }
    public HashMapTable getTable() { return hash; }


    //
    // Implementation of the STLType.Iterator interface 
    //

    public boolean STLisEqual(STLType.Iterator x) 
    { 
      return isEqual((IteratorInner) x);
    }

    public boolean STLnotEqual(STLType.Iterator x)
    {
      return notEqual((IteratorInner) x);
    }

    public STLType.Iterator STLinc() { return inc(); }
    public STLType.Iterator STLdec() { return dec(); }
    public Object STLget() { return _get(); }
    public void STLset(Object x) { current = (PairInner) x; }


    public IteratorInner(HashMapTable x, PairInner t, int i)
    {
      hash = x;
      current = t;
      index = i;
    }

    public IteratorInner(IteratorInner other)
    {
      hash = other.hash;
      current = other.current;
      index = other.index;
    }    
  }


  public IteratorInner find(KeyInner x)
  {
    int hash_value = x.hash();
    HashMapTable next_table = top_table;
    while (next_table != null)
      {
	int index = (int) (hash_value & next_table.mask);
	PairInner y = next_table.table[index];
	while ((y != null) && !x.equals(y))
	  {
	    y = y.next;
	  }

	if (y != null)
	  {
	    return new IteratorInner(next_table, y, index);
	  }

	next_table = next_table.child;
      }

    return new IteratorInner(null, null, 0);
  }

  public PairInner enterValue(KeyInner x, PairInner val)
  {
    int hash_value = x.hash();
    HashMapTable next_table = top_table;
    while (next_table != null)
      {
	int index = (int) (hash_value & next_table.mask);
	PairInner y = next_table.table [index];
	while ((y != null) && !x.equals(y))
	  {
	    y = y.next;
	  }

	if (y != null)
	  {
	    help.setRange(val, y);
	    return y;
	  }

	next_table = next_table.child;
      }

    if (top_table.entry_count > (top_table.table_size << 1))
      {
	top_table = new HashMapTable(top_table.table_size << 3, top_table, 
				     (int) ((top_table.mask << 3) | 0x7));
      }

    top_table.entry_count ++;
    PairInner ny = (PairInner) val.clone();
    int index = (int) (hash_value & top_table.mask);
    ny.next = top_table.table[index];
    top_table.table[index] = ny;
    iterInsert(ny);
    return ny;
  }

  public PairInner enterValueNoChange(KeyInner x, PairInner val)
  {
    int hash_value = x.hash();
    HashMapTable next_table = top_table;
    while (next_table != null)
      {
	int index = (int) (hash_value & next_table.mask);
	PairInner y = next_table.table[index];
	while ((y != null) && !x.equals(y))
	  {
	    y = y.next;
	  }

	if (y != null)
	  {
	    return y;
	  }

	next_table = next_table.child;
      }

    if (top_table.entry_count > (top_table.table_size << 1))
      {
	top_table = new HashMapTable(top_table.table_size << 3, top_table, 
				     (int) ((top_table.mask << 3) | 0x7));
      }

    top_table.entry_count ++;
    PairInner ny = (PairInner) val.clone();
    int index = (int) (hash_value & top_table.mask);
    ny.next = top_table.table[index];
    top_table.table[index] = ny;
    iterInsert(ny);
    return ny;
  }

  public void erase(IteratorInner x)
  {
    int index = x.getIndex();
    HashMapTable table = x.getTable();
    PairInner y = table.table[index];
    PairInner last = null;
    while ((y != null) && (x._get() != y))
      {
	last = y;
	y = y.next;
      }

    if (y == null)
      {
	return;
      }

    if (last == null)
      {
	table.table[index] = y.next;
      }
    else
      {
	last.next = y.next;
      }

    iterErase(y);
  }

  public IteratorInner _begin()
  {
    int i;
    HashMapTable table = top_table;
    while (table != null)
      {
        for (i = 0; (i < table.table_size) && (table.table[i] == null); i ++);
	if (i < table.table_size)
	  {
	    return new IteratorInner(table, begin_list, i);
	  }

	table = table.child;
      }

    return _end();
  }

  public IteratorInner _end() { return new IteratorInner(null, null, 0); }

  public int length()
  {
    int count = 0;
    for (HashMapTable table = top_table; table != null; table = table.child)
      {
	count += table.entry_count;
      }

    return count;
  }

  private int bitsize(long size)
  {
    long i = 1;
    int bits = 0;
    while (size != 0)
      {
	size &= ~i;
	i <<= 1;
	bits ++;
      }

    return bits;
  }

  private void dupTable(HashMapInner x)
  {
    // first dup the hash table
    top_table = null;    
    HashMapTable table = x.top_table;
    while (table != null)
      {
	top_table = new HashMapTable(table.table_size, top_table, 
				     (int) table.mask);
	for (int i = 0; i < table.table_size; i ++)
	  {
	    PairInner y = table.table[i];
	    PairInner last = null;
	    while (y != null)
	      {
		PairInner ny = (PairInner) y.clone();
		if (last == null)
		  {
		    top_table.table[i] = ny;
		  }
		else
		  {
		    last.next = ny;
		  }

		y = y.next;
		last = y;
		top_table.entry_count ++;
	      }
	  }

	table = table.child;
      }

    table = null;
    while (top_table != null)
      {
	HashMapTable t = top_table.child;
	top_table.parent = top_table.child;
	top_table.child = table;
	table = top_table;
	top_table = t;
      }

    top_table = table;

    // then make up the iterator list
    begin_list = null;
    PairInner list = x.begin_list;
    while (list != null)
      {
	iterInsertEnd(list.the_clone);
	list = list.iter_next;
      }
  }

  private void iterInsert(PairInner x)
  {
    x.iter_prev = null;
    x.iter_next = begin_list;
    if (begin_list != null)
      {
	begin_list.iter_prev = x;
      }

    begin_list = x;
  }

  private void iterInsertEnd(PairInner x)
  {
    PairInner y = begin_list;
    PairInner last = null;
    while (y != null)
      {
	last = y;
	y = y.iter_next;
      }
    
    if (last == null)
      {
	x.iter_prev = null;
	x.iter_next = null;
	begin_list = x;
      }
    else
      {
	x.iter_prev = last;
	x.iter_next = null;
	last.iter_next = x;
      }
  }

  private void iterErase(PairInner x)
  {
    PairInner y = begin_list;
    while ((y != null) && (y != x))
      {
	y = y.iter_next;
      }

    if (y == null)
      {
	return;
      }

    if (begin_list == x)
      {
	begin_list = begin_list.iter_next;
      }

    if (x.iter_prev != null)
      {
	x.iter_prev.iter_next = x.iter_next;
      }

    if (x.iter_next != null)
      {
	x.iter_next.iter_prev = x.iter_prev;
      }
  }

  protected PairInner begin_list;
  protected HashMapTable top_table;
  protected HelperInner help;


  public HashMapInner(HelperInner x) { this(x, 32); }

  public HashMapInner(HelperInner x, int size)
  {
    help = x;
    int table_size = 1 << (bitsize(size) - 1);
    int mask = table_size - 1;
    top_table = new HashMapTable(table_size, null, mask);
    begin_list = null;
  }

  public HashMapInner(HashMapInner other)
  {
    help = other.help;
    dupTable(other);
  }
}


public class HashMap extends HashMapInner
{
  public static class Pair extends PairInner 
  {
    public Object first;
    public Object second;

    public Pair() { this(null, null); }
    public Pair(Object x) { this(x, null); }

    public Pair(Object x, Object y)
    {
      first = x;
      second = y;
    }
  }

  
  private static class Helper extends HelperInner
  {
    public void setRange(PairInner val, PairInner x)
    {
      ((Pair) x).second = ((Pair) val).second;
    }
  }

  
  private static class Key extends KeyInner
  {
    private Object value;

    public Key(Object v) { value = v; }
    
    public boolean equals(PairInner p) 
    { 
      if (value == null)
	{
	  return ((Pair) p).first == null;
	}
      
      return value.equals(((Pair) p).first); 
    }

    public int hash() 
    { 
      if (value != null)
	{
	  return value.hashCode();
	}

      return 0;
    }
  }


  public static class Iterator extends IteratorInner
  {
    public Iterator(IteratorInner x) { super(x); }
    public Iterator(Iterator other) { super(other); }

    public Pair get() { return (Pair) _get(); }
  }

  
  /**
   * Enter a value into the table.
   * @param x key
   * @param y value
   */
  public Pair enterValue(Object x, Object y)
  {
    return (Pair) super.enterValue(new Key(x), new Pair(x, y));
  }

  /**
   * To be used for table subscript assignments.
   * @param x key
   * @param y value
   */
  public Pair enterValueAt(Object x, Object y)
  {
    return (Pair) super.enterValueNoChange(new Key(x), new Pair(x, y));
  }

  /**
   * Find an entry by key.
   * Returns end() if not found.
   * @param x search key
   */
  public Iterator find(Object x)
  {
    return new Iterator(super.find(new Key(x)));
  }

  /**
   * Get an iterator to iterate over the values.
   * The order is the insertion order reversed.
   */
  public Iterator begin() { return new Iterator(_begin()); }
  public Iterator end() { return new Iterator(_end()); }

  /**
   * Find a value in the table.
   * If none is found, a new entry is created.
   * @param x search key
   */
  public Pair at(Object x)
  {
    return (Pair) enterValueNoChange(new Key(x), new Pair(x));
  }

  /**
   * Remove item from the table.
   */
  public void erase(Iterator i) { super.erase(i); }

  private Helper the_helper;


  //
  // Implementation of the STLType interface
  //

  public STLType.Iterator STLbegin() { return begin(); }
  public STLType.Iterator STLend() { return end(); }

  public STLType.Iterator STLinsert(STLType.Iterator it, Object object) 
  {
    enterValue(((Pair) object).first, ((Pair) object).second);
    return it;
  }

  public STLType.Iterator STLerase(STLType.Iterator it) 
  { 
    Iterator newit = new Iterator((Iterator) it);
    newit.inc();
    erase((Iterator) it);
    return newit;
  }

  public int STLlength() { return length(); }

  public Object clone() { return new HashMap(); }

  /**
   * Create hash map of default size 32.
   */
  public HashMap() { this(32); }

  /**
   * Create hash map.
   * @param size the size of the hash table. Will be rounded to a power of 2.
   */
  public HashMap(int size) 
  { 
    super(new Helper(), size);
    the_helper = (Helper) help;
  }

  public HashMap(HashMap other)
  {
    super(other);
    the_helper = other.the_helper;
  }
}


