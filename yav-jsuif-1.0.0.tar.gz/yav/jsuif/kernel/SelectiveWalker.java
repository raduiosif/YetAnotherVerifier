/*
 * SelectiveWalker.java - A port from basesuif/suifkernel/group_walker.h 
 *                        to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.MetaClass;

/**
 * SelectiveWalker allows you to walk SuifObjects of a given type
 * (including derived objects). Derive a class from it and overide 
 * apply(). Instantiate it with the name of the class to be walked.
 */
public abstract class SelectiveWalker extends SuifWalker
{
  private String type;

  public String getType() { return type; }

  public boolean isVisitable(Object address, MetaClass mc)
  {
    while (mc != null && !mc.getInstanceName().equals(type))
      {
	mc = mc.getLinkMetaClass();
      }

    return (mc != null);
  }


  public SelectiveWalker(SuifEnv suif, String typeName)
  {
    super(suif);
    type = typeName;
  }
}
