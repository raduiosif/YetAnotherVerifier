/*
 * StreamValueClass.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                         to Java.
 *
 */

package yav.jsuif.kernel;

import java.io.InputStream;


public class StreamValueClass extends ValueClass
{
  private InputStream _stream;

  public InputStream getStream() { return _stream; }


  public StreamValueClass(InputStream stream,
			  ValueClass parent,
			  Option owning_option)
  {
    super(parent, owning_option);
    _stream = stream;
  }
}
