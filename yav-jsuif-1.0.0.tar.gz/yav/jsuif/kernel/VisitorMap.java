/*
 * VisitorMap - A port of basesuif/suifkernel/visitor_map.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.iokernel.MetaClass;


class VisitorEntry
{
  public Object stateAddress;
  public VisitMethod visitMethod;

 
  public VisitorEntry(Object address, VisitMethod method)
  {
    stateAddress = address;
    visitMethod = method;
  }

  public VisitorEntry()
  {
    stateAddress = null;
    visitMethod = null;
  }

  public VisitorEntry(VisitorEntry other)
  {
    stateAddress = other.stateAddress;
    visitMethod = other.visitMethod;
  }
}


/**
 * A dynamically-constructed visitor for SuifObjects, which 
 * dispatches on the most specific one.
 * <p>
 * Example of use:
 * <pre>
 * // write your visitor state class
 * class MyVisitorInfo {
 *   static void doStaticProcedureDefinition(MyVisitorInfo info,
 *                                           ProcedureDefinition obj) {
 *       info.doProcedureDefinition(obj);
 *   }
 *   void doProcedureDefinition(ProcedureDefinition proc_def) {
 *     ...do_something...
 *   }
 * }
 * // register the visitor functions
 * VisitorMap map = new VisitorMap(suif_env);
 * MyVisitorInfo info = new MyVisitorInfo();
 * map.registerVisitMethod(info, 
 *                         new VisitMethod() {
 *                           public void invoke(Object state, 
 *                                              GenericObject object) {
 *                              MyVisitorInfo.doStaticProcedureDefinition(
 *                                            (MyVisitorInfor) state, 
 *                                            (ProcedureDefinition) object);
 *                            }
 *                         },
 *                         ProcedureDefinition.getClassName());
 * // Pick an object:
 * //  SuifObject so;
 * map.apply(so);
 * </pre>
 */
public class VisitorMap
{
  private CascadingMap map;
  private Object unknownState;
  private VisitMethod unknownMethod;

  public void registerVisitMethod(Object stateAddress,
				  VisitMethod visitMethod,
				  String className)
  {
    map.assign(className, new VisitorEntry(stateAddress, visitMethod));
  }

  public void registerVisitMethod(Object stateAddress,
				  VisitMethod visitMethod,
				  MetaClass mc)
  {
    map.assign(mc, new VisitorEntry(stateAddress, visitMethod));
  }

  public void apply(SuifObject object)
  {
    VisitorEntry entry = (VisitorEntry) map.lookup(object);
    if (entry != null)
      {
	if (entry.visitMethod != null)
	  {
	    entry.visitMethod.invoke(entry.stateAddress, object);
	  }
	else
	  {
	    if (unknownMethod != null)
	      {
		entry.visitMethod.invoke(unknownState, object);
	      }
	  }
      }
  }

  public void apply(SuifObject object, MetaClass metaClass)
  {
    VisitorEntry entry = (VisitorEntry) map.lookup(metaClass);
    if (entry != null)
      {
	if (entry.visitMethod != null)
	  {
	    entry.visitMethod.invoke(entry.stateAddress, object);
	  }
	else
	  {
	    if (unknownMethod != null)
	      {
		entry.visitMethod.invoke(unknownState, object);
	      }
	  }
      }
  }

  public void registerUnknownMethod(Object stateAddress,
				    VisitMethod visitMethod)
  {
    unknownState = stateAddress;
    unknownMethod = visitMethod;
  }


  public VisitorMap(SuifEnv suif)
  {
    map = new CascadingMap(suif, new VisitorEntry(null, null));
    unknownState = null;
    unknownMethod = null;
  }
}

