/*
 * OptionMultiString.java - A port of 
 *                          basesuif/suifkernel/command_line_parsing.h
 *                          to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Vector;


/**
 * An OptionMultiString is just like an OptionString
 * but each match of it will push a new string onto the storage
 */

public class OptionMultiString extends Option
{
  private Vector _storage_for_string;
  

  public OptionMultiString() { this("multi-string", null); }
  public OptionMultiString(String argument) { this(argument, null); }

  public OptionMultiString(String argument, Vector storage_for_string)
  {
    super(argument);
    _storage_for_string = storage_for_string;
  }


  public StringValueClass getString() { return getString(0); }

  public StringValueClass getString(int i)
  {
    return (StringValueClass) _values.at(i);
  }

  public StringValueClass getString(ValueClass value, Option context)
  {
    return (StringValueClass) getValueClass(value, context);
  }

  public boolean parse(TokenStream tokens) { return parse(tokens, null); }

  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    if (tokens.isAtEndOfCommand())
      {
	return false;
      }

    Token t = tokens.getToken();
    if (t != null)
      {
	_values.pushBack(new StringValueClass(t, parent, this));
	if (_storage_for_string != null)
	  {
	    _storage_for_string.pushBack(t._token);
	  }

	return true;
      }

    return false;
  }
}
