/*
 * OptionDescription.java - A port of 
 *                          basesuif/suifkernel/command_line_parsing.h to Java.
 *
 */

package yav.jsuif.kernel;


class OptionDescription
{
  public String _group;
  public String _argument;
  public String _description;

  public OptionDescription(String group, String argument, String description)
  {
    _group = group;
    _argument = argument;
    _description = description;
  }
}
