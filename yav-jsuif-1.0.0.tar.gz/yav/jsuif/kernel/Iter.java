/*
 * Iter.java - A port of basesuif/suifkernel/iter.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.iokernel.Iterator;
import yav.jsuif.iokernel.MetaClass;


class IterHelper
{
  private Iterator _iter;
  private boolean _owned;

  private void cloneIter()
  {
    _iter = (Iterator) _iter.clone();
    _owned = true;
  }

  public MetaClass currentMetaClass()
  {
    if (_iter != null)
      {
	return _iter.currentMetaClass();
      }

    return null;
  }

  public String currentName()
  {
    if (_iter != null)
      {
	return _iter.currentName();
      }

    return null;
  }

  /** 
   * Returns true if more elements are left in the iterator.
   */
  public boolean isValid() 
  {
    if (_iter != null)
      {
	return _iter.isValid();
      }

    return false;
  }

  /** 
   * Switches to the next element in the iterator. 
   */
  public void next()
  {
    if (!_owned)
      {
	cloneIter();
      }

    if (_iter != null)
      {
	_iter.next();
      }
  }

  /** 
   * Switches to the previous element in the iterator. 
   */
  public void previous()
  {
    if (!_owned)
      {
	cloneIter();
      }

    if (_iter != null)
      {
	_iter.previous();
      }
  }

  /**
   * Sets the current position to a particular value. 
   */ 
  public void setTo(int index)
  {
    if (!_owned)
      {
	cloneIter();
      }

    if (_iter != null)
      {
	_iter.setTo(index);
      }
  }

  /** 
   * Returns the number of elements in the whole collection. 
   */
  public int length()
  {
    if (_iter != null)
      {
	return _iter.length();
      }

    return 0;
  }

  public Object current()
  {
    if (_iter != null)
      {
	return _iter.current();
      }

    return null;
  }


  public IterHelper(Iterator iter)
  {
    _iter = iter;
    _owned = true;
  }

  public IterHelper(IterHelper other)
  {
    _iter = other._iter;
    _owned = other._owned;
    other._owned = false;
  }
}


public class Iter extends IterHelper
{
  public Object current()
  {
    Assert.condition(isValid(), "iterator not valid");
    return super.current();    
  }

  public Iter(Iterator iter) { super(iter); }
  public Iter(Iter other) { super(other); }
}
