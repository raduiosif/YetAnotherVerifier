/*
 * RealObjectFactory.java - A port of basesuif/suifkernel/real_object_factory.h
 *                          to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.iokernel.ObjectFactory;
import yav.jsuif.iokernel.MetaClass;


public class RealObjectFactory
{
  protected SuifEnv _suif_env;

  public SuifEnv getSuifEnvironment() { return _suif_env; }

  protected ObjectFactory _object_factory;

  protected ObjectFactory getObjectFactory() { return _object_factory; }

  public void init(SuifEnv suif_env)
  {
    _suif_env = suif_env;

    _object_factory = _suif_env.getObjectFactory();
    if (_object_factory != null)
      {
	initIO(_object_factory);
      }

    CloneSubSystem css = _suif_env.getCloneSubSystem();
    if (css != null)
      {
	initCloning(css);
      }

    PrintSubSystem pss = _suif_env.getPrintSubSystem();
    if (pss != null)
      {
	initPrinting(pss);
      }
  }

  public void initIO(ObjectFactory of) {}
  public void initCloning(CloneSubSystem css) {}
  public void initPrinting(PrintSubSystem pss) {}

  public Object createEmptyObject(MetaClass metaClass)
  {
    Assert.condition(_object_factory != null);
    return _object_factory.createEmptyObject(metaClass);
  }

  public String getName() { return ""; }

  protected MetaClass lookupMetaClass(String metaClassName)
  {
    Assert.condition(_object_factory != null);
    return _object_factory.lookupMetaClass(metaClassName);
  }


  public RealObjectFactory()
  {
    _object_factory = null;
    _suif_env = null;
  }
}
