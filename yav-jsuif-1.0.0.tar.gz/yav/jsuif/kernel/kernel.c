#include <jni.h>
#include <suifclasses.h>


extern "C" JNIEXPORT jint JNICALL
  Java_yav_jsuif_kernel_SuifObject_get_1parent_1offset
  (JNIEnv *, jclass)
{
  return (jint) OFFSETOF(SuifObject, parent);
}

