/*
 * CharSource.java - A port of basesuif/suifkernel/char_source.h to Java.
 *
 */

package yav.jsuif.kernel;


/**
 * Generic interface of character stream classes.
 */

public interface CharSource
{
  int get();
  int peek();
}
