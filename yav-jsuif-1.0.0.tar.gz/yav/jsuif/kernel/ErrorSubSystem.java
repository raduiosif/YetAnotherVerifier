/*
 * ErrorSubSystem.java - A port of basesuif/suifkernel/error_subsystem.h 
 *                       to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import java.io.PrintStream;


public class ErrorSubSystem extends SubSystem
{
  private PrintStream _stream;

  public ErrorSubSystem(SuifEnv suif_env) { this(suif_env, System.err); }

  public ErrorSubSystem(SuifEnv suif_env, PrintStream stream)
  {
    super(suif_env);

    _stream = stream;
  }

  
  public void print(String message) { _stream.println(message); }

  public void error(SuifObject obj, String file_name,
		    int line_number, String module_name,
		    String description)
  {
    Assert.condition(obj != null, "expecting non-null argument");
    _stream.println("ERROR IN");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);
  }

  public void error(String file_name, int line_number, 
		    String module_name, String description)
  {
    _stream.println("ERROR IN");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);    
  }

  public void error(String description)
  {
    _stream.println("ERROR:");
    _stream.println(description);
  }

  public void warning(SuifObject obj, String file_name,
		      int line_number, String module_name,
		      String description)
  {
    Assert.condition(obj != null, "expecting non-null argument");
    _stream.println("WARNING IN");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);
  }

  public void warning(String file_name, int line_number, 
		      String module_name, String description)
  {
    _stream.println("WARNING IN");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);    
  }

  public void warning(String description)
  {
    _stream.println("WARNING:");
    _stream.println(description);
  }

  public void information(SuifObject obj, String file_name,
			  int line_number, String module_name,
			  String description)
  {
    Assert.condition(obj != null, "expecting non-null argument");
    _stream.println("INFORMATION");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);
  }

  public void information(String file_name, int line_number, 
			  String module_name, String description)
  {
    _stream.println("INFORMATION");
    _stream.println(" FILE: " + file_name + 
		    " LINE: " + line_number +
		    " MODULE: " + module_name);
    _stream.println(description);    
  }

  public void information(String description)
  {
    _stream.println("INFORMATION");
    _stream.println(description);
  }
}
