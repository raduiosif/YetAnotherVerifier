/*
 * SubSystem.java - A port of basesuif/suifkernel/subsystem.h to Java.
 *
 */

package yav.jsuif.kernel;


/**
 * An abstract class that is the base of all SuifEnv subsystems.
 * The only means is to encapsulate the creating environment.
 */

public abstract class SubSystem
{
  protected SuifEnv _suif_env;

  public SubSystem(SuifEnv suif_env) { _suif_env = suif_env; }

  public SuifEnv getSuifEnv() { return _suif_env; }
}
