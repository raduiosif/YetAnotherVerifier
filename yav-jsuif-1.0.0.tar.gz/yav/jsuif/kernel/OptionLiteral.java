/*
 * OptionLiteral.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                      to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.PBoolean;
import yav.jsuif.common.PString;
import yav.jsuif.common.Vector;


/**
 * An OptionLiteral matches a literal string in the command line.
 */

public class OptionLiteral extends Option
{
  private PBoolean _storage_for_is_set;
  private boolean _default_value;


  public OptionLiteral(String argument) { this(argument, null, false); }

  public OptionLiteral(String argument, PBoolean storage_for_is_set)
  {
    this(argument, storage_for_is_set, false);
  }

  public OptionLiteral(String argument,
		       PBoolean storage_for_is_set,
		       boolean default_value)
  {
    super(argument);
    
    _storage_for_is_set = storage_for_is_set;
    _default_value = default_value;
  }


  public boolean isSet() { return (getNumberOfValues() != 0); }

  public boolean isSet(ValueClass value, Option context)
  {
    return (getValueClass(value, context) != null);
  }

  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    if (tokens.isAtEndOfCommand())
      {
	return false;
      }

    Token t = tokens.getToken();
    if (t == null)
      {
	return false;
      }

    if (!t._token.equals(_argument))
      {
	tokens.pushBack(t);
	return false;
      }

    _values.pushBack(new StringValueClass(t, parent, this));
    if (_storage_for_is_set != null)
      {
	_storage_for_is_set.set(_default_value);
      }

    return true;
  }

  public void print(PString command_line_string, Vector descr)
  {
    if (command_line_string.get() == null)
      {
	command_line_string.set("");
      }

    command_line_string.set(command_line_string.get() + _argument);
    if ((_description != null) && (_description.length() != 0))
      {
	descr.pushBack(new OptionDescription(_group, _argument,
					     _description));
      }
  }
}
