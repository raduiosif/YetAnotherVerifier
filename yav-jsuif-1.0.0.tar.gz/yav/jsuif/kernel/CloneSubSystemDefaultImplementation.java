/*
 * CloneSubSystemDefaultImplementation.java - A port of
 * basesuif/suifkernel/io_subsystem_default_impl.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.CloneStream;


public class CloneSubSystemDefaultImplementation extends CloneSubSystem
{
  private CloneStream _deep_stream;
  private CloneStream _shallow_stream;


  public CloneSubSystemDefaultImplementation(SuifEnv suif_env)
  {
    super(suif_env);

    _deep_stream = null;
    _shallow_stream = null;
  }

  
  public CloneStream getDeepCloneStream() { return _deep_stream; }
  public CloneStream getShallowCloneStream() { return _shallow_stream; }

  public void setDeepCloneStream(CloneStream s) { _deep_stream = s; }
  public void setShallowCloneStream(CloneStream s) { _shallow_stream = s; }
}
