/*
 * TokenStream.java - A port of basesuif/suifkernel/token_stream.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Vector;
import java.io.InputStream;
import java.io.ByteArrayInputStream;


/**
 * A token stream is a source of tokens.
 */

public class TokenStream 
{
  protected CharSource _input_stream;
  protected Vector _tokens;

  /**
   * The token parser will parse the chars into tokens.
   */
  public TokenStream(CharSource i)
  {
    _tokens = new Vector();
    _input_stream = i;
  }

  /**
   * Every element of the vector becomes a token.
   */
  public TokenStream(String[] argv)
  {
    _tokens = new Vector();
    _input_stream = null;
    for (int i = argv.length - 1; i >= 0; i --)
      {
	_tokens.pushBack(new Token("", argv[i], " "));
      }
  }

  private static boolean isSingleton(int ch)
  {
    return ((new String(";{}#[]$\n")).indexOf(ch) != -1);
  }

  private static boolean isNoise(int ch)
  {
    return ((new String(" \t\r\f\0")).indexOf(ch) != -1);
  }

  private static String _prefix(CharSource i)
  {
    String result = "";
    int ch = i.peek();
    while (isNoise(ch))
      {
	result += (char) i.get();
	ch = i.peek();
      }

    return result;
  }

  private static String _string(CharSource i)
  {
    String result = "";
    int ch = i.peek();
    if (isSingleton(ch))
      {
	result += (char) i.get();
      }
    else
      {
	while ((ch != -1) && !isNoise(ch) && !isSingleton(ch))
	  {
	    result += (char) i.get();
	    ch = i.peek();
	  }
      }  

    return result;
  }

  /**
   * Returns null if does not succeed.
   */
  public Token getToken()
  {
    Token t;
    int size = _tokens.length();
    if (size > 0)
      {
	t = (Token) _tokens.at(size - 1);
	_tokens.popBack();
	return t;
      }
    else
      {
	if (_input_stream != null)
	  {
	    t = new Token(_prefix(_input_stream), _string(_input_stream), "");
	    return (t._token.length() > 0) ? t : null;
	  }
	else
	  {
	    return null;
	  }
      }
  }

  /**
   * Returns null if does not succeed.
   */
  public Token peekToken()
  {
    Token t = getToken();
    if (t != null)
      {
	pushBack(t);
	return t;
      }

    return null;
  }

  public void pushBack(Token t)
  {
    _tokens.pushBack(t);
  }

 /**
   * Assume a "{" has been read off, read off tokens until
   * the matching "}".  Append all tokens read into a string stream
   * and return it.  The match "}" is not included in the string stream.
   */
  public InputStream getStream()
  {
    int braces_open = 1, buff_pos = 0;
    byte[] buff = new byte[1024];
    ByteArrayInputStream stream = new ByteArrayInputStream(buff);
    Token t;

    while ((t = getToken()) != null)
      {
	if (t.isEqual("}") && (braces_open == 1))
	  {
	    return stream;
	  }
	else
	  if (t.isEqual("{"))
	    {
	      braces_open ++;
	    }
	  else
	    if (t.isEqual("}"))
	      {
		braces_open --;
	      }

	for (int i = 0; i < t._prefix.length(); i ++)
	  {
	    buff [buff_pos ++] = (byte) t._prefix.charAt(i);
	  }

	for (int i = 0; i < t._token.length(); i ++)
	  {
	    buff [buff_pos ++] = (byte) t._token.charAt(i);
	  }

	for (int i = 0; i < t._separator.length(); i ++)
	  {
	    buff [buff_pos ++] = (byte) t._separator.charAt(i);
	  }
      }

    return stream;
  }

  /**
   * Returns true if next token is either 
   * '\n', ';' or no more tokens can be read.
   */
  public boolean isAtEndOfCommand()
  {
    Token t = peekToken();
    if (t != null) 
      {
	return (t.isEqual("\n") || t.isEqual(";"));
      }
    
    return true;
  }

  /**
   * Returns true if no more tokens can be read.
   */
  public boolean isEmpty()
  {
    if (_tokens.length() > 0)
      {
	return false;
      }

    return (peekToken() == null);
  }
}
