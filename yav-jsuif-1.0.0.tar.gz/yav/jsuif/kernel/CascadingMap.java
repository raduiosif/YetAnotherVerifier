/*
 * CascadingMap.java - A port of basesuif/suifkernel/cascading_map.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;
import yav.jsuif.iokernel.MetaClass;


/**
 * A lookup table with data of generic type java.lang.Object, keyed by 
 * SuifObject, which selects the most specific entry with a key which 
 * is a class or superclass of a given object. 
 * <p>
 * Example of use:
 * <pre>
 * // register the data
 * CascadingMap map = new CascadingMap(suif_env);
 * String my_info1 = "procedure";
 * String my_info2 = "statement";
 * map.assign( ProcedureDefinition.getClassName(), my_info1 );
 * map.assign( Statement.getClassName(), my_info2 );
 * // Pick an object:
 * // SuifObject so;
 * map.lookup(so);
 * // returns my_info1 for any procedure definition,
 * // my_info2 for any statement (or subclass)
 * // null for anything else
 * </pre>
 */

public class CascadingMap
{
  private SuifEnv suif_env;
  private Object defaultValue;
  
  private Vector entries;
  private Vector cached;
  private Vector valid;

  private void clearCache()
  {
    for (int i = 0; i < cached.length(); i ++)
      {
	cached.enter(i, new Boolean(false));
      }
  }
  
  public void assign(String className, Object data)
  {
    assign(suif_env.getObjectFactory().lookupMetaClass(className), data);
  }

  public void assign(MetaClass mc, Object data)
  {
    clearCache();

    Assert.condition(mc != null);
    int id = mc.getMetaClassId();
    while (id >= entries.length())
      {
	entries.pushBack(defaultValue);
      }

    entries.enter(id, data);
    valid.enter(id, new Boolean(true));
  }

  public Object lookup(SuifObject object)
  {
    return lookup(object.getMetaClass());
  }

  public Object lookup(MetaClass mc)
  {
    int id = mc.getMetaClassId();
    while (id >= entries.length())
      {
	entries.pushBack(defaultValue);
      }

    if (((Boolean) valid.at(id)).booleanValue() ||
	((Boolean) cached.at(id)).booleanValue())
      {
	return entries.at(id);
      }
    else
      {
	MetaClass parent = mc.getLinkMetaClass();
	if (parent != null)
	  {
	    Object res = lookup(parent);
	    entries.enter(id, res);
	    cached.enter(id, new Boolean(true));
	    return res;
	  }
	else
	  {
	    entries.enter(id, defaultValue);
	    cached.enter(id, new Boolean(true));
	    return defaultValue;
	  }
      }
  }


  public CascadingMap(SuifEnv suif) { this(suif, null); }
  
  public CascadingMap(SuifEnv suif, Object value)
  {
    defaultValue = value;
    suif_env = suif;
    
    int n = suif_env.getObjectFactory().getLastId();
    entries = new Vector(n);
    cached = new Vector(n);
    valid = new Vector(n);
    for (int i = 0; i < n; i ++)
      {
	entries.enter(i, defaultValue);
	cached.enter(i, new Boolean(false));
	valid.enter(i, new Boolean(false));
      }
  }
}
