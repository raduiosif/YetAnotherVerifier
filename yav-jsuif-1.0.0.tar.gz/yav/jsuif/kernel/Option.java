/*
 * Option.java - A port of basesuif/suifkernel/command_line_parsing.h
 *               to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Vector;
import yav.jsuif.common.PString;

import java.io.InputStream;
import java.io.PrintStream;


/**
 * An Option represents an argument or a flag (like -I) in a unix
 * command. One can build a option tree with option instances as nodes
 * to represent the grammar for the acceptable options. See the subclasses 
 * of Option for ways to construct the tree. Each option may have multiple 
 * values associated with it.
 */

public abstract class Option
{
  protected String _description;
  protected String _group;
  protected String _argument;
  protected Option _parent;
  protected Vector _values;

  public boolean parseOptions(InputStream input, ErrorSubSystem output)
  {
    InputStreamCharSource s = new InputStreamCharSource(input);
    TokenStream t = new TokenStream(s);
    return (parse(t) && t.isEmpty());
  }

  public boolean parseOptions(String[] argv, ErrorSubSystem output)
  {
    TokenStream t = new TokenStream(argv);
    return (parse(t) && t.isEmpty());
  }

  public boolean parse(TokenStream tokens) { return parse(tokens, null); }
  public abstract boolean parse(TokenStream tokens, ValueClass parent);

  public int getNumberOfValues() { return _values.length(); }

  public void deleteValues()
  {
    if (_values != null)
      {
	for (int i = getNumberOfValues(); i > 0; i --)
	  {
	    _values.popBack();
	  }
      }
  }

  public void setArgument(String argument) { _argument = argument; }
  public void setDescription(String descr) { setDescription(descr, ""); }

  public void setDescription(String descr, String group)
  {
    _description = descr;
    _group = group;
  }

  protected ValueClass getValueClass(ValueClass value, Option context)
  {
    ValueClass cv = value;
    for (; (cv != null) && (cv._owning_option != context); cv = cv._parent);
    if (cv == null)
      {
	return null;
      }

    for (int i = 0; i < getNumberOfValues(); i ++)
      {
	ValueClass v = (ValueClass) _values.at(i);
	for (; (v != null) && (v != cv); v = v._parent);
	if (v != null)
	  {
	    return v;
	  }
      }

    return null;
  }

  public void printToStream(PrintStream stream)
  {
    PString command_line = new PString("");
    Vector descriptions = new Vector();

    print(command_line, descriptions);
    stream.println("Description:");

    for (int i = 0; i < descriptions.length(); i ++)
      {
	boolean isEmpty = true;
	OptionDescription d = (OptionDescription) descriptions.at(i);
	if ((d._argument != null) && (d._argument.length() > 0))
	  {
	    stream.println(d._argument);
	    isEmpty = false;
	  }

	if ((d._description != null) && (d._description.length() > 0))
	  {
	    stream.println(d._description);
	    isEmpty = false;
	  }

	if (!isEmpty)
	  {
	    stream.print("\n");
	  }
      }
  }

  public void print(PString command_line_string, Vector descr)
  {
    String argument = "<" + _argument + ">";
    if (command_line_string.get() == null)
      {
	command_line_string.set("");
      }

    command_line_string.set(command_line_string.get() + argument);
    if ((_description != null) && (_description.length() != 0))
      {
	descr.pushBack(new OptionDescription(_group, argument, 
					     _description));
      }
  }

  public static Option buildPrefixedString(String prefix,
					   String argument,
					   PString storage,
					   String description)
  {
    OptionList list = new OptionList();
    list.add(new OptionLiteral(prefix));
    list.add(new OptionString(argument, storage));
    list.setDescription(description);
    return list;
  }


  protected Option() { this("", null); }
  protected Option(String argument) { this(argument, null); }

  protected Option(String argument, Option parent)
  {
    _description = "";
    _group = "";
    _argument = argument;
    _parent = parent;
    _values = new Vector();
  }
}
