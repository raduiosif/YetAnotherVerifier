/*
 * OptionSelection.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                        to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.PString;
import yav.jsuif.common.Vector;


/**
 * An OptionSelection is a collection of sub-options.
 * It matches with one of the sub-options.
 */

public class OptionSelection extends Option
{
  protected boolean _allow_empty;
  protected Vector _selection_list;


  public OptionSelection() { this(false); }
  
  public OptionSelection(boolean allow_empty)
  {
    super("");

    _allow_empty = allow_empty;
    _selection_list = new Vector();
  }

  
  public OptionSelection add(Option o)
  {
    _selection_list.pushBack(o);
    return this;
  }

  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    StructureValueClass selection_list = new StructureValueClass(parent, this);
    _values.pushBack(selection_list);
    for (int i = 0; i < _selection_list.length(); i ++)
      {
	if (((Option) _selection_list.at(i)).parse(tokens, selection_list))
	  {
	    return true;
	  }
      }
    
    return _allow_empty;
  }

  public void deleteValues()
  {
    super.deleteValues();
    for (int i = 0; i < _selection_list.length(); i ++)
      {
	((Option) _selection_list.at(i)).deleteValues();
      }
  }

  public void print(PString command_line_string, Vector descr)
  {
    int cases = _selection_list.length();
    if (cases == 0)
      {
	return;
      }

    if (command_line_string.get() == null)
      {
	command_line_string.set("");
      }

    command_line_string.set(command_line_string.get() + " [ ");
    for (int i = 0; i < cases; i ++)
      {
	((Option) _selection_list.at(i)).print(command_line_string, descr);
	if ((i + 1) < cases)
	  {
	    command_line_string.set(command_line_string.get() + " | ");
	  }
      }

    command_line_string.set(command_line_string.get() + " ] ");
    if ((_description != null) && (_description.length() != 0))
      {
	descr.pushBack(new OptionDescription(_group, _argument,
						    _description));
      }
  }
}
