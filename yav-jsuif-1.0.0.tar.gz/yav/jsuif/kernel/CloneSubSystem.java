/*
 * CloneSubSystem.java - A port of basesuif/suifkernel/io_subsystem.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.iokernel.MetaClass;
import yav.jsuif.iokernel.CloneStream;


public abstract class CloneSubSystem extends SubSystem
{
  public CloneSubSystem(SuifEnv suif_env) { super(suif_env); }

  public SuifObject deepClone(SuifObject object) 
  {
    if (object == null)
      {
	return null;
      }

    return (SuifObject) deepClone((Object) object, object.getMetaClass());
  }

  public SuifObject shallowClone(SuifObject object)
  {
    if (object == null)
      {
	return null;
      }

    return (SuifObject) shallowClone((Object) object, object.getMetaClass());
  }

  private static Object cloneWithStream(Object address, 
					MetaClass metaClass, 
					CloneStream stream)
  {
    Assert.condition(stream != null, "No cloner available, import cloner");
    return stream.clone(address, metaClass);
  }

  public Object deepClone(Object address, MetaClass metaClass)
  {
    if (address == null)
      {
	return null;
      }

    return cloneWithStream(address, metaClass, getDeepCloneStream());
  }

  public Object shallowClone(Object address, MetaClass metaClass)
  {
    return cloneWithStream(address, metaClass, getShallowCloneStream());
  }

  public abstract CloneStream getDeepCloneStream();
  public abstract CloneStream getShallowCloneStream();
  public abstract void setDeepCloneStream(CloneStream str);
  public abstract void setShallowCloneStream(CloneStream str);
}
