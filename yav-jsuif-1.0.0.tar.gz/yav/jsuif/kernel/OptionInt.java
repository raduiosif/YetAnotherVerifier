/*
 * OptionInt.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                  to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.PInteger;


/**
 * An OptionInt matches an integer in the command line.
 */

public class OptionInt extends Option
{
  private PInteger _storage_for_default_value;

  public OptionInt() { this("int", null); } 
  public OptionInt(String argument) { this(argument, null); }

  public OptionInt(String argument, PInteger storage_for_integer)
  {
    super(argument);
    _storage_for_default_value = storage_for_integer;
  }

  public IntValueClass getInt() { return getInt(0); }

  public IntValueClass getInt(int i) 
  {
    return (IntValueClass) _values.at(i);
  }

  public IntValueClass getInt(ValueClass value, Option context)
  {
    return (IntValueClass) getValueClass(value, context);
  }

  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    if (tokens.isAtEndOfCommand())
      {
	return false;
      }

    Token t = tokens.getToken();
    if (t == null)
      {
	return false;
      }

    try {
      Integer.parseInt(t._token);
    } catch(NumberFormatException e) { return false; }

    IntValueClass intValue = new IntValueClass(t, parent, this);
    _values.pushBack(intValue);
    if (_storage_for_default_value != null)
      {
	_storage_for_default_value.set(intValue.getInt());
      }

    return true;
  }
}
