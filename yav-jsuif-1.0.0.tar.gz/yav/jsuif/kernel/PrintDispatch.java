/*
 * PrintDispatch.java
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.ObjectWrapper;
import java.io.PrintStream;


public interface PrintDispatch
{
  public void invoke(Module module, PrintStream output, ObjectWrapper obj);
}
