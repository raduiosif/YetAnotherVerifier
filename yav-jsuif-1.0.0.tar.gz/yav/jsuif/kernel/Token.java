/*
 * Token.java - A port of basesuif/suifkernel/token_stream.h to Java.
 *
 */

package yav.jsuif.kernel;


/**
 * The token parser considers a token to be either:
 * <ul>
 * <li> 1. one of ';', '#', '{', '}', '\n', '[', ']', '$'
 * <li> 2. a string of characters without whitespaces or any char in 1.
 * </ul>
 *
 */

public class Token
{
  public String _prefix;
  public String _token;
  public String _separator;

  public boolean isEqual(String s) 
  {
    if (s == null)
      {
	return (_token.length() == 0);
      }
    else
      {
	return _token.equals(s);
      }
  }


  public Token(String prefix, String token, String separator)
  {
    _prefix = prefix;
    _token = token;
    _separator = separator;
  }

  public Token(Token other)
  {
    _prefix = other._prefix;
    _token = other._token;
    _separator = other._separator;
  }
}
