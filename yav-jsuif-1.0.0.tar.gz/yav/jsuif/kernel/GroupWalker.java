/*
 * GroupWalker.java - A port of basesuif/suifkernel/group_walker.h to Java
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Vector;
import yav.jsuif.iokernel.MetaClass;


/**
 * A list of SelectiveWalkers that will
 * be called for one pass of the tree.
 */
public class GroupWalker extends SuifWalker
{
  private Vector _vector;

  public void appendWalker(SelectiveWalker x)
  {
    MetaClass mc = _env.getObjectFactory().lookupMetaClass(x.getType());
    int index = mc.getMetaClassId();
    while (index >= _vector.length())
      {
	_vector.pushBack(null);
      }

    _vector.enter(index, x);
  }

  private SelectiveWalker lookup(SuifObject x)
  {
    MetaClass mc = x.getMetaClass();
    SelectiveWalker w = null;
    while (mc != null)
      {
	int index = mc.getMetaClassId();
	if (index >= _vector.length())
	  {
	    return null;
	  }

	w = (SelectiveWalker) _vector.at(index);
	if (w != null)
	  {
	    break;
	  }

	mc = mc.getLinkMetaClass();
      }

    if (w != null)
      {
	mc = x.getMetaClass();
	while (mc != null)
	  {
	    int index = mc.getMetaClassId();
	    while (index >= _vector.length())
	      {
		_vector.pushBack(null);
	      }

	    if (_vector.at(index) != null)
	      {
		break;
	      }

	    _vector.enter(index, w);
	    mc = mc.getLinkMetaClass();
	  }
      }
    
    return w;
  }

  public int apply(SuifObject x)
  {
    SelectiveWalker w = lookup(x);
    if (w == null)
      {
	return CONTINUE;
      }

    int status = w.apply(x);
    if (status == REPLACED)
      {
	setAddress(w.getAddress());
      }

    return status;
  }


  public GroupWalker(SuifEnv suif)
  {
    super(suif);
    _vector = new Vector();
  }
}
