/*
 * ValueClass.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                   to Java.
 *
 */

package yav.jsuif.kernel;


public class ValueClass
{
  ValueClass _parent;
  Option _owning_option;


  public ValueClass(ValueClass parent, Option owning_option)
  {
    _parent = parent;
    _owning_option = owning_option;
  }
}
