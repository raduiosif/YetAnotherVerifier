/*
 * OptionStream.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                     to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.PInputStream;
import java.io.InputStream;


/**
 * An OptionStream matches the part of command 
 * line enclosed between a pair of braces ({}).
 */

public class OptionStream extends Option
{
  private PInputStream _storage_for_stream;

  
  public OptionStream() { this("", null); }
  public OptionStream(String argument) { this(argument, null); }

  public OptionStream(String argument, PInputStream storage_for_stream)
  {
    super(argument);   
    _storage_for_stream = storage_for_stream;
  }


  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    if (tokens.isAtEndOfCommand())
      {
	return false;
      }

    Token t = tokens.getToken();
    if (t == null)
      {
	return false;
      }

    if (!t._token.equals("{"))
      {
	tokens.pushBack(t);
	return false;
      }

    InputStream input_stream = tokens.getStream();
    StreamValueClass value = new StreamValueClass(input_stream, parent, this);
    if (_storage_for_stream != null)
      {
	_storage_for_stream.set(input_stream);
      }

    _values.pushBack(value);
    return true;
  }
}
