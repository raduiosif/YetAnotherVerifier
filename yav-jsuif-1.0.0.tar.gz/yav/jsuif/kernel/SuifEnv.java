/*
 * SuifEnv.java - A port of basesuif/suifkernel/suif_env.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.*;
import yav.jsuif.common.Assert;
import yav.jsuif.common.List;
import yav.jsuif.ionative.SizeOf;
import yav.jsuif.typebuilder.TypeBuilder;
import yav.jsuif.nodes.basic.FileSetBlock;


class SuifEnvObjectFactory extends ObjectFactory
{
  public void error(String file_name,
		    int line_number,
		    String module_name,
		    String description)
  {
    getSuifEnv().error(file_name, line_number, module_name, description);
  }

  public void warning(String file_name,
		      int line_number,
		      String module_name,
		      String description)
  {
    getSuifEnv().warning(file_name, line_number, module_name, description);
  }

  public void information(String file_name,
			  int line_number,
			  String module_name,
			  String description)
  {
    getSuifEnv().information(file_name, line_number, module_name, description);
  }
}


/**
 * The global environment of a SUIF session.
 */

public class SuifEnv
{
  protected ObjectFactory _object_factory = null;

  /**
   * Set the default object factory.
   * @param o the object factory
   */
  public void setObjectFactory(ObjectFactory o) { _object_factory = o; }

  /**
   * Get the default object factory.
   */
  public ObjectFactory getObjectFactory() { return _object_factory; }

  protected List factories = new List();

  /**
   * Add another object factory.
   * @param rof the object factory
   */
  public void addObjectFactory(RealObjectFactory rof)
  {
    rof.init(this);
    factories.pushBack(rof);
  }

  /**
   * Get an object factory by name.
   * @param name the factory name
   */
  public RealObjectFactory getObjectFactory(String name)
  {
    List.Iterator it = factories.begin(), end = factories.end();
    while (it.notEqual(end))
      {
	if (((RealObjectFactory)it.get()).getName().equals(name))
	  {
	    return (RealObjectFactory) it.get();
	  }

	it.inc();
      }

    return null;
  }

  protected ModuleSubSystem _module_subsystem = null;

  public void setModuleSubSystem(ModuleSubSystem m) { _module_subsystem = m; }
  public ModuleSubSystem getModuleSubSystem() { return _module_subsystem; }

  protected DLLSubSystem _dll_subsystem = null;

  public void setDLLSubSystem(DLLSubSystem d) { _dll_subsystem = d; }
  public DLLSubSystem getDLLSubSystem() { return _dll_subsystem; }

  public void importModule(String module_name)
  {
    getDLLSubSystem().loadAndInitializeDLL(module_name);
  }

  protected ErrorSubSystem _error_subsystem = null;

  public void setErrorSubSystem(ErrorSubSystem e) { _error_subsystem = e; }
  public ErrorSubSystem getErrorSubSystem() { return _error_subsystem; }

  protected PrintSubSystem _print_subsystem = null;

  public void setPrintSubSystem(PrintSubSystem p) { _print_subsystem = p; }
  public PrintSubSystem getPrintSubSystem() { return _print_subsystem; }

  /**
   * Read in a suif file an make it the current file set block.
   * @param inputFileName the name of the input file
   */
  public void read(String inputFileName)
  {
    _file_set_block = readMore(inputFileName);
  }

  protected InputSubSystem _input_subsystem = null;

  public FileSetBlock readMore(String inputFileName)
  {
    return _input_subsystem.read(inputFileName);
  }

  protected OutputSubSystem _output_subsystem = null;

  /**
   * Write the current file set block into a suif file.
   * @param outputFileName the name of the output file
   */
  public void write(String outputFileName)
  {
    _output_subsystem.write(outputFileName);
  }

  protected CloneSubSystem _clone_subsystem = null;

  public CloneSubSystem getCloneSubSystem() { return _clone_subsystem; }

  protected FileSetBlock _file_set_block = null;

  public FileSetBlock getFileSetBlock() { return _file_set_block; }
  public void setFileSetBlock(FileSetBlock f) { _file_set_block = f; }

  protected TypeBuilder _type_builder = null;

  public TypeBuilder getTypeBuilder() { return _type_builder; }
  public void setTypeBuilder(TypeBuilder t) { _type_builder = t; }

  /**
   * Send an error message to stderr.
   */
  public void error(SuifObject o,
		    String file_name,
		    int line_number,
		    String module_name,
		    String s)
  {
    _error_subsystem.error(o, file_name, line_number, module_name, s);
  }

  public void error(String file_name,
		    int line_number,
		    String module_name,
		    String s)
  {
    _error_subsystem.error(file_name, line_number, module_name, s);
  }

  public void error(String s) { _error_subsystem.error(s); }

  /**
   * Send a warning message to stderr.
   */
  public void warning(SuifObject o,
		      String file_name,
		      int line_number,
		      String module_name,
		      String s)
  {
    _error_subsystem.warning(o, file_name, line_number, module_name, s);
  }

  public void warning(String file_name,
		      int line_number,
		      String module_name,
		      String s)
  {
    _error_subsystem.warning(file_name, line_number, module_name, s);
  }

  public void warning(String s) { _error_subsystem.warning(s); }

  public void information(SuifObject o,
			  String file_name,
			  int line_number,
			  String module_name,
			  String s)
  {
    _error_subsystem.information(o, file_name, line_number, module_name, s);
  }

  public void information(String file_name,
			  int line_number,
			  String module_name,
			  String s)
  {
    _error_subsystem.information(file_name, line_number, module_name, s);
  }

  public void information(String s) { _error_subsystem.information(s); }

  public void init()
  {
    ObjectFactory of = new SuifEnvObjectFactory();

    setObjectFactory(of);
    of.init(this);

    AggregateMetaClass objectMC = 
      (AggregateMetaClass) of.lookupMetaClass(GenericObject.getClassName());

    AggregateMetaClass suifObjectMC =
      of.createObjectMetaClass(SuifObject.getClassName(),
			       SizeOf.SUIF_OBJECT, objectMC);

    PointerMetaClass pointerToSuifObjectR = 
      of.getPointerMetaClass(suifObjectMC, false);

    of.addField(suifObjectMC, "parent", pointerToSuifObjectR, 
		SuifObject.get_parent_offset());

    _input_subsystem = new InputSubSystemDefaultImplementation(this);
    _output_subsystem = new OutputSubSystemDefaultImplementation(this);
    _clone_subsystem = new CloneSubSystemDefaultImplementation(this);
    _module_subsystem = new ModuleSubSystem(this);
    _dll_subsystem = new DLLSubSystem(this);
    _error_subsystem = new ErrorSubSystem(this);
    _print_subsystem = new PrintSubSystem(this);
  }
}
