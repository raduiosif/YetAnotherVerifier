/*
 * Util.java - A general purpose kernel utility class.
 *             A port of basesuif/suifkernel/utilities.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;
import yav.jsuif.common.List;
import yav.jsuif.iokernel.MetaClass;
import yav.jsuif.iokernel.ObjectWrapper;
import yav.jsuif.iokernel.Iterator;
import yav.jsuif.iokernel.ObjectFactory;


class ObjectIterator extends Iterator
{
  protected boolean _is_valid;
  protected MetaClass _what;
  protected Object _start_object;
  protected MetaClass _object_type;
  protected Vector _it_stack;
  protected Iterator _top;
  protected boolean _itself_too;


  protected ObjectIterator(Object start_object,
			   MetaClass object_type,
			   MetaClass what,
			   boolean itself_too)
  {
    _is_valid = false;
    _what = what;
    _start_object = start_object;
    _object_type = object_type.getMetaClass(start_object);
    _it_stack = new Vector();
    _top = null;
    _itself_too = itself_too;
  }

  public ObjectIterator(ObjectIterator other)
  {
    _is_valid = other._is_valid;
    _what = other._what;
    _start_object = other._start_object;
    _object_type = other._object_type;
    _it_stack = new Vector(other._it_stack);
    _top = other._top;
    _itself_too = other._itself_too;
  }


  public static ObjectIterator createObjectIterator(Object start_object,
						    MetaClass object_type,
						    MetaClass what)
  {
    return createObjectIterator(start_object, object_type, what, true);
  }

  public static ObjectIterator createObjectIterator(Object start_object,
						    MetaClass object_type,
						    MetaClass what,
						    boolean itself_too)
  {
    ObjectIterator it = 
      new ObjectIterator(start_object, object_type, what, itself_too);
    it.first();
    return it;
  }

  public MetaClass currentMetaClass() 
  {
    return _is_valid ? _what : null;
  }

  public String currentName()
  {
    return _is_valid ? _top.currentName() : null;
  }

  public Object current() 
  {
    if (_is_valid)
      {
	return (_top != null) ? _top.current() : _start_object;       
      }
    else
      {
	return null;
      }
  }

  public void setCurrent(Object x) 
  {
    if (_is_valid)
      {
	if (_top != null)
	  {
	    _top.setCurrent(x);
	  }
	else
	  {
	    _start_object = x;
	  }
      }
  }
  
  public boolean isValid() { return _is_valid; }

  public void next() 
  {
    if (_is_valid)
      {
	if (_top == null)
	  {
	    Assert.condition(_object_type.definesASubTypeOf(_what));
	    _top = _object_type.getIterator(_start_object);
	    _is_valid = (_top != null);
	  }
      }

    if (_is_valid)
      {
	Assert.condition(_top != null);
	while (_top.isValid())
	  {
	    Iterator new_top = goDeeper();
	    if (new_top != null && !new_top.isValid())
	      {
		new_top = null;
	      }

	    if (new_top != null)
	      {
		_it_stack.pushBack(_top);
		_top = new_top;
	      }
	    else
	      {
		_top.next();
		while (!_top.isValid() && _it_stack.length() > 0)
		  {
		    _top = (Iterator) _it_stack.back();
		    _it_stack.popBack();
		    _top.next();
		  }
	      }

	    _is_valid = _top.isValid();
	    if (_is_valid)
	      {
		if (_top.currentMetaClass().definesASubTypeOf(_what))
		  {
		    break;
		  }
	      }
	  }
      }

    if (_is_valid)
      {
	Assert.condition(_top.currentMetaClass().definesASubTypeOf(_what));
      }
  }

  public void previous() { Assert.fatal(); }

  public void first() 
  {
    // flush the stack
    _top = null;
    while (_it_stack.length() > 0)
      {
	_it_stack.popBack();
      }

    // get first element
    _is_valid = false;
    if (_itself_too)
      {
	_is_valid = _object_type.definesASubTypeOf(_what);
      }

    if (!_is_valid)
      {
	Assert.condition(_top == null);
	_top = _object_type.getIterator(_start_object);
	if (_top != null)
	  {
	    _is_valid = true;
	    if (_top.currentMetaClass().definesASubTypeOf(_what))
	      {
		return;
	      }

	    next();
	  }
	else
	  {
	    _is_valid = false;
	  }
      }
  }

  public Object clone() 
  {
    ObjectIterator n = new ObjectIterator(this);
    if (_top != null)
      {
	n._top = (Iterator) _top.clone();
      }
    else
      {
	n._top = null;
      }

    for (int i = 0; i < _it_stack.length(); i ++)
      {
	n._it_stack.enter(i, ((Iterator) _it_stack.at(i)).clone());
      }

    return n;
  }

  public Iterator goDeeper() 
  {
    Assert.condition(_is_valid);
    Assert.condition(_top != null);
    MetaClass current_mc = _top.currentMetaClass();
    Object address = _top.current();
    return current_mc.getIterator(address);
  }
}


class StopObjectIterator extends ObjectIterator
{
  protected MetaClass _dont_search_beyond;
  
  protected StopObjectIterator(Object start_object,
			       MetaClass object_type,
			       MetaClass dont_search_beyond,
			       MetaClass what, boolean itself_too)
  {
    super(start_object, object_type, what, itself_too);
    _dont_search_beyond = dont_search_beyond;
  }


  public static StopObjectIterator
    createStopObjectIterator(Object start_object,
			     MetaClass object_type,
			     MetaClass dont_search_beyond,
			     MetaClass what,
			     boolean itself_too)
  {
    StopObjectIterator it = new StopObjectIterator(start_object, object_type, 
						   dont_search_beyond, 
						   what, itself_too);
    it.first();
    return it;
  }

  public Iterator goDeeper()
  {
    Assert.condition(_is_valid);
    Assert.condition(_top != null);
    MetaClass current = _top.currentMetaClass();
    Iterator it = null;
    if (!current.definesASubTypeOf(_dont_search_beyond))
      {
	it = current.getIterator(_top.current(), Iterator.OWNED);
      }

    return it;
  }
}


class ObjectRefIterator extends Iterator
{
  protected Vector _obj_stack;
  protected Vector _it_stack;

  protected MetaClass _what;
  protected SuifObject _start_object;


  protected ObjectRefIterator(SuifObject start_object, MetaClass what)
  {
    _what = what;
    _start_object = start_object;
    _obj_stack = new Vector();
    _it_stack = new Vector();
  }

  public ObjectRefIterator(ObjectRefIterator other)
  {
    _what = other._what;
    _start_object = other._start_object;
    _obj_stack = new Vector(other._obj_stack);
    _it_stack = new Vector(other._it_stack);
  }


  public static ObjectRefIterator createObjectIterator(SuifObject start_object,
						       MetaClass what)
  {
    ObjectRefIterator it = new ObjectRefIterator(start_object, what);
    it.first();
    return it;
  }

  public ObjectWrapper currentObj()
  {
    return new ObjectWrapper(current(), currentMetaClass());
  }

  public String currentName()
  {
    return isValid() ? topIter().currentName() : null;
  }

  public MetaClass currentMetaClass()
  {
    return isValid() ?  topIter().currentMetaClass() : null;
  }

  public Object current()
  {
    return isValid() ? topIter().current() : null;
  }

  public void setCurrent(Object x)
  {
    if (isValid())
      {
	topIter().setCurrent(x);
      }
  }

  public boolean isValid() { return !_it_stack.empty(); }

  public void next()
  {
    Assert.condition(isValid());
    while (isValid())
      {
	if (!goDeeper(currentObj()))
	  {
	    topIter().next();
	    while (isValid() && !topIter().isValid())
	      {
		popIter();
		if (!isValid())
		  {
		    break;
		  }
		topIter().next();
	      }
	  }
	if (isTargetObject())
	  {
	    return;
	  }
      }
  }

  public void previous() { Assert.fatal(); }

  public void first()
  {
    clear();
    if (!goDeeper(new ObjectWrapper(_start_object)))
      {
	return;
      }

    if (isTargetObject())
      {
	return;
      }

    next();
  }

  public Object clone()
  {
    ObjectRefIterator n = new ObjectRefIterator(this);
    for (Vector.Iterator iter = _it_stack.begin(); 
	 iter.notEqual(_it_stack.end()); iter.inc())
      {
	n._it_stack.pushBack(iter.get());
      }

    for (Vector.Iterator iter = _it_stack.begin();
	 iter.notEqual(_it_stack.end()); iter.inc())
      {
	n._obj_stack.pushBack(iter.get());
      }

    return n;
  }
  
  protected void clear()
  {
    while (isValid()) popIter();
  }

  protected boolean goDeeper(ObjectWrapper obj)
  {
    if (SuifObject.isKindOfSuifObjectMetaClass(obj.getMetaClass()))
      {
	if (obj.get() != _start_object)
	  {
	    return false;
	  }
      }

    Iterator it = obj.getMetaClass().getIterator(obj.get());
    if (it == null || !it.isValid())
      {
	return false;
      }

    pushIter(it, obj);
    return true;
  }

  protected boolean isTargetObject()
  {
    if (!isValid())
      {
	return false;
      }

    return currentMetaClass().definesASubTypeOf(_what);
  }

  protected Iterator topIter()
  {
    Assert.condition(isValid());
    return (Iterator) _it_stack.back();
  }

  protected void popIter()
  {
    Assert.condition(isValid());
    _it_stack.popBack();
    _obj_stack.popBack();
  }

  protected void pushIter(Iterator iter, ObjectWrapper obj)
  {
    _it_stack.pushBack(iter);
    _obj_stack.pushBack(obj);
  }
}


/**
 * Routines for iterating over subsets of suif objects
 */
public class Util
{
  public static Iterator objectIterator(Object start_object,
					MetaClass object_type,
					MetaClass what)
  {
    return ObjectIterator.createObjectIterator(start_object,
					       object_type,
					       what);
  }

  public static Iterator objectIterator(Object start_object,
					MetaClass start_object_type,
					MetaClass dont_search_beyond,
					MetaClass what)
  {
    return StopObjectIterator.createStopObjectIterator(start_object,
						       start_object_type,
						       dont_search_beyond,
						       what, false);
  }

  public static Iterator objectRefIterator(SuifObject start_object,
					   MetaClass what)
  {
    return ObjectRefIterator.createObjectIterator(start_object, what);
  }

  /**
   * Build an iterator that will walk over all OWNED objects 
   * in the ownership tree rooted at the start_object.
   * <p>
   * Example Usage:
   * <pre>
   * for (Iter iter = Util.objectIterator(file_set_block, "CallStatement");
   *      iter.is_valid(); iter.next())
   * {
   *   CallStatement call = (CallStatement)iter.current();
   *   // do something with the call
   * }
   * </pre>
   * WARNING:<p>
   * even though this iterator will give you access to a
   * reference to the desired object, it is a VERY BAD idea
   * to try to modify the object during iteration.  Instead
   * consider using the collectObjects to build a list of all 
   * the objects to operate on, then make transformations
   */
  public static Iter objectIterator(SuifObject start_object, String mcName)
  {
    Iterator it = null;
    if (start_object != null)
      {
	MetaClass what = start_object.getObjectFactory().findMetaClass(mcName);
	Assert.condition(what != null, "meta class " + mcName + " not found");
	it = objectIterator(start_object, start_object.getMetaClass(), what);
      }

    return new Iter(it);
  }

  public static Iter objectIterator(SuifObject start_object)
  {
    return objectIterator(start_object, SuifObject.getClassName());
  }

  /**
   * Build a list of all OWNED objects in the ownership 
   * tree rooted at the start_object that subclass from the given type.
   * <p>
   * Example Usage:
   * <pre>
   * List sym_list = Util.collectObjects(root, "ProcedureSymbol");
   * for (List.Iterator iter = sym_list->begin();
   *      iter.notEqual(sym_list->end()); iter.inc())
   *   {
   *     ProcedureSymbol ps = (ProcedureSymbol) iter.get();
   *     // do something with the procedure symbol
   *   }
   * </pre>
   * NOTES:<p>
   * Use this iterator to collect all of the objects that
   * subclass from the given type. You can then use the
   * and modify the returned objects after collecting the objects.
   */
  public static List collectObjects(SuifObject start_object, String mcName)
  {
    List l = new List();
    Iterator it;
    if (start_object != null)
      {
	MetaClass what = start_object.getObjectFactory().findMetaClass(mcName);
	Assert.condition(what != null, "meta class " + mcName + " not found");
	it = objectIterator(start_object, start_object.getMetaClass(), what);
	while (it.isValid())
	  {
	    Assert.condition(it.currentMetaClass() == what);
	    l.pushBack(it.current());
	    it.next();
	  }
      }
    
    return l;
  }

  public static List collectObjects(SuifObject start_object)
  {
    return collectObjects(start_object, SuifObject.getClassName());
  }

  /**
   * Build an iterator that will walk over all of the immediate child 
   * SuifObjects that are subtypes of the template type that are OWNED 
   * by this SuifObject.
   * <p>
   * Example Usage:
   * <pre>
   * for (Iter iter = collectInstanceObjects(statement, "Expression");
   *      iter.is_valid(); iter.next()) 
   *   {
   *      Expression exp = (Expression) iter.current();
   *      // do something with the OWNED expression
   *   }
   * </pre>
   * NOTES:<p>
   * The above example is similar to the
   * Statement.getExpressionIterator() method for Statements.
   * This iterator does not dive into the entire ownership tree
   * rooted at the start_object
   */
  
  public static Iter collectInstanceObjects(SuifObject start_object, 
					    String mcName)
  {
    Iterator it = null;
    if (start_object != null)
      {
	ObjectFactory of = start_object.getSuifEnv().getObjectFactory();
	MetaClass what = of.findMetaClass(mcName);
	Assert.condition(what != null, "meta class " + mcName + " not found");
	
	MetaClass dont_search_beyond = 
	  of.findMetaClass(SuifObject.getClassName());
	Assert.condition(dont_search_beyond != null);
	
	it = objectIterator(start_object, 
			    start_object.getMetaClass(),
			    dont_search_beyond, 
			    what);
      }
    
    return new Iter(it);
  }

  public static Iter collectInstanceObjects(SuifObject start_object)
  {
    return collectInstanceObjects(start_object, SuifObject.getClassName());
  }

  /**
   * Build an iterator that will walk over all of the immediate child 
   * SuifObjects that are subtypes of the template type that are REFERENCED
   * (not OWNED) by this SuifObject.
   * <p>
   * Example of use:
   * <pre>
   * for (Iter iter = suifObjectRefIterator(expression, "Type");
   *      iter.is_valid(); iter.next()) 
   *   {
   *      Type t = (Type) iter.current();
   *      // do something with the referenced type.
   *   }
   * </pre>
   * NOTES:<p>
   * This can be used with an iterator over the ownership
   * tree like the objectIterator() to find all the
   * SuifObject links in a system
   */
  public static Iter suifObjectRefIterator(SuifObject start_object, 
					   String mcName)
  {
    Iterator it = null;
    if (start_object != null)
      {
	ObjectFactory of = start_object.getSuifEnv().getObjectFactory();
	MetaClass what = of.findMetaClass(mcName);
	Assert.condition(what != null, "meta class " + mcName + " not found");
	Assert.condition(SuifObject.isKindOfSuifObjectMetaClass(what));
	it = objectRefIterator(start_object, what);
      }
    
    return new Iter(it);
  }

  public static Iter suifObjectRefIterator(SuifObject start_object)
  {
    return suifObjectRefIterator(start_object, SuifObject.getClassName());
  }
}
