/*
 * Module.java - A port of basesuif/suifkernel/module.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;


/**
 * Defines the interface of a module, the basis of IR nodes or passes.
 */

public class Module implements Cloneable
{
  public Module(SuifEnv suif_env) { this(suif_env, ""); }

  public Module(SuifEnv suif_env, String module_name)
  {
    _suif_env = suif_env;
    _module_name = module_name;
    _command_name = null;
    _command_line = null;    
    _command_flags = null;
    _interfaces = new HashMap();
  }


  protected SuifEnv _suif_env;

  public SuifEnv getSuifEnv() { return _suif_env; }

  protected String _module_name;

  public String getModuleName()
  {
    Assert.condition((_module_name != null) && 
		     (_module_name.length() != 0),
		     "module has an empty name");

    return _module_name;
  }

  /**
   * Performs a shallow copy.
   * Should be overridden in subclasses.
   */
  public Object clone()
  {
    try {
      return super.clone();
    } catch(CloneNotSupportedException e) { return null; }
  }

  protected HashMap _interfaces;

  protected void setInterface(String name, Object inter)
  {
    Assert.condition(_interfaces != null);
    _interfaces.enterValue(name, inter);
  }

  public Object getInterface(String name)
  {
    Assert.condition(_interfaces != null);
    HashMap.Iterator iter = _interfaces.find(name);
    Assert.condition(iter.notEqual(_interfaces.end()));
    return iter.get().second;
  }

  public boolean supportsInterface(String name)
  {
    if (_interfaces == null)
      {
	return false;
      }

    HashMap.Iterator iter = _interfaces.find(name);
    return (iter.notEqual(_interfaces.end()));
  }

  public void interfaceRegistered(String module, String iname) {}
  public void interfaceObjectCreated(Module m, String iname) {}
  public void interfaceObjectDestructed(Module m, String iname) {}

  protected OptionList _command_line;
  protected OptionLiteral _command_name;
  protected OptionSelection _command_flags;

  public boolean isInitialized() { return _command_line != null; }
  
  public void initialize()
  {
    _command_line = new OptionList();
    _command_name = new OptionLiteral(getModuleName());
    _command_line.add(_command_name);
    _command_flags = new OptionSelection(true);
    _command_line.add(_command_flags);
  }

  public boolean parseCommandLine(TokenStream command_line_stream)
  {
    Assert.condition(_command_line != null, "parse called before initialize");
    _command_line.deleteValues();

    String command_name = "";
    Token t = command_line_stream.peekToken();
    if (t != null)
      {
	command_name = t._token;
      }

    _command_name.setArgument(command_name);
    if (!_command_line.parse(command_line_stream))
      {
	_command_line.printToStream(System.err);
	System.err.println(_module_name + ": parsing of command line failed");
	return false;
      }

    if (!command_line_stream.isAtEndOfCommand())
      {
	System.err.print("Illegal arguments [");
	while ((t = command_line_stream.getToken()) != null)
	  {
	    System.err.print(t._prefix + t._token + t._separator);	    
	  }

	System.err.println("]");
	_command_line.printToStream(System.err);
	return false;
      }

    return true;
  }

  public void execute() {}

  public void importModule(String module_name) 
  { 
    _suif_env.importModule(module_name);
  }
}


