/*
 * VisitMethod.java - A port from basesuif/suifkernel/visitor_map.h to Java.
 *
 */

package yav.jsuif.kernel;


public interface VisitMethod
{
  void invoke(Object state, SuifObject object);
}
