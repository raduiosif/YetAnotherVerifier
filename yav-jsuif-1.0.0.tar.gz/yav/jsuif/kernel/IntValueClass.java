/*
 * IntValueClass.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                      to Java.
 *
 */

package yav.jsuif.kernel;


public class IntValueClass extends ValueClass
{
  protected Token _token;

  public IntValueClass(Token t, ValueClass parent, Option owning_option)
  {
    super(parent, owning_option);
    _token = new Token(t);
  }

  public int getInt() 
  {
    try { 
      return Integer.parseInt(_token._token);
    } catch(NumberFormatException e) { return 0; }
  }
}
