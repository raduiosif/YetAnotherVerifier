/*
 * IStreamCharSource.java - A port of basesuif/suifkernel/char_source.h
 *                          to Java.
 *
 */

package yav.jsuif.kernel;

import java.io.InputStream;
import java.io.IOException;


public class InputStreamCharSource implements CharSource
{
  private InputStream _stream;
  private int _peek;

  public int get() 
  { 
    if (_peek != -1)
      {
	int b = _peek;
	_peek = -1; 
	return b;
      }

    try {
      return _stream.read();
    } catch(IOException e) { return -1; }
  }

  public int peek()
  {
    if (_peek != -1)
      {
	return _peek;
      }

    try {
      return (_peek = _stream.read());
    } catch(IOException e) { return -1; }
  }


  public InputStreamCharSource(InputStream stream) { _stream = stream; }
}
