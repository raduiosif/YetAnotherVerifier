/*
 * ModuleSubSystem.java - A port of basesuif/suifkernel/module_subsystem.h
 *                        to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.Map;

import java.io.PrintStream;


public class ModuleSubSystem extends SubSystem
{
  private Map listOfRegisteredModules;
  private Map moduleInterfaces;

  public ModuleSubSystem(SuifEnv suif_env)
  {
    super(suif_env);

    listOfRegisteredModules = new Map();
    moduleInterfaces = new Map();
  }

  public Module initializeModule(String moduleName)
  {
    Module module = retrieveModule(moduleName);

    Assert.condition(module != null, "module [" + moduleName + "] not found");
    module.initialize();
    return module;
  }

  public boolean isInitialized(String moduleName)
  {
    Module module = retrieveModule(moduleName);

    Assert.condition(module != null, "module [" + moduleName + "] not found");
    return module.isInitialized();
  }

  public boolean isAvailable(String moduleName)
  {
    return (retrieveModule(moduleName) != null);
  }

  public void registerModule(Module module)
  {
    String moduleName = module.getModuleName();
    if (retrieveModule(moduleName) == null)
      {
	module.initialize();
	listOfRegisteredModules.enterValueAt(moduleName, module);
      }
  }

  /**
   * Returns true iff registering succeeds.
   * @param module the module to be registered
   */
  public boolean testAndRegisterModule(Module module)
  {
    String moduleName = module.getModuleName();
    if (retrieveModule(moduleName) == null)
      {
	registerModule(module);
	return true;
      }

    return false;
  }

  public Module retrieveModule(String moduleName)
  {
    Module module = null;
    Map.Iterator i = listOfRegisteredModules.find(moduleName);
    if (i.notEqual(listOfRegisteredModules.end()))
      {
	module = (Module) i.get().second;
      }

    return module;
  }

  public boolean execute(String moduleName, TokenStream commandLine)
  {
    Module module = parseCommandLineAndClone(moduleName, commandLine);
    if (module != null)
      {
	module.execute();
	return true;
      }
    
    return false;
  }

  public void printModules(PrintStream output, 
			   String separator,
			   String interfaceFilter)
  {
    boolean comma = false;
    Map.Iterator start = listOfRegisteredModules.begin();
    Map.Iterator end = listOfRegisteredModules.end();
    for (Map.Iterator i = start; i.notEqual(end); i.inc())
      {
	Module module = (Module) i.get().second;
	if (comma)
	  {
	    output.print(separator);
	  }

	if (interfaceFilter != null
	    && interfaceFilter.length() != 0
	    && !module.supportsInterface(interfaceFilter))
	  {
	    continue;
	  }

	comma = true;
	output.print("[" + module.getModuleName() + "]");
      }
  }

  public Module parseCommandLineAndClone(String moduleName, 
					 TokenStream commandLine)
  {
    Module module = retrieveModule(moduleName);
    if (module == null)
      {
	System.err.print("Available modules are: ");
	printModules(System.err, ", ", null);
	System.err.print("\nUse one of these or import another library\n");
	Assert.recoverable("Could not load module [" + moduleName + "]");
      }

    module = (Module) module.clone();
    if (!module.isInitialized())
      {
	module.initialize();
      }

    if (!module.parseCommandLine(commandLine))
      {
	return null;
      }

    return module;
  }

  /**
   * Returns null if interface does not exist.
   * @param interfaceName name of the interface
   */
  public ModuleInterface getInterface(String interfaceName)
  {
    Map.Iterator i = moduleInterfaces.find(interfaceName);
    if (i.isEqual(moduleInterfaces.end()))
      {
	return null;
      }

    return (ModuleInterface) i.get().second;
  }

  /**
   * Builds interface if does not exist.
   * @param interfaceName name of the interface
   */
  public ModuleInterface retrieveInterface(String interfaceName)
  {
    ModuleInterface mi = getInterface(interfaceName);
    if (mi == null)
      {
	mi = new ModuleInterface(interfaceName);
	moduleInterfaces.enterValue(interfaceName, mi);
      }

    return mi;
  }

  public void registerInterfaceListener(Module listeningModule,
					String interfaceName)
  {
    ModuleInterface mi = retrieveInterface(interfaceName);
    if (mi.existsListener(listeningModule))
      {
	return;
      }

    mi.addListener(listeningModule);
    mi.notifyListenerOfAllProducerNames(listeningModule);
    mi.notifyListenerOfAllProducers(listeningModule);
  }

  public void registerInterfaceProducerName(String producerName,
					    String interfaceName)
  {
    ModuleInterface mi = retrieveInterface(interfaceName);

    if (mi.existsProducerName(producerName))
      {
	return;
      }
    
    mi.addProducerName(producerName);
    mi.notifyAllListenersOfProducerName(producerName);
  }

  public void registerInterfaceProducer(Module producerModule,
					String interfaceName)
  {
    ModuleInterface mi = retrieveInterface(interfaceName);
    String producerName = producerModule.getModuleName();
    
    registerInterfaceProducerName(producerName, interfaceName);    
    if (mi.existsProducer(producerModule))
      {
	return;
      }

    mi.addProducer(producerModule);
    mi.notifyAllListenersOfProducer(producerModule);
  }

  public void registerInterfaceProducerDestruction(Module producerModule,
						   String interfaceName)
  {
    ModuleInterface mi = retrieveInterface(interfaceName);

    if (!mi.existsProducer(producerModule))
      {
	return;
      }

    mi.removeProducer(producerModule);
    mi.notifyAllListenersOfProducerDestruction(producerModule);
  }
}
