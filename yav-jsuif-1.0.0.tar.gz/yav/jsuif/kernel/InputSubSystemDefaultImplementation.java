/*
 * InputSubSystemDefaultImplementation.java - A port of
 * basesuif/suifkernel/io_subsystem_default_impl.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.*;
import yav.jsuif.common.Assert;
import yav.jsuif.nodes.basic.FileSetBlock;

import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class InputSubSystemDefaultImplementation extends InputSubSystem
{
  public InputSubSystemDefaultImplementation(SuifEnv suif_env)
  {
    super(suif_env);
  }


  public FileSetBlock read(String inputFileName)
  {
    FileSetBlock file_set_block = null;
    ObjectFactory fileOF = null;
    ObjectFactory _object_factory = _suif_env.getObjectFactory();
    FileInputStream inputFile = null;

    try {
      inputFile = new FileInputStream(inputFileName);
    } catch(FileNotFoundException e) {}

    Assert.condition(inputFile != null, 
		     "Could not open file " + inputFileName);

    Assert.condition(SuifCompatibleHeaders.readHeader(inputFile), 
		     "Invalid format for file " + inputFileName);
    
    SuifInputStream inputStream = 
      new SuifBinaryInputStream(_object_factory, inputFile);

    _object_factory.getRudimentaryAddressMap().addToStream(inputStream);

    MetaClass metaClassObjectFactoryMC = 
      _object_factory.lookupMetaClass("ObjectFactory");

    fileOF = (ObjectFactory) inputStream.readObject(metaClassObjectFactoryMC);
    inputStream.readClose();

    Synchronizer sync = new Synchronizer(_object_factory);
    sync.synchronize(_object_factory, fileOF, inputStream);

    MetaClass objectMC = 
      _object_factory.lookupMetaClass(GenericObject.getClassName());

    PointerMetaClass objectMCPO = 
      _object_factory.getPointerMetaClass(objectMC, true);

    file_set_block = (FileSetBlock) inputStream.readObject(objectMCPO);
    inputStream.readClose();

    try {
      inputFile.close();
    } catch(IOException e) {}

    return file_set_block;
  }
}
