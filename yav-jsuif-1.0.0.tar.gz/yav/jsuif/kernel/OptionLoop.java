/*
 * OptionLoop.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                   to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Vector;
import yav.jsuif.common.PString;


public class OptionLoop extends Option
{
  private Option _loop_contents;
  private boolean _allow_empty;


  public OptionLoop(Option loop_contents) { this(loop_contents, true); }
  
  public OptionLoop(Option loop_contents, boolean allow_empty)
  {
    _loop_contents = loop_contents;
    _allow_empty = allow_empty;
  }


  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    StructureValueClass loop_instance = new StructureValueClass(parent, this);
    _values.pushBack(loop_instance);

    boolean is_empty = true;
    while (_loop_contents.parse(tokens, loop_instance)) 
      {
	is_empty = false;
      }
    
    return (_allow_empty || !is_empty);
  }

  public void deleteValues()
  {
    super.deleteValues();
    _loop_contents.deleteValues();
  }

  public void print(PString command_line_string, Vector descr)
  {
    if (command_line_string.get() == null)
      {
	command_line_string.set("");
      }

    command_line_string.set(command_line_string.get() + " { ");
    PString argument = new PString("");
    _loop_contents.print(argument, descr);
    command_line_string.set(command_line_string.get() + argument.get());
    command_line_string.set(command_line_string.get() + " } ");
    if ((_description != null) && (_description.length() != 0))
      {
	descr.pushBack(new OptionDescription(_group, _argument,
					     _description));
      }
  }
}
