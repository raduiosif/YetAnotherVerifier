/*
 * PrintSubSystem.java - A port of basesuif/suifkernel/print_subsystem.h
 *                       to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;
import yav.jsuif.common.FormattedText;
import yav.jsuif.iokernel.ObjectWrapper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;


public class PrintSubSystem extends SubSystem
{
  private String _style;
  private HashMap _string_map;

  private static void printDefault(PrintStream output, ObjectWrapper obj)
  {
    if (SuifObject.isKindOfSuifObjectMetaClass(obj.getMetaClass()))
      {
	FormattedText text = new FormattedText();
	((SuifObject) obj.get()).printSuifObject(text);
	output.println(text.getValue());
      }
    else
      {
	output.println("No available printer for non-SuifObject");
      }
  }

  public void print(String style, PrintStream output, ObjectWrapper obj)
  {
    ModuleSubSystem ms = getSuifEnv().getModuleSubSystem();
    if ((style == null || style.equals("")) ||
	(ms == null || !ms.isAvailable(style) || !ms.isInitialized(style)))
      {
	printDefault(output, obj);
	return;
      }

    Module module = ms.retrieveModule(style);
    String print_interface = "print";
    if (!module.supportsInterface(print_interface))
      {
	printDefault(output, obj);
	return;
      }

    PrintDispatch pfunc = (PrintDispatch) module.getInterface(print_interface);
    if (pfunc != null)
      {
	pfunc.invoke(module, output, obj);
      }
    else
      {
	output.println("installed style " + style + 
		       " has no valid print function");
      }
  }

  public void print(String style, PrintStream output, SuifObject obj)
  {
    if (obj == null)
      {
	return;
      }

    print(style, output, new ObjectWrapper(obj));
  }

  public String printToString(String style, ObjectWrapper obj)
  {
    ByteArrayOutputStream s = new ByteArrayOutputStream();
    print(style, new PrintStream(s), obj);
    return s.toString();
  }

  public void print(PrintStream output, ObjectWrapper obj)
  {
    print(getDefaultPrintStyle(), output, obj);
  }

  public void print(PrintStream output, SuifObject obj)
  {
    print(getDefaultPrintStyle(), output, new ObjectWrapper(obj));
  }

  public void print(File file, ObjectWrapper obj)
  {
    FileOutputStream fos;

    try {
      fos = new FileOutputStream(file);
    } catch (IOException e) { return; }

    print(getDefaultPrintStyle(), new PrintStream(fos), obj);
  }

  public String printToString(ObjectWrapper obj)
  {
    return printToString(getDefaultPrintStyle(), obj);
  }

  public void print(ObjectWrapper obj)
  {
    print(getDefaultPrintStyle(), getDefaultStream(), obj);
  }
  
  public void print(SuifObject obj)
  {
    if (obj == null)
      {
	return;
      }

    print(getDefaultPrintStyle(), getDefaultStream(), new ObjectWrapper(obj));
  }

  public String printToString(SuifObject obj)
  {
    if (obj == null)
      {
	return "";
      }

    return printToString(getDefaultPrintStyle(), new ObjectWrapper(obj));
  }

  public PrintStream getDefaultStream() { return System.err; }

  public void setDefaultPrintStyle(String style) { _style = style; }
  public String getDefaultPrintStyle() { return _style; }

  public PrintStringRepository retrieveStringRepository(String style)
  {
    if (_string_map == null)
      {
	_string_map = new HashMap();
      }

    HashMap.Iterator iter = _string_map.find(style);
    if (iter.isEqual(_string_map.end()))
      {
	_string_map.enterValueAt(style, new PrintStringRepository());
      }

    return (PrintStringRepository) _string_map.at(style).second;
  }


  public PrintSubSystem(SuifEnv suif_env)
  {
    super(suif_env);

    _string_map = null;
    _suif_env.setPrintSubSystem(this);
  }
}

