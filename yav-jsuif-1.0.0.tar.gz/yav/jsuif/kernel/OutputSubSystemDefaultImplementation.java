/*
 * InputSubSystemDefaultImplementation.java - A port of
 * basesuif/suifkernel/io_subsystem_default_impl.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.*;
import yav.jsuif.common.Assert;
import yav.jsuif.nodes.basic.FileSetBlock;

import java.io.IOException;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;


public class OutputSubSystemDefaultImplementation extends OutputSubSystem
{
  public OutputSubSystemDefaultImplementation(SuifEnv suif_env)
  {
    super(suif_env);
  }


  public void write(String outputFileName)
  {
    ObjectFactory _object_factory = _suif_env.getObjectFactory();
    FileSetBlock rootNode = _suif_env.getFileSetBlock();
    FileOutputStream outputFile = null;

    try {
      outputFile = new FileOutputStream(outputFileName);
    } catch(FileNotFoundException e) {}

    Assert.condition(outputFile != null,
		     "Could not open file " + outputFileName);

    SuifOutputStream outputStream = new SuifBinaryOutputStream(outputFile);
    
    SuifCompatibleHeaders.writeHeader(outputFile);    
    
    _object_factory.getRudimentaryAddressMap().addToStream(outputStream);

    MetaClass ofMC = _object_factory.getMetaClass();
    outputStream.writeObject(new ObjectWrapper(_object_factory, ofMC));

    MetaClass objectMC = 
      _object_factory.lookupMetaClass(GenericObject.getClassName());

    PointerMetaClass rootNodeMetaClass =
      _object_factory.getPointerMetaClass(objectMC, true);

    outputStream.writeObject(new ObjectWrapper(rootNode, rootNodeMetaClass));
    outputStream.writeClose();

    try {
      outputFile.close();
    } catch(IOException e) {}
  }
}
