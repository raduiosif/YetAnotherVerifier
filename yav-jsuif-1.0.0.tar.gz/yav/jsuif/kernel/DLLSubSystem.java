/*
 * DLLSubSystem.java - An emulation of the SUIF DLL subsystem. 
 *                     Loads Java-written modules from the CLASSPATH.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;


public class DLLSubSystem extends SubSystem
{
  public DLLSubSystem(SuifEnv suif_env) { super(suif_env); }

  public void loadAndInitializeDLL(String moduleName)
  {
    String initName = "init";
    Class classFile = null;
    try {
      classFile = Class.forName(moduleName);      
    } catch(ClassNotFoundException e) {
      Assert.recoverable("Class " + moduleName + " not found");
    }

    Method method = null;
    try {
      method = classFile.getMethod(initName, new Class[] { SuifEnv.class } );
    } catch(NoSuchMethodException e) {
      Assert.fatal("Could not find method " + initName
		   + " in class " + moduleName);
    } catch(SecurityException e) {
      Assert.fatal("Method " + initName + " in class "
		   + moduleName + " not accessible");
    }
    
    try {
      method.invoke(null, new Object[] { _suif_env } );
    } catch (IllegalAccessException e) {
      Assert.fatal(e.toString());
    } catch(IllegalArgumentException e) {
      Assert.fatal(e.toString());
    } catch(InvocationTargetException e) {
      Assert.fatal(e.toString());
    }
  }
}
