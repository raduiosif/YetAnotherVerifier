/*
 * PrintStringRepository.java - A port of basesuif/suifkernel/print_subsystem.h
 *                              to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.HashMap;


public class PrintStringRepository
{
  private HashMap _print_full;
  private HashMap _print_ref;

  public String getPrintRefString(String key)
  {
    if (!hasPrintRefString(key))
      {
	return null;
      }

    return (String) _print_ref.at(key).second;
  }

  public String getPrintString(String key)
  {
    if (!hasPrintString(key))
      {
	return null;
      }

    return (String) _print_full.at(key).second;
  }

  public void setPrintRefString(String key, String value)
  {
    _print_ref.enterValueAt(key, value);
  }

  public void setPrintString(String key, String value)
  {
    _print_full.enterValueAt(key, value);
  }

  public boolean hasPrintRefString(String key)
  {
    return _print_ref.find(key).notEqual(_print_ref.end());
  }

  public boolean hasPrintString(String key)
  {
    return _print_full.find(key).notEqual(_print_full.end());
  }

  
  public PrintStringRepository()
  {
    _print_full = new HashMap();
    _print_ref = new HashMap();
  }
}
