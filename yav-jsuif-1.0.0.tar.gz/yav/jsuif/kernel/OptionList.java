/*
 * OptionList.java - A port of basesuif/suifkernel/command_line_parsing.h
 *                   to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.PString;
import yav.jsuif.common.Vector;


/**
 * An OptionList represents a sequence of sub-options.
 * It matches with all the options in the sequence.
 */

public class OptionList extends Option
{
  private Vector _option_list;

  public OptionList() { _option_list = new Vector(); }

  public OptionList add(Option o)
  {
    _option_list.pushBack(o);
    return this;
  }

  public boolean parse(TokenStream tokens, ValueClass parent)
  {
    StructureValueClass list_contents = new StructureValueClass(parent, this);
    _values.pushBack(list_contents);
    for (int i = 0; i < _option_list.length(); i ++)
      {
	if (!((Option) _option_list.at(i)).parse(tokens, list_contents))
	  {
	    return false;
	  }
      }

    return true;
  }

  public void deleteValues()
  {
    super.deleteValues();
    for (int i = 0; i < _option_list.length(); i ++)
      {
	((Option) _option_list.at(i)).deleteValues();
      }
  }

  public void print(PString command_line_string, Vector descr)
  {
    PString argument = new PString("");
    int index = 0;
    if ((_description != null) && (_description.length() != 0))
      {
	index = descr.length();
	descr.pushBack(new OptionDescription(_group, _argument,
					     _description));
      }

    for (int i = 0; i < _option_list.length(); i ++)
      {
	((Option) _option_list.at(i)).print(argument, descr);
	argument.set(argument.get() + " ");
      }

    if (command_line_string.get() == null)
      {
	command_line_string.set("");
      }

    command_line_string.set(command_line_string.get() + argument.get());
    if ((_description != null) && (_description.length() != 0))
      {
	((OptionDescription) descr.at(index))._argument = argument.get();
      }
  }
}
