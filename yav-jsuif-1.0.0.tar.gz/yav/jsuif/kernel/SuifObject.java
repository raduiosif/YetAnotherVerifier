/*
 * SuifObject.java - A port of basesuif/suifkernel/suif_object.h to Java.
 * 
 */

package yav.jsuif.kernel;

import yav.jsuif.iokernel.*;
import yav.jsuif.common.Assert;
import yav.jsuif.common.FormattedText;
import java.io.PrintStream;

/**
 * The base class for all IR nodes in the SUIF representation.
 */

public class SuifObject extends GenericObject
{
  private static final String _className = "SuifObject";

  public static String getClassName() { return _className; }

  public static boolean isKindOfSuifObjectMetaClass(MetaClass mc)
  {
    while (mc != null && !mc.getInstanceName().equals(_className))
      {
	mc = mc.getLinkMetaClass();
      }

    return (mc != null);
  }

  /**
   * Clone this object and all objects in the 
   * ownership tree rooted at this object.
   * @param suif_env the SUIF environment (default null)
   */
  public SuifObject deepClone(SuifEnv suif_env)
  {
    if (suif_env == null)
      {
	suif_env = getSuifEnv();
      }

    SuifObject cloned = suif_env.getCloneSubSystem().deepClone(this);
    cloned.setParent(null);
    return cloned;
  }

  /**
   * Clone this object only. All references that this object
   * has to other objects will be copied to the new clone.
   * @param suif_env the SUIF environment (default null)
   */
  public SuifObject shallowClone(SuifEnv suif_env)
  {
    if (suif_env == null)
      {
	suif_env = getSuifEnv();
      }

    SuifObject cloned = suif_env.getCloneSubSystem().shallowClone(this);
    cloned.setParent(null);
    return cloned;
  }

  // FieldDescription.buildObject() needs public access to this field
  public SuifObject parent;

  public static native int get_parent_offset();

  /**
   * Get the object's parent in the ownership tree.
   * It must be the case that the parent also has
   * a reference to this object. Any object removed
   * from the tree must set its parent to null and 
   * remove parent's the reference to it.
   */
  public SuifObject getParent()
  {
    return parent;
  }

  /**
   * Set the object's parent.
   * It is an error to set the parent to a 
   * new object if the parent was not null.
   * @param object the new parent
   */
  public void setParent(SuifObject object)
  {
    Assert.condition((object == null) || (parent == null),
		     "Attempt to set parent of an (" + getClassName() + 
		     ") to a (" + object.getClassName() + ") " + 
		     "not disconnected from (" + parent.getClassName() + ")");
    parent = object;
  }

  /**
   * Get the object factory that built this object.
   */
  public ObjectFactory getObjectFactory()
  {
    return getMetaClass().getOwningFactory();
  }

  /**
   * Get the suif environment that built this object.
   */
  public SuifEnv getSuifEnv()
  {
    return getObjectFactory().getSuifEnv();
  }

  /**
   * Output this object on an output stream.
   */
  public void print(PrintStream output)
  {
    SuifEnv suif_env = getObjectFactory().getSuifEnv();
    suif_env.getPrintSubSystem().print(output, this);
  }

  /**
   * Output this object to a string.
   */
  public String printToString()
  {
    SuifEnv suif_env = getObjectFactory().getSuifEnv();
    return suif_env.getPrintSubSystem().printToString(this);    
  }

  /**
   * Replace this object with the new object.
   * This method replaces the parent pointer in this object
   * and set the reference from its parent to the new object.
   * @param original the original object
   * @param new_object the new object
   */
  public int replace(SuifObject original, SuifObject new_object)
  {
    int number_replacements = 0;
    ObjectFactory of = getObjectFactory();

    MetaClass suif_mc = of.findMetaClass(SuifObject.getClassName());
    MetaClass what = of.getPointerMetaClass(suif_mc, true);
    Iterator it = Util.objectIterator(this, getMetaClass(), suif_mc, what);
    while (it.isValid())
      {
	if (it.current().equals(original))
	  {
	    it.setCurrent(new_object);
	    if ((new_object != null) && (new_object.getParent() != this))
	      {
		new_object.setParent(this);
	      }

	    number_replacements ++;
	  }

	it.next();
      }

    return number_replacements;
  }

  /**
   * A placeholder for a method that will
   * verify various internal invariants.
   * @param destination message printer object
   */
  public void verifyInvariants(ErrorSubSystem destination) {}

  public void print(FormattedText text) {}

  /**
   * Print method to be used when
   * no system printer is installed.
   * @param x printer object
   */
  public void printSuifObject(FormattedText text)
  {
    String name = "{Unregistered " + getInstanceName() + "}";
    text.startBlock(name);
    for (Iter iter = Util.collectInstanceObjects(this); 
	 iter.isValid(); iter.next())
      {
	SuifObject child = (SuifObject) iter.current();
	child.printSuifObject(text);
      }
    text.endBlock();
  }

  public int walk(Walker walk)
  {
    return getMetaClass().walk(this, walk);
  }


  static {
    System.loadLibrary("jsuif");
  }


  public SuifObject()
  {
    parent = null;
  }
}
