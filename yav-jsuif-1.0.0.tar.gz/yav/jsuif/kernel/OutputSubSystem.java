/*
 * OutputSubSystem.java - A port of basesuif/suifkernel/io_subsystem.h to Java
 *
 */

package yav.jsuif.kernel;


public abstract class OutputSubSystem extends SubSystem
{
  public OutputSubSystem(SuifEnv suif_env) { super(suif_env); }

  public abstract void write(String outputFileName);
}
