/*
 * ModuleInterface.java - A port of basesuif/suifkernel/module_subsystem.cpp
 *                        to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.common.List;


/**
 * Support for the SUIF module interface system.
 * Permits to each module to find out about other
 * modules that support a particular interface.
 */

public class ModuleInterface
{
  protected String interfaceName;
  protected List listenerModules;
  protected List producerModules;
  protected List producerModuleNames;


  public ModuleInterface(String iname)
  {
    interfaceName = iname;
    listenerModules = new List();
    producerModules = new List();
    producerModuleNames = new List();
  }


  public boolean existsListener(Module m)
  {
    List.Iterator start = listenerModules.begin();
    List.Iterator end = listenerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	if (i.get() == m)
	  {
	    return true;
	  }
      }

    return false;
  }

  public void addListener(Module m)
  {
    Assert.condition(!existsListener(m), "listener module already exists");
    listenerModules.pushBack(m);
  }

  public boolean existsProducer(Module m)
  {
    List.Iterator start = producerModules.begin();
    List.Iterator end = producerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	if (i.get() == m)
	  {
	    return true;
	  }
      }

    return false;
  }

  public void addProducer(Module m)
  {
    Assert.condition(!existsProducer(m), "producer module already exists");
    producerModules.pushBack(m);
  }

  public void removeProducer(Module m)
  {
    if (!existsProducer(m))
      {
	return;
      }

    List.Iterator start = producerModules.begin();
    List.Iterator end = producerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	if (i.get() == m)
	  {
	    producerModules.erase(i);
	    return;
	  }
      }
  }

  public boolean existsProducerName(String pname)
  {
    List.Iterator start = producerModuleNames.begin();
    List.Iterator end = producerModuleNames.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	if (i.get() == pname)
	  {
	    return true;
	  }
      }

    return false;
  }

  public void addProducerName(String pname)
  {
    Assert.condition(!existsProducerName(pname), 
		     "producer name already exists");
    producerModuleNames.pushBack(pname);
  }

  /**
   * @param m listening module
   */
  public void notifyListenerOfAllProducerNames(Module m)
  {
    List.Iterator start = producerModuleNames.begin();
    List.Iterator end = producerModuleNames.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	m.interfaceRegistered((String) i.get(), interfaceName);
      }
  }

  /**
   * @param m listening module
   */
  public void notifyListenerOfAllProducers(Module m)
  {
    List.Iterator start = producerModules.begin();
    List.Iterator end = producerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	m.interfaceObjectCreated((Module) i.get(), interfaceName);
      }
  }

  /**
   * @param name 
   */
  public void notifyAllListenersOfProducerName(String name)
  {
    List.Iterator start = listenerModules.begin();
    List.Iterator end = listenerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	((Module) i.get()).interfaceRegistered(name, interfaceName);
      }
  }

  /**
   * @param m producer module
   */
  public void notifyAllListenersOfProducer(Module m)
  {
    List.Iterator start = listenerModules.begin();
    List.Iterator end = listenerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	((Module) i.get()).interfaceObjectCreated(m, interfaceName);
      }
  }

  /**
   * @param m producer module
   */
  public void notifyAllListenersOfProducerDestruction(Module m)
  {
    List.Iterator start = listenerModules.begin();
    List.Iterator end = listenerModules.end();
    for (List.Iterator i = start; i.notEqual(end); i.inc())
      {
	((Module) m).interfaceObjectDestructed(m, interfaceName);
      }    
  }
}
