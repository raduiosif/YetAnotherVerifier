/*
 * StructureValueClass.java - A port of 
 *                            basesuif/suifkernel/command_line_parsing.h
 *                            to Java.
 *
 */

package yav.jsuif.kernel;


public class StructureValueClass extends ValueClass
{
  public StructureValueClass(ValueClass parent, Option owning_option)
  {
    super(parent, owning_option);
  }
}
