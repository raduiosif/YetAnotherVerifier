/*
 * SuifWalker.java - A port of basesuif/suifkernel/suif_walker.h to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;
import yav.jsuif.iokernel.Walker;
import yav.jsuif.iokernel.MetaClass;


public abstract class SuifWalker extends Walker
{
  public boolean isVisitable(Object address, MetaClass mc)
  {
    return SuifObject.isKindOfSuifObjectMetaClass(mc);
  }

  public int apply(Object address, MetaClass mc)
  {
    Assert.condition(SuifObject.isKindOfSuifObjectMetaClass(mc),
		     "non-Suif object passed to SuifWalker");

    return apply((SuifObject) address);
  }

  public abstract int apply(SuifObject x);
  
  
  public SuifWalker(SuifEnv suif) { super(suif); }
}

