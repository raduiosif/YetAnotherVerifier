/*
 * StdCharSource.java - A port of basesuif/suifkernel/char_source.h to Java.
 *
 */

package yav.jsuif.kernel;

import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;
import java.io.IOException;


/**
 * Character stream implementation class. 
 * Takes input from either a java.io.InputStream or java.io.Reader.
 */

public class StdCharSource implements CharSource
{
  private Reader _istream;
  private String _prompt;
  private boolean _isNewline;
  private int _cbuf;
  private boolean _isBufFull;

  public StdCharSource() { this(System.in, ""); }

  /**
   * Sets the default input stream to java.lang.System.in.
   */
  public StdCharSource(String prompt)
  {
    this(System.in, prompt);
  }

  /**
   * Builds a InputStream - based character stream.
   */
  public StdCharSource(InputStream istream, String prompt)
  {
    this(new InputStreamReader(istream), prompt);
  }

  /**
   * Builds a Reader - based character stream.
   */
  public StdCharSource(Reader istream, String prompt)
  {
    _istream = istream;
    _prompt = prompt;
    _isNewline = true;
    _cbuf = 0;
    _isBufFull = false;
  }


  public int get()
  {
    int ch;
    if (_isBufFull)
      {
	ch = _cbuf;
	_isBufFull = false;
      }
    else
      {
	if (_isNewline && _prompt != null)
	  {
	    System.out.print(_prompt);
	    System.out.flush();
	  }

	try {
	  ch = _istream.read();
	} catch(IOException e) { return -1; }
      }

    _isNewline = (ch == '\n');
    return ch;
  }

  public int peek()
  {
    if (!_isBufFull)
      {
	_cbuf = get();
	_isBufFull = true;
      }

    return _cbuf;
  }
}
