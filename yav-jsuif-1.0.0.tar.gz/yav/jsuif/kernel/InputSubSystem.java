/*
 * InputSubSystem.java - A port of basesuif/suifkernel/io_subsystem.h to Java
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.nodes.basic.FileSetBlock;


public abstract class InputSubSystem extends SubSystem
{
  public InputSubSystem(SuifEnv suif_env) { super(suif_env); }

  public abstract FileSetBlock read(String inputFileName);
}
