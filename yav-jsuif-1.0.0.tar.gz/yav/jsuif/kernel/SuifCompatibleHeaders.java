/*
 * SuifCompatibleHeaders.java - A port of
 * basesuif/suifkernel/io_subsystem_default_impl.cpp to Java.
 *
 */

package yav.jsuif.kernel;

import yav.jsuif.common.Assert;

import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;


class SuifCompatibleHeaders
{
  private static final byte[] MAGIC = {0x70, 0x69, 0x67, 0x73};
  private static final String VERSION = "2.0.0";
  private static final String SYSTEM = "2.0.0.0";

  public static String getSUIFMagicWord() { return new String(MAGIC); }
  public static String getSUIFVersion() { return VERSION; }
  public static String getSUIFSystem() { return SYSTEM; }

  private static int getPaddedSize(int size)
  {
    return (((size + 3) / 4) * 4);
  }

  public static void writeString(OutputStream outputFile, String str)
    throws IOException
  {
    int length = str.length() + 1;
    int padded_length = getPaddedSize(length);

    Assert.condition(length < 256);

    outputFile.write((byte) 0);
    outputFile.write((byte) 0);
    outputFile.write((byte) 0);
    outputFile.write((byte) length);
    outputFile.write(str.getBytes());
    outputFile.write((byte) 0);
    for (int i = length; i < padded_length; i ++)
      {
	outputFile.write((byte) 0);
      }
  }

  public static String readString(InputStream inputFile)
    throws IOException
  {
    String str = "";
    int size = 0;
    for (int i = 0; i < 4; i ++)
      {
	int b = inputFile.read();
	Assert.condition(b > -1, "Early end of file");
	size = size * 256 + (byte) b;	
      }

    int padded_size = getPaddedSize(size);
    int bytes_read = 0;
    for (; bytes_read < size - 1; bytes_read ++)
      {
	int b = inputFile.read();
	Assert.condition(b > -1, "Early end of file");
	str += (char) b;
      }

    for (; bytes_read < padded_size; bytes_read ++)
      {
	int b = inputFile.read();
	Assert.condition(b > -1, "Early end of file");
	Assert.condition(b == 0, "Expected 0 padding");
      }
    
    return str;
  }

  public static void writeChunk(OutputStream outputFile, String chunk)
    throws IOException
  {
    outputFile.write(chunk.getBytes());
  }

  public static String readChunk(InputStream inputFile, int len)
    throws IOException
  {
    String chunk = "";
    for (int i = 0; i < len; i ++)
      {
	int b = inputFile.read();
	Assert.condition(b > -1, "Early end of file");
	chunk += (char) b;
      }

    return chunk;
  }

  public static void writeHeader(OutputStream outputFile)
  {
    String magic_word =  getSUIFMagicWord();
    String version = getSUIFVersion();
    String system = getSUIFSystem();
    
    try {
      writeChunk(outputFile, magic_word);
      writeString(outputFile, version);
      writeString(outputFile, system);
    } catch(IOException e) { Assert.fatal("write header failed"); }
  }

  public static boolean readHeader(InputStream inputFile)
  {
    String SUIF2_magic_word = getSUIFMagicWord();
    String chunk;
    try {
      chunk = readChunk(inputFile, 4);
    } catch(IOException e) { return false; }

    if (!chunk.equals(SUIF2_magic_word))
      {
	char[] SUIF1_magic_word = {0x50, 0x69, 0x67, 0x73};
	char[] SUIF1_reverse_magic_word = {0x73, 0x67, 0x69, 0x50};
	char[] SUIF_32_magic_word = {0x70, 0x69, 0x67, 0x73};
	char[] SUIF_32_reverse_magic_word = {0x73, 0x67, 0x69, 0x70};
	char[] oldsuif_magic_word = {0x73, 0x75, 0x69, 0x66};
	char[] oldsuif_reverse_magic_word = {0x66, 0x69, 0x75, 0x73};
	if (chunk.equals(new String(SUIF1_magic_word))
	    || chunk.equals(new String(SUIF1_reverse_magic_word))
	    || chunk.equals(new String(SUIF_32_magic_word))
	    || chunk.equals(new String(SUIF_32_reverse_magic_word)))
	  {
	    Assert.fatal("\nThis file is in SUIF1 file format.\n" +
			 "This pass uses the SUIF2 file format.\n" +
			 "The file must go through ``convertsuif1to2'' " +
			 "before this pass is used\n");
	  }
	
	if (chunk.equals(new String(oldsuif_magic_word))
	    || chunk.equals(new String(oldsuif_reverse_magic_word)))
	  {
	    Assert.fatal("\nThis file is in the oldsuif file format.\n" +
			 "This pass uses the SUIF2 file format.\n" +
			 "The file must go through ``newsuif'' and " +
			 "``convertsuif1to2'' before this pass is used\n");
	  }

	Assert.fatal("This file is not a valid SUIF file.");
      }

    String version;    
    try {
      version = readString(inputFile);
    } catch(IOException e) { return false; }

    if (!version.equals(getSUIFVersion()))
      {
	Assert.fatal("\nThis file is in SUIF version " + 
		     version + " file format.\n" + 
		     "This pass requires SUIF version " +
		     getSUIFVersion() + " file format.\n" +
		     "The file must go through ``convertsuif1to2'' " +
		     "before this pass is used\n");
      }

    String system;
    try {
      system = readString(inputFile);
    } catch(IOException e) { return false; }

    return true;
  }
}
