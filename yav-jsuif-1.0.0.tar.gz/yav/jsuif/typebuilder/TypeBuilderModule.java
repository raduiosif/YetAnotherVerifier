/*
 * TypeBuilderModule.java
 *
 */

package yav.jsuif.typebuilder;

import yav.jsuif.kernel.Module;
import yav.jsuif.kernel.ModuleSubSystem;
import yav.jsuif.kernel.SuifEnv;


public class TypeBuilderModule extends Module
{
  public TypeBuilderModule(SuifEnv env)
  {
    super(env, TypeBuilder.getClassName());
  }

  public void initialize()
  {
    _suif_env.addObjectFactory(new TypeBuilder());
  }

  public static void init(SuifEnv env)
  {
    ModuleSubSystem mSubSystem = env.getModuleSubSystem();
    if (mSubSystem.retrieveModule(TypeBuilder.getClassName()) == null)
      {
	mSubSystem.registerModule(new TypeBuilderModule(env));
      }
  }

  public Object clone() { return this; }
}
