/*
 * TypeBuilder.java - A port of basesuif/typebuilder/type_builder.h to Java
 *
 */

package yav.jsuif.typebuilder;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.nodes.suif.*;
import yav.jsuif.common.*;
import yav.jsuif.ionative.*;


/**
 * Utility functions for building, retrieving, and manipulating types
 *
 * For each class of type, the get_type functions look for that type
 * in the appropriate symbol tables. If none is found, then the
 * type is created and inserted into the highest valid symbol table.
 *
 * For each class of type, there is generally a get_type
 * routine which takes all parameters and one which defaults
 * the size and alignment parameters. The defaults for these
 * are looked up in the TargetInformationBlock or, if no
 * target information block has been found, they are derived
 * from the types on the HOST machine. This will be bad if the
 * host machine and the target machine are not the same.
 *
 * The default size will be a size best suited to a variable in
 * memory.
 */

public class TypeBuilder extends RealObjectFactory 
{
  public static String _className = "TypeBuilder";

  public static String getClassName() { return _className; }
  public String getName() { return getClassName(); }
  public void init(SuifEnv suif_env) { _suif_env = suif_env; }

  public static GlobalInformationBlock getGlobalInformationBlock(SuifEnv env,
								 String name)
  {
    GlobalInformationBlock block = null;
    FileSetBlock file_set_block = env.getFileSetBlock();
    if (file_set_block != null)
      {
	for (Iter iter = file_set_block.getInformationBlockIterator();
	     iter.isValid(); iter.next())
	  {
	    GlobalInformationBlock currentBlock = 
	      (GlobalInformationBlock) iter.current();

	    if (currentBlock.getClassName().equals(name))
	      {
		block = currentBlock;
		break;
	      }
	  }
      }

    return block;
  }

  public static TargetInformationBlock findTargetInformationBlock(SuifEnv env)
  {
    String name = TargetInformationBlock.getClassName();
    return (TargetInformationBlock) getGlobalInformationBlock(env, name);
  }
  
  public DataType unqualifyDataType(Type t)
  {
    while (t.isKindOf(QualifiedType.getClassName()))
      {
	t = ((QualifiedType) t).getBaseType();
      }

    return t.isKindOf(QualifiedType.getClassName()) ? (DataType) t : null;
  }

  public Type unqualifyType(Type t)
  {
    while (t.isKindOf(QualifiedType.getClassName()))
      {
	t = ((QualifiedType) t).getBaseType();
      }
    
    return t;
  }

  public VoidType getVoidType()
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(VoidType.getClassName()))
	  {
	    return (VoidType) obj;
	  }

	iter.next();
      }

    VoidType element = 
      SuifObjectFactory.createVoidType(_suif_env, new IInteger(0), 0, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public BooleanType getBooleanType()
  {
    TargetInformationBlock tib = findTargetInformationBlock(_suif_env);
    BooleanType type = null;
    if (tib != null)
      {
	type = tib.getDefaultBooleanType();
      }

    if (type == null)
      {
	type = getBooleanType(new IInteger(SizeOf.BOOL*8), SizeOf.BOOL*8);
      }
    
    return type;
  }

  public BooleanType getBooleanType(int size_in_bits,
				    int alignment_in_bits)
  {
    return getBooleanType(new IInteger(size_in_bits), alignment_in_bits);
  }

  public BooleanType getBooleanType(IInteger size_in_bits, 
				    int alignment_in_bits)
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(BooleanType.getClassName()))
	  {
	    BooleanType element = (BooleanType) obj;
	    if (element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits)
	      {
		return element;
	      }
	  }

	iter.next();
      }

    BooleanType element = 
      SuifObjectFactory.createBooleanType(_suif_env, size_in_bits, 
					  alignment_in_bits, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public IntegerType getIntegerType() { return getIntegerType(true); }

  public IntegerType getIntegerType(boolean is_signed)
  {
    TargetInformationBlock tib = findTargetInformationBlock(_suif_env);
    IntegerType type = null;
    if (tib != null)
      {
	type = tib.getWordType();
      }

    if (type == null)
      {
	type = getIntegerType(new IInteger(SizeOf.INT*8), 
			      SizeOf.INT*8, is_signed);
      }

    return type;
  }

  public IntegerType getIntegerType(int size_in_bits,
				    int alignment_in_bits)
  {
    return getIntegerType(new IInteger(size_in_bits), alignment_in_bits);
  }

  public IntegerType getIntegerType(IInteger size_in_bits, 
				    int alignment_in_bits)
  {
    return getIntegerType(size_in_bits, alignment_in_bits, true);
  }

  public IntegerType getIntegerType(IInteger size_in_bits, 
				    int alignment_in_bits,
				    boolean is_signed)
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(IntegerType.getClassName()))
	  {
	    IntegerType element = (IntegerType) obj;
	    if (element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits
		&& element.getIsSigned() == is_signed)
	      {
		return element;
	      }
	  }
	
	iter.next();
      }

    IntegerType element = 
      SuifObjectFactory.createIntegerType(_suif_env, size_in_bits, 
					  alignment_in_bits, is_signed, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public IntegerType getSmallestIntegerType()
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    IntegerType smallest_yet = null;
    IInteger smallest_size_yet = new IInteger(0);
    int smallest_alignment_yet = 0;
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(IntegerType.getClassName()))
	  {
	    IntegerType element = (IntegerType) obj;
	    if (smallest_yet == null 
		|| element.getBitSize().lt(smallest_size_yet)
		|| (element.getBitSize().lt(smallest_size_yet)
		    && element.getBitAlignment() < smallest_alignment_yet))
	      {
		smallest_yet = element;
		smallest_size_yet = element.getBitSize();
		smallest_alignment_yet = element.getBitAlignment();
	      }	       
	  }

	iter.next();
      }

    return smallest_yet;
  }

  public FloatingPointType getFloatingPointType()
  {
    return getFloatingPointType(new IInteger(SizeOf.FLOAT*8),SizeOf.FLOAT*8);
  }

  public FloatingPointType getDoubleFloatingPointType()
  {
    return getFloatingPointType(new IInteger(SizeOf.DOUBLE*8),SizeOf.DOUBLE*8);
  }

  public FloatingPointType getFloatingPointType(int size_in_bits,
						int alignment_in_bits)
  {
    return getFloatingPointType(new IInteger(size_in_bits), alignment_in_bits);
  }

  public FloatingPointType getFloatingPointType(IInteger size_in_bits,
						int alignment_in_bits)
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();    
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(FloatingPointType.getClassName()))
	  {
	    FloatingPointType element = (FloatingPointType) obj;
	    if (element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits)
	      {
		return element;
	      }
	  }
	
	iter.next();
      }

    FloatingPointType element = 
      SuifObjectFactory.createFloatingPointType(_suif_env, size_in_bits,
						alignment_in_bits, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public PointerType getPointerType(Type reference_type)
  {
    return getPointerType(new IInteger(SizeOf.VOID_PTR),
			  SizeOf.VOID_PTR, reference_type);
  }

  public PointerType getPointerType(int size_in_bits,
				    int alignment_in_bits,
				    Type reference_type)
  {
    return getPointerType(new IInteger(size_in_bits), 
			  alignment_in_bits, reference_type);
  }

  public PointerType getPointerType(IInteger size_in_bits,
				    int alignment_in_bits,
				    Type reference_type)
  {
    if (reference_type.isKindOf(DataType.getClassName()))
      {
	reference_type = getQualifiedType((DataType) reference_type);
      }

    PointerType element;
    SymbolTable symbolTable = reference_type.getSymbolTable();
    Assert.condition(symbolTable != null, "reference type not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(PointerType.getClassName()))
	  {
	    element = (PointerType) obj;
	    if (element.getReferenceType() == reference_type
		&& element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits)
	      {
		return element;
	      }
	  }

	iter.next();
      }

    element = 
      SuifObjectFactory.createPointerType(_suif_env, size_in_bits,
					  alignment_in_bits, 
					  reference_type, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public ReferenceType getReferenceType(Type reference_type)
  {
    return getReferenceType(new IInteger(SizeOf.VOID_PTR*8),
			    SizeOf.VOID_PTR*8, reference_type);
  }

  public ReferenceType getReferenceType(int size_in_bits,
					int alignment_in_bits,
					Type reference_type)
  {
    return getReferenceType(new IInteger(size_in_bits), 
			    alignment_in_bits, reference_type);
  }

  public ReferenceType getReferenceType(IInteger size_in_bits,
					int alignment_in_bits,
					Type reference_type)
  {
    if (reference_type.isKindOf(DataType.getClassName()))
      {
	reference_type = getQualifiedType((DataType) reference_type);
      }

    ReferenceType element;
    SymbolTable symbolTable = reference_type.getSymbolTable();
    Assert.condition(symbolTable != null, "reference type not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(ReferenceType.getClassName()))
	  {
	    element = (ReferenceType) obj;
	    if (element.getReferenceType() == reference_type
		&& element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits)
	      {
		return element;
	      }
	  }

	iter.next();
      }

    element = 
      SuifObjectFactory.createReferenceType(_suif_env, size_in_bits,
					    alignment_in_bits, 
					    reference_type, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }
  
  private static boolean isEqualExpression(Expression a, Expression b)
  {
    if (a.isKindOf(IntConstant.getClassName()))
      {
	if (!b.isKindOf(IntConstant.getClassName()))
	  {
	    return false;
	  }

	return (((IntConstant) a).getValue() ==
		((IntConstant) b).getValue());
      }

    if (a.isKindOf(LoadVariableExpression.getClassName()))
      {
	if (!b.isKindOf(LoadVariableExpression.getClassName()))
	  {
	    return false;
	  }

	return (((LoadVariableExpression) a).getSource() ==
		((LoadVariableExpression) b).getSource());
      }

    return (a == b);
  }

  private static IInteger getBound(Expression exp)
  {
    if (exp.isKindOf(IntConstant.getClassName()))
      {
	return ((IntConstant) exp).getValue();
      }

    return new IInteger();
  }

  public ArrayType getArrayType(QualifiedType element_type,
				int lower_bound,
				int upper_bound)
  {
    return getArrayType(element_type, 
			new IInteger(lower_bound),
			new IInteger(upper_bound));
  }

  public ArrayType getArrayType(QualifiedType element_type,
				IInteger lower_bound,
				IInteger upper_bound)
  {
    Expression lower = 
      BasicObjectFactory.createIntConstant(_suif_env,
					   getIntegerType(true),
					   lower_bound);

    Expression upper =
      BasicObjectFactory.createIntConstant(_suif_env,
					   getIntegerType(true),
					   upper_bound);

    return getArrayType(element_type, lower, upper);
  }

  private static IInteger getIntConstant(Expression expr)
  {
    if (expr.isKindOf(IntConstant.getClassName()))
      {
	return ((IntConstant) expr).getValue();
      }

    return new IInteger();
  }

  public ArrayType getArrayType(QualifiedType element_type,
				Expression lower_bound,
				Expression upper_bound)
  {
    DataType etype = unqualifyDataType(element_type);
    IInteger ilb = getIntConstant(lower_bound);
    IInteger iub = getIntConstant(upper_bound);
    IInteger size_in_bits = iub.sub(ilb).add(1).mul(etype.getBitSize());

    return getArrayType(size_in_bits,
			etype.getBitAlignment(),
			element_type,
			lower_bound,
			upper_bound);
  }

  public ArrayType getArrayType(int size_in_bits,
				int alignment_in_bits,
				QualifiedType element_type,
				Expression lower_bound,
				Expression upper_bound)
  {
    return getArrayType(new IInteger(size_in_bits),
			alignment_in_bits, element_type,
			lower_bound, upper_bound);
  }

  public ArrayType getArrayType(IInteger size_in_bits,
				int alignment_in_bits,
				QualifiedType element_type,
				Expression lower_bound,
				Expression upper_bound)
  {
    ArrayType element;
    SymbolTable symbolTable = element_type.getSymbolTable();
    Assert.condition(symbolTable != null, "element type not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(ArrayType.getClassName()))
	  {
	    element = (ArrayType) obj;
	    if (element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() == alignment_in_bits
		&& element.getElementType() == element_type
		&& isEqualExpression(element.getLowerBound(), lower_bound)
		&& isEqualExpression(element.getUpperBound(), upper_bound))
	      {
		return element;
	      }
	  }

	iter.next();
      }

    element = SuifObjectFactory.createArrayType(_suif_env,
						size_in_bits,
						alignment_in_bits,
						element_type,
						lower_bound,
						upper_bound, "");

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  MultiDimArrayType getMultiDimArrayType(IInteger size_in_bits,
					 int alignment_in_bits,
					 QualifiedType element_type,
					 Vector lower_bounds,
					 Vector upper_bounds)
  {
    MultiDimArrayType element;
    SymbolTable symbolTable = element_type.getSymbolTable();
    Assert.condition(symbolTable != null, "element type not attached");
    Assert.condition(lower_bounds.length() == upper_bounds.length(),
		     "inconsistent numbers of bounds in multi dim array");

    int bounds = upper_bounds.length();
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(MultiDimArrayType.getClassName()))
	  {
	    element  = (MultiDimArrayType) obj;
	    if (element.getBitSize().eq(size_in_bits)
		&& element.getBitAlignment() ==  alignment_in_bits
		&& element.getElementType() == element_type
		&& lower_bounds.length() == element.getLowerBoundCount()
		&& upper_bounds.length() == element.getUpperBoundCount())
	      {
		return element;
	      }
	  }
	
	iter.next();
      }

    element = SuifObjectFactory.createMultiDimArrayType(_suif_env,
							size_in_bits,
							alignment_in_bits,
							element_type, "");

    for (int i = 0; i < bounds; i ++)
      {
	element.appendLowerBound((Expression) lower_bounds.at(i));
	element.appendUpperBound((Expression) upper_bounds.at(i));
      }

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public MultiDimArrayType getMultiDimArrayType(QualifiedType element_type,
						Vector lower_bounds,
						Vector upper_bounds)
  {
    DataType etype = unqualifyDataType(element_type);
    IInteger size_in_bits = etype.getBitSize();
    for (int i = 0; i < lower_bounds.length(); i ++)
      {
	IInteger ilb = getIntConstant((Expression) lower_bounds.at(i));
	IInteger iub = getIntConstant((Expression) upper_bounds.at(i));
	size_in_bits = iub.sub(ilb).add(1).mul(size_in_bits);
      }

    return getMultiDimArrayType(size_in_bits,
				etype.getBitAlignment(),
				element_type,
				lower_bounds,
				upper_bounds);
  }

  public void getArrayBounds(Type type, int bound, 
			     IInteger low, IInteger high)
  {
    if (type.isKindOf(QualifiedType.getClassName()))
      {
	type = ((QualifiedType) type).getBaseType();
      }

    if (type.isKindOf(ArrayType.getClassName()))
      {
	ArrayType atype = (ArrayType) type;
	Assert.condition(bound == 0, "bound not zero of ArrayType");
	low.setInteger(getBound(atype.getLowerBound()));
	high.setInteger(getBound(atype.getUpperBound()));
	return;
      }

    if (type.isKindOf(MultiDimArrayType.getClassName()))
      {
	MultiDimArrayType atype = (MultiDimArrayType) type;
	Assert.condition(bound >= 0 && bound < atype.getLowerBoundCount(),
			 "bound out of range for MultiDimArrayType");
	low.setInteger(getBound(atype.getLowerBound(bound)));
	high.setInteger(getBound(atype.getUpperBound(bound)));
	return;
      }

    Assert.fatal("non-array type");
  }

  private boolean sameQualifiers(QualifiedType element, List qualifiers)
  {
    if (element.getQualificationCount() != qualifiers.length())
      {
	return false;
      }

    List.Iterator iter = qualifiers.begin();
    while (iter.notEqual(qualifiers.end()))
      {
	if (!element.hasQualificationMember((String) iter.get()))
	  {
	    return false;
	  }

	iter.inc();
      }

    return true;
  }

  public QualifiedType getQualifiedType(DataType base_type, List qualifiers)
  {
    QualifiedType element;
    SymbolTable symbolTable = base_type.getSymbolTable();
    Assert.condition(symbolTable != null, "base type not attached");
    Iter iter = symbolTable.getSymbolTableObjectIterator();
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(QualifiedType.getClassName()))
	  {
	    element = (QualifiedType) obj;
	    if (element.getBaseType() == base_type
		&& sameQualifiers(element, qualifiers))
	      {
		return element;
	      }
	  }

	iter.next();
      }

    element = BasicObjectFactory.createQualifiedType(_suif_env, 
						     base_type, "");

    List.Iterator it = qualifiers.begin();
    while (it.notEqual(qualifiers.end()))
      {
	element.appendQualification((String) it.get());
	it.inc();
      }

    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public QualifiedType getQualifiedType(DataType base_type, 
					String qualifier)
  {
    List qualifiers = new List();
    qualifiers.pushBack(qualifier);
    return getQualifiedType(base_type, qualifiers);
  }

  public QualifiedType getQualifiedType(QualifiedType qt, 
					List qualifiers)
  {
    List all_qualifiers = new List();
    for (Iter qualIter = qt.getQualificationIterator();
	 qualIter.isValid(); qualIter.next())
      {
	all_qualifiers.pushBack(qualIter.current());
      }

    for (List.Iterator iter = qualifiers.begin();
	 iter.notEqual(qualifiers.end()); iter.inc())
      {
	String qual = (String) iter.get();
	if (!qt.hasQualificationMember(qual))
	  {
	    all_qualifiers.pushBack(qual);
	  }
      }

    return getQualifiedType(qt.getBaseType(), all_qualifiers);
  }

  public QualifiedType getQualifiedType(QualifiedType base_type,
					String qualifier)
  {
    List qualifiers = new List();
    qualifiers.pushBack(qualifier);
    return getQualifiedType(base_type, qualifiers);
  }

  public QualifiedType getQualifiedType(Type base_type)
  {
    if (base_type.isKindOf(QualifiedType.getClassName()))
      {
	return (QualifiedType) base_type;
      }

    return getQualifiedType((DataType) base_type, new List());
  }

  public QualifiedType getQualifiedType(DataType base_type)
  {
    return getQualifiedType(base_type, new List());
  }

  public LabelType getLabelType()
  {
    FileSetBlock block = _suif_env.getFileSetBlock();
    Assert.condition(block != null, "file set block not attached");
    SymbolTable symbolTable = block.getExternalSymbolTable();
    Assert.condition(symbolTable != null,"external symbol table not attached");
    for (Iter iter = symbolTable.getSymbolTableObjectIterator();
	 iter.isValid(); iter.next())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(LabelType.getClassName()))
	  {
	    LabelType element = (LabelType) obj;
	    return element;
	  }
      }

    LabelType element = BasicObjectFactory.createLabelType(_suif_env, "");
    symbolTable.appendSymbolTableObject(element);
    return element;
  }

  public static boolean isAncestorOf(SuifObject parent,
				     SuifObject child)
  {
    while (child != null && child != parent)
      {
	child = child.getParent();
      }

    return child == parent;
  }

  public static SymbolTable mostNestedCommonScope(SymbolTable t1, 
						  SymbolTable t2)
  {
    if (isAncestorOf(t1, t2))
      {
	return t1;
      }

    if (isAncestorOf(t2, t1))
      {
	return t2;
      }

    SymbolTable pt = t1;
    while (pt != null)
      {
	pt = pt.getExplicitSuperScope();
	if (isAncestorOf(pt, t2))
	  {
	    return t1;
	  }
      }

    pt = t1;
    while (pt != null)
      {
	pt = pt.getExplicitSuperScope();
	if (isAncestorOf(t1, pt))
	  {
	    return pt;
	  }
      }

    return null;
  }

  public static SymbolTable mostNestedCommonScope(List type_list,
						  SymbolTable table)
  {
    List.Iterator iter = type_list.begin();
    if (iter.isEqual(type_list.end()))
      {
	return table;
      }

    if (table == null)
      {
	table = (SymbolTable) ((QualifiedType) iter.get()).getParent();
	iter.inc();
      }

    while (iter.notEqual(type_list.end()))
      {
	SymbolTable t = (SymbolTable) ((QualifiedType) iter.get()).getParent();
	table = mostNestedCommonScope(t, table);
	if (table == null)
	  {
	    return null;
	  }

	iter.inc();
      }

    return table;
  }

  public static boolean isArgumentTypesMatch(List argument_list,
					     CProcedureType type)
  {
    List.Iterator it = argument_list.begin();
    Iter iter = type.getArgumentIterator();
    while (it.notEqual(argument_list.end()) && iter.isValid())
      {
	if (iter.current() != it.get())
	  {
	    return false;
	  }

	iter.next();
	it.inc();
      }

    return (it.isEqual(argument_list.end()) && !iter.isValid());
  }

  public CProcedureType getCProcedureType(DataType result_type,
					  List argument_list)
  {
    return getCProcedureType(result_type, argument_list, false, true, 0);
  }

  public CProcedureType getCProcedureType(DataType result_type,
					  List argument_list,
					  boolean has_varargs)
  {
    return getCProcedureType(result_type, argument_list, 
			     has_varargs, true, 0);
  }

  public CProcedureType getCProcedureType(DataType result_type,
					  List argument_list,
					  boolean has_varargs,
					  boolean arguments_known)
  {
    return getCProcedureType(result_type, argument_list, 
			     has_varargs, arguments_known, 0);
  }

  public CProcedureType getCProcedureType(DataType result_type,
					  List argument_list,
					  boolean has_varargs,
					  boolean arguments_known,
					  int bit_alignment)
  {
    if (bit_alignment == 0)
      {
	bit_alignment = SizeOf.INT*8;
      }

    FileSetBlock block = _suif_env.getFileSetBlock();
    SymbolTable table = block.getExternalSymbolTable();
    table = mostNestedCommonScope((SymbolTable) result_type.getParent(),table);
    table = mostNestedCommonScope(argument_list, table);
    if (table == null)
      {
	table = _suif_env.getFileSetBlock().getExternalSymbolTable();
      }

    Iter iter = table.getSymbolTableObjectIterator();
    CProcedureType type;
    while (iter.isValid())
      {
	SymbolTableObject obj = (SymbolTableObject) iter.current();
	if (obj.isA(CProcedureType.getClassName()))
	  {
	    type = (CProcedureType) obj;
	    if (type.getArgumentCount() == argument_list.length()
		&& type.getHasVarargs() == has_varargs
		&& type.getArgumentsKnown() == arguments_known
		&& type.getBitAlignment() == bit_alignment
		&& type.getResultType() == result_type
		&& isArgumentTypesMatch(argument_list, type))
	      {
		return type;
	      }
	  }

	iter.next();
      }

    type = SuifObjectFactory.createCProcedureType(_suif_env,
						  result_type,
						  has_varargs,
						  arguments_known,
						  bit_alignment, "");

    table.appendSymbolTableObject(type);
    List.Iterator it = argument_list.begin();
    while (it.notEqual(argument_list.end()))
      {
	type.appendArgument((QualifiedType) it.get());
	it.inc();
      }

    return type;
  }

  private static boolean matchingGroup(GroupType type,
				       List names,
				       List type_list)
  {
    GroupSymbolTable gst = type.getGroupSymbolTable();
    int field_no = 0;
    int field_count = gst.getSymbolTableObjectCount();

    if (field_count != type_list.length())
      {
	return false;
      }

    while (field_no < field_count)
      {
	FieldSymbol field = (FieldSymbol) gst.getSymbolTableObject(field_no);
	if (field.getType() != type_list.at(field_no))
	  {
	    return false;
	  }

	field_no ++;
      }

    return true;
  }

  private static boolean isOuterScope(SymbolTable outer,
				      SymbolTable inner)
  {
    while (outer != inner && inner != null)
      {
	inner = inner.getExplicitSuperScope();
      }

    return (inner != null);
  }

  /** 
   * Get a group type, returning an existing group if it exists
   * the name list is may be empty or partial - missing names are empty
   * if a new group is created it is created in the first symbol table
   * enclosing all the types, or the last symbol table if none
   */
  public GroupType getGroupType(List symbol_tables,
				List names,
				List type_list)
  {
    int i;
    for (i = 0; i < symbol_tables.length(); i ++)
      {
	SymbolTable table = (SymbolTable) symbol_tables.at(i);
	Iter iter = table.getSymbolTableObjectIterator();
	while (iter.isValid())
	  {
	    SymbolTableObject obj = (SymbolTableObject) iter.current();
	    if (obj.isA(GroupType.getClassName()))
	      {
		GroupType group = (GroupType) obj;
		if (group.getIsComplete()
		    && matchingGroup(group, names, type_list))
		  {
		    return group;
		  }
	      }

	    iter.next();
	  }
      }

    i = 0;
    while (i < symbol_tables.length() - 1)
      {
	int j = 0;
	while (j < type_list.length())
	  {
	    SymbolTable s = (SymbolTable) symbol_tables.at(i);
	    QualifiedType t = (QualifiedType) type_list.at(j);
	    SymbolTable u = (SymbolTable) t.getParent();
	    if (!isOuterScope(s, u))
	      {
		break;
	      }

	    j ++;
	  }
	
	if (j < type_list.length())
	  {
	    break;
	  }

	i ++;
      }

    SymbolTable target_table = (SymbolTable) symbol_tables.at(i);
    GroupType gtype = SuifObjectFactory.createGroupType(_suif_env,
							new IInteger(0),
							0, "", true, null);

    for (i = 0; i < type_list.length(); i ++)
      {
	String name = null;
	if (names.length() > i)
	  {
	    name = (String) names.at(i);
	  }

	addSymbolToGroup(gtype, name, (QualifiedType) type_list.at(i));
      }

    target_table.appendSymbolTableObject(gtype);
    return gtype;
  }

  /** 
   * Get a union type, returning an existing union if it exists
   * the name list is may be empty or partial - missing names are empty
   * if a new union is created it is created in the first symbol table
   * enclosing all the types, or the last symbol table if none
   */
  public UnionType getUnionType(List symbol_tables,
				List names,
				List type_list)
  {
    int i;
    for (i = 0; i < symbol_tables.length(); i ++)
      {
	SymbolTable table = (SymbolTable) symbol_tables.at(i);
	Iter iter = table.getSymbolTableObjectIterator();
	while (iter.isValid())
	  {
	    SymbolTableObject obj = (SymbolTableObject) iter.current();
	    if (obj.isA(UnionType.getClassName()))
	      {
		UnionType group = (UnionType) obj;
		if (group.getIsComplete()
		    && matchingGroup(group, names, type_list))
		  {
		    return group;
		  }
	      }

	    iter.next();
	  }
      }

    i = 0;
    while (i < symbol_tables.length() - 1)
      {
	int j = 0;
	while (j < type_list.length())
	  {
	    SymbolTable s = (SymbolTable) symbol_tables.at(i);
	    QualifiedType t = (QualifiedType) type_list.at(j);
	    SymbolTable u = (SymbolTable) t.getParent();
	    if (!isOuterScope(s, u))
	      {
		break;
	      }

	    j ++;
	  }

	if (j < type_list.length())
	  {
	    break;
	  }

	i  ++;
      }

    SymbolTable target_table = (SymbolTable) symbol_tables.at(i);
    UnionType gtype = SuifObjectFactory.createUnionType(_suif_env,
							new IInteger(0),
							0, "", true, null);

    for (i = 0; i < type_list.length(); i ++)
      {
	String name = null;
	if (names.length() > 1)
	  {
	    name = (String) names.at(i);
	  }

	addUnionSymbolToGroup(gtype, name, (QualifiedType) type_list.at(i));
      }

    target_table.appendSymbolTableObject(gtype);
    return gtype;
  }

  public FieldSymbol addSymbolToGroup(GroupType group,
				      String symbol_name,
				      QualifiedType q_symbol_type)
  {
    IInteger size = group.getBitSize();
    int align = group.getBitAlignment();
    DataType symbol_type = q_symbol_type.getBaseType();
    IInteger sym_size = symbol_type.getBitSize();
    int sym_align = symbol_type.getBitAlignment();

    if (align < sym_align)
      {
	group.setBitAlignment(sym_align);
      }

    if (sym_align > 0)
      {
	int inc = size.cInt() % sym_align;
	if (inc > 0)
	  {
	    size = size.add(sym_align - inc);
	  }
      }

    Expression offset = 
      BasicObjectFactory.createIntConstant(_suif_env, 
					   getIntegerType(false), size);

    FieldSymbol fsym = 
      SuifObjectFactory.createFieldSymbol(_suif_env, q_symbol_type,
					  offset, symbol_name, false);

    group.getGroupSymbolTable().addSymbol(fsym);
    size.add(sym_size);
    group.setBitSize(size);

    return fsym;
  }

  public FieldSymbol addUnionSymbolToGroup(GroupType group,
					   String symbol_name,
					   QualifiedType symbol_type)
  {
    return addUnionSymbolToGroup(group, symbol_name, symbol_type, -1);
  }

  public FieldSymbol addUnionSymbolToGroup(GroupType group,
					   String symbol_name,
					   QualifiedType symbol_type,
					   int pos)
  {
    int align = group.getBitAlignment();
    IInteger sym_size = symbol_type.getBaseType().getBitSize();
    int sym_align = symbol_type.getBaseType().getBitAlignment();
    if (align < sym_align)
      {
	group.setBitAlignment(sym_align);
      }

    Expression offset = 
      BasicObjectFactory.createIntConstant(_suif_env, 
					   getIntegerType(false),
					   new IInteger(0));

    FieldSymbol fsym =
      SuifObjectFactory.createFieldSymbol(_suif_env, symbol_type,
					  offset, symbol_name, false);

    if (pos >= 0)
      {
	group.getGroupSymbolTable().insertSymbolTableObject(pos, fsym);
      }
    else
      {
	group.getGroupSymbolTable().addSymbol(fsym);
      }

    IInteger size = group.getBitSize();
    if (size.lt(sym_size))
      {
	group.setBitSize(sym_size);
      }

    return fsym;
  }

  /**
   * Find a field of a given type. Useful when building unions to do
   * type breaking activities. The field_type can be either of a 
   * QualifiedType or a simple type. If it is a simple type, any
   * qualifications on the field symbol's type are ignored in matching
   */
  FieldSymbol findFieldOfType(GroupType group, Type field_type)
  {
    UnionType utype = (UnionType) group;
    GroupSymbolTable gst= utype.getGroupSymbolTable();
    int field_count = gst.getSymbolTableObjectCount();
    for (int field_no = 0; field_no < field_count; field_no ++)
      {
	FieldSymbol field = (FieldSymbol) gst.getSymbolTableObject(field_no);
	QualifiedType ftype = (QualifiedType) field.getType();
	if ((field_type == ftype) || (field_type == ftype.getBaseType()))
	  {
	    return field;
	  }
      }

    return null;
  }

  /** 
   * Find the field containing the offset. In the case of unions, 
   * the first union containing the field is returned.
   */
  public FieldSymbol findSymbolContainingOffset(GroupType group,
						IInteger offset)
  {
    GroupSymbolTable gst = group.getGroupSymbolTable();
    int field_count = gst.getSymbolTableObjectCount();
    for (int field_no = 0; field_no < field_count; field_no ++)
      {
	FieldSymbol fsym = (FieldSymbol) gst.getSymbolTableObject(field_no);
	DataType ftype = 
	  (DataType) ((QualifiedType) fsym.getType()).getBaseType();
	IInteger position = ((IntConstant) fsym.getBitOffset()).getValue();
	IInteger size = ftype.getBitSize();
	if (position.leq(offset) && position.add(size).gt(offset))
	  {
	    return fsym;
	  }
      }

    return null;
  }

  public FieldSymbol findSymbolContainingOffset(GroupType group,
						int offset)
  {
    return findSymbolContainingOffset(group, new IInteger(offset));
  }

  /**
   * As findSymbolContainingOffset, but groups are looked 
   * through until a suitable non-group field is found.
   */
  public FieldSymbol findNonGroupSymbolContainingOffset(GroupType group,
							IInteger offset)
  {
    FieldSymbol fsym = findSymbolContainingOffset(group, offset);
    if (fsym == null)
      {
	return null;
      }
    
    DataType ftyp = (DataType) ((QualifiedType) fsym.getType()).getBaseType();
    while (ftyp.isKindOf(GroupType.getClassName()))
      {
	offset = offset.sub(((IntConstant) fsym.getBitOffset()).getValue());
	fsym = findSymbolContainingOffset((GroupType) ftyp, offset);
	if (fsym == null)
	  {
	    return null;
	  }

	ftyp = (DataType) ((QualifiedType) fsym.getType()).getBaseType();
      }

    return fsym;
  }

  public FieldSymbol findNonGroupSymbolContainingOffset(GroupType group,
							int offset)
  {
    return findNonGroupSymbolContainingOffset(group, new IInteger(offset));
  }

  /**
   * Returns the type of the non_group_symbol, but arrays are
   * also looked through to find a non-group, non-array type.
   */
  public DataType findTypeOfFieldContainingOffset(GroupType group,
						  IInteger offset)
  {
    FieldSymbol fsym = findNonGroupSymbolContainingOffset(group, offset);
    Type ftyp = ((QualifiedType) fsym.getType()).getBaseType();
    while (ftyp.isKindOf(ArrayType.getClassName()))
      {
	ftyp = ((ArrayType) ftyp).getElementType().getBaseType();
      }
    
    return (DataType) ftyp;
  }

  public DataType findTypeOfFieldContainingOffset(GroupType group,
						  int offset)
  {
    return findTypeOfFieldContainingOffset(group, new IInteger(offset));
  }
}



