/*
 * Main.java - 
 *
 */

package yav.jsuif.driver;

import yav.jsuif.kernel.SuifEnv;
import yav.jsuif.kernel.ModuleSubSystem;
import yav.jsuif.kernel.TokenStream;
import yav.jsuif.passes.SuifPasses;


public class Main
{
  public static void main(String[] args)
  {
    SuifEnv suif = new SuifEnv();
    suif.init();
    SuifPasses.init(suif);

    String[] argv = new String [args.length + 1];
    argv[0] = "java yav.jsuif.driver.Main";
    for(int i = 0; i < args.length; i ++)
      {
	argv[i + 1] = args[i];
      }

    TokenStream token_stream = new TokenStream(argv);
    ModuleSubSystem mSubSystem = suif.getModuleSubSystem();
    mSubSystem.execute("execute", token_stream);
  }
}
