/*
 * FrontendPass.java - A port of basesuif/suifpasses/passes.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.FileSetBlock;


public abstract class FrontendPass extends Module
{
  public FrontendPass(SuifEnv suif_env, String name)
  {
    super(suif_env, name);
  }

  /**
   * The default implementation invokes buildFileSetBlock
   * and stores the returned pointer.
   */
  public void execute()
  {
    FileSetBlock fsb = buildFileSetBlock();
    getSuifEnv().setFileSetBlock(fsb);
  }

  public abstract FileSetBlock buildFileSetBlock();
}

