/*
 * XLoadModule.java - A port of basesuif/suifpasses/standard_modules.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;


public class XLoadModule extends Module
{
  private static final String _className = "load";

  public static String getClassName() { return _className; }

  private OptionString _file_name_argument;

  
  public XLoadModule(SuifEnv suif_env)
  {
    super(suif_env);
    _file_name_argument = null;
    _module_name = _className;
  }

  
  public void initialize()
  {
    super.initialize();

    _file_name_argument = new OptionString("file-name");
    _command_line.add(_file_name_argument);
    _command_line.setDescription("loads a SUIF tree from a file");
  }

  public Object clone() { return this; }

  public void execute()
  {
    String file_name = _file_name_argument.getString().getString();
    _suif_env.read(file_name);
  }
}
