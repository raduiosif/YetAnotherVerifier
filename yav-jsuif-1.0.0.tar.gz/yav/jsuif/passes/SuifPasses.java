/*
 * SuifPasses.java - A port of basesuif/suifpasses/suifpasses.cpp to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.SuifEnv;
import yav.jsuif.kernel.ModuleSubSystem;


public class SuifPasses
{
  public static void init(SuifEnv suif_env)
  {
    ModuleSubSystem module_subsystem = suif_env.getModuleSubSystem();
    if (module_subsystem.retrieveModule(Driver.getClassName()) == null)
      {
	module_subsystem.registerModule(new Driver(suif_env));
	module_subsystem.registerModule(new Pipeliner(suif_env));
	module_subsystem.registerModule(new XLoadModule(suif_env));
	module_subsystem.registerModule(new SaveModule(suif_env));
	module_subsystem.registerModule(new ImportModule(suif_env));
	module_subsystem.registerModule(new PrintModule(suif_env));
      }
  }
}
