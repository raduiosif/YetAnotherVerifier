/*
 * PipelinablePass.java - A port of basesuif/suifpasses/passes.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.common.Vector;


public class PipelinablePass extends Pass
{
  public PipelinablePass(SuifEnv suif_env, String name)
  {
    super(suif_env, name);
  }

  /** 
   * Will execute the Pass as if it is not pipelined 
   */
  public void execute()
  {
    Vector pipelined_modules = new Vector();
    pipelined_modules.pushBack(this);
    PipelinerDispatchPass dispatch_pass = 
      new PipelinerDispatchPass(_suif_env, pipelined_modules);
    dispatch_pass.execute();
  }

  /** 
   * Override this if computation is to be applied to a FileSetBlock.
   * The default is empty.
   */
  public void doFileSetBlock(FileSetBlock file_set_block) {}

  /** 
   * Override this if computation is to be applied to a FileBlock.
   * The default is empty.
   */
  public void doFileBlock(FileBlock file_block) {}

  /** 
   * Override this if computation is to be applied to a ProcedureDefinition.
   * The default is empty.
   */
  public void doProcedureDefinition(ProcedureDefinition proc_def) {}

  /** 
   * Override this if computation is to be applied to a VariableDefinition.
   * The default is empty.
   */
  public void doVariableDefinition(VariableDefinition var_def) {}

  /** 
   * Override this if computation is to be executed after all processing is 
   * done. The default is empty.
   */
  public void finalize() {}
}
