/*
 * Pipeliner.java - A port of basesuif/suifpasses/drivers.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.common.Vector;


public class Pipeliner extends Driver
{
  private static final String _className = "pipeline";

  public static String getClassName() { return _className; }


  public Pipeliner(SuifEnv suif_env)
  {
    super(suif_env);
    _module_name = _className;
  }

  
  public Object clone() { return new Pipeliner(_suif_env); }

  public void execute()
  {
    Vector pipelined_modules = new Vector();
    ModuleSubSystem mSubSystem = _suif_env.getModuleSubSystem();
    Token module_name;
    
    while (true)
      {
	while (_token_stream.isAtEndOfCommand() &&
	       ((module_name = _token_stream.getToken()) != null));

	if (_token_stream.isEmpty())
	  {
	    break;
	  }

	if ((module_name = _token_stream.peekToken()) == null)
	  {
	    break;
	  }
	
	Module module = mSubSystem.parseCommandLineAndClone(module_name._token,
							    _token_stream);
	if (module != null)
	  {
	    pipelined_modules.pushBack(module);
	  }
	else
	  {
	    System.err.println("Could not find module: " + module_name._token);
	  }
      }

    PipelinerDispatchPass dispatch_pass = 
      new PipelinerDispatchPass(_suif_env, pipelined_modules);
    
    dispatch_pass.execute();
  }
}
