/*
 * ImportModule.java - A port of basesuif/suifpasses/standard_modules.h to Java
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;


public class ImportModule extends Module
{
  private static final String _className = "import";
  
  public static String getClassName() { return _className; }

  private OptionLoop _repetition;
  private OptionString _module_name_argument;


  public ImportModule(SuifEnv suif_env)
  {
    super(suif_env);

    _module_name_argument = null;
    _module_name = _className;
  }

  
  public void initialize()
  {
    super.initialize();

    _module_name_argument = new OptionString("module name");
    _repetition = new OptionLoop(_module_name_argument);
    _command_line.add(_repetition);
    _command_line.setDescription("imports a number of modules");
  }

  public Object clone() { return this; }

  public void execute()
  {
    int module_count = _module_name_argument.getNumberOfValues();
    for (int i = 0; i < module_count; i ++)
      {
	String module_name = _module_name_argument.getString(i).getString();
	_suif_env.getDLLSubSystem().loadAndInitializeDLL(module_name);
      }
  }
}
