/*
 * Pass.java - A port of basesuif/suifpasses/passes.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.FileSetBlock;


public abstract class Pass extends Module
{
  public Pass(SuifEnv suif_env, String name) 
  { 
    super(suif_env, name); 
  }

  
  public void execute()
  {
    if (_suif_env.getFileSetBlock() == null)
      {
	_suif_env.warning("Pass execution attempted without a file set block");
      }
    else
      {
	doFileSetBlock(_suif_env.getFileSetBlock());
      }
  }

  public abstract void doFileSetBlock(FileSetBlock file_set_block);
}
