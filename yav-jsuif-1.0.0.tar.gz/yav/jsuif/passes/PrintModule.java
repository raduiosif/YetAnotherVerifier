/*
 * PrintModule.java - A port of basesuif/suifpasses/standard_modules.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.ObjectWrapper;
import yav.jsuif.common.PString;
import yav.jsuif.common.FormattedText;

import java.io.PrintStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;


public class PrintModule extends Module
{
  private static final String _className = "print";

  public static String getClassName() { return _className; }

  private OptionLiteral _is_raw;
  private PString _style;
  private PString _filename;
  private OptionLiteral _do_list;


  public PrintModule(SuifEnv suif_env)
  {
    super(suif_env);

    _style = new PString();
    _filename = new PString();
    _module_name = _className;
  }

  
  public void initialize()
  {
    super.initialize();

    _is_raw = new OptionLiteral("-raw");
    _do_list = new OptionLiteral("-list");
    _command_line.setDescription("use the default print subsystem to "
				 + "print the default file_set_block");

    Option libstyle = Option.buildPrefixedString("-style", "stylename", _style,
						 "choose a module to " +
						 "implement the print");

    Option filename = Option.buildPrefixedString("-o", "filename", _filename,
						 "output the result to the " +
						 "filename");

    OptionSelection sel = new OptionSelection();
    sel.add(_is_raw).add(_do_list).add(libstyle).add(filename);
    OptionLoop opt = new OptionLoop(sel, true);
    _command_line.add(opt);

    setInterface("print", 
		 new PrintDispatch() 
		 {
		   public void invoke(Module module, 
				      PrintStream output, 
				      ObjectWrapper obj)
		     {
		       printDispatch((PrintModule) module, output, obj);
		     }
		 }
		 );
  }

  public Object clone() { return this; }

  public void execute()
  {
    if (_do_list.isSet())
      {
	System.out.println("List of available print styles: ");
	_suif_env.getModuleSubSystem().printModules(System.out, ", ", "print");
	return;
      }

    SuifObject fsb = _suif_env.getFileSetBlock();
    if (fsb == null)
      {
	return;
      }

    if ((_filename.get() != null) && !_filename.get().equals(""))
      {
	FileOutputStream outputFile = null;
	try {
	  outputFile = new FileOutputStream(_filename.get());
	} catch (FileNotFoundException e) {
	  System.err.println("Could not open " + _filename.get() + ". Abort");
	  return;
	}

	printDispatch(this, new PrintStream(outputFile), 
		      new ObjectWrapper(fsb));
	return;
      }

    printDispatch(this, System.out, new ObjectWrapper(fsb));
  }

  private static void printDispatch(PrintModule mod,
				    PrintStream output,
				    ObjectWrapper obj)
  {
    SuifEnv suif_env = mod.getSuifEnv();
    PrintSubSystem pss = suif_env.getPrintSubSystem();
    if (pss != null)
      {
	String style = null;
	if (!mod._is_raw.isSet())
	  {
	    if ((mod._style == null) || 
		(mod._style.get() == null) ||
		(mod._style.get().equals("")))
	      {
		style = pss.getDefaultPrintStyle();
	      }
	    else
	      {
		style = mod._style.get();
	      }
	  }

	if ((style == null) ||
	    ((style != null) && !style.equals(mod.getModuleName())))
	  {
	    pss.print(style, output, obj);
	    return;
	  }
      }

    if (!SuifObject.isKindOfSuifObjectMetaClass(obj.getMetaClass()))
      {
	System.err.println("no raw print defined on a non-suif object." +
			   " Aborting");
	return;
      }

    FormattedText text = new FormattedText();
    suif_env.getFileSetBlock().print(text);
    output.println(text.getValue());
  }
}
