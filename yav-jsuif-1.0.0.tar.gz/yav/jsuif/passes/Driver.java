/*
 * Driver.java - A port of basesuif/suifpasses/drivers.h to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.common.Assert;
import yav.jsuif.common.PString;
import yav.jsuif.common.PBoolean;
import yav.jsuif.common.PInputStream;
import yav.jsuif.common.RecoverableException;

import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class Driver extends Module
{
  private static final String _className = "execute";

  public static String getClassName() { return _className; }

  protected OptionSelection _arguments;
  protected OptionLiteral _f;
  protected OptionLiteral _e;

  protected OptionString _file;
  protected OptionList _f_file;

  protected OptionString _istring;
  protected OptionList _i_string;

  protected OptionStream _stream;
  protected PInputStream _istream;
  protected TokenStream _token_stream;

  protected PString _file_name;
  protected PString _input_string;
 
  protected PBoolean _isInteractive;


  public Driver (SuifEnv suif_env)
  {
    super(suif_env);

    _arguments = null;
    _f         = null;
    _file      = null;
    _stream    = null;
    _istream   = new PInputStream();

    _token_stream  = null;

    _file_name = new PString();
    _input_string = new PString();
    _isInteractive = new PBoolean();

    _module_name = _className;
  }

  
  public void initialize()
  {
    super.initialize();

    _command_line.setDescription("This module executes a series of modules " +
				 "which are read in either from a file, " +
				 "from the command line, or from standard " +
				 " input.");

    _f = new OptionLiteral("-f");
    _file = new OptionString("file-name", _file_name);
    _e = new OptionLiteral("-e");

    _istring = new OptionString("input-string", _input_string);
    _istring.setDescription("A semicolon separated list of modules " + 
			    "and their command line options");

    _stream = new OptionStream("input-stream", _istream);
    _stream.setDescription("A list of modules and their command line " +
			   " options surrounded by curly braces");

    _f_file = (new OptionList()).add(_f).add(_file);
    _f_file.setDescription("A file name that contains the input");

    _i_string = (new OptionList()).add(_e).add(_istring);
    _i_string.setDescription("A string of semicolon separated modules");

    OptionLiteral intOpt = new OptionLiteral("-i", _isInteractive, true);
    intOpt.setDescription("Interactive mode, read commands from stdin");
    OptionString intStr = new OptionString("init-string", _input_string);
    intStr.setDescription("A list of commands surrounded by curly braces");
    OptionList intLst = (new OptionList()).add(intOpt).add(intStr);
    
    _arguments = new OptionSelection(true);
    _arguments.add(_f_file);
    _arguments.add(_i_string);
    _arguments.add(_stream);
    _arguments.add(intLst);

    _command_line.add(_arguments);
  }

  public Object clone() { return new Driver(_suif_env); }

  public boolean parseCommandLine(TokenStream command_line_stream)
  {
    if (!super.parseCommandLine(command_line_stream))
      {
	return false;
      }

    if (_istream.get() != null)
      {
	CharSource s = new InputStreamCharSource(_istream.get());
	_token_stream = new TokenStream(s);
	return true;
      }

    if ((_file_name.get() != null) && (_file_name.get().length() != 0))
      {
	FileInputStream f = null;
	try {
	  f = new FileInputStream(_file_name.get());
	} catch (FileNotFoundException e) { 
	  Assert.fatal("could not open file: " + _file_name.get());
	}

	CharSource s = new InputStreamCharSource(f);
	_token_stream = new TokenStream(s);
	return true;
      }
    
    if ((_input_string.get() != null) && (_input_string.get().length() != 0))
      {
	byte[] buff = _input_string.get().getBytes();
	ByteArrayInputStream s = new ByteArrayInputStream(buff);
	_token_stream = new TokenStream(new InputStreamCharSource(s));
	return true;
      }

    if (_isInteractive.get())
      {
	return true;
      }

    System.out.println("reading input from stdin:");
    _token_stream = new TokenStream(new StdCharSource());
    
    return true;
  }

  private static void doIt(TokenStream tokstr, 
			   SuifEnv suif_env,
			   boolean isInteractive)
  {
    ModuleSubSystem mSubSystem = suif_env.getModuleSubSystem();
    Token module_name;

    while ((module_name = tokstr.peekToken()) != null)
      {
	if (module_name.isEqual("#")) 
	  {
	    while (((module_name = tokstr.getToken()) != null)
		   && !module_name.isEqual("\n"));
	    continue;
	  }
	else if (module_name.isEqual("\n") || 
		 module_name.isEqual(";"))
	  {
	    tokstr.getToken();
	    continue;
	  }
	else
	  {
	    try {
	      if (!mSubSystem.execute(module_name._token, tokstr))
		break;
	    } catch(RecoverableException e) {
	      System.out.println(e.getMessage());
	      if (isInteractive)
		{
		  Token t;
		  for (;(t = tokstr.getToken()) != null && !t.isEqual("\n"););
		}
	      else
		{
		  throw e;
		}
	    }
	  }
      }
  }

  public void execute()
  {
    if (_token_stream != null)
      {
	doIt(_token_stream, _suif_env, false);	
      }
    
    if (_isInteractive.get())
      {
	StdCharSource c = new StdCharSource("jsuif> ");
	TokenStream s = new TokenStream(c);
	doIt(s, _suif_env, true);
      }
  }
}
