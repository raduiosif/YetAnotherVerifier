/*
 * PipelinerDispatchPass.java - A port of basesuif/suifpasses/dispatcher.h
 *                              to Java.
 *
 */

package yav.jsuif.passes;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*;
import yav.jsuif.common.Assert;
import yav.jsuif.common.Vector;


public class PipelinerDispatchPass extends PipelinablePass
{
  private Vector _modules;
  private int _module_count;


  public PipelinerDispatchPass(SuifEnv suif_env,
			       Vector modules)
  {
    super(suif_env, "dispatch-pass");

    _modules = modules;
    _module_count = modules.length();
  }

  public Object clone() { return this; }

  public void execute() 
  {
    if (_suif_env.getFileSetBlock() == null)
      {
	_suif_env.warning("Pass execution attempted without a file set block");
      }
    else
      {
	for (int i = 0; i < _module_count; i ++)
	  {
	    Assert.recoverable(_modules.at(i) instanceof PipelinablePass, 
			       "Module " + 
			       ((Module) _modules.at(i)).getModuleName() + 
			       " is not a pipelinable one");
	  }

	doFileSetBlock(_suif_env.getFileSetBlock());
      }
  }

  public void doFileSetBlock(FileSetBlock file_set_block)
  {
    for (int i = 0; i < _module_count; i ++)
      {
	((PipelinablePass) _modules.at(i)).doFileSetBlock(file_set_block);
      }

    for (Iter iter = file_set_block.getFileBlockIterator();
	 iter.isValid(); iter.next())
      {
	doFileBlock((FileBlock) iter.current());
      }

    for (int i = 0; i < _module_count; i ++)
      {
	((PipelinablePass) _modules.at(i)).finalize();	
      }
  }

  public void doFileBlock(FileBlock file_block)
  {
    for (int i = 0; i < _module_count; i ++)
      {
	((PipelinablePass) _modules.at(i)).doFileBlock(file_block);
      }

    doDefinitionBlock(file_block.getDefinitionBlock());
  }

  public void doDefinitionBlock(DefinitionBlock def_block)
  {
    for (Iter iter = def_block.getVariableDefinitionIterator();
	 iter.isValid(); iter.next())
      {
	doVariableDefinition((VariableDefinition) iter.current());
      }

    for (Iter iter = def_block.getProcedureDefinitionIterator();
	 iter.isValid(); iter.next())
      {
	doProcedureDefinition((ProcedureDefinition) iter.current());
      }
  }

  public void doProcedureDefinition(ProcedureDefinition proc_def)
  {
    for (int i = 0; i < _module_count; i ++)
      {
	((PipelinablePass) _modules.at(i)).doProcedureDefinition(proc_def);
      }
    
    doDefinitionBlock(proc_def.getDefinitionBlock());
  }

  public void doVariableDefinition(VariableDefinition var_def)
  {
    for (int i = 0; i < _module_count; i ++)
      {
	((PipelinablePass) _modules.at(i)).doVariableDefinition(var_def);
      }
  }
}
