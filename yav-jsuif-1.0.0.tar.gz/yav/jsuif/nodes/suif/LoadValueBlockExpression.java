package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class LoadValueBlockExpression extends Expression
 {  
  public ValueBlock _value_block;
  public static native int get__value_block_offset();
  
  public ValueBlock getValueBlock()
  {
    return _value_block;
  }
  
  public ValueBlock setValueBlock(ValueBlock the_value) 
  {
    ValueBlock old_value = _value_block;
    if (old_value != null) old_value.setParent(null);
    _value_block = (ValueBlock) the_value;
    if (the_value != null) the_value.setParent(this);
    return (ValueBlock) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "LoadValueBlockExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{LoadValueBlockExpression}");
    text.startBlock(text.pointerHeader("_value_block", _value_block));
    if (_value_block != null)
      _value_block.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
