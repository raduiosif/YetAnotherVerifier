package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class FloatingPointType extends NumericType
 {  
  
  
  public static native int get_size();
  
  private static String _className = "FloatingPointType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FloatingPointType}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
