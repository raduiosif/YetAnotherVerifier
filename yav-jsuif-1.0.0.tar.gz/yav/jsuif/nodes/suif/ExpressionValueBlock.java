package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class ExpressionValueBlock extends ValueBlock
 {  
  public Expression _expression;
  public static native int get__expression_offset();
  
  public Expression getExpression()
  {
    return _expression;
  }
  
  public Expression setExpression(Expression the_value) 
  {
    Expression old_value = _expression;
    if (old_value != null) old_value.setParent(null);
    _expression = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ExpressionValueBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ExpressionValueBlock}");
    text.startBlock(text.pointerHeader("_expression", _expression));
    if (_expression != null)
      _expression.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
