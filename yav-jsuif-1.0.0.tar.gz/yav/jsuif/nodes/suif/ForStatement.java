package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class ForStatement extends Statement
 {  
  public VariableSymbol _index;
  public static native int get__index_offset();
  
  public VariableSymbol getIndex()
  {
    return _index;
  }
  
  public void setIndex(VariableSymbol the_value) 
  {
    _index = (VariableSymbol) the_value;
  }
  
  public Expression _lower_bound;
  public static native int get__lower_bound_offset();
  
  public Expression getLowerBound()
  {
    return _lower_bound;
  }
  
  public Expression setLowerBound(Expression the_value) 
  {
    Expression old_value = _lower_bound;
    if (old_value != null) old_value.setParent(null);
    _lower_bound = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _upper_bound;
  public static native int get__upper_bound_offset();
  
  public Expression getUpperBound()
  {
    return _upper_bound;
  }
  
  public Expression setUpperBound(Expression the_value) 
  {
    Expression old_value = _upper_bound;
    if (old_value != null) old_value.setParent(null);
    _upper_bound = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _step;
  public static native int get__step_offset();
  
  public Expression getStep()
  {
    return _step;
  }
  
  public Expression setStep(Expression the_value) 
  {
    Expression old_value = _step;
    if (old_value != null) old_value.setParent(null);
    _step = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public String _comparison_opcode;
  public static native int get__comparison_opcode_offset();
  
  public String getComparisonOpcode()
  {
    return _comparison_opcode;
  }
  
  public void setComparisonOpcode(String the_value) 
  {
    _comparison_opcode = (String) the_value;
  }
  
  public Statement _body;
  public static native int get__body_offset();
  
  public Statement getBody()
  {
    return _body;
  }
  
  public Statement setBody(Statement the_value) 
  {
    Statement old_value = _body;
    if (old_value != null) old_value.setParent(null);
    _body = (Statement) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Statement) old_value;
  }
  
  public Statement _pre_pad;
  public static native int get__pre_pad_offset();
  
  public Statement getPrePad()
  {
    return _pre_pad;
  }
  
  public Statement setPrePad(Statement the_value) 
  {
    Statement old_value = _pre_pad;
    if (old_value != null) old_value.setParent(null);
    _pre_pad = (Statement) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Statement) old_value;
  }
  
  public CodeLabelSymbol _break_label;
  public static native int get__break_label_offset();
  
  public CodeLabelSymbol getBreakLabel()
  {
    return _break_label;
  }
  
  public void setBreakLabel(CodeLabelSymbol the_value) 
  {
    _break_label = (CodeLabelSymbol) the_value;
  }
  
  public CodeLabelSymbol _continue_label;
  public static native int get__continue_label_offset();
  
  public CodeLabelSymbol getContinueLabel()
  {
    return _continue_label;
  }
  
  public void setContinueLabel(CodeLabelSymbol the_value) 
  {
    _continue_label = (CodeLabelSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ForStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ForStatement}");
    text.startBlock("_index");
    text.setValue(_index);
    text.endBlock();
    text.startBlock(text.pointerHeader("_lower_bound", _lower_bound));
    if (_lower_bound != null)
      _lower_bound.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_upper_bound", _upper_bound));
    if (_upper_bound != null)
      _upper_bound.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_step", _step));
    if (_step != null)
      _step.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("comparison_opcode=");
    text.setValue(_comparison_opcode);
    text.endBlock();
    text.startBlock(text.pointerHeader("_body", _body));
    if (_body != null)
      _body.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_pre_pad", _pre_pad));
    if (_pre_pad != null)
      _pre_pad.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_break_label");
    text.setValue(_break_label);
    text.endBlock();
    text.startBlock("_continue_label");
    text.setValue(_continue_label);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
