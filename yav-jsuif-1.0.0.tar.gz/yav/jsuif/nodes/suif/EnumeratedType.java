package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class EnumeratedType extends IntegerType
 {  
  public IndexedList _case = new IndexedList();
  public static native int get__case_offset();
  
  
  
  // extra accessors for `indexed_list case'
  public Iter getCaseIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_case");
    Iterator i = new STLIterator(_case,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void addCase(String key, IInteger value)
  {
    _case.pushBack(key, value);
  }
  
  public void insertCase(String key, IInteger value)
  {
    List.Iterator iter = _case.begin();
    while (iter.notEqual(_case.end()) && ((IndexedList.Pair) iter.get()).first.hashCode() < key.hashCode()) iter.inc();
    _case.insert(iter, new IndexedList.Pair(key, value));
  }
  
  public IInteger removeCase(String key) 
  {
    List.Iterator iter = _case.find(key);
    Assert.condition(iter.notEqual(_case.end()), "removing up a non-existant value");
    return (IInteger) _case.remove(iter);
  }
  
  public boolean hasCaseMember(String key) 
  {
    return _case.isMember(key);
  }
  
  public IInteger lookupCase(String key) 
  {
    List.Iterator iter = _case.find(key);
    Assert.condition(iter.notEqual(_case.end()), "looking up a non-existant value");
    return (IInteger) ((IndexedList.Pair) iter.get()).second;
  }
  
  public int numCaseWithKey(String key) 
  {
    return _case.numWithKey(key);
  }
  
  public IInteger lookupCase(String key, int no) 
  {
    List.Iterator iter = _case.find(key, no);
    Assert.condition(iter.notEqual(_case.end()), "looking up a non-existant value");
    return (IInteger) ((IndexedList.Pair) iter.get()).second;
  }
  
   public IInteger removeCase(String key, int no) 
  {
    List.Iterator iter = _case.find(key, no);
    Assert.condition(iter.notEqual(_case.end()), "removing up a non-existant value");
    return (IInteger) _case.remove(iter);
  }
  
  public void removeAllFromCase(IInteger value) 
  {
    List.Iterator iter = _case.begin();
    List.Iterator end = _case.end();
    while (iter.notEqual(end)) 
    {
      if (((IndexedList.Pair) iter.get()).second.equals(value)) 
      {
        List.Iterator iter1 = new List.Iterator(iter);
        iter.inc();
        _case.remove(iter1);
      }
      else 
      {
        iter.inc();
      }
      
    }
    
  }
  
  public int getCaseCount() 
  {
    return _case.length();
  }
  
  public IndexedList.Pair getCase(int pos) 
  {
    return (IndexedList.Pair) _case.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "EnumeratedType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{EnumeratedType}");
    
     { 
      int i = 0;
      List.Iterator iter = _case.begin();
      while (iter.notEqual(_case.end())) 
       { 
        String item_first = (String) ((IndexedList.Pair) iter.get()).first;
        text.startBlock("_case[" + i + "].");
        text.setValue(item_first);
        text.endBlock();
        
        IInteger item_second = (IInteger) ((IndexedList.Pair) iter.get()).second;
        text.startBlock("_case[" + i + "].");
        text.setValue(item_second);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
