package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class SelectExpression extends Expression
 {  
  public Expression _selector;
  public static native int get__selector_offset();
  
  public Expression getSelector()
  {
    return _selector;
  }
  
  public Expression setSelector(Expression the_value) 
  {
    Expression old_value = _selector;
    if (old_value != null) old_value.setParent(null);
    _selector = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _selection1;
  public static native int get__selection1_offset();
  
  public Expression getSelection1()
  {
    return _selection1;
  }
  
  public Expression setSelection1(Expression the_value) 
  {
    Expression old_value = _selection1;
    if (old_value != null) old_value.setParent(null);
    _selection1 = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _selection2;
  public static native int get__selection2_offset();
  
  public Expression getSelection2()
  {
    return _selection2;
  }
  
  public Expression setSelection2(Expression the_value) 
  {
    Expression old_value = _selection2;
    if (old_value != null) old_value.setParent(null);
    _selection2 = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "SelectExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{SelectExpression}");
    text.startBlock(text.pointerHeader("_selector", _selector));
    if (_selector != null)
      _selector.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_selection1", _selection1));
    if (_selection1 != null)
      _selection1.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_selection2", _selection2));
    if (_selection2 != null)
      _selection2.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
