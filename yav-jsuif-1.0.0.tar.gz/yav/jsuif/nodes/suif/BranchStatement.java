package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class BranchStatement extends Statement
 {  
  public Expression _decision_operand;
  public static native int get__decision_operand_offset();
  
  public Expression getDecisionOperand()
  {
    return _decision_operand;
  }
  
  public Expression setDecisionOperand(Expression the_value) 
  {
    Expression old_value = _decision_operand;
    if (old_value != null) old_value.setParent(null);
    _decision_operand = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public CodeLabelSymbol _target;
  public static native int get__target_offset();
  
  public CodeLabelSymbol getTarget()
  {
    return _target;
  }
  
  public void setTarget(CodeLabelSymbol the_value) 
  {
    _target = (CodeLabelSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "BranchStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{BranchStatement}");
    text.startBlock(text.pointerHeader("_decision_operand", _decision_operand));
    if (_decision_operand != null)
      _decision_operand.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_target");
    text.setValue(_target);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
