package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class UnaryExpression extends Expression
 {  
  public String _opcode;
  public static native int get__opcode_offset();
  
  public String getOpcode()
  {
    return _opcode;
  }
  
  public void setOpcode(String the_value) 
  {
    _opcode = (String) the_value;
  }
  
  public Expression _source;
  public static native int get__source_offset();
  
  public Expression getSource()
  {
    return _source;
  }
  
  public Expression setSource(Expression the_value) 
  {
    Expression old_value = _source;
    if (old_value != null) old_value.setParent(null);
    _source = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "UnaryExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{UnaryExpression}");
    text.startBlock("opcode=");
    text.setValue(_opcode);
    text.endBlock();
    text.startBlock(text.pointerHeader("_source", _source));
    if (_source != null)
      _source.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
