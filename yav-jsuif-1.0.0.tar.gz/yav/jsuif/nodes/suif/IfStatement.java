package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class IfStatement extends Statement
 {  
  public Expression _condition;
  public static native int get__condition_offset();
  
  public Expression getCondition()
  {
    return _condition;
  }
  
  public Expression setCondition(Expression the_value) 
  {
    Expression old_value = _condition;
    if (old_value != null) old_value.setParent(null);
    _condition = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Statement _then_part;
  public static native int get__then_part_offset();
  
  public Statement getThenPart()
  {
    return _then_part;
  }
  
  public Statement setThenPart(Statement the_value) 
  {
    Statement old_value = _then_part;
    if (old_value != null) old_value.setParent(null);
    _then_part = (Statement) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Statement) old_value;
  }
  
  public Statement _else_part;
  public static native int get__else_part_offset();
  
  public Statement getElsePart()
  {
    return _else_part;
  }
  
  public Statement setElsePart(Statement the_value) 
  {
    Statement old_value = _else_part;
    if (old_value != null) old_value.setParent(null);
    _else_part = (Statement) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Statement) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "IfStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{IfStatement}");
    text.startBlock(text.pointerHeader("_condition", _condition));
    if (_condition != null)
      _condition.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_then_part", _then_part));
    if (_then_part != null)
      _then_part.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_else_part", _else_part));
    if (_else_part != null)
      _else_part.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
