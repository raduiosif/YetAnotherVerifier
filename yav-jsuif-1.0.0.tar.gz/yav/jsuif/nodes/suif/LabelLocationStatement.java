package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class LabelLocationStatement extends Statement
 {  
  public CodeLabelSymbol _defined_label;
  public static native int get__defined_label_offset();
  
  public CodeLabelSymbol getDefinedLabel()
  {
    return _defined_label;
  }
  
  public void setDefinedLabel(CodeLabelSymbol the_value) 
  {
    _defined_label = (CodeLabelSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "LabelLocationStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{LabelLocationStatement}");
    text.startBlock("_defined_label");
    text.setValue(_defined_label);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
