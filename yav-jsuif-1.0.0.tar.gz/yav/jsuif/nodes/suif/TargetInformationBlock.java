package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class TargetInformationBlock extends GlobalInformationBlock
 {  
  public List _integer_types = new List();
  public static native int get__integer_types_offset();
  
  public List _floating_point_types = new List();
  public static native int get__floating_point_types_offset();
  
  public String _pointer_size_calculation_rule;
  public static native int get__pointer_size_calculation_rule_offset();
  
  public String getPointerSizeCalculationRule()
  {
    return _pointer_size_calculation_rule;
  }
  
  public void setPointerSizeCalculationRule(String the_value) 
  {
    _pointer_size_calculation_rule = (String) the_value;
  }
  
  public String _pointer_alignment_calculation_rule;
  public static native int get__pointer_alignment_calculation_rule_offset();
  
  public String getPointerAlignmentCalculationRule()
  {
    return _pointer_alignment_calculation_rule;
  }
  
  public void setPointerAlignmentCalculationRule(String the_value) 
  {
    _pointer_alignment_calculation_rule = (String) the_value;
  }
  
  public String _array_alignment_calculation_rule;
  public static native int get__array_alignment_calculation_rule_offset();
  
  public String getArrayAlignmentCalculationRule()
  {
    return _array_alignment_calculation_rule;
  }
  
  public void setArrayAlignmentCalculationRule(String the_value) 
  {
    _array_alignment_calculation_rule = (String) the_value;
  }
  
  public String _group_alignment_calculation_rule;
  public static native int get__group_alignment_calculation_rule_offset();
  
  public String getGroupAlignmentCalculationRule()
  {
    return _group_alignment_calculation_rule;
  }
  
  public void setGroupAlignmentCalculationRule(String the_value) 
  {
    _group_alignment_calculation_rule = (String) the_value;
  }
  
  public String _procedure_alignment_calculation_rule;
  public static native int get__procedure_alignment_calculation_rule_offset();
  
  public String getProcedureAlignmentCalculationRule()
  {
    return _procedure_alignment_calculation_rule;
  }
  
  public void setProcedureAlignmentCalculationRule(String the_value) 
  {
    _procedure_alignment_calculation_rule = (String) the_value;
  }
  
  public String _integer_representation_rule;
  public static native int get__integer_representation_rule_offset();
  
  public String getIntegerRepresentationRule()
  {
    return _integer_representation_rule;
  }
  
  public void setIntegerRepresentationRule(String the_value) 
  {
    _integer_representation_rule = (String) the_value;
  }
  
  public String _floating_point_representation_rule;
  public static native int get__floating_point_representation_rule_offset();
  
  public String getFloatingPointRepresentationRule()
  {
    return _floating_point_representation_rule;
  }
  
  public void setFloatingPointRepresentationRule(String the_value) 
  {
    _floating_point_representation_rule = (String) the_value;
  }
  
  public boolean _is_big_endian;
  public static native int get__is_big_endian_offset();
  
  public boolean getIsBigEndian()
  {
    return _is_big_endian;
  }
  
  public void setIsBigEndian(boolean the_value) 
  {
    _is_big_endian = (boolean) the_value;
  }
  
  public IInteger _byte_size;
  public static native int get__byte_size_offset();
  
  public IInteger getByteSize()
  {
    return _byte_size;
  }
  
  public void setByteSize(IInteger the_value) 
  {
    _byte_size = (IInteger) the_value;
  }
  
  public IntegerType _word_type;
  public static native int get__word_type_offset();
  
  public IntegerType getWordType()
  {
    return _word_type;
  }
  
  public void setWordType(IntegerType the_value) 
  {
    _word_type = (IntegerType) the_value;
  }
  
  public BooleanType _default_boolean_type;
  public static native int get__default_boolean_type_offset();
  
  public BooleanType getDefaultBooleanType()
  {
    return _default_boolean_type;
  }
  
  public void setDefaultBooleanType(BooleanType the_value) 
  {
    _default_boolean_type = (BooleanType) the_value;
  }
  
  public VoidType _default_void_type;
  public static native int get__default_void_type_offset();
  
  public VoidType getDefaultVoidType()
  {
    return _default_void_type;
  }
  
  public void setDefaultVoidType(VoidType the_value) 
  {
    _default_void_type = (VoidType) the_value;
  }
  
  public boolean _pointer_size_fixed;
  public static native int get__pointer_size_fixed_offset();
  
  public boolean getPointerSizeFixed()
  {
    return _pointer_size_fixed;
  }
  
  public void setPointerSizeFixed(boolean the_value) 
  {
    _pointer_size_fixed = (boolean) the_value;
  }
  
  public IInteger _pointer_size;
  public static native int get__pointer_size_offset();
  
  public IInteger getPointerSize()
  {
    return _pointer_size;
  }
  
  public void setPointerSize(IInteger the_value) 
  {
    _pointer_size = (IInteger) the_value;
  }
  
  public boolean _pointer_alignment_fixed;
  public static native int get__pointer_alignment_fixed_offset();
  
  public boolean getPointerAlignmentFixed()
  {
    return _pointer_alignment_fixed;
  }
  
  public void setPointerAlignmentFixed(boolean the_value) 
  {
    _pointer_alignment_fixed = (boolean) the_value;
  }
  
  public int _pointer_alignment;
  public static native int get__pointer_alignment_offset();
  
  public int getPointerAlignment()
  {
    return _pointer_alignment;
  }
  
  public void setPointerAlignment(int the_value) 
  {
    _pointer_alignment = (int) the_value;
  }
  
  public boolean _array_alignment_calculation_is_standard;
  public static native int get__array_alignment_calculation_is_standard_offset();
  
  public boolean getArrayAlignmentCalculationIsStandard()
  {
    return _array_alignment_calculation_is_standard;
  }
  
  public void setArrayAlignmentCalculationIsStandard(boolean the_value) 
  {
    _array_alignment_calculation_is_standard = (boolean) the_value;
  }
  
  public int _array_alignment_minimum;
  public static native int get__array_alignment_minimum_offset();
  
  public int getArrayAlignmentMinimum()
  {
    return _array_alignment_minimum;
  }
  
  public void setArrayAlignmentMinimum(int the_value) 
  {
    _array_alignment_minimum = (int) the_value;
  }
  
  public boolean _group_alignment_calculation_is_standard;
  public static native int get__group_alignment_calculation_is_standard_offset();
  
  public boolean getGroupAlignmentCalculationIsStandard()
  {
    return _group_alignment_calculation_is_standard;
  }
  
  public void setGroupAlignmentCalculationIsStandard(boolean the_value) 
  {
    _group_alignment_calculation_is_standard = (boolean) the_value;
  }
  
  public int _group_alignment_minimum;
  public static native int get__group_alignment_minimum_offset();
  
  public int getGroupAlignmentMinimum()
  {
    return _group_alignment_minimum;
  }
  
  public void setGroupAlignmentMinimum(int the_value) 
  {
    _group_alignment_minimum = (int) the_value;
  }
  
  public boolean _procedure_alignment_fixed;
  public static native int get__procedure_alignment_fixed_offset();
  
  public boolean getProcedureAlignmentFixed()
  {
    return _procedure_alignment_fixed;
  }
  
  public void setProcedureAlignmentFixed(boolean the_value) 
  {
    _procedure_alignment_fixed = (boolean) the_value;
  }
  
  public int _procedure_alignment;
  public static native int get__procedure_alignment_offset();
  
  public int getProcedureAlignment()
  {
    return _procedure_alignment;
  }
  
  public void setProcedureAlignment(int the_value) 
  {
    _procedure_alignment = (int) the_value;
  }
  
  public boolean _integer_representation_is_twos_complement;
  public static native int get__integer_representation_is_twos_complement_offset();
  
  public boolean getIntegerRepresentationIsTwosComplement()
  {
    return _integer_representation_is_twos_complement;
  }
  
  public void setIntegerRepresentationIsTwosComplement(boolean the_value) 
  {
    _integer_representation_is_twos_complement = (boolean) the_value;
  }
  
  
  
  // extra accessors for `list integer_types'
  public Iter getIntegerTypeIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_integer_types");
    Iterator i = new STLIterator(_integer_types,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendIntegerType(IntegerType x) 
   {
    _integer_types.pushBack(x);
  }
  
  public int getIntegerTypeCount() 
   {
    return _integer_types.length();
  }
  
  public void insertIntegerType(int pos, IntegerType x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _integer_types.length(), "index too large " + pos); 
    _integer_types.insert(pos, x);
  }
  
  public IntegerType removeIntegerType(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _integer_types.length(), "index too large " + pos);
    IntegerType tmp = (IntegerType) _integer_types.at(pos);
    _integer_types.erase(pos);
    return tmp;
  }
  
  public IntegerType getIntegerType(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _integer_types.length(), "index too large " + pos);
    return (IntegerType) _integer_types.at(pos);
  }
  
  
  
  // extra accessors for `list floating_point_types'
  public Iter getFloatingPointTypeIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_floating_point_types");
    Iterator i = new STLIterator(_floating_point_types,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendFloatingPointType(FloatingPointType x) 
   {
    _floating_point_types.pushBack(x);
  }
  
  public int getFloatingPointTypeCount() 
   {
    return _floating_point_types.length();
  }
  
  public void insertFloatingPointType(int pos, FloatingPointType x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _floating_point_types.length(), "index too large " + pos); 
    _floating_point_types.insert(pos, x);
  }
  
  public FloatingPointType removeFloatingPointType(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _floating_point_types.length(), "index too large " + pos);
    FloatingPointType tmp = (FloatingPointType) _floating_point_types.at(pos);
    _floating_point_types.erase(pos);
    return tmp;
  }
  
  public FloatingPointType getFloatingPointType(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _floating_point_types.length(), "index too large " + pos);
    return (FloatingPointType) _floating_point_types.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "TargetInformationBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{TargetInformationBlock}");
    
     { 
      int i = 0;
      List.Iterator iter = _integer_types.begin();
      while (iter.notEqual(_integer_types.end())) 
       { 
        IntegerType item = (IntegerType) iter.get();
        text.startBlock("_integer_types[" + i + "]");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    
     { 
      int i = 0;
      List.Iterator iter = _floating_point_types.begin();
      while (iter.notEqual(_floating_point_types.end())) 
       { 
        FloatingPointType item = (FloatingPointType) iter.get();
        text.startBlock("_floating_point_types[" + i + "]");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    text.startBlock("pointer_size_calculation_rule=");
    text.setValue(_pointer_size_calculation_rule);
    text.endBlock();
    text.startBlock("pointer_alignment_calculation_rule=");
    text.setValue(_pointer_alignment_calculation_rule);
    text.endBlock();
    text.startBlock("array_alignment_calculation_rule=");
    text.setValue(_array_alignment_calculation_rule);
    text.endBlock();
    text.startBlock("group_alignment_calculation_rule=");
    text.setValue(_group_alignment_calculation_rule);
    text.endBlock();
    text.startBlock("procedure_alignment_calculation_rule=");
    text.setValue(_procedure_alignment_calculation_rule);
    text.endBlock();
    text.startBlock("integer_representation_rule=");
    text.setValue(_integer_representation_rule);
    text.endBlock();
    text.startBlock("floating_point_representation_rule=");
    text.setValue(_floating_point_representation_rule);
    text.endBlock();
    text.startBlock("is_big_endian=");
    text.setValue(_is_big_endian);
    text.endBlock();
    text.startBlock("byte_size=");
    text.setValue(_byte_size);
    text.endBlock();
    text.startBlock("_word_type");
    text.setValue(_word_type);
    text.endBlock();
    text.startBlock("_default_boolean_type");
    text.setValue(_default_boolean_type);
    text.endBlock();
    text.startBlock("_default_void_type");
    text.setValue(_default_void_type);
    text.endBlock();
    text.startBlock("pointer_size_fixed=");
    text.setValue(_pointer_size_fixed);
    text.endBlock();
    text.startBlock("pointer_size=");
    text.setValue(_pointer_size);
    text.endBlock();
    text.startBlock("pointer_alignment_fixed=");
    text.setValue(_pointer_alignment_fixed);
    text.endBlock();
    text.startBlock("pointer_alignment=");
    text.setValue(_pointer_alignment);
    text.endBlock();
    text.startBlock("array_alignment_calculation_is_standard=");
    text.setValue(_array_alignment_calculation_is_standard);
    text.endBlock();
    text.startBlock("array_alignment_minimum=");
    text.setValue(_array_alignment_minimum);
    text.endBlock();
    text.startBlock("group_alignment_calculation_is_standard=");
    text.setValue(_group_alignment_calculation_is_standard);
    text.endBlock();
    text.startBlock("group_alignment_minimum=");
    text.setValue(_group_alignment_minimum);
    text.endBlock();
    text.startBlock("procedure_alignment_fixed=");
    text.setValue(_procedure_alignment_fixed);
    text.endBlock();
    text.startBlock("procedure_alignment=");
    text.setValue(_procedure_alignment);
    text.endBlock();
    text.startBlock("integer_representation_is_twos_complement=");
    text.setValue(_integer_representation_is_twos_complement);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
