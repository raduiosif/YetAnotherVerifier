package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class FieldAccessExpression extends Expression
 {  
  public Expression _base_group_address;
  public static native int get__base_group_address_offset();
  
  public Expression getBaseGroupAddress()
  {
    return _base_group_address;
  }
  
  public Expression setBaseGroupAddress(Expression the_value) 
  {
    Expression old_value = _base_group_address;
    if (old_value != null) old_value.setParent(null);
    _base_group_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public FieldSymbol _field;
  public static native int get__field_offset();
  
  public FieldSymbol getField()
  {
    return _field;
  }
  
  public void setField(FieldSymbol the_value) 
  {
    _field = (FieldSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "FieldAccessExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FieldAccessExpression}");
    text.startBlock(text.pointerHeader("_base_group_address", _base_group_address));
    if (_base_group_address != null)
      _base_group_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_field");
    text.setValue(_field);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
