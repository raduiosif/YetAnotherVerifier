package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class IntegerType extends NumericType
 {  
  public boolean _is_signed;
  public static native int get__is_signed_offset();
  
  public boolean getIsSigned()
  {
    return _is_signed;
  }
  
  public void setIsSigned(boolean the_value) 
  {
    _is_signed = (boolean) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "IntegerType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{IntegerType}");
    text.startBlock("is_signed=");
    text.setValue(_is_signed);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
