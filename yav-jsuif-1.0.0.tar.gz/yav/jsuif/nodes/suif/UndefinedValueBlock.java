package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class UndefinedValueBlock extends ValueBlock
 {  
  public DataType _type;
  public static native int get__type_offset();
  
  public DataType getType()
  {
    return _type;
  }
  
  public void setType(DataType the_value) 
  {
    _type = (DataType) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "UndefinedValueBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{UndefinedValueBlock}");
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
