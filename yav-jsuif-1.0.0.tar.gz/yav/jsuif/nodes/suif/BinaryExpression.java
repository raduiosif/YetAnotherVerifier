package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class BinaryExpression extends Expression
 {  
  public String _opcode;
  public static native int get__opcode_offset();
  
  public String getOpcode()
  {
    return _opcode;
  }
  
  public void setOpcode(String the_value) 
  {
    _opcode = (String) the_value;
  }
  
  public Expression _source1;
  public static native int get__source1_offset();
  
  public Expression getSource1()
  {
    return _source1;
  }
  
  public Expression setSource1(Expression the_value) 
  {
    Expression old_value = _source1;
    if (old_value != null) old_value.setParent(null);
    _source1 = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _source2;
  public static native int get__source2_offset();
  
  public Expression getSource2()
  {
    return _source2;
  }
  
  public Expression setSource2(Expression the_value) 
  {
    Expression old_value = _source2;
    if (old_value != null) old_value.setParent(null);
    _source2 = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "BinaryExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{BinaryExpression}");
    text.startBlock("opcode=");
    text.setValue(_opcode);
    text.endBlock();
    text.startBlock(text.pointerHeader("_source1", _source1));
    if (_source1 != null)
      _source1.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_source2", _source2));
    if (_source2 != null)
      _source2.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
