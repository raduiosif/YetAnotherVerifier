package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class FieldSymbol extends VariableSymbol
 {  
  public Expression _bit_offset;
  public static native int get__bit_offset_offset();
  
  public Expression getBitOffset()
  {
    return _bit_offset;
  }
  
  public Expression setBitOffset(Expression the_value) 
  {
    Expression old_value = _bit_offset;
    if (old_value != null) old_value.setParent(null);
    _bit_offset = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "FieldSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FieldSymbol}");
    text.startBlock(text.pointerHeader("_bit_offset", _bit_offset));
    if (_bit_offset != null)
      _bit_offset.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
