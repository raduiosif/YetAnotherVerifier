package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class CInformationBlock extends GlobalInformationBlock
 {  
  public String _va_start_builtin;
  public static native int get__va_start_builtin_offset();
  
  public String getVaStartBuiltin()
  {
    return _va_start_builtin;
  }
  
  public void setVaStartBuiltin(String the_value) 
  {
    _va_start_builtin = (String) the_value;
  }
  
  public String _va_start_old_builtin;
  public static native int get__va_start_old_builtin_offset();
  
  public String getVaStartOldBuiltin()
  {
    return _va_start_old_builtin;
  }
  
  public void setVaStartOldBuiltin(String the_value) 
  {
    _va_start_old_builtin = (String) the_value;
  }
  
  public String _va_arg_builtin;
  public static native int get__va_arg_builtin_offset();
  
  public String getVaArgBuiltin()
  {
    return _va_arg_builtin;
  }
  
  public void setVaArgBuiltin(String the_value) 
  {
    _va_arg_builtin = (String) the_value;
  }
  
  public String _va_end_builtin;
  public static native int get__va_end_builtin_offset();
  
  public String getVaEndBuiltin()
  {
    return _va_end_builtin;
  }
  
  public void setVaEndBuiltin(String the_value) 
  {
    _va_end_builtin = (String) the_value;
  }
  
  public IntegerType _signed_char_type;
  public static native int get__signed_char_type_offset();
  
  public IntegerType getSignedCharType()
  {
    return _signed_char_type;
  }
  
  public void setSignedCharType(IntegerType the_value) 
  {
    _signed_char_type = (IntegerType) the_value;
  }
  
  public IntegerType _unsigned_char_type;
  public static native int get__unsigned_char_type_offset();
  
  public IntegerType getUnsignedCharType()
  {
    return _unsigned_char_type;
  }
  
  public void setUnsignedCharType(IntegerType the_value) 
  {
    _unsigned_char_type = (IntegerType) the_value;
  }
  
  public IntegerType _char_type;
  public static native int get__char_type_offset();
  
  public IntegerType getCharType()
  {
    return _char_type;
  }
  
  public void setCharType(IntegerType the_value) 
  {
    _char_type = (IntegerType) the_value;
  }
  
  public IntegerType _signed_short_type;
  public static native int get__signed_short_type_offset();
  
  public IntegerType getSignedShortType()
  {
    return _signed_short_type;
  }
  
  public void setSignedShortType(IntegerType the_value) 
  {
    _signed_short_type = (IntegerType) the_value;
  }
  
  public IntegerType _unsigned_short_type;
  public static native int get__unsigned_short_type_offset();
  
  public IntegerType getUnsignedShortType()
  {
    return _unsigned_short_type;
  }
  
  public void setUnsignedShortType(IntegerType the_value) 
  {
    _unsigned_short_type = (IntegerType) the_value;
  }
  
  public IntegerType _signed_int_type;
  public static native int get__signed_int_type_offset();
  
  public IntegerType getSignedIntType()
  {
    return _signed_int_type;
  }
  
  public void setSignedIntType(IntegerType the_value) 
  {
    _signed_int_type = (IntegerType) the_value;
  }
  
  public IntegerType _unsigned_int_type;
  public static native int get__unsigned_int_type_offset();
  
  public IntegerType getUnsignedIntType()
  {
    return _unsigned_int_type;
  }
  
  public void setUnsignedIntType(IntegerType the_value) 
  {
    _unsigned_int_type = (IntegerType) the_value;
  }
  
  public IntegerType _signed_long_type;
  public static native int get__signed_long_type_offset();
  
  public IntegerType getSignedLongType()
  {
    return _signed_long_type;
  }
  
  public void setSignedLongType(IntegerType the_value) 
  {
    _signed_long_type = (IntegerType) the_value;
  }
  
  public IntegerType _unsigned_long_type;
  public static native int get__unsigned_long_type_offset();
  
  public IntegerType getUnsignedLongType()
  {
    return _unsigned_long_type;
  }
  
  public void setUnsignedLongType(IntegerType the_value) 
  {
    _unsigned_long_type = (IntegerType) the_value;
  }
  
  public IntegerType _signed_long_long_type;
  public static native int get__signed_long_long_type_offset();
  
  public IntegerType getSignedLongLongType()
  {
    return _signed_long_long_type;
  }
  
  public void setSignedLongLongType(IntegerType the_value) 
  {
    _signed_long_long_type = (IntegerType) the_value;
  }
  
  public IntegerType _unsigned_long_long_type;
  public static native int get__unsigned_long_long_type_offset();
  
  public IntegerType getUnsignedLongLongType()
  {
    return _unsigned_long_long_type;
  }
  
  public void setUnsignedLongLongType(IntegerType the_value) 
  {
    _unsigned_long_long_type = (IntegerType) the_value;
  }
  
  public FloatingPointType _float_type;
  public static native int get__float_type_offset();
  
  public FloatingPointType getFloatType()
  {
    return _float_type;
  }
  
  public void setFloatType(FloatingPointType the_value) 
  {
    _float_type = (FloatingPointType) the_value;
  }
  
  public FloatingPointType _double_type;
  public static native int get__double_type_offset();
  
  public FloatingPointType getDoubleType()
  {
    return _double_type;
  }
  
  public void setDoubleType(FloatingPointType the_value) 
  {
    _double_type = (FloatingPointType) the_value;
  }
  
  public FloatingPointType _long_double_type;
  public static native int get__long_double_type_offset();
  
  public FloatingPointType getLongDoubleType()
  {
    return _long_double_type;
  }
  
  public void setLongDoubleType(FloatingPointType the_value) 
  {
    _long_double_type = (FloatingPointType) the_value;
  }
  
  public Type _file_type;
  public static native int get__file_type_offset();
  
  public Type getFileType()
  {
    return _file_type;
  }
  
  public void setFileType(Type the_value) 
  {
    _file_type = (Type) the_value;
  }
  
  public IntegerType _ptrdiff_t_type;
  public static native int get__ptrdiff_t_type_offset();
  
  public IntegerType getPtrdiffTType()
  {
    return _ptrdiff_t_type;
  }
  
  public void setPtrdiffTType(IntegerType the_value) 
  {
    _ptrdiff_t_type = (IntegerType) the_value;
  }
  
  public IntegerType _size_t_type;
  public static native int get__size_t_type_offset();
  
  public IntegerType getSizeTType()
  {
    return _size_t_type;
  }
  
  public void setSizeTType(IntegerType the_value) 
  {
    _size_t_type = (IntegerType) the_value;
  }
  
  public Type _va_list_type;
  public static native int get__va_list_type_offset();
  
  public Type getVaListType()
  {
    return _va_list_type;
  }
  
  public void setVaListType(Type the_value) 
  {
    _va_list_type = (Type) the_value;
  }
  
  public boolean _plain_bit_field_is_signed;
  public static native int get__plain_bit_field_is_signed_offset();
  
  public boolean getPlainBitFieldIsSigned()
  {
    return _plain_bit_field_is_signed;
  }
  
  public void setPlainBitFieldIsSigned(boolean the_value) 
  {
    _plain_bit_field_is_signed = (boolean) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "CInformationBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{CInformationBlock}");
    text.startBlock("va_start_builtin=");
    text.setValue(_va_start_builtin);
    text.endBlock();
    text.startBlock("va_start_old_builtin=");
    text.setValue(_va_start_old_builtin);
    text.endBlock();
    text.startBlock("va_arg_builtin=");
    text.setValue(_va_arg_builtin);
    text.endBlock();
    text.startBlock("va_end_builtin=");
    text.setValue(_va_end_builtin);
    text.endBlock();
    text.startBlock("_signed_char_type");
    text.setValue(_signed_char_type);
    text.endBlock();
    text.startBlock("_unsigned_char_type");
    text.setValue(_unsigned_char_type);
    text.endBlock();
    text.startBlock("_char_type");
    text.setValue(_char_type);
    text.endBlock();
    text.startBlock("_signed_short_type");
    text.setValue(_signed_short_type);
    text.endBlock();
    text.startBlock("_unsigned_short_type");
    text.setValue(_unsigned_short_type);
    text.endBlock();
    text.startBlock("_signed_int_type");
    text.setValue(_signed_int_type);
    text.endBlock();
    text.startBlock("_unsigned_int_type");
    text.setValue(_unsigned_int_type);
    text.endBlock();
    text.startBlock("_signed_long_type");
    text.setValue(_signed_long_type);
    text.endBlock();
    text.startBlock("_unsigned_long_type");
    text.setValue(_unsigned_long_type);
    text.endBlock();
    text.startBlock("_signed_long_long_type");
    text.setValue(_signed_long_long_type);
    text.endBlock();
    text.startBlock("_unsigned_long_long_type");
    text.setValue(_unsigned_long_long_type);
    text.endBlock();
    text.startBlock("_float_type");
    text.setValue(_float_type);
    text.endBlock();
    text.startBlock("_double_type");
    text.setValue(_double_type);
    text.endBlock();
    text.startBlock("_long_double_type");
    text.setValue(_long_double_type);
    text.endBlock();
    text.startBlock("_file_type");
    text.setValue(_file_type);
    text.endBlock();
    text.startBlock("_ptrdiff_t_type");
    text.setValue(_ptrdiff_t_type);
    text.endBlock();
    text.startBlock("_size_t_type");
    text.setValue(_size_t_type);
    text.endBlock();
    text.startBlock("_va_list_type");
    text.setValue(_va_list_type);
    text.endBlock();
    text.startBlock("plain_bit_field_is_signed=");
    text.setValue(_plain_bit_field_is_signed);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
