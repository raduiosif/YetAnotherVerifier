package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class SymbolAddressExpression extends Expression
 {  
  public Symbol _addressed_symbol;
  public static native int get__addressed_symbol_offset();
  
  public Symbol getAddressedSymbol()
  {
    return _addressed_symbol;
  }
  
  public void setAddressedSymbol(Symbol the_value) 
  {
    _addressed_symbol = (Symbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "SymbolAddressExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{SymbolAddressExpression}");
    text.startBlock("_addressed_symbol");
    text.setValue(_addressed_symbol);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
