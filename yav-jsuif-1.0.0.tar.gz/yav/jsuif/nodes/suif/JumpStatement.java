package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class JumpStatement extends Statement
 {  
  public CodeLabelSymbol _target;
  public static native int get__target_offset();
  
  public CodeLabelSymbol getTarget()
  {
    return _target;
  }
  
  public void setTarget(CodeLabelSymbol the_value) 
  {
    _target = (CodeLabelSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "JumpStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{JumpStatement}");
    text.startBlock("_target");
    text.setValue(_target);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
