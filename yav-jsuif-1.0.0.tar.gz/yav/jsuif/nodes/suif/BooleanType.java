package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class BooleanType extends NumericType
 {  
  
  
  public static native int get_size();
  
  private static String _className = "BooleanType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{BooleanType}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
