#include <jni.h>
#include <suifclasses.h>
#include <suif.h>

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VoidType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VoidType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_NumericType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( NumericType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BooleanType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( BooleanType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IntegerType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( IntegerType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IntegerType_get_1_1is_1signed_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IntegerType, _is_signed);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FloatingPointType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FloatingPointType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_EnumeratedType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( EnumeratedType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_EnumeratedType_get_1_1case_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(EnumeratedType, _case);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_PointerType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( PointerType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_PointerType_get_1_1reference_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(PointerType, _reference_type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ReferenceType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ReferenceType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ReferenceType_get_1_1reference_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ReferenceType, _reference_type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ArrayType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayType_get_1_1element_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ArrayType, _element_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayType_get_1_1lower_1bound_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ArrayType, _lower_bound);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayType_get_1_1upper_1bound_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ArrayType, _upper_bound);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( MultiDimArrayType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayType_get_1_1element_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayType, _element_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayType_get_1_1lower_1bounds_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayType, _lower_bounds);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayType_get_1_1upper_1bounds_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayType, _upper_bounds);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_GroupType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( GroupType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_GroupType_get_1_1is_1complete_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(GroupType, _is_complete);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_GroupType_get_1_1group_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(GroupType, _group_symbol_table);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StructType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( StructType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UnionType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( UnionType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( CProcedureType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1_1arguments_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CProcedureType, _arguments);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1_1result_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CProcedureType, _result_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1_1has_1varargs_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CProcedureType, _has_varargs);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1_1arguments_1known_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CProcedureType, _arguments_known);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CProcedureType_get_1_1bit_1alignment_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CProcedureType, _bit_alignment);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FieldSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FieldSymbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FieldSymbol_get_1_1bit_1offset_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FieldSymbol, _bit_offset);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_NestingVariableSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( NestingVariableSymbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_NestingVariableSymbol_get_1_1super_1variable_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(NestingVariableSymbol, _super_variable);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_NestingVariableSymbol_get_1_1bit_1offset_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(NestingVariableSymbol, _bit_offset);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_NestingVariableSymbol_get_1_1child_1variables_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(NestingVariableSymbol, _child_variables);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_EvalStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( EvalStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_EvalStatement_get_1_1expressions_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(EvalStatement, _expressions);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CallStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( CallStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CallStatement_get_1_1destination_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CallStatement, _destination);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CallStatement_get_1_1callee_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CallStatement, _callee_address);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CallStatement_get_1_1arguments_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CallStatement, _arguments);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IfStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( IfStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IfStatement_get_1_1condition_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IfStatement, _condition);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IfStatement_get_1_1then_1part_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IfStatement, _then_part);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_IfStatement_get_1_1else_1part_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IfStatement, _else_part);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_WhileStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( WhileStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_WhileStatement_get_1_1condition_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(WhileStatement, _condition);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_WhileStatement_get_1_1body_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(WhileStatement, _body);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_WhileStatement_get_1_1break_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(WhileStatement, _break_label);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_WhileStatement_get_1_1continue_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(WhileStatement, _continue_label);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_DoWhileStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( DoWhileStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_DoWhileStatement_get_1_1condition_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DoWhileStatement, _condition);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_DoWhileStatement_get_1_1body_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DoWhileStatement, _body);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_DoWhileStatement_get_1_1break_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DoWhileStatement, _break_label);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_DoWhileStatement_get_1_1continue_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DoWhileStatement, _continue_label);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ForStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1index_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _index);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1lower_1bound_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _lower_bound);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1upper_1bound_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _upper_bound);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1step_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _step);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1comparison_1opcode_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _comparison_opcode);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1body_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _body);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1pre_1pad_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _pre_pad);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1break_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _break_label);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ForStatement_get_1_1continue_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ForStatement, _continue_label);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ScopeStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ScopeStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ScopeStatement_get_1_1body_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ScopeStatement, _body);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ScopeStatement_get_1_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ScopeStatement, _symbol_table);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ScopeStatement_get_1_1definition_1block_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ScopeStatement, _definition_block);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaStartStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VaStartStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaStartStatement_get_1_1ap_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VaStartStatement, _ap_address);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaStartStatement_get_1_1parmn_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VaStartStatement, _parmn);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaStartOldStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VaStartOldStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaStartOldStatement_get_1_1ap_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VaStartOldStatement, _ap_address);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaEndStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VaEndStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaEndStatement_get_1_1ap_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VaEndStatement, _ap_address);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( StoreStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreStatement_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StoreStatement, _value);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreStatement_get_1_1destination_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StoreStatement, _destination_address);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreVariableStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( StoreVariableStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreVariableStatement_get_1_1destination_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StoreVariableStatement, _destination);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_StoreVariableStatement_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StoreVariableStatement, _value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ReturnStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ReturnStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ReturnStatement_get_1_1return_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ReturnStatement, _return_value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_JumpStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( JumpStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_JumpStatement_get_1_1target_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(JumpStatement, _target);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_JumpIndirectStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( JumpIndirectStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_JumpIndirectStatement_get_1_1target_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(JumpIndirectStatement, _target);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BranchStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( BranchStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BranchStatement_get_1_1decision_1operand_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BranchStatement, _decision_operand);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BranchStatement_get_1_1target_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BranchStatement, _target);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiWayBranchStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( MultiWayBranchStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiWayBranchStatement_get_1_1decision_1operand_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiWayBranchStatement, _decision_operand);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiWayBranchStatement_get_1_1default_1target_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiWayBranchStatement, _default_target);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiWayBranchStatement_get_1_1case_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiWayBranchStatement, _case);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LabelLocationStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( LabelLocationStatement );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LabelLocationStatement_get_1_1defined_1label_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(LabelLocationStatement, _defined_label);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MarkStatement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( MarkStatement );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BinaryExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( BinaryExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BinaryExpression_get_1_1opcode_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BinaryExpression, _opcode);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BinaryExpression_get_1_1source1_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BinaryExpression, _source1);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_BinaryExpression_get_1_1source2_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BinaryExpression, _source2);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UnaryExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( UnaryExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UnaryExpression_get_1_1opcode_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(UnaryExpression, _opcode);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UnaryExpression_get_1_1source_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(UnaryExpression, _source);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SelectExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SelectExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SelectExpression_get_1_1selector_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SelectExpression, _selector);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SelectExpression_get_1_1selection1_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SelectExpression, _selection1);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SelectExpression_get_1_1selection2_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SelectExpression, _selection2);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( MultiDimArrayExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayExpression_get_1_1array_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayExpression, _array_address);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayExpression_get_1_1offset_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayExpression, _offset);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayExpression_get_1_1index_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayExpression, _index);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiDimArrayExpression_get_1_1elements_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiDimArrayExpression, _elements);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayReferenceExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ArrayReferenceExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayReferenceExpression_get_1_1base_1array_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ArrayReferenceExpression, _base_array_address);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ArrayReferenceExpression_get_1_1index_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ArrayReferenceExpression, _index);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FieldAccessExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FieldAccessExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FieldAccessExpression_get_1_1base_1group_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FieldAccessExpression, _base_group_address);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_FieldAccessExpression_get_1_1field_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FieldAccessExpression, _field);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaArgExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VaArgExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_VaArgExpression_get_1_1ap_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VaArgExpression, _ap_address);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( LoadExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadExpression_get_1_1source_1address_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(LoadExpression, _source_address);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadVariableExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( LoadVariableExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadVariableExpression_get_1_1source_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(LoadVariableExpression, _source);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SymbolAddressExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SymbolAddressExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SymbolAddressExpression_get_1_1addressed_1symbol_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SymbolAddressExpression, _addressed_symbol);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadValueBlockExpression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( LoadValueBlockExpression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_LoadValueBlockExpression_get_1_1value_1block_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(LoadValueBlockExpression, _value_block);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ExpressionValueBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ExpressionValueBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_ExpressionValueBlock_get_1_1expression_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ExpressionValueBlock, _expression);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiValueBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( MultiValueBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiValueBlock_get_1_1sub_1blocks_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiValueBlock, _sub_blocks);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MultiValueBlock_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(MultiValueBlock, _type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_RepeatValueBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( RepeatValueBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_RepeatValueBlock_get_1_1num_1repetitions_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(RepeatValueBlock, _num_repetitions);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_RepeatValueBlock_get_1_1sub_1block_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(RepeatValueBlock, _sub_block);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_RepeatValueBlock_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(RepeatValueBlock, _type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UndefinedValueBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( UndefinedValueBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_UndefinedValueBlock_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(UndefinedValueBlock, _type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_GroupSymbolTable_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( GroupSymbolTable );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( TargetInformationBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1integer_1types_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _integer_types);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1floating_1point_1types_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _floating_point_types);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1size_1calculation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_size_calculation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1alignment_1calculation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_alignment_calculation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1array_1alignment_1calculation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _array_alignment_calculation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1group_1alignment_1calculation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _group_alignment_calculation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1procedure_1alignment_1calculation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _procedure_alignment_calculation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1integer_1representation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _integer_representation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1floating_1point_1representation_1rule_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _floating_point_representation_rule);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1is_1big_1endian_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _is_big_endian);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1byte_1size_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _byte_size);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1word_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _word_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1default_1boolean_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _default_boolean_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1default_1void_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _default_void_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1size_1fixed_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_size_fixed);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1size_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_size);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1alignment_1fixed_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_alignment_fixed);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1pointer_1alignment_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _pointer_alignment);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1array_1alignment_1calculation_1is_1standard_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _array_alignment_calculation_is_standard);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1array_1alignment_1minimum_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _array_alignment_minimum);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1group_1alignment_1calculation_1is_1standard_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _group_alignment_calculation_is_standard);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1group_1alignment_1minimum_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _group_alignment_minimum);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1procedure_1alignment_1fixed_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _procedure_alignment_fixed);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1procedure_1alignment_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _procedure_alignment);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_TargetInformationBlock_get_1_1integer_1representation_1is_1twos_1complement_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(TargetInformationBlock, _integer_representation_is_twos_complement);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( CInformationBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1va_1start_1builtin_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _va_start_builtin);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1va_1start_1old_1builtin_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _va_start_old_builtin);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1va_1arg_1builtin_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _va_arg_builtin);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1va_1end_1builtin_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _va_end_builtin);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1signed_1char_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _signed_char_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1unsigned_1char_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _unsigned_char_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1char_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _char_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1signed_1short_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _signed_short_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1unsigned_1short_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _unsigned_short_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1signed_1int_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _signed_int_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1unsigned_1int_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _unsigned_int_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1signed_1long_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _signed_long_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1unsigned_1long_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _unsigned_long_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1signed_1long_1long_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _signed_long_long_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1unsigned_1long_1long_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _unsigned_long_long_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1float_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _float_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1double_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _double_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1long_1double_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _long_double_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1file_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _file_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1ptrdiff_1t_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _ptrdiff_t_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1size_1t_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _size_t_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1va_1list_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _va_list_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CInformationBlock_get_1_1plain_1bit_1field_1is_1signed_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CInformationBlock, _plain_bit_field_is_signed);
 } 



typedef indexed_list<IInteger, CodeLabelSymbol* >::pair yav_jsuif_nodes_suif_CasePair_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CasePair_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_CasePair_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CasePair_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_CasePair_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_CasePair_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_CasePair_type, second);
 } 

typedef indexed_list<IInteger, ValueBlock* >::pair yav_jsuif_nodes_suif_SubBlockPair_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SubBlockPair_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_SubBlockPair_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SubBlockPair_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_SubBlockPair_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SubBlockPair_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_SubBlockPair_type, second);
 } 

typedef indexed_list<LString, IInteger>::pair yav_jsuif_nodes_suif_MetaPairLStringIInteger_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIInteger_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairLStringIInteger_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIInteger_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairLStringIInteger_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIInteger_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairLStringIInteger_type, second);
 } 

typedef indexed_list<LString, IInteger>::pair yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairLStringIIntegerType_type, second);
 } 

typedef indexed_list<IInteger, CodeLabelSymbol* >::pair yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRef_type, second);
 } 

typedef indexed_list<IInteger, CodeLabelSymbol* >::pair yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerCodeLabelSymbolRefType_type, second);
 } 

typedef indexed_list<IInteger, ValueBlock* >::pair yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwner_type, second);
 } 

typedef indexed_list<IInteger, ValueBlock* >::pair yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_suif_MetaPairIIntegerValueBlockOwnerType_type, second);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1indexed_1list_1LString_1IInteger_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(indexed_list <LString,IInteger>);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1vector_1Expression_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(suif_vector <Expression* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1vector_1QualifiedType_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(suif_vector <QualifiedType* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1list_1NestingVariableSymbol_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <NestingVariableSymbol* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1list_1Expression_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <Expression* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1indexed_1list_1IInteger_1CodeLabelSymbol_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(indexed_list <IInteger,CodeLabelSymbol* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1indexed_1list_1IInteger_1ValueBlock_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(indexed_list <IInteger,ValueBlock* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1list_1IntegerType_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <IntegerType* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_suif_SuifObjectFactory_get_1list_1FloatingPointType_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <FloatingPointType* >);
 } 

