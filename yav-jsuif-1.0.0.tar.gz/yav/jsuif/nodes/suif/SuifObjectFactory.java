package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;

import yav.jsuif.nodes.basic.*; 

public class SuifObjectFactory extends RealObjectFactory
 {  
  private static String _className = "SuifObjectFactory"; 
  public static String getClassName() { return _className; } 
  public String getName() { return getClassName(); } 
  
  static { System.loadLibrary("jsuif"); } 
  
  public void initIO(ObjectFactory mcof) 
   {  
    super.initIO(mcof);
    
    AggregateMetaClass meta_VoidType =
      mcof.createObjectMetaClass(VoidType.getClassName(), VoidType.get_size());
    
    AggregateMetaClass meta_NumericType =
      mcof.createObjectMetaClass(NumericType.getClassName(), NumericType.get_size());
    
    AggregateMetaClass meta_BooleanType =
      mcof.createObjectMetaClass(BooleanType.getClassName(), BooleanType.get_size());
    
    AggregateMetaClass meta_IntegerType =
      mcof.createObjectMetaClass(IntegerType.getClassName(), IntegerType.get_size());
    
    AggregateMetaClass meta_FloatingPointType =
      mcof.createObjectMetaClass(FloatingPointType.getClassName(), FloatingPointType.get_size());
    
    AggregateMetaClass meta_EnumeratedType =
      mcof.createObjectMetaClass(EnumeratedType.getClassName(), EnumeratedType.get_size());
    
    AggregateMetaClass meta_PointerType =
      mcof.createObjectMetaClass(PointerType.getClassName(), PointerType.get_size());
    
    AggregateMetaClass meta_ReferenceType =
      mcof.createObjectMetaClass(ReferenceType.getClassName(), ReferenceType.get_size());
    
    AggregateMetaClass meta_ArrayType =
      mcof.createObjectMetaClass(ArrayType.getClassName(), ArrayType.get_size());
    
    AggregateMetaClass meta_MultiDimArrayType =
      mcof.createObjectMetaClass(MultiDimArrayType.getClassName(), MultiDimArrayType.get_size());
    
    AggregateMetaClass meta_GroupType =
      mcof.createObjectMetaClass(GroupType.getClassName(), GroupType.get_size());
    
    AggregateMetaClass meta_StructType =
      mcof.createObjectMetaClass(StructType.getClassName(), StructType.get_size());
    
    AggregateMetaClass meta_UnionType =
      mcof.createObjectMetaClass(UnionType.getClassName(), UnionType.get_size());
    
    AggregateMetaClass meta_CProcedureType =
      mcof.createObjectMetaClass(CProcedureType.getClassName(), CProcedureType.get_size());
    
    AggregateMetaClass meta_FieldSymbol =
      mcof.createObjectMetaClass(FieldSymbol.getClassName(), FieldSymbol.get_size());
    
    AggregateMetaClass meta_NestingVariableSymbol =
      mcof.createObjectMetaClass(NestingVariableSymbol.getClassName(), NestingVariableSymbol.get_size());
    
    AggregateMetaClass meta_EvalStatement =
      mcof.createObjectMetaClass(EvalStatement.getClassName(), EvalStatement.get_size());
    
    AggregateMetaClass meta_CallStatement =
      mcof.createObjectMetaClass(CallStatement.getClassName(), CallStatement.get_size());
    
    AggregateMetaClass meta_IfStatement =
      mcof.createObjectMetaClass(IfStatement.getClassName(), IfStatement.get_size());
    
    AggregateMetaClass meta_WhileStatement =
      mcof.createObjectMetaClass(WhileStatement.getClassName(), WhileStatement.get_size());
    
    AggregateMetaClass meta_DoWhileStatement =
      mcof.createObjectMetaClass(DoWhileStatement.getClassName(), DoWhileStatement.get_size());
    
    AggregateMetaClass meta_ForStatement =
      mcof.createObjectMetaClass(ForStatement.getClassName(), ForStatement.get_size());
    
    AggregateMetaClass meta_ScopeStatement =
      mcof.createObjectMetaClass(ScopeStatement.getClassName(), ScopeStatement.get_size());
    
    AggregateMetaClass meta_VaStartStatement =
      mcof.createObjectMetaClass(VaStartStatement.getClassName(), VaStartStatement.get_size());
    
    AggregateMetaClass meta_VaStartOldStatement =
      mcof.createObjectMetaClass(VaStartOldStatement.getClassName(), VaStartOldStatement.get_size());
    
    AggregateMetaClass meta_VaEndStatement =
      mcof.createObjectMetaClass(VaEndStatement.getClassName(), VaEndStatement.get_size());
    
    AggregateMetaClass meta_StoreStatement =
      mcof.createObjectMetaClass(StoreStatement.getClassName(), StoreStatement.get_size());
    
    AggregateMetaClass meta_StoreVariableStatement =
      mcof.createObjectMetaClass(StoreVariableStatement.getClassName(), StoreVariableStatement.get_size());
    
    AggregateMetaClass meta_ReturnStatement =
      mcof.createObjectMetaClass(ReturnStatement.getClassName(), ReturnStatement.get_size());
    
    AggregateMetaClass meta_JumpStatement =
      mcof.createObjectMetaClass(JumpStatement.getClassName(), JumpStatement.get_size());
    
    AggregateMetaClass meta_JumpIndirectStatement =
      mcof.createObjectMetaClass(JumpIndirectStatement.getClassName(), JumpIndirectStatement.get_size());
    
    AggregateMetaClass meta_BranchStatement =
      mcof.createObjectMetaClass(BranchStatement.getClassName(), BranchStatement.get_size());
    
    AggregateMetaClass meta_MultiWayBranchStatement =
      mcof.createObjectMetaClass(MultiWayBranchStatement.getClassName(), MultiWayBranchStatement.get_size());
    
    AggregateMetaClass meta_LabelLocationStatement =
      mcof.createObjectMetaClass(LabelLocationStatement.getClassName(), LabelLocationStatement.get_size());
    
    AggregateMetaClass meta_MarkStatement =
      mcof.createObjectMetaClass(MarkStatement.getClassName(), MarkStatement.get_size());
    
    AggregateMetaClass meta_BinaryExpression =
      mcof.createObjectMetaClass(BinaryExpression.getClassName(), BinaryExpression.get_size());
    
    AggregateMetaClass meta_UnaryExpression =
      mcof.createObjectMetaClass(UnaryExpression.getClassName(), UnaryExpression.get_size());
    
    AggregateMetaClass meta_SelectExpression =
      mcof.createObjectMetaClass(SelectExpression.getClassName(), SelectExpression.get_size());
    
    AggregateMetaClass meta_MultiDimArrayExpression =
      mcof.createObjectMetaClass(MultiDimArrayExpression.getClassName(), MultiDimArrayExpression.get_size());
    
    AggregateMetaClass meta_ArrayReferenceExpression =
      mcof.createObjectMetaClass(ArrayReferenceExpression.getClassName(), ArrayReferenceExpression.get_size());
    
    AggregateMetaClass meta_FieldAccessExpression =
      mcof.createObjectMetaClass(FieldAccessExpression.getClassName(), FieldAccessExpression.get_size());
    
    AggregateMetaClass meta_VaArgExpression =
      mcof.createObjectMetaClass(VaArgExpression.getClassName(), VaArgExpression.get_size());
    
    AggregateMetaClass meta_LoadExpression =
      mcof.createObjectMetaClass(LoadExpression.getClassName(), LoadExpression.get_size());
    
    AggregateMetaClass meta_LoadVariableExpression =
      mcof.createObjectMetaClass(LoadVariableExpression.getClassName(), LoadVariableExpression.get_size());
    
    AggregateMetaClass meta_SymbolAddressExpression =
      mcof.createObjectMetaClass(SymbolAddressExpression.getClassName(), SymbolAddressExpression.get_size());
    
    AggregateMetaClass meta_LoadValueBlockExpression =
      mcof.createObjectMetaClass(LoadValueBlockExpression.getClassName(), LoadValueBlockExpression.get_size());
    
    AggregateMetaClass meta_ExpressionValueBlock =
      mcof.createObjectMetaClass(ExpressionValueBlock.getClassName(), ExpressionValueBlock.get_size());
    
    AggregateMetaClass meta_MultiValueBlock =
      mcof.createObjectMetaClass(MultiValueBlock.getClassName(), MultiValueBlock.get_size());
    
    AggregateMetaClass meta_RepeatValueBlock =
      mcof.createObjectMetaClass(RepeatValueBlock.getClassName(), RepeatValueBlock.get_size());
    
    AggregateMetaClass meta_UndefinedValueBlock =
      mcof.createObjectMetaClass(UndefinedValueBlock.getClassName(), UndefinedValueBlock.get_size());
    
    AggregateMetaClass meta_GroupSymbolTable =
      mcof.createObjectMetaClass(GroupSymbolTable.getClassName(), GroupSymbolTable.get_size());
    
    AggregateMetaClass meta_TargetInformationBlock =
      mcof.createObjectMetaClass(TargetInformationBlock.getClassName(), TargetInformationBlock.get_size());
    
    AggregateMetaClass meta_CInformationBlock =
      mcof.createObjectMetaClass(CInformationBlock.getClassName(), CInformationBlock.get_size());
    
    MetaClass meta_bool =
      _object_factory.findMetaClass("bool");
    
    MetaClass meta_LString =
      _object_factory.findMetaClass("LString");
    
    MetaClass meta_IInteger =
      _object_factory.findMetaClass("IInteger");
    
    AggregateMetaClass meta_pair_LString_IInteger =
      mcof.findAggregateMetaClass("meta_pair_LString_IInteger");
    
    if (meta_pair_LString_IInteger == null) {
      meta_pair_LString_IInteger = mcof.createAggregateMetaClass("meta_pair_LString_IInteger", MetaPairLStringIIntegerType.get_size());
      _object_factory.addField(meta_pair_LString_IInteger, "_first",meta_LString, MetaPairLStringIIntegerType.get_first_offset());
      _object_factory.addField(meta_pair_LString_IInteger, "_second",meta_IInteger, MetaPairLStringIIntegerType.get_second_offset());
      }
    
    STLMetaClass meta_LString_IInteger_indexed_list =
      _object_factory.getSTLMetaClass("LIST:indexed_list<LString, IInteger>", new STLDescriptor(meta_pair_LString_IInteger, get_indexed_list_LString_IInteger_size()));
    
    AggregateMetaClass meta_Type =
       mcof.findAggregateMetaClass(Type.getClassName());
    
    PointerMetaClass meta_Type_ref =
       mcof.getPointerMetaClass(meta_Type ,false, false, false);
    
    AggregateMetaClass meta_QualifiedType =
       mcof.findAggregateMetaClass(QualifiedType.getClassName());
    
    PointerMetaClass meta_QualifiedType_ref =
       mcof.getPointerMetaClass(meta_QualifiedType ,false, false, false);
    
    AggregateMetaClass meta_Expression =
       mcof.findAggregateMetaClass(Expression.getClassName());
    
    PointerMetaClass meta_Expression_owner =
       mcof.getPointerMetaClass(meta_Expression ,true, false, true);
    
    STLMetaClass meta_Expression_owner_vector =
      mcof.getSTLMetaClass("LIST:vector<Expression* >", new STLDescriptor(meta_Expression_owner, get_vector_Expression_ptr_size()));
    
    PointerMetaClass meta_GroupSymbolTable_owner =
       mcof.getPointerMetaClass(meta_GroupSymbolTable ,true, false, true);
    
    STLMetaClass meta_QualifiedType_ref_vector =
      mcof.getSTLMetaClass("LIST:vector<QualifiedType* >", new STLDescriptor(meta_QualifiedType_ref, get_vector_QualifiedType_ptr_size()));
    
    AggregateMetaClass meta_DataType =
       mcof.findAggregateMetaClass(DataType.getClassName());
    
    PointerMetaClass meta_DataType_ref =
       mcof.getPointerMetaClass(meta_DataType ,false, false, false);
    
    MetaClass meta_int =
      _object_factory.findMetaClass("int");
    
    PointerMetaClass meta_NestingVariableSymbol_ref =
       mcof.getPointerMetaClass(meta_NestingVariableSymbol ,false, false, false);
    
    STLMetaClass meta_NestingVariableSymbol_ref_list =
      mcof.getSTLMetaClass("LIST:list<NestingVariableSymbol* >", new STLDescriptor(meta_NestingVariableSymbol_ref, get_list_NestingVariableSymbol_ptr_size()));
    
    STLMetaClass meta_Expression_owner_list =
      mcof.getSTLMetaClass("LIST:list<Expression* >", new STLDescriptor(meta_Expression_owner, get_list_Expression_ptr_size()));
    
    AggregateMetaClass meta_VariableSymbol =
       mcof.findAggregateMetaClass(VariableSymbol.getClassName());
    
    PointerMetaClass meta_VariableSymbol_ref =
       mcof.getPointerMetaClass(meta_VariableSymbol,false, false, false);
    
    AggregateMetaClass meta_Statement =
       mcof.findAggregateMetaClass(Statement.getClassName());
    
    PointerMetaClass meta_Statement_owner =
       mcof.getPointerMetaClass(meta_Statement ,true, false, true);
    
    AggregateMetaClass meta_CodeLabelSymbol =
       mcof.findAggregateMetaClass(CodeLabelSymbol.getClassName());
    
    PointerMetaClass meta_CodeLabelSymbol_ref =
       mcof.getPointerMetaClass(meta_CodeLabelSymbol ,false, false, false);
    
    AggregateMetaClass meta_SymbolTable =
       mcof.findAggregateMetaClass(SymbolTable.getClassName());
    
    PointerMetaClass meta_SymbolTable_owner =
       mcof.getPointerMetaClass(meta_SymbolTable ,true, false, true);
    
    AggregateMetaClass meta_DefinitionBlock =
       mcof.findAggregateMetaClass(DefinitionBlock.getClassName());
    
    PointerMetaClass meta_DefinitionBlock_owner =
       mcof.getPointerMetaClass(meta_DefinitionBlock ,true, false, true);
    
    AggregateMetaClass meta_ParameterSymbol =
       mcof.findAggregateMetaClass(ParameterSymbol.getClassName());
    
    PointerMetaClass meta_ParameterSymbol_ref =
       mcof.getPointerMetaClass(meta_ParameterSymbol ,false, false, false);
    
    AggregateMetaClass meta_pair_IInteger_CodeLabelSymbol_ref =
      mcof.findAggregateMetaClass("meta_pair_IInteger_CodeLabelSymbol_ref");
    
    if (meta_pair_IInteger_CodeLabelSymbol_ref == null) {
      meta_pair_IInteger_CodeLabelSymbol_ref = mcof.createAggregateMetaClass("meta_pair_IInteger_CodeLabelSymbol_ref", MetaPairIIntegerCodeLabelSymbolRefType.get_size());
      _object_factory.addField(meta_pair_IInteger_CodeLabelSymbol_ref, "_first",meta_IInteger, MetaPairIIntegerCodeLabelSymbolRefType.get_first_offset());
      _object_factory.addField(meta_pair_IInteger_CodeLabelSymbol_ref, "_second",meta_CodeLabelSymbol_ref, MetaPairIIntegerCodeLabelSymbolRefType.get_second_offset());
      }
    
    STLMetaClass meta_IInteger_CodeLabelSymbol_ref_indexed_list =
      _object_factory.getSTLMetaClass("LIST:indexed_list<IInteger, CodeLabelSymbol* >", new STLDescriptor(meta_pair_IInteger_CodeLabelSymbol_ref, get_indexed_list_IInteger_CodeLabelSymbol_ptr_size()));
    
    PointerMetaClass meta_CodeLabelSymbol_def =
       mcof.getPointerMetaClass(meta_CodeLabelSymbol ,false, false, true);
    
    PointerMetaClass meta_FieldSymbol_ref =
       mcof.getPointerMetaClass(meta_FieldSymbol ,false, false, false);
    
    AggregateMetaClass meta_Symbol =
       mcof.findAggregateMetaClass(Symbol.getClassName());
    
    PointerMetaClass meta_Symbol_ref =
       mcof.getPointerMetaClass(meta_Symbol ,false, false, false);
    
    AggregateMetaClass meta_ValueBlock =
       mcof.findAggregateMetaClass(ValueBlock.getClassName());
    
    PointerMetaClass meta_ValueBlock_owner =
       mcof.getPointerMetaClass(meta_ValueBlock ,true, false, true);
    
    AggregateMetaClass meta_pair_IInteger_ValueBlock_owner =
      mcof.findAggregateMetaClass("meta_pair_IInteger_ValueBlock_owner");
    
    if (meta_pair_IInteger_ValueBlock_owner == null) {
      meta_pair_IInteger_ValueBlock_owner = mcof.createAggregateMetaClass("meta_pair_IInteger_ValueBlock_owner", MetaPairIIntegerValueBlockOwnerType.get_size());
      _object_factory.addField(meta_pair_IInteger_ValueBlock_owner, "_first",meta_IInteger, MetaPairIIntegerValueBlockOwnerType.get_first_offset());
      _object_factory.addField(meta_pair_IInteger_ValueBlock_owner, "_second",meta_ValueBlock_owner, MetaPairIIntegerValueBlockOwnerType.get_second_offset());
      }
    
    STLMetaClass meta_IInteger_ValueBlock_owner_indexed_list =
      _object_factory.getSTLMetaClass("LIST:indexed_list<IInteger, ValueBlock* >", new STLDescriptor(meta_pair_IInteger_ValueBlock_owner, get_indexed_list_IInteger_ValueBlock_ptr_size()));
    
    PointerMetaClass meta_IntegerType_ref =
       mcof.getPointerMetaClass(meta_IntegerType ,false, false, false);
    
    STLMetaClass meta_IntegerType_ref_list =
      mcof.getSTLMetaClass("LIST:list<IntegerType* >", new STLDescriptor(meta_IntegerType_ref, get_list_IntegerType_ptr_size()));
    
    PointerMetaClass meta_FloatingPointType_ref =
       mcof.getPointerMetaClass(meta_FloatingPointType ,false, false, false);
    
    STLMetaClass meta_FloatingPointType_ref_list =
      mcof.getSTLMetaClass("LIST:list<FloatingPointType* >", new STLDescriptor(meta_FloatingPointType_ref, get_list_FloatingPointType_ptr_size()));
    
    PointerMetaClass meta_BooleanType_ref =
       mcof.getPointerMetaClass(meta_BooleanType ,false, false, false);
    
    PointerMetaClass meta_VoidType_ref =
       mcof.getPointerMetaClass(meta_VoidType ,false, false, false);
    
    meta_VoidType.inheritsFrom(meta_DataType);
    
    meta_NumericType.inheritsFrom(meta_DataType);
    
    meta_BooleanType.inheritsFrom(meta_NumericType);
    
    meta_IntegerType.inheritsFrom(meta_NumericType);
    
    _object_factory.addField(meta_IntegerType, "_is_signed", meta_bool, IntegerType.get__is_signed_offset());
    meta_FloatingPointType.inheritsFrom(meta_NumericType);
    
    meta_EnumeratedType.inheritsFrom(meta_IntegerType);
    
    _object_factory.addField(meta_EnumeratedType, "_case", meta_LString_IInteger_indexed_list, EnumeratedType.get__case_offset());
    meta_PointerType.inheritsFrom(meta_DataType);
    
    _object_factory.addField(meta_PointerType, "_reference_type", meta_Type_ref, PointerType.get__reference_type_offset());
    meta_ReferenceType.inheritsFrom(meta_DataType);
    
    _object_factory.addField(meta_ReferenceType, "_reference_type", meta_Type_ref, ReferenceType.get__reference_type_offset());
    meta_ArrayType.inheritsFrom(meta_DataType);
    
    _object_factory.addField(meta_ArrayType, "_element_type", meta_QualifiedType_ref, ArrayType.get__element_type_offset());
    _object_factory.addField(meta_ArrayType, "_lower_bound", meta_Expression_owner, ArrayType.get__lower_bound_offset());
    _object_factory.addField(meta_ArrayType, "_upper_bound", meta_Expression_owner, ArrayType.get__upper_bound_offset());
    meta_MultiDimArrayType.inheritsFrom(meta_DataType);
    
    _object_factory.addField(meta_MultiDimArrayType, "_element_type", meta_QualifiedType_ref, MultiDimArrayType.get__element_type_offset());
    _object_factory.addField(meta_MultiDimArrayType, "_lower_bounds", meta_Expression_owner_vector, MultiDimArrayType.get__lower_bounds_offset());
    _object_factory.addField(meta_MultiDimArrayType, "_upper_bounds", meta_Expression_owner_vector, MultiDimArrayType.get__upper_bounds_offset());
    meta_GroupType.inheritsFrom(meta_DataType);
    
    _object_factory.addField(meta_GroupType, "_is_complete", meta_bool, GroupType.get__is_complete_offset());
    _object_factory.addField(meta_GroupType, "_group_symbol_table", meta_GroupSymbolTable_owner, GroupType.get__group_symbol_table_offset());
    meta_StructType.inheritsFrom(meta_GroupType);
    
    meta_UnionType.inheritsFrom(meta_GroupType);
    
    AggregateMetaClass meta_ProcedureType =
       mcof.findAggregateMetaClass(ProcedureType.getClassName());
    
    meta_CProcedureType.inheritsFrom(meta_ProcedureType);
    
    _object_factory.addField(meta_CProcedureType, "_arguments", meta_QualifiedType_ref_vector, CProcedureType.get__arguments_offset());
    _object_factory.addField(meta_CProcedureType, "_result_type", meta_DataType_ref, CProcedureType.get__result_type_offset());
    _object_factory.addField(meta_CProcedureType, "_has_varargs", meta_bool, CProcedureType.get__has_varargs_offset());
    _object_factory.addField(meta_CProcedureType, "_arguments_known", meta_bool, CProcedureType.get__arguments_known_offset());
    _object_factory.addField(meta_CProcedureType, "_bit_alignment", meta_int, CProcedureType.get__bit_alignment_offset());
    meta_FieldSymbol.inheritsFrom(meta_VariableSymbol);
    
    _object_factory.addField(meta_FieldSymbol, "_bit_offset", meta_Expression_owner, FieldSymbol.get__bit_offset_offset());
    meta_NestingVariableSymbol.inheritsFrom(meta_VariableSymbol);
    
    _object_factory.addField(meta_NestingVariableSymbol, "_super_variable", meta_NestingVariableSymbol_ref, NestingVariableSymbol.get__super_variable_offset());
    _object_factory.addField(meta_NestingVariableSymbol, "_bit_offset", meta_Expression_owner, NestingVariableSymbol.get__bit_offset_offset());
    _object_factory.addField(meta_NestingVariableSymbol, "_child_variables", meta_NestingVariableSymbol_ref_list, NestingVariableSymbol.get__child_variables_offset());
    meta_EvalStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_EvalStatement, "_expressions", meta_Expression_owner_list, EvalStatement.get__expressions_offset());
    meta_EvalStatement.addVirtualField("source_ops","_expressions");
    meta_CallStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_CallStatement, "_destination", meta_VariableSymbol_ref, CallStatement.get__destination_offset());
    _object_factory.addField(meta_CallStatement, "_callee_address", meta_Expression_owner, CallStatement.get__callee_address_offset());
    _object_factory.addField(meta_CallStatement, "_arguments", meta_Expression_owner_vector, CallStatement.get__arguments_offset());
    meta_CallStatement.addVirtualField("destination_vars","_destination");
    meta_CallStatement.addVirtualField("source_ops","_callee_address;_arguments");
    meta_IfStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_IfStatement, "_condition", meta_Expression_owner, IfStatement.get__condition_offset());
    _object_factory.addField(meta_IfStatement, "_then_part", meta_Statement_owner, IfStatement.get__then_part_offset());
    _object_factory.addField(meta_IfStatement, "_else_part", meta_Statement_owner, IfStatement.get__else_part_offset());
    meta_IfStatement.addVirtualField("source_ops","_condition");
    meta_IfStatement.addVirtualField("child_statements","_then_part;_else_part");
    meta_WhileStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_WhileStatement, "_condition", meta_Expression_owner, WhileStatement.get__condition_offset());
    _object_factory.addField(meta_WhileStatement, "_body", meta_Statement_owner, WhileStatement.get__body_offset());
    _object_factory.addField(meta_WhileStatement, "_break_label", meta_CodeLabelSymbol_ref, WhileStatement.get__break_label_offset());
    _object_factory.addField(meta_WhileStatement, "_continue_label", meta_CodeLabelSymbol_ref, WhileStatement.get__continue_label_offset());
    meta_WhileStatement.addVirtualField("source_ops","_condition");
    meta_WhileStatement.addVirtualField("child_statements","_body");
    meta_WhileStatement.addVirtualField("defined_labels","_break_label;_continue_label");
    meta_DoWhileStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_DoWhileStatement, "_condition", meta_Expression_owner, DoWhileStatement.get__condition_offset());
    _object_factory.addField(meta_DoWhileStatement, "_body", meta_Statement_owner, DoWhileStatement.get__body_offset());
    _object_factory.addField(meta_DoWhileStatement, "_break_label", meta_CodeLabelSymbol_ref, DoWhileStatement.get__break_label_offset());
    _object_factory.addField(meta_DoWhileStatement, "_continue_label", meta_CodeLabelSymbol_ref, DoWhileStatement.get__continue_label_offset());
    meta_DoWhileStatement.addVirtualField("source_ops","_condition");
    meta_DoWhileStatement.addVirtualField("child_statements","_body");
    meta_DoWhileStatement.addVirtualField("defined_labels","_break_label;_continue_label");
    meta_ForStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_ForStatement, "_index", meta_VariableSymbol_ref, ForStatement.get__index_offset());
    _object_factory.addField(meta_ForStatement, "_lower_bound", meta_Expression_owner, ForStatement.get__lower_bound_offset());
    _object_factory.addField(meta_ForStatement, "_upper_bound", meta_Expression_owner, ForStatement.get__upper_bound_offset());
    _object_factory.addField(meta_ForStatement, "_step", meta_Expression_owner, ForStatement.get__step_offset());
    _object_factory.addField(meta_ForStatement, "_comparison_opcode", meta_LString, ForStatement.get__comparison_opcode_offset());
    _object_factory.addField(meta_ForStatement, "_body", meta_Statement_owner, ForStatement.get__body_offset());
    _object_factory.addField(meta_ForStatement, "_pre_pad", meta_Statement_owner, ForStatement.get__pre_pad_offset());
    _object_factory.addField(meta_ForStatement, "_break_label", meta_CodeLabelSymbol_ref, ForStatement.get__break_label_offset());
    _object_factory.addField(meta_ForStatement, "_continue_label", meta_CodeLabelSymbol_ref, ForStatement.get__continue_label_offset());
    meta_ForStatement.addVirtualField("source_ops","_lower_bound;_upper_bound;_step");
    meta_ForStatement.addVirtualField("child_statements","_body;_pre_pad");
    meta_ForStatement.addVirtualField("defined_labels","_break_label;_continue_label");
    meta_ScopeStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_ScopeStatement, "_body", meta_Statement_owner, ScopeStatement.get__body_offset());
    _object_factory.addField(meta_ScopeStatement, "_symbol_table", meta_SymbolTable_owner, ScopeStatement.get__symbol_table_offset());
    _object_factory.addField(meta_ScopeStatement, "_definition_block", meta_DefinitionBlock_owner, ScopeStatement.get__definition_block_offset());
    meta_ScopeStatement.addVirtualField("child_statements","_body");
    meta_VaStartStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_VaStartStatement, "_ap_address", meta_Expression_owner, VaStartStatement.get__ap_address_offset());
    _object_factory.addField(meta_VaStartStatement, "_parmn", meta_ParameterSymbol_ref, VaStartStatement.get__parmn_offset());
    meta_VaStartStatement.addVirtualField("source_ops","_ap_address");
    meta_VaStartOldStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_VaStartOldStatement, "_ap_address", meta_Expression_owner, VaStartOldStatement.get__ap_address_offset());
    meta_VaStartOldStatement.addVirtualField("source_ops","_ap_address");
    meta_VaEndStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_VaEndStatement, "_ap_address", meta_Expression_owner, VaEndStatement.get__ap_address_offset());
    meta_VaEndStatement.addVirtualField("source_ops","_ap_address");
    meta_StoreStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_StoreStatement, "_value", meta_Expression_owner, StoreStatement.get__value_offset());
    _object_factory.addField(meta_StoreStatement, "_destination_address", meta_Expression_owner, StoreStatement.get__destination_address_offset());
    meta_StoreStatement.addVirtualField("source_ops","_value;_destination_address");
    meta_StoreVariableStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_StoreVariableStatement, "_destination", meta_VariableSymbol_ref, StoreVariableStatement.get__destination_offset());
    _object_factory.addField(meta_StoreVariableStatement, "_value", meta_Expression_owner, StoreVariableStatement.get__value_offset());
    meta_StoreVariableStatement.addVirtualField("destination_vars","_destination");
    meta_StoreVariableStatement.addVirtualField("source_ops","_value");
    meta_ReturnStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_ReturnStatement, "_return_value", meta_Expression_owner, ReturnStatement.get__return_value_offset());
    meta_ReturnStatement.addVirtualField("source_ops","_return_value");
    meta_JumpStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_JumpStatement, "_target", meta_CodeLabelSymbol_ref, JumpStatement.get__target_offset());
    meta_JumpIndirectStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_JumpIndirectStatement, "_target", meta_Expression_owner, JumpIndirectStatement.get__target_offset());
    meta_JumpIndirectStatement.addVirtualField("source_ops","_target");
    meta_BranchStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_BranchStatement, "_decision_operand", meta_Expression_owner, BranchStatement.get__decision_operand_offset());
    _object_factory.addField(meta_BranchStatement, "_target", meta_CodeLabelSymbol_ref, BranchStatement.get__target_offset());
    meta_BranchStatement.addVirtualField("source_ops","_decision_operand");
    meta_MultiWayBranchStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_MultiWayBranchStatement, "_decision_operand", meta_Expression_owner, MultiWayBranchStatement.get__decision_operand_offset());
    _object_factory.addField(meta_MultiWayBranchStatement, "_default_target", meta_CodeLabelSymbol_ref, MultiWayBranchStatement.get__default_target_offset());
    _object_factory.addField(meta_MultiWayBranchStatement, "_case", meta_IInteger_CodeLabelSymbol_ref_indexed_list, MultiWayBranchStatement.get__case_offset());
    meta_MultiWayBranchStatement.addVirtualField("source_ops","_decision_operand");
    meta_LabelLocationStatement.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_LabelLocationStatement, "_defined_label", meta_CodeLabelSymbol_def, LabelLocationStatement.get__defined_label_offset());
    meta_LabelLocationStatement.addVirtualField("defined_labels","_defined_label");
    meta_MarkStatement.inheritsFrom(meta_Statement);
    
    meta_BinaryExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_BinaryExpression, "_opcode", meta_LString, BinaryExpression.get__opcode_offset());
    _object_factory.addField(meta_BinaryExpression, "_source1", meta_Expression_owner, BinaryExpression.get__source1_offset());
    _object_factory.addField(meta_BinaryExpression, "_source2", meta_Expression_owner, BinaryExpression.get__source2_offset());
    meta_BinaryExpression.addVirtualField("source_ops","_source1;_source2");
    meta_UnaryExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_UnaryExpression, "_opcode", meta_LString, UnaryExpression.get__opcode_offset());
    _object_factory.addField(meta_UnaryExpression, "_source", meta_Expression_owner, UnaryExpression.get__source_offset());
    meta_UnaryExpression.addVirtualField("source_ops","_source");
    meta_SelectExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_SelectExpression, "_selector", meta_Expression_owner, SelectExpression.get__selector_offset());
    _object_factory.addField(meta_SelectExpression, "_selection1", meta_Expression_owner, SelectExpression.get__selection1_offset());
    _object_factory.addField(meta_SelectExpression, "_selection2", meta_Expression_owner, SelectExpression.get__selection2_offset());
    meta_SelectExpression.addVirtualField("source_ops","_selector;_selection1;_selection2");
    meta_MultiDimArrayExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_MultiDimArrayExpression, "_array_address", meta_Expression_owner, MultiDimArrayExpression.get__array_address_offset());
    _object_factory.addField(meta_MultiDimArrayExpression, "_offset", meta_Expression_owner, MultiDimArrayExpression.get__offset_offset());
    _object_factory.addField(meta_MultiDimArrayExpression, "_index", meta_Expression_owner_vector, MultiDimArrayExpression.get__index_offset());
    _object_factory.addField(meta_MultiDimArrayExpression, "_elements", meta_Expression_owner_vector, MultiDimArrayExpression.get__elements_offset());
    meta_MultiDimArrayExpression.addVirtualField("source_ops","_array_address;_offset;_index;_elements");
    meta_ArrayReferenceExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_ArrayReferenceExpression, "_base_array_address", meta_Expression_owner, ArrayReferenceExpression.get__base_array_address_offset());
    _object_factory.addField(meta_ArrayReferenceExpression, "_index", meta_Expression_owner, ArrayReferenceExpression.get__index_offset());
    meta_ArrayReferenceExpression.addVirtualField("source_ops","_base_array_address;_index");
    meta_FieldAccessExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_FieldAccessExpression, "_base_group_address", meta_Expression_owner, FieldAccessExpression.get__base_group_address_offset());
    _object_factory.addField(meta_FieldAccessExpression, "_field", meta_FieldSymbol_ref, FieldAccessExpression.get__field_offset());
    meta_FieldAccessExpression.addVirtualField("source_ops","_base_group_address");
    meta_VaArgExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_VaArgExpression, "_ap_address", meta_Expression_owner, VaArgExpression.get__ap_address_offset());
    meta_VaArgExpression.addVirtualField("source_ops","_ap_address");
    meta_LoadExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_LoadExpression, "_source_address", meta_Expression_owner, LoadExpression.get__source_address_offset());
    meta_LoadExpression.addVirtualField("source_ops","_source_address");
    meta_LoadVariableExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_LoadVariableExpression, "_source", meta_VariableSymbol_ref, LoadVariableExpression.get__source_offset());
    meta_LoadVariableExpression.addVirtualField("source_vars","_source");
    meta_SymbolAddressExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_SymbolAddressExpression, "_addressed_symbol", meta_Symbol_ref, SymbolAddressExpression.get__addressed_symbol_offset());
    meta_LoadValueBlockExpression.inheritsFrom(meta_Expression);
    
    _object_factory.addField(meta_LoadValueBlockExpression, "_value_block", meta_ValueBlock_owner, LoadValueBlockExpression.get__value_block_offset());
    meta_ExpressionValueBlock.inheritsFrom(meta_ValueBlock);
    
    _object_factory.addField(meta_ExpressionValueBlock, "_expression", meta_Expression_owner, ExpressionValueBlock.get__expression_offset());
    meta_ExpressionValueBlock.addVirtualField("source_ops","_expression");
    meta_MultiValueBlock.inheritsFrom(meta_ValueBlock);
    
    _object_factory.addField(meta_MultiValueBlock, "_sub_blocks", meta_IInteger_ValueBlock_owner_indexed_list, MultiValueBlock.get__sub_blocks_offset());
    _object_factory.addField(meta_MultiValueBlock, "_type", meta_DataType_ref, MultiValueBlock.get__type_offset());
    meta_RepeatValueBlock.inheritsFrom(meta_ValueBlock);
    
    _object_factory.addField(meta_RepeatValueBlock, "_num_repetitions", meta_int, RepeatValueBlock.get__num_repetitions_offset());
    _object_factory.addField(meta_RepeatValueBlock, "_sub_block", meta_ValueBlock_owner, RepeatValueBlock.get__sub_block_offset());
    _object_factory.addField(meta_RepeatValueBlock, "_type", meta_DataType_ref, RepeatValueBlock.get__type_offset());
    meta_UndefinedValueBlock.inheritsFrom(meta_ValueBlock);
    
    _object_factory.addField(meta_UndefinedValueBlock, "_type", meta_DataType_ref, UndefinedValueBlock.get__type_offset());
    AggregateMetaClass meta_BasicSymbolTable =
       mcof.findAggregateMetaClass(BasicSymbolTable.getClassName());
    
    meta_GroupSymbolTable.inheritsFrom(meta_BasicSymbolTable);
    
    AggregateMetaClass meta_GlobalInformationBlock =
       mcof.findAggregateMetaClass(GlobalInformationBlock.getClassName());
    
    meta_TargetInformationBlock.inheritsFrom(meta_GlobalInformationBlock);
    
    _object_factory.addField(meta_TargetInformationBlock, "_integer_types", meta_IntegerType_ref_list, TargetInformationBlock.get__integer_types_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_floating_point_types", meta_FloatingPointType_ref_list, TargetInformationBlock.get__floating_point_types_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_size_calculation_rule", meta_LString, TargetInformationBlock.get__pointer_size_calculation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_alignment_calculation_rule", meta_LString, TargetInformationBlock.get__pointer_alignment_calculation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_array_alignment_calculation_rule", meta_LString, TargetInformationBlock.get__array_alignment_calculation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_group_alignment_calculation_rule", meta_LString, TargetInformationBlock.get__group_alignment_calculation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_procedure_alignment_calculation_rule", meta_LString, TargetInformationBlock.get__procedure_alignment_calculation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_integer_representation_rule", meta_LString, TargetInformationBlock.get__integer_representation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_floating_point_representation_rule", meta_LString, TargetInformationBlock.get__floating_point_representation_rule_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_is_big_endian", meta_bool, TargetInformationBlock.get__is_big_endian_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_byte_size", meta_IInteger, TargetInformationBlock.get__byte_size_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_word_type", meta_IntegerType_ref, TargetInformationBlock.get__word_type_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_default_boolean_type", meta_BooleanType_ref, TargetInformationBlock.get__default_boolean_type_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_default_void_type", meta_VoidType_ref, TargetInformationBlock.get__default_void_type_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_size_fixed", meta_bool, TargetInformationBlock.get__pointer_size_fixed_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_size", meta_IInteger, TargetInformationBlock.get__pointer_size_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_alignment_fixed", meta_bool, TargetInformationBlock.get__pointer_alignment_fixed_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_pointer_alignment", meta_int, TargetInformationBlock.get__pointer_alignment_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_array_alignment_calculation_is_standard", meta_bool, TargetInformationBlock.get__array_alignment_calculation_is_standard_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_array_alignment_minimum", meta_int, TargetInformationBlock.get__array_alignment_minimum_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_group_alignment_calculation_is_standard", meta_bool, TargetInformationBlock.get__group_alignment_calculation_is_standard_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_group_alignment_minimum", meta_int, TargetInformationBlock.get__group_alignment_minimum_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_procedure_alignment_fixed", meta_bool, TargetInformationBlock.get__procedure_alignment_fixed_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_procedure_alignment", meta_int, TargetInformationBlock.get__procedure_alignment_offset());
    _object_factory.addField(meta_TargetInformationBlock, "_integer_representation_is_twos_complement", meta_bool, TargetInformationBlock.get__integer_representation_is_twos_complement_offset());
    meta_CInformationBlock.inheritsFrom(meta_GlobalInformationBlock);
    
    _object_factory.addField(meta_CInformationBlock, "_va_start_builtin", meta_LString, CInformationBlock.get__va_start_builtin_offset());
    _object_factory.addField(meta_CInformationBlock, "_va_start_old_builtin", meta_LString, CInformationBlock.get__va_start_old_builtin_offset());
    _object_factory.addField(meta_CInformationBlock, "_va_arg_builtin", meta_LString, CInformationBlock.get__va_arg_builtin_offset());
    _object_factory.addField(meta_CInformationBlock, "_va_end_builtin", meta_LString, CInformationBlock.get__va_end_builtin_offset());
    _object_factory.addField(meta_CInformationBlock, "_signed_char_type", meta_IntegerType_ref, CInformationBlock.get__signed_char_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_unsigned_char_type", meta_IntegerType_ref, CInformationBlock.get__unsigned_char_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_char_type", meta_IntegerType_ref, CInformationBlock.get__char_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_signed_short_type", meta_IntegerType_ref, CInformationBlock.get__signed_short_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_unsigned_short_type", meta_IntegerType_ref, CInformationBlock.get__unsigned_short_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_signed_int_type", meta_IntegerType_ref, CInformationBlock.get__signed_int_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_unsigned_int_type", meta_IntegerType_ref, CInformationBlock.get__unsigned_int_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_signed_long_type", meta_IntegerType_ref, CInformationBlock.get__signed_long_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_unsigned_long_type", meta_IntegerType_ref, CInformationBlock.get__unsigned_long_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_signed_long_long_type", meta_IntegerType_ref, CInformationBlock.get__signed_long_long_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_unsigned_long_long_type", meta_IntegerType_ref, CInformationBlock.get__unsigned_long_long_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_float_type", meta_FloatingPointType_ref, CInformationBlock.get__float_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_double_type", meta_FloatingPointType_ref, CInformationBlock.get__double_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_long_double_type", meta_FloatingPointType_ref, CInformationBlock.get__long_double_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_file_type", meta_Type_ref, CInformationBlock.get__file_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_ptrdiff_t_type", meta_IntegerType_ref, CInformationBlock.get__ptrdiff_t_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_size_t_type", meta_IntegerType_ref, CInformationBlock.get__size_t_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_va_list_type", meta_Type_ref, CInformationBlock.get__va_list_type_offset());
    _object_factory.addField(meta_CInformationBlock, "_plain_bit_field_is_signed", meta_bool, CInformationBlock.get__plain_bit_field_is_signed_offset());
     
   } 
  
  private static native int get_indexed_list_LString_IInteger_size();
  private static native int get_vector_Expression_ptr_size();
  private static native int get_vector_QualifiedType_ptr_size();
  private static native int get_list_NestingVariableSymbol_ptr_size();
  private static native int get_list_Expression_ptr_size();
  private static native int get_indexed_list_IInteger_CodeLabelSymbol_ptr_size();
  private static native int get_indexed_list_IInteger_ValueBlock_ptr_size();
  private static native int get_list_IntegerType_ptr_size();
  private static native int get_list_FloatingPointType_ptr_size();
  
  
  public static void addCompatibleNames() 
   {  
    CompatibleNames.addCompatibleName("case_pair", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("sub_block_pair", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_LString_IInteger", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_LString_IInteger_type", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_IInteger_CodeLabelSymbol_ref", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_IInteger_CodeLabelSymbol_ref_type", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_IInteger_ValueBlock_owner", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_IInteger_ValueBlock_owner_type", "IndexedList$Pair");
     
   } 
  
  public VoidType createVoidType(IInteger bit_size, int bit_alignment, String name) 
   {  
    VoidType obj =
      (VoidType) _object_factory.createEmptyObjectByName(VoidType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static VoidType createVoidType(SuifEnv env, IInteger bit_size, int bit_alignment, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVoidType(bit_size, bit_alignment, name ); 
   } 
  
  public NumericType createNumericType(IInteger bit_size, int bit_alignment, String name) 
   {  
    NumericType obj =
      (NumericType) _object_factory.createEmptyObjectByName(NumericType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static NumericType createNumericType(SuifEnv env, IInteger bit_size, int bit_alignment, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createNumericType(bit_size, bit_alignment, name ); 
   } 
  
  public BooleanType createBooleanType(IInteger bit_size, int bit_alignment, String name) 
   {  
    BooleanType obj =
      (BooleanType) _object_factory.createEmptyObjectByName(BooleanType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static BooleanType createBooleanType(SuifEnv env, IInteger bit_size, int bit_alignment, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createBooleanType(bit_size, bit_alignment, name ); 
   } 
  
  public IntegerType createIntegerType(IInteger bit_size, int bit_alignment, boolean is_signed, String name) 
   {  
    IntegerType obj =
      (IntegerType) _object_factory.createEmptyObjectByName(IntegerType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setIsSigned(is_signed);
     return obj; 
   } 
  
  public static IntegerType createIntegerType(SuifEnv env, IInteger bit_size, int bit_alignment, boolean is_signed, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createIntegerType(bit_size, bit_alignment, is_signed, name ); 
   } 
  
  public FloatingPointType createFloatingPointType(IInteger bit_size, int bit_alignment, String name) 
   {  
    FloatingPointType obj =
      (FloatingPointType) _object_factory.createEmptyObjectByName(FloatingPointType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static FloatingPointType createFloatingPointType(SuifEnv env, IInteger bit_size, int bit_alignment, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFloatingPointType(bit_size, bit_alignment, name ); 
   } 
  
  public EnumeratedType createEnumeratedType(IInteger bit_size, int bit_alignment, boolean is_signed, String name) 
   {  
    EnumeratedType obj =
      (EnumeratedType) _object_factory.createEmptyObjectByName(EnumeratedType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setIsSigned(is_signed);
     return obj; 
   } 
  
  public static EnumeratedType createEnumeratedType(SuifEnv env, IInteger bit_size, int bit_alignment, boolean is_signed, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createEnumeratedType(bit_size, bit_alignment, is_signed, name ); 
   } 
  
  public PointerType createPointerType(IInteger bit_size, int bit_alignment, Type reference_type, String name) 
   {  
    PointerType obj =
      (PointerType) _object_factory.createEmptyObjectByName(PointerType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setReferenceType(reference_type);
     return obj; 
   } 
  
  public static PointerType createPointerType(SuifEnv env, IInteger bit_size, int bit_alignment, Type reference_type, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createPointerType(bit_size, bit_alignment, reference_type, name ); 
   } 
  
  public ReferenceType createReferenceType(IInteger bit_size, int bit_alignment, Type reference_type, String name) 
   {  
    ReferenceType obj =
      (ReferenceType) _object_factory.createEmptyObjectByName(ReferenceType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setReferenceType(reference_type);
     return obj; 
   } 
  
  public static ReferenceType createReferenceType(SuifEnv env, IInteger bit_size, int bit_alignment, Type reference_type, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createReferenceType(bit_size, bit_alignment, reference_type, name ); 
   } 
  
  public ArrayType createArrayType(IInteger bit_size, int bit_alignment, QualifiedType element_type, Expression lower_bound, Expression upper_bound, String name) 
   {  
    ArrayType obj =
      (ArrayType) _object_factory.createEmptyObjectByName(ArrayType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setElementType(element_type);
    obj.setLowerBound(lower_bound);
    obj.setUpperBound(upper_bound);
     return obj; 
   } 
  
  public static ArrayType createArrayType(SuifEnv env, IInteger bit_size, int bit_alignment, QualifiedType element_type, Expression lower_bound, Expression upper_bound, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createArrayType(bit_size, bit_alignment, element_type, lower_bound, upper_bound, name ); 
   } 
  
  public MultiDimArrayType createMultiDimArrayType(IInteger bit_size, int bit_alignment, QualifiedType element_type, String name) 
   {  
    MultiDimArrayType obj =
      (MultiDimArrayType) _object_factory.createEmptyObjectByName(MultiDimArrayType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setElementType(element_type);
     return obj; 
   } 
  
  public static MultiDimArrayType createMultiDimArrayType(SuifEnv env, IInteger bit_size, int bit_alignment, QualifiedType element_type, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createMultiDimArrayType(bit_size, bit_alignment, element_type, name ); 
   } 
  
  public GroupType createGroupType(IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    GroupType obj =
      (GroupType) _object_factory.createEmptyObjectByName(GroupType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setIsComplete(is_complete);
    obj.setGroupSymbolTable(group_symbol_table);
     return obj; 
   } 
  
  public static GroupType createGroupType(SuifEnv env, IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createGroupType(bit_size, bit_alignment, name , is_complete , group_symbol_table ); 
   } 
  
  public StructType createStructType(IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    StructType obj =
      (StructType) _object_factory.createEmptyObjectByName(StructType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setIsComplete(is_complete);
    obj.setGroupSymbolTable(group_symbol_table);
     return obj; 
   } 
  
  public static StructType createStructType(SuifEnv env, IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStructType(bit_size, bit_alignment, name , is_complete , group_symbol_table ); 
   } 
  
  public UnionType createUnionType(IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    UnionType obj =
      (UnionType) _object_factory.createEmptyObjectByName(UnionType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
    obj.setIsComplete(is_complete);
    obj.setGroupSymbolTable(group_symbol_table);
     return obj; 
   } 
  
  public static UnionType createUnionType(SuifEnv env, IInteger bit_size, int bit_alignment, String name, boolean is_complete, GroupSymbolTable group_symbol_table) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createUnionType(bit_size, bit_alignment, name , is_complete , group_symbol_table ); 
   } 
  
  public CProcedureType createCProcedureType(DataType result_type, boolean has_varargs, boolean arguments_known, int bit_alignment, String name) 
   {  
    CProcedureType obj =
      (CProcedureType) _object_factory.createEmptyObjectByName(CProcedureType.getClassName());
    obj.setName(name);
    obj.setResultType(result_type);
    obj.setHasVarargs(has_varargs);
    obj.setArgumentsKnown(arguments_known);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static CProcedureType createCProcedureType(SuifEnv env, DataType result_type, boolean has_varargs, boolean arguments_known, int bit_alignment, String name) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createCProcedureType(result_type, has_varargs, arguments_known, bit_alignment, name ); 
   } 
  
  public FieldSymbol createFieldSymbol(QualifiedType type, Expression bit_offset, String name, boolean is_address_taken) 
   {  
    FieldSymbol obj =
      (FieldSymbol) _object_factory.createEmptyObjectByName(FieldSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
    obj.setDefinition(null);
    obj.setBitOffset(bit_offset);
     return obj; 
   } 
  
  public static FieldSymbol createFieldSymbol(SuifEnv env, QualifiedType type, Expression bit_offset, String name, boolean is_address_taken) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFieldSymbol(type, bit_offset, name , is_address_taken ); 
   } 
  
  public NestingVariableSymbol createNestingVariableSymbol(QualifiedType type, NestingVariableSymbol super_variable, Expression bit_offset, String name, boolean is_address_taken) 
   {  
    NestingVariableSymbol obj =
      (NestingVariableSymbol) _object_factory.createEmptyObjectByName(NestingVariableSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
    obj.setDefinition(null);
    obj.setSuperVariable(super_variable);
    obj.setBitOffset(bit_offset);
     return obj; 
   } 
  
  public static NestingVariableSymbol createNestingVariableSymbol(SuifEnv env, QualifiedType type, NestingVariableSymbol super_variable, Expression bit_offset, String name, boolean is_address_taken) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createNestingVariableSymbol(type, super_variable, bit_offset, name , is_address_taken ); 
   } 
  
  public EvalStatement createEvalStatement() 
   {  
    EvalStatement obj =
      (EvalStatement) _object_factory.createEmptyObjectByName(EvalStatement.getClassName());
     return obj; 
   } 
  
  public static EvalStatement createEvalStatement(SuifEnv env) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createEvalStatement(); 
   } 
  
  public CallStatement createCallStatement(VariableSymbol destination, Expression callee_address) 
   {  
    CallStatement obj =
      (CallStatement) _object_factory.createEmptyObjectByName(CallStatement.getClassName());
    obj.setDestination(destination);
    obj.setCalleeAddress(callee_address);
     return obj; 
   } 
  
  public static CallStatement createCallStatement(SuifEnv env, VariableSymbol destination, Expression callee_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createCallStatement(destination, callee_address); 
   } 
  
  public IfStatement createIfStatement(Expression condition, Statement then_part, Statement else_part) 
   {  
    IfStatement obj =
      (IfStatement) _object_factory.createEmptyObjectByName(IfStatement.getClassName());
    obj.setCondition(condition);
    obj.setThenPart(then_part);
    obj.setElsePart(else_part);
     return obj; 
   } 
  
  public static IfStatement createIfStatement(SuifEnv env, Expression condition, Statement then_part, Statement else_part) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createIfStatement(condition, then_part, else_part ); 
   } 
  
  public WhileStatement createWhileStatement(Expression condition, Statement body, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    WhileStatement obj =
      (WhileStatement) _object_factory.createEmptyObjectByName(WhileStatement.getClassName());
    obj.setCondition(condition);
    obj.setBody(body);
    obj.setBreakLabel(break_label);
    obj.setContinueLabel(continue_label);
     return obj; 
   } 
  
  public static WhileStatement createWhileStatement(SuifEnv env, Expression condition, Statement body, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createWhileStatement(condition, body, break_label , continue_label ); 
   } 
  
  public DoWhileStatement createDoWhileStatement(Expression condition, Statement body, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    DoWhileStatement obj =
      (DoWhileStatement) _object_factory.createEmptyObjectByName(DoWhileStatement.getClassName());
    obj.setCondition(condition);
    obj.setBody(body);
    obj.setBreakLabel(break_label);
    obj.setContinueLabel(continue_label);
     return obj; 
   } 
  
  public static DoWhileStatement createDoWhileStatement(SuifEnv env, Expression condition, Statement body, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createDoWhileStatement(condition, body, break_label , continue_label ); 
   } 
  
  public ForStatement createForStatement(VariableSymbol index, Expression lower_bound, Expression upper_bound, Expression step, String comparison_opcode, Statement body, Statement pre_pad, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    ForStatement obj =
      (ForStatement) _object_factory.createEmptyObjectByName(ForStatement.getClassName());
    obj.setIndex(index);
    obj.setLowerBound(lower_bound);
    obj.setUpperBound(upper_bound);
    obj.setStep(step);
    obj.setComparisonOpcode(comparison_opcode);
    obj.setBody(body);
    obj.setPrePad(pre_pad);
    obj.setBreakLabel(break_label);
    obj.setContinueLabel(continue_label);
     return obj; 
   } 
  
  public static ForStatement createForStatement(SuifEnv env, VariableSymbol index, Expression lower_bound, Expression upper_bound, Expression step, String comparison_opcode, Statement body, Statement pre_pad, CodeLabelSymbol break_label, CodeLabelSymbol continue_label) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createForStatement(index, lower_bound, upper_bound, step, comparison_opcode, body, pre_pad , break_label , continue_label ); 
   } 
  
  public ScopeStatement createScopeStatement(Statement body, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    ScopeStatement obj =
      (ScopeStatement) _object_factory.createEmptyObjectByName(ScopeStatement.getClassName());
    obj.setBody(body);
    obj.setSymbolTable(symbol_table);
    obj.setDefinitionBlock(definition_block);
     return obj; 
   } 
  
  public static ScopeStatement createScopeStatement(SuifEnv env, Statement body, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createScopeStatement(body , symbol_table , definition_block ); 
   } 
  
  public VaStartStatement createVaStartStatement(Expression ap_address, ParameterSymbol parmn) 
   {  
    VaStartStatement obj =
      (VaStartStatement) _object_factory.createEmptyObjectByName(VaStartStatement.getClassName());
    obj.setApAddress(ap_address);
    obj.setParmn(parmn);
     return obj; 
   } 
  
  public static VaStartStatement createVaStartStatement(SuifEnv env, Expression ap_address, ParameterSymbol parmn) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVaStartStatement(ap_address, parmn); 
   } 
  
  public VaStartOldStatement createVaStartOldStatement(Expression ap_address) 
   {  
    VaStartOldStatement obj =
      (VaStartOldStatement) _object_factory.createEmptyObjectByName(VaStartOldStatement.getClassName());
    obj.setApAddress(ap_address);
     return obj; 
   } 
  
  public static VaStartOldStatement createVaStartOldStatement(SuifEnv env, Expression ap_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVaStartOldStatement(ap_address); 
   } 
  
  public VaEndStatement createVaEndStatement(Expression ap_address) 
   {  
    VaEndStatement obj =
      (VaEndStatement) _object_factory.createEmptyObjectByName(VaEndStatement.getClassName());
    obj.setApAddress(ap_address);
     return obj; 
   } 
  
  public static VaEndStatement createVaEndStatement(SuifEnv env, Expression ap_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVaEndStatement(ap_address); 
   } 
  
  public StoreStatement createStoreStatement(Expression value, Expression destination_address) 
   {  
    StoreStatement obj =
      (StoreStatement) _object_factory.createEmptyObjectByName(StoreStatement.getClassName());
    obj.setValue(value);
    obj.setDestinationAddress(destination_address);
     return obj; 
   } 
  
  public static StoreStatement createStoreStatement(SuifEnv env, Expression value, Expression destination_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStoreStatement(value, destination_address); 
   } 
  
  public StoreVariableStatement createStoreVariableStatement(VariableSymbol destination, Expression value) 
   {  
    StoreVariableStatement obj =
      (StoreVariableStatement) _object_factory.createEmptyObjectByName(StoreVariableStatement.getClassName());
    obj.setDestination(destination);
    obj.setValue(value);
     return obj; 
   } 
  
  public static StoreVariableStatement createStoreVariableStatement(SuifEnv env, VariableSymbol destination, Expression value) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStoreVariableStatement(destination, value); 
   } 
  
  public ReturnStatement createReturnStatement(Expression return_value) 
   {  
    ReturnStatement obj =
      (ReturnStatement) _object_factory.createEmptyObjectByName(ReturnStatement.getClassName());
    obj.setReturnValue(return_value);
     return obj; 
   } 
  
  public static ReturnStatement createReturnStatement(SuifEnv env, Expression return_value) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createReturnStatement(return_value); 
   } 
  
  public JumpStatement createJumpStatement(CodeLabelSymbol target) 
   {  
    JumpStatement obj =
      (JumpStatement) _object_factory.createEmptyObjectByName(JumpStatement.getClassName());
    obj.setTarget(target);
     return obj; 
   } 
  
  public static JumpStatement createJumpStatement(SuifEnv env, CodeLabelSymbol target) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createJumpStatement(target); 
   } 
  
  public JumpIndirectStatement createJumpIndirectStatement(Expression target) 
   {  
    JumpIndirectStatement obj =
      (JumpIndirectStatement) _object_factory.createEmptyObjectByName(JumpIndirectStatement.getClassName());
    obj.setTarget(target);
     return obj; 
   } 
  
  public static JumpIndirectStatement createJumpIndirectStatement(SuifEnv env, Expression target) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createJumpIndirectStatement(target); 
   } 
  
  public BranchStatement createBranchStatement(Expression decision_operand, CodeLabelSymbol target) 
   {  
    BranchStatement obj =
      (BranchStatement) _object_factory.createEmptyObjectByName(BranchStatement.getClassName());
    obj.setDecisionOperand(decision_operand);
    obj.setTarget(target);
     return obj; 
   } 
  
  public static BranchStatement createBranchStatement(SuifEnv env, Expression decision_operand, CodeLabelSymbol target) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createBranchStatement(decision_operand, target); 
   } 
  
  public MultiWayBranchStatement createMultiWayBranchStatement(Expression decision_operand, CodeLabelSymbol default_target) 
   {  
    MultiWayBranchStatement obj =
      (MultiWayBranchStatement) _object_factory.createEmptyObjectByName(MultiWayBranchStatement.getClassName());
    obj.setDecisionOperand(decision_operand);
    obj.setDefaultTarget(default_target);
     return obj; 
   } 
  
  public static MultiWayBranchStatement createMultiWayBranchStatement(SuifEnv env, Expression decision_operand, CodeLabelSymbol default_target) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createMultiWayBranchStatement(decision_operand, default_target); 
   } 
  
  public LabelLocationStatement createLabelLocationStatement(CodeLabelSymbol defined_label) 
   {  
    LabelLocationStatement obj =
      (LabelLocationStatement) _object_factory.createEmptyObjectByName(LabelLocationStatement.getClassName());
    obj.setDefinedLabel(defined_label);
     return obj; 
   } 
  
  public static LabelLocationStatement createLabelLocationStatement(SuifEnv env, CodeLabelSymbol defined_label) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createLabelLocationStatement(defined_label); 
   } 
  
  public MarkStatement createMarkStatement() 
   {  
    MarkStatement obj =
      (MarkStatement) _object_factory.createEmptyObjectByName(MarkStatement.getClassName());
     return obj; 
   } 
  
  public static MarkStatement createMarkStatement(SuifEnv env) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createMarkStatement(); 
   } 
  
  public BinaryExpression createBinaryExpression(DataType result_type, String opcode, Expression source1, Expression source2) 
   {  
    BinaryExpression obj =
      (BinaryExpression) _object_factory.createEmptyObjectByName(BinaryExpression.getClassName());
    obj.setResultType(result_type);
    obj.setOpcode(opcode);
    obj.setSource1(source1);
    obj.setSource2(source2);
     return obj; 
   } 
  
  public static BinaryExpression createBinaryExpression(SuifEnv env, DataType result_type, String opcode, Expression source1, Expression source2) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createBinaryExpression(result_type, opcode, source1, source2); 
   } 
  
  public UnaryExpression createUnaryExpression(DataType result_type, String opcode, Expression source) 
   {  
    UnaryExpression obj =
      (UnaryExpression) _object_factory.createEmptyObjectByName(UnaryExpression.getClassName());
    obj.setResultType(result_type);
    obj.setOpcode(opcode);
    obj.setSource(source);
     return obj; 
   } 
  
  public static UnaryExpression createUnaryExpression(SuifEnv env, DataType result_type, String opcode, Expression source) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createUnaryExpression(result_type, opcode, source); 
   } 
  
  public SelectExpression createSelectExpression(DataType result_type, Expression selector, Expression selection1, Expression selection2) 
   {  
    SelectExpression obj =
      (SelectExpression) _object_factory.createEmptyObjectByName(SelectExpression.getClassName());
    obj.setResultType(result_type);
    obj.setSelector(selector);
    obj.setSelection1(selection1);
    obj.setSelection2(selection2);
     return obj; 
   } 
  
  public static SelectExpression createSelectExpression(SuifEnv env, DataType result_type, Expression selector, Expression selection1, Expression selection2) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSelectExpression(result_type, selector, selection1, selection2); 
   } 
  
  public MultiDimArrayExpression createMultiDimArrayExpression(DataType result_type, Expression array_address, Expression offset) 
   {  
    MultiDimArrayExpression obj =
      (MultiDimArrayExpression) _object_factory.createEmptyObjectByName(MultiDimArrayExpression.getClassName());
    obj.setResultType(result_type);
    obj.setArrayAddress(array_address);
    obj.setOffset(offset);
     return obj; 
   } 
  
  public static MultiDimArrayExpression createMultiDimArrayExpression(SuifEnv env, DataType result_type, Expression array_address, Expression offset) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createMultiDimArrayExpression(result_type, array_address, offset); 
   } 
  
  public ArrayReferenceExpression createArrayReferenceExpression(DataType result_type, Expression base_array_address, Expression index) 
   {  
    ArrayReferenceExpression obj =
      (ArrayReferenceExpression) _object_factory.createEmptyObjectByName(ArrayReferenceExpression.getClassName());
    obj.setResultType(result_type);
    obj.setBaseArrayAddress(base_array_address);
    obj.setIndex(index);
     return obj; 
   } 
  
  public static ArrayReferenceExpression createArrayReferenceExpression(SuifEnv env, DataType result_type, Expression base_array_address, Expression index) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createArrayReferenceExpression(result_type, base_array_address, index); 
   } 
  
  public FieldAccessExpression createFieldAccessExpression(DataType result_type, Expression base_group_address, FieldSymbol field) 
   {  
    FieldAccessExpression obj =
      (FieldAccessExpression) _object_factory.createEmptyObjectByName(FieldAccessExpression.getClassName());
    obj.setResultType(result_type);
    obj.setBaseGroupAddress(base_group_address);
    obj.setField(field);
     return obj; 
   } 
  
  public static FieldAccessExpression createFieldAccessExpression(SuifEnv env, DataType result_type, Expression base_group_address, FieldSymbol field) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFieldAccessExpression(result_type, base_group_address, field); 
   } 
  
  public VaArgExpression createVaArgExpression(DataType result_type, Expression ap_address) 
   {  
    VaArgExpression obj =
      (VaArgExpression) _object_factory.createEmptyObjectByName(VaArgExpression.getClassName());
    obj.setResultType(result_type);
    obj.setApAddress(ap_address);
     return obj; 
   } 
  
  public static VaArgExpression createVaArgExpression(SuifEnv env, DataType result_type, Expression ap_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVaArgExpression(result_type, ap_address); 
   } 
  
  public LoadExpression createLoadExpression(DataType result_type, Expression source_address) 
   {  
    LoadExpression obj =
      (LoadExpression) _object_factory.createEmptyObjectByName(LoadExpression.getClassName());
    obj.setResultType(result_type);
    obj.setSourceAddress(source_address);
     return obj; 
   } 
  
  public static LoadExpression createLoadExpression(SuifEnv env, DataType result_type, Expression source_address) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createLoadExpression(result_type, source_address); 
   } 
  
  public LoadVariableExpression createLoadVariableExpression(DataType result_type, VariableSymbol source) 
   {  
    LoadVariableExpression obj =
      (LoadVariableExpression) _object_factory.createEmptyObjectByName(LoadVariableExpression.getClassName());
    obj.setResultType(result_type);
    obj.setSource(source);
     return obj; 
   } 
  
  public static LoadVariableExpression createLoadVariableExpression(SuifEnv env, DataType result_type, VariableSymbol source) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createLoadVariableExpression(result_type, source); 
   } 
  
  public SymbolAddressExpression createSymbolAddressExpression(DataType result_type, Symbol addressed_symbol) 
   {  
    SymbolAddressExpression obj =
      (SymbolAddressExpression) _object_factory.createEmptyObjectByName(SymbolAddressExpression.getClassName());
    obj.setResultType(result_type);
    obj.setAddressedSymbol(addressed_symbol);
     return obj; 
   } 
  
  public static SymbolAddressExpression createSymbolAddressExpression(SuifEnv env, DataType result_type, Symbol addressed_symbol) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSymbolAddressExpression(result_type, addressed_symbol); 
   } 
  
  public LoadValueBlockExpression createLoadValueBlockExpression(DataType result_type, ValueBlock value_block) 
   {  
    LoadValueBlockExpression obj =
      (LoadValueBlockExpression) _object_factory.createEmptyObjectByName(LoadValueBlockExpression.getClassName());
    obj.setResultType(result_type);
    obj.setValueBlock(value_block);
     return obj; 
   } 
  
  public static LoadValueBlockExpression createLoadValueBlockExpression(SuifEnv env, DataType result_type, ValueBlock value_block) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createLoadValueBlockExpression(result_type, value_block); 
   } 
  
  public ExpressionValueBlock createExpressionValueBlock(Expression expression) 
   {  
    ExpressionValueBlock obj =
      (ExpressionValueBlock) _object_factory.createEmptyObjectByName(ExpressionValueBlock.getClassName());
    obj.setExpression(expression);
     return obj; 
   } 
  
  public static ExpressionValueBlock createExpressionValueBlock(SuifEnv env, Expression expression) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createExpressionValueBlock(expression); 
   } 
  
  public MultiValueBlock createMultiValueBlock(DataType type) 
   {  
    MultiValueBlock obj =
      (MultiValueBlock) _object_factory.createEmptyObjectByName(MultiValueBlock.getClassName());
    obj.setType(type);
     return obj; 
   } 
  
  public static MultiValueBlock createMultiValueBlock(SuifEnv env, DataType type) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createMultiValueBlock(type); 
   } 
  
  public RepeatValueBlock createRepeatValueBlock(int num_repetitions, ValueBlock sub_block, DataType type) 
   {  
    RepeatValueBlock obj =
      (RepeatValueBlock) _object_factory.createEmptyObjectByName(RepeatValueBlock.getClassName());
    obj.setNumRepetitions(num_repetitions);
    obj.setSubBlock(sub_block);
    obj.setType(type);
     return obj; 
   } 
  
  public static RepeatValueBlock createRepeatValueBlock(SuifEnv env, int num_repetitions, ValueBlock sub_block, DataType type) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createRepeatValueBlock(num_repetitions, sub_block, type); 
   } 
  
  public UndefinedValueBlock createUndefinedValueBlock(DataType type) 
   {  
    UndefinedValueBlock obj =
      (UndefinedValueBlock) _object_factory.createEmptyObjectByName(UndefinedValueBlock.getClassName());
    obj.setType(type);
     return obj; 
   } 
  
  public static UndefinedValueBlock createUndefinedValueBlock(SuifEnv env, DataType type) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createUndefinedValueBlock(type); 
   } 
  
  public GroupSymbolTable createGroupSymbolTable(SymbolTable explicit_super_scope) 
   {  
    GroupSymbolTable obj =
      (GroupSymbolTable) _object_factory.createEmptyObjectByName(GroupSymbolTable.getClassName());
    obj.setExplicitSuperScope(explicit_super_scope);
     return obj; 
   } 
  
  public static GroupSymbolTable createGroupSymbolTable(SuifEnv env, SymbolTable explicit_super_scope) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createGroupSymbolTable(explicit_super_scope ); 
   } 
  
  public TargetInformationBlock createTargetInformationBlock(String pointer_size_calculation_rule, String pointer_alignment_calculation_rule, String array_alignment_calculation_rule, String group_alignment_calculation_rule, String procedure_alignment_calculation_rule, String integer_representation_rule, String floating_point_representation_rule, boolean is_big_endian, IInteger byte_size, IntegerType word_type, BooleanType default_boolean_type, VoidType default_void_type, boolean pointer_size_fixed, IInteger pointer_size, boolean pointer_alignment_fixed, int pointer_alignment, boolean array_alignment_calculation_is_standard, int array_alignment_minimum, boolean group_alignment_calculation_is_standard, int group_alignment_minimum, boolean procedure_alignment_fixed, int procedure_alignment, boolean integer_representation_is_twos_complement) 
   {  
    TargetInformationBlock obj =
      (TargetInformationBlock) _object_factory.createEmptyObjectByName(TargetInformationBlock.getClassName());
    obj.setPointerSizeCalculationRule(pointer_size_calculation_rule);
    obj.setPointerAlignmentCalculationRule(pointer_alignment_calculation_rule);
    obj.setArrayAlignmentCalculationRule(array_alignment_calculation_rule);
    obj.setGroupAlignmentCalculationRule(group_alignment_calculation_rule);
    obj.setProcedureAlignmentCalculationRule(procedure_alignment_calculation_rule);
    obj.setIntegerRepresentationRule(integer_representation_rule);
    obj.setFloatingPointRepresentationRule(floating_point_representation_rule);
    obj.setIsBigEndian(is_big_endian);
    obj.setByteSize(byte_size);
    obj.setWordType(word_type);
    obj.setDefaultBooleanType(default_boolean_type);
    obj.setDefaultVoidType(default_void_type);
    obj.setPointerSizeFixed(pointer_size_fixed);
    obj.setPointerSize(pointer_size);
    obj.setPointerAlignmentFixed(pointer_alignment_fixed);
    obj.setPointerAlignment(pointer_alignment);
    obj.setArrayAlignmentCalculationIsStandard(array_alignment_calculation_is_standard);
    obj.setArrayAlignmentMinimum(array_alignment_minimum);
    obj.setGroupAlignmentCalculationIsStandard(group_alignment_calculation_is_standard);
    obj.setGroupAlignmentMinimum(group_alignment_minimum);
    obj.setProcedureAlignmentFixed(procedure_alignment_fixed);
    obj.setProcedureAlignment(procedure_alignment);
    obj.setIntegerRepresentationIsTwosComplement(integer_representation_is_twos_complement);
     return obj; 
   } 
  
  public static TargetInformationBlock createTargetInformationBlock(SuifEnv env, String pointer_size_calculation_rule, String pointer_alignment_calculation_rule, String array_alignment_calculation_rule, String group_alignment_calculation_rule, String procedure_alignment_calculation_rule, String integer_representation_rule, String floating_point_representation_rule, boolean is_big_endian, IInteger byte_size, IntegerType word_type, BooleanType default_boolean_type, VoidType default_void_type, boolean pointer_size_fixed, IInteger pointer_size, boolean pointer_alignment_fixed, int pointer_alignment, boolean array_alignment_calculation_is_standard, int array_alignment_minimum, boolean group_alignment_calculation_is_standard, int group_alignment_minimum, boolean procedure_alignment_fixed, int procedure_alignment, boolean integer_representation_is_twos_complement) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createTargetInformationBlock(pointer_size_calculation_rule , pointer_alignment_calculation_rule , array_alignment_calculation_rule , group_alignment_calculation_rule , procedure_alignment_calculation_rule , integer_representation_rule , floating_point_representation_rule , is_big_endian , byte_size , word_type , default_boolean_type , default_void_type , pointer_size_fixed , pointer_size , pointer_alignment_fixed , pointer_alignment , array_alignment_calculation_is_standard , array_alignment_minimum , group_alignment_calculation_is_standard , group_alignment_minimum , procedure_alignment_fixed , procedure_alignment , integer_representation_is_twos_complement ); 
   } 
  
  public CInformationBlock createCInformationBlock(String va_start_builtin, String va_start_old_builtin, String va_arg_builtin, String va_end_builtin, IntegerType signed_char_type, IntegerType unsigned_char_type, IntegerType char_type, IntegerType signed_short_type, IntegerType unsigned_short_type, IntegerType signed_int_type, IntegerType unsigned_int_type, IntegerType signed_long_type, IntegerType unsigned_long_type, IntegerType signed_long_long_type, IntegerType unsigned_long_long_type, FloatingPointType float_type, FloatingPointType double_type, FloatingPointType long_double_type, Type file_type, IntegerType ptrdiff_t_type, IntegerType size_t_type, Type va_list_type, boolean plain_bit_field_is_signed) 
   {  
    CInformationBlock obj =
      (CInformationBlock) _object_factory.createEmptyObjectByName(CInformationBlock.getClassName());
    obj.setVaStartBuiltin(va_start_builtin);
    obj.setVaStartOldBuiltin(va_start_old_builtin);
    obj.setVaArgBuiltin(va_arg_builtin);
    obj.setVaEndBuiltin(va_end_builtin);
    obj.setSignedCharType(signed_char_type);
    obj.setUnsignedCharType(unsigned_char_type);
    obj.setCharType(char_type);
    obj.setSignedShortType(signed_short_type);
    obj.setUnsignedShortType(unsigned_short_type);
    obj.setSignedIntType(signed_int_type);
    obj.setUnsignedIntType(unsigned_int_type);
    obj.setSignedLongType(signed_long_type);
    obj.setUnsignedLongType(unsigned_long_type);
    obj.setSignedLongLongType(signed_long_long_type);
    obj.setUnsignedLongLongType(unsigned_long_long_type);
    obj.setFloatType(float_type);
    obj.setDoubleType(double_type);
    obj.setLongDoubleType(long_double_type);
    obj.setFileType(file_type);
    obj.setPtrdiffTType(ptrdiff_t_type);
    obj.setSizeTType(size_t_type);
    obj.setVaListType(va_list_type);
    obj.setPlainBitFieldIsSigned(plain_bit_field_is_signed);
     return obj; 
   } 
  
  public static CInformationBlock createCInformationBlock(SuifEnv env, String va_start_builtin, String va_start_old_builtin, String va_arg_builtin, String va_end_builtin, IntegerType signed_char_type, IntegerType unsigned_char_type, IntegerType char_type, IntegerType signed_short_type, IntegerType unsigned_short_type, IntegerType signed_int_type, IntegerType unsigned_int_type, IntegerType signed_long_type, IntegerType unsigned_long_type, IntegerType signed_long_long_type, IntegerType unsigned_long_long_type, FloatingPointType float_type, FloatingPointType double_type, FloatingPointType long_double_type, Type file_type, IntegerType ptrdiff_t_type, IntegerType size_t_type, Type va_list_type, boolean plain_bit_field_is_signed) 
   {  
    SuifObjectFactory of =
      (SuifObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createCInformationBlock(va_start_builtin , va_start_old_builtin , va_arg_builtin , va_end_builtin , signed_char_type , unsigned_char_type , char_type , signed_short_type , unsigned_short_type , signed_int_type , unsigned_int_type , signed_long_type , unsigned_long_type , signed_long_long_type , unsigned_long_long_type , float_type , double_type , long_double_type , file_type , ptrdiff_t_type , size_t_type , va_list_type , plain_bit_field_is_signed ); 
   } 
  
   
 } 
class CasePair 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class SubBlockPair 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairLStringIInteger 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairLStringIIntegerType 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairIIntegerCodeLabelSymbolRef 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairIIntegerCodeLabelSymbolRefType 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairIIntegerValueBlockOwner 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairIIntegerValueBlockOwnerType 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
