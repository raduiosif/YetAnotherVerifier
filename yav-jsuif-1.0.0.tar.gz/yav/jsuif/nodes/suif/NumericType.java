package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class NumericType extends DataType
 {  
  
  
  public static native int get_size();
  
  private static String _className = "NumericType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{NumericType}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
