package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.nodes.basic.*; 


public class SuifModule extends Module
 {  
  public SuifModule(SuifEnv env)
   {  
    super(env, "suif"); 
   } 
  
  public void initialize()
   {  
    _suif_env.addObjectFactory(new SuifObjectFactory()); 
   } 
  
  public static void init(SuifEnv env)
   {  
    ModuleSubSystem mSubSystem = env.getModuleSubSystem();
    if (mSubSystem.retrieveModule("suif") == null) { 
      BasicModule.init(env);
      mSubSystem.registerModule(new SuifModule(env)); 
     } 
   } 
  
  public Object clone() { return this; } 
 } 

