package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class LoadExpression extends Expression
 {  
  public Expression _source_address;
  public static native int get__source_address_offset();
  
  public Expression getSourceAddress()
  {
    return _source_address;
  }
  
  public Expression setSourceAddress(Expression the_value) 
  {
    Expression old_value = _source_address;
    if (old_value != null) old_value.setParent(null);
    _source_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "LoadExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{LoadExpression}");
    text.startBlock(text.pointerHeader("_source_address", _source_address));
    if (_source_address != null)
      _source_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
