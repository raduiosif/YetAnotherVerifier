package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class CProcedureType extends ProcedureType
 {  
  public Vector _arguments = new Vector();
  public static native int get__arguments_offset();
  
  public DataType _result_type;
  public static native int get__result_type_offset();
  
  public DataType getResultType()
  {
    return _result_type;
  }
  
  public void setResultType(DataType the_value) 
  {
    _result_type = (DataType) the_value;
  }
  
  public boolean _has_varargs;
  public static native int get__has_varargs_offset();
  
  public boolean getHasVarargs()
  {
    return _has_varargs;
  }
  
  public void setHasVarargs(boolean the_value) 
  {
    _has_varargs = (boolean) the_value;
  }
  
  public boolean _arguments_known;
  public static native int get__arguments_known_offset();
  
  public boolean getArgumentsKnown()
  {
    return _arguments_known;
  }
  
  public void setArgumentsKnown(boolean the_value) 
  {
    _arguments_known = (boolean) the_value;
  }
  
  public int _bit_alignment;
  public static native int get__bit_alignment_offset();
  
  public int getBitAlignment()
  {
    return _bit_alignment;
  }
  
  public void setBitAlignment(int the_value) 
  {
    _bit_alignment = (int) the_value;
  }
  
  
  
  // extra accessors for `vector arguments'
  public Iter getArgumentIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_arguments");
    Iterator i = new STLIterator(_arguments,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendArgument(QualifiedType x) 
  {
    _arguments.pushBack(x);
  }
  
  public int getArgumentCount() 
  {
    return _arguments.length();
  }
  
  public void replaceArgument(int pos, QualifiedType x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    _arguments.insert(pos, x);
  }
  
  public void insertArgument(int pos, QualifiedType x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    _arguments.insert(_arguments.begin().add(pos), x);
  }
  
  public void removeArgument(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    _arguments.erase(_arguments.begin().add(pos));
  }
  
  public QualifiedType getArgument(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    return (QualifiedType) _arguments.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "CProcedureType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{CProcedureType}");
    
     { 
      int i = 0;
      Vector.Iterator iter = _arguments.begin();
      while (iter.notEqual(_arguments.end())) 
       { 
        QualifiedType item = (QualifiedType) iter.get();
        text.startBlock("_arguments[" + i + "]");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    text.startBlock("_result_type");
    text.setValue(_result_type);
    text.endBlock();
    text.startBlock("has_varargs=");
    text.setValue(_has_varargs);
    text.endBlock();
    text.startBlock("arguments_known=");
    text.setValue(_arguments_known);
    text.endBlock();
    text.startBlock("bit_alignment=");
    text.setValue(_bit_alignment);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
