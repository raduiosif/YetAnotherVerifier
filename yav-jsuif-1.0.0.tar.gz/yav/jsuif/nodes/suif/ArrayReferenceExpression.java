package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class ArrayReferenceExpression extends Expression
 {  
  public Expression _base_array_address;
  public static native int get__base_array_address_offset();
  
  public Expression getBaseArrayAddress()
  {
    return _base_array_address;
  }
  
  public Expression setBaseArrayAddress(Expression the_value) 
  {
    Expression old_value = _base_array_address;
    if (old_value != null) old_value.setParent(null);
    _base_array_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _index;
  public static native int get__index_offset();
  
  public Expression getIndex()
  {
    return _index;
  }
  
  public Expression setIndex(Expression the_value) 
  {
    Expression old_value = _index;
    if (old_value != null) old_value.setParent(null);
    _index = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ArrayReferenceExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ArrayReferenceExpression}");
    text.startBlock(text.pointerHeader("_base_array_address", _base_array_address));
    if (_base_array_address != null)
      _base_array_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_index", _index));
    if (_index != null)
      _index.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
