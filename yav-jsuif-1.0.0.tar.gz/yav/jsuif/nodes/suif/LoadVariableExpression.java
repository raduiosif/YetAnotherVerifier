package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class LoadVariableExpression extends Expression
 {  
  public VariableSymbol _source;
  public static native int get__source_offset();
  
  public VariableSymbol getSource()
  {
    return _source;
  }
  
  public void setSource(VariableSymbol the_value) 
  {
    _source = (VariableSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "LoadVariableExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{LoadVariableExpression}");
    text.startBlock("_source");
    text.setValue(_source);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
