package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class RepeatValueBlock extends ValueBlock
 {  
  public int _num_repetitions;
  public static native int get__num_repetitions_offset();
  
  public int getNumRepetitions()
  {
    return _num_repetitions;
  }
  
  public void setNumRepetitions(int the_value) 
  {
    _num_repetitions = (int) the_value;
  }
  
  public ValueBlock _sub_block;
  public static native int get__sub_block_offset();
  
  public ValueBlock getSubBlock()
  {
    return _sub_block;
  }
  
  public ValueBlock setSubBlock(ValueBlock the_value) 
  {
    ValueBlock old_value = _sub_block;
    if (old_value != null) old_value.setParent(null);
    _sub_block = (ValueBlock) the_value;
    if (the_value != null) the_value.setParent(this);
    return (ValueBlock) old_value;
  }
  
  public DataType _type;
  public static native int get__type_offset();
  
  public DataType getType()
  {
    return _type;
  }
  
  public void setType(DataType the_value) 
  {
    _type = (DataType) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "RepeatValueBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{RepeatValueBlock}");
    text.startBlock("num_repetitions=");
    text.setValue(_num_repetitions);
    text.endBlock();
    text.startBlock(text.pointerHeader("_sub_block", _sub_block));
    if (_sub_block != null)
      _sub_block.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
