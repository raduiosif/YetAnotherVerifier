package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class MultiDimArrayExpression extends Expression
 {  
  public Expression _array_address;
  public static native int get__array_address_offset();
  
  public Expression getArrayAddress()
  {
    return _array_address;
  }
  
  public Expression setArrayAddress(Expression the_value) 
  {
    Expression old_value = _array_address;
    if (old_value != null) old_value.setParent(null);
    _array_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _offset;
  public static native int get__offset_offset();
  
  public Expression getOffset()
  {
    return _offset;
  }
  
  public Expression setOffset(Expression the_value) 
  {
    Expression old_value = _offset;
    if (old_value != null) old_value.setParent(null);
    _offset = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Vector _index = new Vector();
  public static native int get__index_offset();
  
  public Vector _elements = new Vector();
  public static native int get__elements_offset();
  
  
  
  // extra accessors for `vector index'
  public Iter getIndexIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_index");
    Iterator i = new STLIterator(_index,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendIndex(Expression x) 
  {
    _index.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getIndexCount() 
  {
    return _index.length();
  }
  
  public void replaceIndex(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _index.length(), "index too large " + pos);
    if (_index.at(pos) != null) ((Expression) _index.at(pos)).setParent(null);
    _index.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public void insertIndex(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _index.length(), "index too large " + pos);
    _index.insert(_index.begin().add(pos), x);
    if (x != null) x.setParent(this);
  }
  
  public void removeIndex(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _index.length(), "index too large " + pos);
    if (_index.at(pos) != null) ((Expression) _index.at(pos)).setParent(null);
    _index.erase(_index.begin().add(pos));
  }
  
  public Expression getIndex(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _index.length(), "index too large " + pos);
    return (Expression) _index.at(pos);
  }
  
  // extra accessors for `vector elements'
  public Iter getElementIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_elements");
    Iterator i = new STLIterator(_elements,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendElement(Expression x) 
  {
    _elements.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getElementCount() 
  {
    return _elements.length();
  }
  
  public void replaceElement(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _elements.length(), "index too large " + pos);
    if (_elements.at(pos) != null) ((Expression) _elements.at(pos)).setParent(null);
    _elements.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public void insertElement(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _elements.length(), "index too large " + pos);
    _elements.insert(_elements.begin().add(pos), x);
    if (x != null) x.setParent(this);
  }
  
  public void removeElement(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _elements.length(), "index too large " + pos);
    if (_elements.at(pos) != null) ((Expression) _elements.at(pos)).setParent(null);
    _elements.erase(_elements.begin().add(pos));
  }
  
  public Expression getElement(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _elements.length(), "index too large " + pos);
    return (Expression) _elements.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "MultiDimArrayExpression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{MultiDimArrayExpression}");
    text.startBlock(text.pointerHeader("_array_address", _array_address));
    if (_array_address != null)
      _array_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_offset", _offset));
    if (_offset != null)
      _offset.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    
     { 
      int i = 0;
      Vector.Iterator iter = _index.begin();
      while (iter.notEqual(_index.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_index[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    
     { 
      int i = 0;
      Vector.Iterator iter = _elements.begin();
      while (iter.notEqual(_elements.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_elements[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
