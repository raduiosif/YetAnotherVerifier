package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class MarkStatement extends Statement
 {  
  
  
  public static native int get_size();
  
  private static String _className = "MarkStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{MarkStatement}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
