package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class MultiDimArrayType extends DataType
 {  
  public QualifiedType _element_type;
  public static native int get__element_type_offset();
  
  public QualifiedType getElementType()
  {
    return _element_type;
  }
  
  public void setElementType(QualifiedType the_value) 
  {
    _element_type = (QualifiedType) the_value;
  }
  
  public Vector _lower_bounds = new Vector();
  public static native int get__lower_bounds_offset();
  
  public Vector _upper_bounds = new Vector();
  public static native int get__upper_bounds_offset();
  
  
  
  // extra accessors for `vector lower_bounds'
  public Iter getLowerBoundIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_lower_bounds");
    Iterator i = new STLIterator(_lower_bounds,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendLowerBound(Expression x) 
  {
    _lower_bounds.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getLowerBoundCount() 
  {
    return _lower_bounds.length();
  }
  
  public void replaceLowerBound(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _lower_bounds.length(), "index too large " + pos);
    if (_lower_bounds.at(pos) != null) ((Expression) _lower_bounds.at(pos)).setParent(null);
    _lower_bounds.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public void insertLowerBound(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _lower_bounds.length(), "index too large " + pos);
    _lower_bounds.insert(_lower_bounds.begin().add(pos), x);
    if (x != null) x.setParent(this);
  }
  
  public void removeLowerBound(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _lower_bounds.length(), "index too large " + pos);
    if (_lower_bounds.at(pos) != null) ((Expression) _lower_bounds.at(pos)).setParent(null);
    _lower_bounds.erase(_lower_bounds.begin().add(pos));
  }
  
  public Expression getLowerBound(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _lower_bounds.length(), "index too large " + pos);
    return (Expression) _lower_bounds.at(pos);
  }
  
  // extra accessors for `vector upper_bounds'
  public Iter getUpperBoundIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_upper_bounds");
    Iterator i = new STLIterator(_upper_bounds,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendUpperBound(Expression x) 
  {
    _upper_bounds.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getUpperBoundCount() 
  {
    return _upper_bounds.length();
  }
  
  public void replaceUpperBound(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _upper_bounds.length(), "index too large " + pos);
    if (_upper_bounds.at(pos) != null) ((Expression) _upper_bounds.at(pos)).setParent(null);
    _upper_bounds.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public void insertUpperBound(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _upper_bounds.length(), "index too large " + pos);
    _upper_bounds.insert(_upper_bounds.begin().add(pos), x);
    if (x != null) x.setParent(this);
  }
  
  public void removeUpperBound(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _upper_bounds.length(), "index too large " + pos);
    if (_upper_bounds.at(pos) != null) ((Expression) _upper_bounds.at(pos)).setParent(null);
    _upper_bounds.erase(_upper_bounds.begin().add(pos));
  }
  
  public Expression getUpperBound(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _upper_bounds.length(), "index too large " + pos);
    return (Expression) _upper_bounds.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "MultiDimArrayType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{MultiDimArrayType}");
    text.startBlock("_element_type");
    text.setValue(_element_type);
    text.endBlock();
    
     { 
      int i = 0;
      Vector.Iterator iter = _lower_bounds.begin();
      while (iter.notEqual(_lower_bounds.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_lower_bounds[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    
     { 
      int i = 0;
      Vector.Iterator iter = _upper_bounds.begin();
      while (iter.notEqual(_upper_bounds.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_upper_bounds[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
