package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class VoidType extends DataType
 {  
  
  
  public static native int get_size();
  
  private static String _className = "VoidType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{VoidType}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
