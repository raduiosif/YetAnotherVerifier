package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class ReturnStatement extends Statement
 {  
  public Expression _return_value;
  public static native int get__return_value_offset();
  
  public Expression getReturnValue()
  {
    return _return_value;
  }
  
  public Expression setReturnValue(Expression the_value) 
  {
    Expression old_value = _return_value;
    if (old_value != null) old_value.setParent(null);
    _return_value = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ReturnStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ReturnStatement}");
    text.startBlock(text.pointerHeader("_return_value", _return_value));
    if (_return_value != null)
      _return_value.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
