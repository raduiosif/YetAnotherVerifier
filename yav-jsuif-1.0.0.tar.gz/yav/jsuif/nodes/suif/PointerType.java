package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class PointerType extends DataType
 {  
  public Type _reference_type;
  public static native int get__reference_type_offset();
  
  public Type getReferenceType()
  {
    return _reference_type;
  }
  
  public void setReferenceType(Type the_value) 
  {
    _reference_type = (Type) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "PointerType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{PointerType}");
    text.startBlock("_reference_type");
    text.setValue(_reference_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
