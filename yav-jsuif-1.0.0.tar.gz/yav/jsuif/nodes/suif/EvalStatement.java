package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class EvalStatement extends Statement
 {  
  public List _expressions = new List();
  public static native int get__expressions_offset();
  
  
  
  // extra accessors for `list expressions'
  public Iter getExpressionIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_expressions");
    Iterator i = new STLIterator(_expressions,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendExpression(Expression x) 
   {
    _expressions.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getExpressionCount() 
   {
    return _expressions.length();
  }
  
  public void insertExpression(int pos, Expression x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _expressions.length(), "index too large " + pos); 
    _expressions.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public Expression removeExpression(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _expressions.length(), "index too large " + pos);
    Expression tmp = (Expression) _expressions.at(pos);
    _expressions.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public Expression getExpression(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _expressions.length(), "index too large " + pos);
    return (Expression) _expressions.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "EvalStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{EvalStatement}");
    
     { 
      int i = 0;
      List.Iterator iter = _expressions.begin();
      while (iter.notEqual(_expressions.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_expressions[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
