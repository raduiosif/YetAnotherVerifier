package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class MultiValueBlock extends ValueBlock
 {  
  public IndexedList _sub_blocks = new IndexedList();
  public static native int get__sub_blocks_offset();
  
  public DataType _type;
  public static native int get__type_offset();
  
  public DataType getType()
  {
    return _type;
  }
  
  public void setType(DataType the_value) 
  {
    _type = (DataType) the_value;
  }
  
  
  
  // extra accessors for `indexed_list sub_blocks'
  public Iter getSubBlockIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_sub_blocks");
    Iterator i = new STLIterator(_sub_blocks,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void addSubBlock(IInteger key, ValueBlock value)
  {
    _sub_blocks.pushBack(key, value);
    if (value != null) value.setParent(this);
  }
  
  public void insertSubBlock(IInteger key, ValueBlock value)
  {
    List.Iterator iter = _sub_blocks.begin();
    while (iter.notEqual(_sub_blocks.end()) && ((IndexedList.Pair) iter.get()).first.hashCode() < key.hashCode()) iter.inc();
    _sub_blocks.insert(iter, new IndexedList.Pair(key, value));
  }
  
  public ValueBlock removeSubBlock(IInteger key) 
  {
    List.Iterator iter = _sub_blocks.find(key);
    Assert.condition(iter.notEqual(_sub_blocks.end()), "removing up a non-existant value");
    return (ValueBlock) _sub_blocks.remove(iter);
  }
  
  public boolean hasSubBlockMember(IInteger key) 
  {
    return _sub_blocks.isMember(key);
  }
  
  public ValueBlock lookupSubBlock(IInteger key) 
  {
    List.Iterator iter = _sub_blocks.find(key);
    if (iter.isEqual(_sub_blocks.end())) return null;
    return (ValueBlock) ((IndexedList.Pair) iter.get()).second;
  }
  
  public int numSubBlockWithKey(IInteger key) 
  {
    return _sub_blocks.numWithKey(key);
  }
  
  public ValueBlock lookupSubBlock(IInteger key, int no) 
  {
    List.Iterator iter = _sub_blocks.find(key, no);
    Assert.condition(iter.notEqual(_sub_blocks.end()), "looking up a non-existant value");
    return (ValueBlock) ((IndexedList.Pair) iter.get()).second;
  }
  
   public ValueBlock removeSubBlock(IInteger key, int no) 
  {
    List.Iterator iter = _sub_blocks.find(key, no);
    Assert.condition(iter.notEqual(_sub_blocks.end()), "removing up a non-existant value");
    return (ValueBlock) _sub_blocks.remove(iter);
  }
  
  public void removeAllFromSubBlock(ValueBlock value) 
  {
    List.Iterator iter = _sub_blocks.begin();
    List.Iterator end = _sub_blocks.end();
    while (iter.notEqual(end)) 
    {
      if (((IndexedList.Pair) iter.get()).second.equals(value)) 
      {
        List.Iterator iter1 = new List.Iterator(iter);
        iter.inc();
        _sub_blocks.remove(iter1);
      }
      else 
      {
        iter.inc();
      }
      
    }
    
  }
  
  public int getSubBlockCount() 
  {
    return _sub_blocks.length();
  }
  
  public IndexedList.Pair getSubBlock(int pos) 
  {
    return (IndexedList.Pair) _sub_blocks.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "MultiValueBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{MultiValueBlock}");
    
     { 
      int i = 0;
      List.Iterator iter = _sub_blocks.begin();
      while (iter.notEqual(_sub_blocks.end())) 
       { 
        IInteger item_first = (IInteger) ((IndexedList.Pair) iter.get()).first;
        text.startBlock("_sub_blocks[" + i + "].");
        text.setValue(item_first);
        text.endBlock();
        
        ValueBlock item_second = (ValueBlock) ((IndexedList.Pair) iter.get()).second;
        text.startBlock(text.pointerHeader("_sub_blocks[" + i +"]._second", item_second));
        if (item_second != null)
          item_second.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
