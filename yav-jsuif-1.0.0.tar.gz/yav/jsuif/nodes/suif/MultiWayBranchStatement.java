package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class MultiWayBranchStatement extends Statement
 {  
  public Expression _decision_operand;
  public static native int get__decision_operand_offset();
  
  public Expression getDecisionOperand()
  {
    return _decision_operand;
  }
  
  public Expression setDecisionOperand(Expression the_value) 
  {
    Expression old_value = _decision_operand;
    if (old_value != null) old_value.setParent(null);
    _decision_operand = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public CodeLabelSymbol _default_target;
  public static native int get__default_target_offset();
  
  public CodeLabelSymbol getDefaultTarget()
  {
    return _default_target;
  }
  
  public void setDefaultTarget(CodeLabelSymbol the_value) 
  {
    _default_target = (CodeLabelSymbol) the_value;
  }
  
  public IndexedList _case = new IndexedList();
  public static native int get__case_offset();
  
  
  
  // extra accessors for `indexed_list case'
  public Iter getCaseIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_case");
    Iterator i = new STLIterator(_case,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void addCase(IInteger key, CodeLabelSymbol value)
  {
    _case.pushBack(key, value);
  }
  
  public void insertCase(IInteger key, CodeLabelSymbol value)
  {
    List.Iterator iter = _case.begin();
    while (iter.notEqual(_case.end()) && ((IndexedList.Pair) iter.get()).first.hashCode() < key.hashCode()) iter.inc();
    _case.insert(iter, new IndexedList.Pair(key, value));
  }
  
  public CodeLabelSymbol removeCase(IInteger key) 
  {
    List.Iterator iter = _case.find(key);
    Assert.condition(iter.notEqual(_case.end()), "removing up a non-existant value");
    return (CodeLabelSymbol) _case.remove(iter);
  }
  
  public boolean hasCaseMember(IInteger key) 
  {
    return _case.isMember(key);
  }
  
  public CodeLabelSymbol lookupCase(IInteger key) 
  {
    List.Iterator iter = _case.find(key);
    if (iter.isEqual(_case.end())) return null;
    return (CodeLabelSymbol) ((IndexedList.Pair) iter.get()).second;
  }
  
  public int numCaseWithKey(IInteger key) 
  {
    return _case.numWithKey(key);
  }
  
  public CodeLabelSymbol lookupCase(IInteger key, int no) 
  {
    List.Iterator iter = _case.find(key, no);
    Assert.condition(iter.notEqual(_case.end()), "looking up a non-existant value");
    return (CodeLabelSymbol) ((IndexedList.Pair) iter.get()).second;
  }
  
   public CodeLabelSymbol removeCase(IInteger key, int no) 
  {
    List.Iterator iter = _case.find(key, no);
    Assert.condition(iter.notEqual(_case.end()), "removing up a non-existant value");
    return (CodeLabelSymbol) _case.remove(iter);
  }
  
  public void removeAllFromCase(CodeLabelSymbol value) 
  {
    List.Iterator iter = _case.begin();
    List.Iterator end = _case.end();
    while (iter.notEqual(end)) 
    {
      if (((IndexedList.Pair) iter.get()).second.equals(value)) 
      {
        List.Iterator iter1 = new List.Iterator(iter);
        iter.inc();
        _case.remove(iter1);
      }
      else 
      {
        iter.inc();
      }
      
    }
    
  }
  
  public int getCaseCount() 
  {
    return _case.length();
  }
  
  public IndexedList.Pair getCase(int pos) 
  {
    return (IndexedList.Pair) _case.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "MultiWayBranchStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{MultiWayBranchStatement}");
    text.startBlock(text.pointerHeader("_decision_operand", _decision_operand));
    if (_decision_operand != null)
      _decision_operand.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_default_target");
    text.setValue(_default_target);
    text.endBlock();
    
     { 
      int i = 0;
      List.Iterator iter = _case.begin();
      while (iter.notEqual(_case.end())) 
       { 
        IInteger item_first = (IInteger) ((IndexedList.Pair) iter.get()).first;
        text.startBlock("_case[" + i + "].");
        text.setValue(item_first);
        text.endBlock();
        
        CodeLabelSymbol item_second = (CodeLabelSymbol) ((IndexedList.Pair) iter.get()).second;
        text.startBlock("_case[" + i + "]");
        text.setValue(item_second);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
