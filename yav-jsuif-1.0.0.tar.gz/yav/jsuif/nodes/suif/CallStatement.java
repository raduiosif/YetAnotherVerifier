package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class CallStatement extends Statement
 {  
  public VariableSymbol _destination;
  public static native int get__destination_offset();
  
  public VariableSymbol getDestination()
  {
    return _destination;
  }
  
  public void setDestination(VariableSymbol the_value) 
  {
    _destination = (VariableSymbol) the_value;
  }
  
  public Expression _callee_address;
  public static native int get__callee_address_offset();
  
  public Expression getCalleeAddress()
  {
    return _callee_address;
  }
  
  public Expression setCalleeAddress(Expression the_value) 
  {
    Expression old_value = _callee_address;
    if (old_value != null) old_value.setParent(null);
    _callee_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Vector _arguments = new Vector();
  public static native int get__arguments_offset();
  
  
  
  // extra accessors for `vector arguments'
  public Iter getArgumentIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_arguments");
    Iterator i = new STLIterator(_arguments,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendArgument(Expression x) 
  {
    _arguments.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getArgumentCount() 
  {
    return _arguments.length();
  }
  
  public void replaceArgument(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    if (_arguments.at(pos) != null) ((Expression) _arguments.at(pos)).setParent(null);
    _arguments.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public void insertArgument(int pos, Expression x) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    _arguments.insert(_arguments.begin().add(pos), x);
    if (x != null) x.setParent(this);
  }
  
  public void removeArgument(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    if (_arguments.at(pos) != null) ((Expression) _arguments.at(pos)).setParent(null);
    _arguments.erase(_arguments.begin().add(pos));
  }
  
  public Expression getArgument(int pos) 
  {
    Assert.condition(pos >= 0 , "invalid index " + pos);
    Assert.condition(pos <= _arguments.length(), "index too large " + pos);
    return (Expression) _arguments.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "CallStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{CallStatement}");
    text.startBlock("_destination");
    text.setValue(_destination);
    text.endBlock();
    text.startBlock(text.pointerHeader("_callee_address", _callee_address));
    if (_callee_address != null)
      _callee_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    
     { 
      int i = 0;
      Vector.Iterator iter = _arguments.begin();
      while (iter.notEqual(_arguments.end())) 
       { 
        Expression item = (Expression) iter.get();
        text.startBlock(text.pointerHeader("_arguments[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
