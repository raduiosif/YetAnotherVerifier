package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class WhileStatement extends Statement
 {  
  public Expression _condition;
  public static native int get__condition_offset();
  
  public Expression getCondition()
  {
    return _condition;
  }
  
  public Expression setCondition(Expression the_value) 
  {
    Expression old_value = _condition;
    if (old_value != null) old_value.setParent(null);
    _condition = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Statement _body;
  public static native int get__body_offset();
  
  public Statement getBody()
  {
    return _body;
  }
  
  public Statement setBody(Statement the_value) 
  {
    Statement old_value = _body;
    if (old_value != null) old_value.setParent(null);
    _body = (Statement) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Statement) old_value;
  }
  
  public CodeLabelSymbol _break_label;
  public static native int get__break_label_offset();
  
  public CodeLabelSymbol getBreakLabel()
  {
    return _break_label;
  }
  
  public void setBreakLabel(CodeLabelSymbol the_value) 
  {
    _break_label = (CodeLabelSymbol) the_value;
  }
  
  public CodeLabelSymbol _continue_label;
  public static native int get__continue_label_offset();
  
  public CodeLabelSymbol getContinueLabel()
  {
    return _continue_label;
  }
  
  public void setContinueLabel(CodeLabelSymbol the_value) 
  {
    _continue_label = (CodeLabelSymbol) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "WhileStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{WhileStatement}");
    text.startBlock(text.pointerHeader("_condition", _condition));
    if (_condition != null)
      _condition.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_body", _body));
    if (_body != null)
      _body.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("_break_label");
    text.setValue(_break_label);
    text.endBlock();
    text.startBlock("_continue_label");
    text.setValue(_continue_label);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
