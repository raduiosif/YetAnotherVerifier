package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class ArrayType extends DataType
 {  
  public QualifiedType _element_type;
  public static native int get__element_type_offset();
  
  public QualifiedType getElementType()
  {
    return _element_type;
  }
  
  public void setElementType(QualifiedType the_value) 
  {
    _element_type = (QualifiedType) the_value;
  }
  
  public Expression _lower_bound;
  public static native int get__lower_bound_offset();
  
  public Expression getLowerBound()
  {
    return _lower_bound;
  }
  
  public Expression setLowerBound(Expression the_value) 
  {
    Expression old_value = _lower_bound;
    if (old_value != null) old_value.setParent(null);
    _lower_bound = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _upper_bound;
  public static native int get__upper_bound_offset();
  
  public Expression getUpperBound()
  {
    return _upper_bound;
  }
  
  public Expression setUpperBound(Expression the_value) 
  {
    Expression old_value = _upper_bound;
    if (old_value != null) old_value.setParent(null);
    _upper_bound = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ArrayType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ArrayType}");
    text.startBlock("_element_type");
    text.setValue(_element_type);
    text.endBlock();
    text.startBlock(text.pointerHeader("_lower_bound", _lower_bound));
    if (_lower_bound != null)
      _lower_bound.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_upper_bound", _upper_bound));
    if (_upper_bound != null)
      _upper_bound.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
