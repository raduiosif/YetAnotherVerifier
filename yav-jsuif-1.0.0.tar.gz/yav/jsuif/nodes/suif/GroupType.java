package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class GroupType extends DataType
 {  
  public boolean _is_complete;
  public static native int get__is_complete_offset();
  
  public boolean getIsComplete()
  {
    return _is_complete;
  }
  
  public void setIsComplete(boolean the_value) 
  {
    _is_complete = (boolean) the_value;
  }
  
  public GroupSymbolTable _group_symbol_table;
  public static native int get__group_symbol_table_offset();
  
  public GroupSymbolTable getGroupSymbolTable()
  {
    return _group_symbol_table;
  }
  
  public GroupSymbolTable setGroupSymbolTable(GroupSymbolTable the_value) 
  {
    GroupSymbolTable old_value = _group_symbol_table;
    if (old_value != null) old_value.setParent(null);
    _group_symbol_table = (GroupSymbolTable) the_value;
    if (the_value != null) the_value.setParent(this);
    return (GroupSymbolTable) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "GroupType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{GroupType}");
    text.startBlock("is_complete=");
    text.setValue(_is_complete);
    text.endBlock();
    text.startBlock(text.pointerHeader("_group_symbol_table", _group_symbol_table));
    if (_group_symbol_table != null)
      _group_symbol_table.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
