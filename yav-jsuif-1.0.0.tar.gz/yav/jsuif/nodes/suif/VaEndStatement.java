package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class VaEndStatement extends Statement
 {  
  public Expression _ap_address;
  public static native int get__ap_address_offset();
  
  public Expression getApAddress()
  {
    return _ap_address;
  }
  
  public Expression setApAddress(Expression the_value) 
  {
    Expression old_value = _ap_address;
    if (old_value != null) old_value.setParent(null);
    _ap_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "VaEndStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{VaEndStatement}");
    text.startBlock(text.pointerHeader("_ap_address", _ap_address));
    if (_ap_address != null)
      _ap_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
