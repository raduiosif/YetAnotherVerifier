package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class NestingVariableSymbol extends VariableSymbol
 {  
  public NestingVariableSymbol _super_variable;
  public static native int get__super_variable_offset();
  
  public NestingVariableSymbol getSuperVariable()
  {
    return _super_variable;
  }
  
  public void setSuperVariable(NestingVariableSymbol the_value) 
  {
    _super_variable = (NestingVariableSymbol) the_value;
  }
  
  public Expression _bit_offset;
  public static native int get__bit_offset_offset();
  
  public Expression getBitOffset()
  {
    return _bit_offset;
  }
  
  public Expression setBitOffset(Expression the_value) 
  {
    Expression old_value = _bit_offset;
    if (old_value != null) old_value.setParent(null);
    _bit_offset = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public List _child_variables = new List();
  public static native int get__child_variables_offset();
  
  
  
  // extra accessors for `list child_variables'
  public Iter getChildVariableIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_child_variables");
    Iterator i = new STLIterator(_child_variables,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendChildVariable(NestingVariableSymbol x) 
   {
    _child_variables.pushBack(x);
  }
  
  public int getChildVariableCount() 
   {
    return _child_variables.length();
  }
  
  public void insertChildVariable(int pos, NestingVariableSymbol x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _child_variables.length(), "index too large " + pos); 
    _child_variables.insert(pos, x);
  }
  
  public NestingVariableSymbol removeChildVariable(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _child_variables.length(), "index too large " + pos);
    NestingVariableSymbol tmp = (NestingVariableSymbol) _child_variables.at(pos);
    _child_variables.erase(pos);
    return tmp;
  }
  
  public NestingVariableSymbol getChildVariable(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _child_variables.length(), "index too large " + pos);
    return (NestingVariableSymbol) _child_variables.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "NestingVariableSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{NestingVariableSymbol}");
    text.startBlock("_super_variable");
    text.setValue(_super_variable);
    text.endBlock();
    text.startBlock(text.pointerHeader("_bit_offset", _bit_offset));
    if (_bit_offset != null)
      _bit_offset.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    
     { 
      int i = 0;
      List.Iterator iter = _child_variables.begin();
      while (iter.notEqual(_child_variables.end())) 
       { 
        NestingVariableSymbol item = (NestingVariableSymbol) iter.get();
        text.startBlock("_child_variables[" + i + "]");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
