package yav.jsuif.nodes.suif;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;
import yav.jsuif.nodes.basic.*; 


public class StoreStatement extends Statement
 {  
  public Expression _value;
  public static native int get__value_offset();
  
  public Expression getValue()
  {
    return _value;
  }
  
  public Expression setValue(Expression the_value) 
  {
    Expression old_value = _value;
    if (old_value != null) old_value.setParent(null);
    _value = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  public Expression _destination_address;
  public static native int get__destination_address_offset();
  
  public Expression getDestinationAddress()
  {
    return _destination_address;
  }
  
  public Expression setDestinationAddress(Expression the_value) 
  {
    Expression old_value = _destination_address;
    if (old_value != null) old_value.setParent(null);
    _destination_address = (Expression) the_value;
    if (the_value != null) the_value.setParent(this);
    return (Expression) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "StoreStatement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{StoreStatement}");
    text.startBlock(text.pointerHeader("_value", _value));
    if (_value != null)
      _value.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_destination_address", _destination_address));
    if (_destination_address != null)
      _destination_address.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
