package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class DataType extends Type
 {  
  public IInteger _bit_size;
  public static native int get__bit_size_offset();
  
  public IInteger getBitSize()
  {
    return _bit_size;
  }
  
  public void setBitSize(IInteger the_value) 
  {
    _bit_size = (IInteger) the_value;
  }
  
  public int _bit_alignment;
  public static native int get__bit_alignment_offset();
  
  public int getBitAlignment()
  {
    return _bit_alignment;
  }
  
  public void setBitAlignment(int the_value) 
  {
    _bit_alignment = (int) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "DataType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{DataType}");
    text.startBlock("bit_size=");
    text.setValue(_bit_size);
    text.endBlock();
    text.startBlock("bit_alignment=");
    text.setValue(_bit_alignment);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
