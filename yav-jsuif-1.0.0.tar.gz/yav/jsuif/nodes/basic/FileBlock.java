package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class FileBlock extends ScopedObject
 {  
  public String _source_file_name;
  public static native int get__source_file_name_offset();
  
  public String getSourceFileName()
  {
    return _source_file_name;
  }
  
  public void setSourceFileName(String the_value) 
  {
    _source_file_name = (String) the_value;
  }
  
  public SymbolTable _symbol_table;
  public static native int get__symbol_table_offset();
  
  public SymbolTable getSymbolTable()
  {
    return _symbol_table;
  }
  
  public SymbolTable setSymbolTable(SymbolTable the_value) 
  {
    SymbolTable old_value = _symbol_table;
    if (old_value != null) old_value.setParent(null);
    _symbol_table = (SymbolTable) the_value;
    if (the_value != null) the_value.setParent(this);
    return (SymbolTable) old_value;
  }
  
  public DefinitionBlock _definition_block;
  public static native int get__definition_block_offset();
  
  public DefinitionBlock getDefinitionBlock()
  {
    return _definition_block;
  }
  
  public DefinitionBlock setDefinitionBlock(DefinitionBlock the_value) 
  {
    DefinitionBlock old_value = _definition_block;
    if (old_value != null) old_value.setParent(null);
    _definition_block = (DefinitionBlock) the_value;
    if (the_value != null) the_value.setParent(this);
    return (DefinitionBlock) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "FileBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FileBlock}");
    text.startBlock("source_file_name=");
    text.setValue(_source_file_name);
    text.endBlock();
    text.startBlock(text.pointerHeader("_symbol_table", _symbol_table));
    if (_symbol_table != null)
      _symbol_table.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_definition_block", _definition_block));
    if (_definition_block != null)
      _definition_block.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
