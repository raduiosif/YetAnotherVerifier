package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Statement extends ExecutionObject
 {  
  
  
  
  
  
  
  // extra accessors for `list child_statements'
  public Iter getChildStatementIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "child_statements");
    return new Iter(i);
  }
  
  public void appendChildStatement(Statement x) 
   {
    Assert.fatal("attempt to access virtual field ChildStatement");
  }
  
  public int getChildStatementCount() 
   {
    Assert.fatal("attempt to access virtual field ChildStatement");return 0;
  }
  
  public void insertChildStatement(int pos, Statement x) 
   {
    Assert.fatal("attempt to access virtual field ChildStatement");
  }
  
  public Statement removeChildStatement(int pos) 
   {
    Assert.fatal("attempt to access virtual field ChildStatement");return null;
  }
  
  public Statement getChildStatement(int pos) 
   {
    Assert.fatal("attempt to access virtual field ChildStatement");return null;
  }
  
  
  
  // extra accessors for `list destination_vars'
  public Iter getDestinationVarIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "destination_vars");
    return new Iter(i);
  }
  
  public void appendDestinationVar(VariableSymbol x) 
   {
    Assert.fatal("attempt to access virtual field DestinationVar");
  }
  
  public int getDestinationVarCount() 
   {
    Assert.fatal("attempt to access virtual field DestinationVar");return 0;
  }
  
  public void insertDestinationVar(int pos, VariableSymbol x) 
   {
    Assert.fatal("attempt to access virtual field DestinationVar");
  }
  
  public VariableSymbol removeDestinationVar(int pos) 
   {
    Assert.fatal("attempt to access virtual field DestinationVar");return null;
  }
  
  public VariableSymbol getDestinationVar(int pos) 
   {
    Assert.fatal("attempt to access virtual field DestinationVar");return null;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "Statement"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Statement}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
