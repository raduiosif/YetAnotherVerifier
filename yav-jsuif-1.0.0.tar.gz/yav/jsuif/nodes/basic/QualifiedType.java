package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class QualifiedType extends Type
 {  
  public DataType _base_type;
  public static native int get__base_type_offset();
  
  public DataType getBaseType()
  {
    return _base_type;
  }
  
  public void setBaseType(DataType the_value) 
  {
    _base_type = (DataType) the_value;
  }
  
  public SearchableList _qualifications = new SearchableList();
  public static native int get__qualifications_offset();
  
  
  
  // extra accessors for `searchable_list qualifications'
  public Iter getQualificationIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_qualifications");
    Iterator i = new STLIterator(_qualifications,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendQualification(String key) 
  {
    _qualifications.pushBack(key);
  }
  
  public int getQualificationCount() 
  {
    return _qualifications.length();
  }
  
  public void removeQualification(String key) 
  {
    SearchableList.Iterator iter = _qualifications.find(key);
    Assert.condition(iter.notEqual(_qualifications.end()),
    "attempt to remove missing key");
    _qualifications.erase(iter);
  }
  
  public boolean hasQualificationMember(String key) 
  {
    return _qualifications.isMember(key);
  }
  
  public void insertQualification(int pos, String x) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _qualifications.length(), "index too large " + pos); 
    _qualifications.insert(pos, x);
  }
  
  public String removeQualification(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _qualifications.length(), "index too large " + pos);
    String tmp = (String) _qualifications.at(pos);
    _qualifications.erase(pos);
    return tmp;
  }
  
  public String getQualification(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _qualifications.length(), "index too large " + pos);
    return (String) _qualifications.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "QualifiedType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{QualifiedType}");
    text.startBlock("_base_type");
    text.setValue(_base_type);
    text.endBlock();
    
     { 
      int i = 0;
      SearchableList.Iterator iter = _qualifications.begin();
      while (iter.notEqual(_qualifications.end())) 
       { 
        String item = (String) iter.get();
        text.startBlock("_qualifications[" + i + "].");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
