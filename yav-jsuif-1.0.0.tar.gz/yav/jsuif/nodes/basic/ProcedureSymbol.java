package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class ProcedureSymbol extends Symbol
 {  
  public ProcedureType _type;
  public static native int get__type_offset();
  
  public Type getType()
  {
    return _type;
  }
  
  public void setType(Type the_value) 
  {
    _type = (ProcedureType) the_value;
  }
  
  public ProcedureDefinition _definition;
  public static native int get__definition_offset();
  
  public ProcedureDefinition getDefinition()
  {
    return _definition;
  }
  
  public void setDefinition(ProcedureDefinition the_value) 
  {
    _definition = (ProcedureDefinition) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ProcedureSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ProcedureSymbol}");
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    text.startBlock("_definition");
    text.setValue(_definition);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
