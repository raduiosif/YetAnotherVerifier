package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class AnnotableObject extends SuifObject
 {  
  public SearchableList _annotes = new SearchableList();
  public static native int get__annotes_offset();
  
  
  
  // extra accessors for `searchable_list annotes'
  public Iter getAnnoteIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_annotes");
    Iterator i = new STLIterator(_annotes,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendAnnote(Annote key) 
  {
    _annotes.pushBack(key);
    if (key != null) key.setParent(this);
  }
  
  public int getAnnoteCount() 
  {
    return _annotes.length();
  }
  
  public void removeAnnote(Annote key) 
  {
    SearchableList.Iterator iter = _annotes.find(key);
    Assert.condition(iter.notEqual(_annotes.end()),
    "attempt to remove missing key");
    if (iter.get() != null) ((Annote) iter.get()).setParent(null);
    _annotes.erase(iter);
  }
  
  public boolean hasAnnoteMember(Annote key) 
  {
    return _annotes.isMember(key);
  }
  
  public void insertAnnote(int pos, Annote x) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _annotes.length(), "index too large " + pos); 
    _annotes.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public Annote removeAnnote(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _annotes.length(), "index too large " + pos);
    Annote tmp = (Annote) _annotes.at(pos);
    _annotes.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public Annote getAnnote(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _annotes.length(), "index too large " + pos);
    return (Annote) _annotes.at(pos);
  }
  
  public Annote removeAnnoteByName(String key) 
  {
    SearchableList.Iterator iter = _annotes.begin();
    while (iter.notEqual(_annotes.end())) 
    {
      if (((Annote) iter.get()).getName().equals(key)) 
      {
        Annote tmp = (Annote) iter.get();
        if (tmp != null) tmp.setParent(null);
        _annotes.erase(iter);
        return tmp;
      }
      iter.inc();
    }
    return null;
  }
  
  public Annote lookupAnnoteByName(String key) 
  {
    SearchableList.Iterator iter = _annotes.begin();
    while (iter.notEqual(_annotes.end())) 
    {
      if (((Annote) iter.get()).getName().equals(key)) 
      {
        return (Annote) iter.get();
      }
      iter.inc();
    }
    return null;
  }
  
  public int numAnnoteOfName(String key) 
  {
    int count = 0;
    SearchableList.Iterator iter = _annotes.begin();
    while (iter.notEqual(_annotes.end())) 
    {
      if (((Annote) iter.get()).getName().equals(key)) 
      {
        count ++;
      }
      iter.inc();
    }
    return count;
  }
  
  public Annote lookupAnnoteByName(String key, int no) 
  {
    SearchableList.Iterator iter = _annotes.begin();
    while (iter.notEqual(_annotes.end())) 
    {
      if (((Annote) iter.get()).getName().equals(key)) 
      {
        no --;
        if (no <= 0) return (Annote) iter.get();
      }
      iter.inc();
    }
    return null;
  }
  
  public Annote removeAnnoteByName(String key, int no) 
  {
    SearchableList.Iterator iter = _annotes.begin();
    while (iter.notEqual(_annotes.end())) 
    {
      if (((Annote) iter.get()).getName().equals(key)) 
      {
        no --;
        if (no <= 0) 
        {
          Annote tmp = (Annote) iter.get();
          if (tmp != null) tmp.setParent(null);
          _annotes.erase(iter);
          return tmp;
        }
      }
      iter.inc();
    }
    return null;
  }
  
  public static native int get_size();
  
  private static String _className = "AnnotableObject"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{AnnotableObject}");
    
     { 
      int i = 0;
      SearchableList.Iterator iter = _annotes.begin();
      while (iter.notEqual(_annotes.end())) 
       { 
        Annote item = (Annote) iter.get();
        text.startBlock(text.pointerHeader("_annotes[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    text.endBlock();
    
   } 
 } 
 
