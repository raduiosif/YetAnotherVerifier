package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class ParameterSymbol extends VariableSymbol
 {  
  
  
  public static native int get_size();
  
  private static String _className = "ParameterSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ParameterSymbol}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
