package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class OwnedSuifObjectBrick extends SuifBrick
 {  
  public SuifObject _object;
  public static native int get__object_offset();
  
  public SuifObject getObject()
  {
    return _object;
  }
  
  public SuifObject setObject(SuifObject the_value) 
  {
    SuifObject old_value = _object;
    if (old_value != null) old_value.setParent(null);
    _object = (SuifObject) the_value;
    if (the_value != null) the_value.setParent(this);
    return (SuifObject) old_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "OwnedSuifObjectBrick"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{OwnedSuifObjectBrick}");
    text.startBlock(text.pointerHeader("_object", _object));
    if (_object != null)
      _object.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
