package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class DefinitionBlock extends ScopedObject
 {  
  public List _variable_definitions = new List();
  public static native int get__variable_definitions_offset();
  
  public List _procedure_definitions = new List();
  public static native int get__procedure_definitions_offset();
  
  
  
  // extra accessors for `list variable_definitions'
  public Iter getVariableDefinitionIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_variable_definitions");
    Iterator i = new STLIterator(_variable_definitions,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendVariableDefinition(VariableDefinition x) 
   {
    _variable_definitions.pushBack(x);
    if (x != null) x.setParent(this);
    if (x != null) x.notifier(true, this);
  }
  
  public int getVariableDefinitionCount() 
   {
    return _variable_definitions.length();
  }
  
  public void insertVariableDefinition(int pos, VariableDefinition x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _variable_definitions.length(), "index too large " + pos); 
    _variable_definitions.insert(pos, x);
    if (x != null) x.setParent(this);
    if (x != null) x.notifier(true, this);
  }
  
  public VariableDefinition removeVariableDefinition(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _variable_definitions.length(), "index too large " + pos);
    ((VariableDefinition)_variable_definitions.at(pos)).notifier(false, this);
    VariableDefinition tmp = (VariableDefinition) _variable_definitions.at(pos);
    _variable_definitions.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public VariableDefinition getVariableDefinition(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _variable_definitions.length(), "index too large " + pos);
    return (VariableDefinition) _variable_definitions.at(pos);
  }
  
  
  
  // extra accessors for `list procedure_definitions'
  public Iter getProcedureDefinitionIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_procedure_definitions");
    Iterator i = new STLIterator(_procedure_definitions,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendProcedureDefinition(ProcedureDefinition x) 
   {
    _procedure_definitions.pushBack(x);
    if (x != null) x.setParent(this);
    if (x != null) x.notifier(true, this);
  }
  
  public int getProcedureDefinitionCount() 
   {
    return _procedure_definitions.length();
  }
  
  public void insertProcedureDefinition(int pos, ProcedureDefinition x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _procedure_definitions.length(), "index too large " + pos); 
    _procedure_definitions.insert(pos, x);
    if (x != null) x.setParent(this);
    if (x != null) x.notifier(true, this);
  }
  
  public ProcedureDefinition removeProcedureDefinition(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _procedure_definitions.length(), "index too large " + pos);
    ((ProcedureDefinition)_procedure_definitions.at(pos)).notifier(false, this);
    ProcedureDefinition tmp = (ProcedureDefinition) _procedure_definitions.at(pos);
    _procedure_definitions.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public ProcedureDefinition getProcedureDefinition(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _procedure_definitions.length(), "index too large " + pos);
    return (ProcedureDefinition) _procedure_definitions.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "DefinitionBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{DefinitionBlock}");
    
     { 
      int i = 0;
      List.Iterator iter = _variable_definitions.begin();
      while (iter.notEqual(_variable_definitions.end())) 
       { 
        VariableDefinition item = (VariableDefinition) iter.get();
        text.startBlock(text.pointerHeader("_variable_definitions[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    
     { 
      int i = 0;
      List.Iterator iter = _procedure_definitions.begin();
      while (iter.notEqual(_procedure_definitions.end())) 
       { 
        ProcedureDefinition item = (ProcedureDefinition) iter.get();
        text.startBlock(text.pointerHeader("_procedure_definitions[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
