package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class BrickAnnote extends Annote
 {  
  public String _name;
  public static native int get__name_offset();
  
  public String getName()
  {
    return _name;
  }
  
  public void setName(String the_value) 
  {
    _name = (String) the_value;
  }
  
  public List _bricks = new List();
  public static native int get__bricks_offset();
  
  
  
  // extra accessors for `list bricks'
  public Iter getBrickIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_bricks");
    Iterator i = new STLIterator(_bricks,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendBrick(SuifBrick x) 
   {
    _bricks.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getBrickCount() 
   {
    return _bricks.length();
  }
  
  public void insertBrick(int pos, SuifBrick x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _bricks.length(), "index too large " + pos); 
    _bricks.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public SuifBrick removeBrick(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _bricks.length(), "index too large " + pos);
    SuifBrick tmp = (SuifBrick) _bricks.at(pos);
    _bricks.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public SuifBrick getBrick(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _bricks.length(), "index too large " + pos);
    return (SuifBrick) _bricks.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "BrickAnnote"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{BrickAnnote}");
    text.startBlock("name=");
    text.setValue(_name);
    text.endBlock();
    
     { 
      int i = 0;
      List.Iterator iter = _bricks.begin();
      while (iter.notEqual(_bricks.end())) 
       { 
        SuifBrick item = (SuifBrick) iter.get();
        text.startBlock(text.pointerHeader("_bricks[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
