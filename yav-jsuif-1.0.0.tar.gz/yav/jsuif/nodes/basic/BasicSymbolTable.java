package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class BasicSymbolTable extends SymbolTable
 {  
  public SearchableList _symbol_table_objects = new SearchableList();
  public static native int get__symbol_table_objects_offset();
  
  public SymbolTable _explicit_super_scope;
  public static native int get__explicit_super_scope_offset();
  
  public SymbolTable getExplicitSuperScope()
  {
    return _explicit_super_scope;
  }
  
  public void setExplicitSuperScope(SymbolTable the_value) 
  {
    _explicit_super_scope = (SymbolTable) the_value;
  }
  
  
  
  // extra accessors for `searchable_list symbol_table_objects'
  public Iter getSymbolTableObjectIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_symbol_table_objects");
    Iterator i = new STLIterator(_symbol_table_objects,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendSymbolTableObject(SymbolTableObject key) 
  {
    _symbol_table_objects.pushBack(key);
    if (key != null) key.setParent(this);
  }
  
  public int getSymbolTableObjectCount() 
  {
    return _symbol_table_objects.length();
  }
  
  public void removeSymbolTableObject(SymbolTableObject key) 
  {
    SearchableList.Iterator iter = _symbol_table_objects.find(key);
    Assert.condition(iter.notEqual(_symbol_table_objects.end()),
    "attempt to remove missing key");
    if (iter.get() != null) ((SymbolTableObject) iter.get()).setParent(null);
    _symbol_table_objects.erase(iter);
  }
  
  public boolean hasSymbolTableObjectMember(SymbolTableObject key) 
  {
    return _symbol_table_objects.isMember(key);
  }
  
  public void insertSymbolTableObject(int pos, SymbolTableObject x) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _symbol_table_objects.length(), "index too large " + pos); 
    _symbol_table_objects.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public SymbolTableObject removeSymbolTableObject(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _symbol_table_objects.length(), "index too large " + pos);
    SymbolTableObject tmp = (SymbolTableObject) _symbol_table_objects.at(pos);
    _symbol_table_objects.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public SymbolTableObject getSymbolTableObject(int pos) 
  {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _symbol_table_objects.length(), "index too large " + pos);
    return (SymbolTableObject) _symbol_table_objects.at(pos);
  }
  
  public static native int get_size();
  
  private static String _className = "BasicSymbolTable"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{BasicSymbolTable}");
    
     { 
      int i = 0;
      SearchableList.Iterator iter = _symbol_table_objects.begin();
      while (iter.notEqual(_symbol_table_objects.end())) 
       { 
        SymbolTableObject item = (SymbolTableObject) iter.get();
        text.startBlock(text.pointerHeader("_symbol_table_objects[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    text.startBlock("_explicit_super_scope");
    text.setValue(_explicit_super_scope);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
