package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class CodeLabelSymbol extends Symbol
 {  
  public LabelType _type;
  public static native int get__type_offset();
  
  public Type getType()
  {
    return _type;
  }
  
  public void setType(Type the_value) 
  {
    _type = (LabelType) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "CodeLabelSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{CodeLabelSymbol}");
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
