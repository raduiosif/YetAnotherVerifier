package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Annote extends AnnotableObject
 {  
  
  
  public String getName()
  {
    Assert.fatal("trying to get virtual field");return null;
  }
  
  public void setName(String the_value) 
  {
    Assert.fatal("trying to set virtual field");
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "Annote"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Annote}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
