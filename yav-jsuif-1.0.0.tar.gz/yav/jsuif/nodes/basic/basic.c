#include <jni.h>
#include <suifclasses.h>
#include <basic.h>

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_AnnotableObject_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( AnnotableObject );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_AnnotableObject_get_1_1annotes_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(AnnotableObject, _annotes);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Annote_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Annote );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_GeneralAnnote_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( GeneralAnnote );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_GeneralAnnote_get_1_1name_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(GeneralAnnote, _name);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BrickAnnote_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( BrickAnnote );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BrickAnnote_get_1_1name_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BrickAnnote, _name);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BrickAnnote_get_1_1bricks_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BrickAnnote, _bricks);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SuifBrick_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SuifBrick );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_StringBrick_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( StringBrick );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_StringBrick_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StringBrick, _value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_IntegerBrick_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( IntegerBrick );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_IntegerBrick_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IntegerBrick, _value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SuifObjectBrick_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SuifObjectBrick );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SuifObjectBrick_get_1_1object_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SuifObjectBrick, _object);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_OwnedSuifObjectBrick_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( OwnedSuifObjectBrick );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_OwnedSuifObjectBrick_get_1_1object_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(OwnedSuifObjectBrick, _object);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SymbolTableObject_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SymbolTableObject );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SymbolTableObject_get_1_1name_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SymbolTableObject, _name);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Type_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Type );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_QualifiedType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( QualifiedType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_QualifiedType_get_1_1base_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(QualifiedType, _base_type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_QualifiedType_get_1_1qualifications_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(QualifiedType, _qualifications);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DataType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( DataType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DataType_get_1_1bit_1size_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DataType, _bit_size);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DataType_get_1_1bit_1alignment_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DataType, _bit_alignment);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ProcedureType );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureType_get_1_1qualifications_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureType, _qualifications);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_LabelType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( LabelType );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Symbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Symbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Symbol_get_1_1is_1address_1taken_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(Symbol, _is_address_taken);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VariableSymbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableSymbol_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableSymbol, _type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableSymbol_get_1_1definition_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableSymbol, _definition);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ParameterSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ParameterSymbol );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ProcedureSymbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureSymbol_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureSymbol, _type);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureSymbol_get_1_1definition_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureSymbol, _definition);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_CodeLabelSymbol_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( CodeLabelSymbol );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_CodeLabelSymbol_get_1_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(CodeLabelSymbol, _type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ScopedObject_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ScopedObject );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ExecutionObject_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ExecutionObject );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Statement_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Statement );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Expression_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Expression );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Expression_get_1_1result_1type_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(Expression, _result_type);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_StatementList_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( StatementList );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_StatementList_get_1_1statements_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(StatementList, _statements);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_Constant_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( Constant );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_IntConstant_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( IntConstant );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_IntConstant_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(IntConstant, _value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FloatConstant_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FloatConstant );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FloatConstant_get_1_1value_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FloatConstant, _value);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ValueBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ValueBlock );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableDefinition_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( VariableDefinition );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableDefinition_get_1_1variable_1symbol_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableDefinition, _variable_symbol);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableDefinition_get_1_1bit_1alignment_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableDefinition, _bit_alignment);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableDefinition_get_1_1initialization_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableDefinition, _initialization);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_VariableDefinition_get_1_1is_1static_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(VariableDefinition, _is_static);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( ProcedureDefinition );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1_1procedure_1symbol_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureDefinition, _procedure_symbol);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1_1body_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureDefinition, _body);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureDefinition, _symbol_table);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1_1definition_1block_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureDefinition, _definition_block);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_ProcedureDefinition_get_1_1formal_1parameters_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(ProcedureDefinition, _formal_parameters);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DefinitionBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( DefinitionBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DefinitionBlock_get_1_1variable_1definitions_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DefinitionBlock, _variable_definitions);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_DefinitionBlock_get_1_1procedure_1definitions_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(DefinitionBlock, _procedure_definitions);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FileBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileBlock_get_1_1source_1file_1name_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileBlock, _source_file_name);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileBlock_get_1_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileBlock, _symbol_table);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileBlock_get_1_1definition_1block_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileBlock, _definition_block);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SymbolTable_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( SymbolTable );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_SymbolTable_get_1_1lookup_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(SymbolTable, _lookup_table);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicSymbolTable_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( BasicSymbolTable );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicSymbolTable_get_1_1symbol_1table_1objects_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BasicSymbolTable, _symbol_table_objects);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicSymbolTable_get_1_1explicit_1super_1scope_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(BasicSymbolTable, _explicit_super_scope);
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_GlobalInformationBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( GlobalInformationBlock );
 } 



extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileSetBlock_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( FileSetBlock );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileSetBlock_get_1_1external_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileSetBlock, _external_symbol_table);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileSetBlock_get_1_1file_1set_1symbol_1table_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileSetBlock, _file_set_symbol_table);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileSetBlock_get_1_1file_1blocks_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileSetBlock, _file_blocks);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_FileSetBlock_get_1_1information_1blocks_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(FileSetBlock, _information_blocks);
 } 



typedef indexed_list<LString, SymbolTableObject* >::pair yav_jsuif_nodes_basic_LookupTablePair_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_LookupTablePair_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_basic_LookupTablePair_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_LookupTablePair_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_LookupTablePair_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_LookupTablePair_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_LookupTablePair_type, second);
 } 

typedef indexed_list<LString, SymbolTableObject* >::pair yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRef_type, second);
 } 

typedef indexed_list<LString, SymbolTableObject* >::pair yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_type;
extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_get_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof( yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_type );
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_get_1first_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_type, first);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_get_1second_1offset
(JNIEnv *, jclass)
 { 
  return (jint) OFFSETOF(yav_jsuif_nodes_basic_MetaPairLStringSymbolTableObjectRefType_type, second);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1searchable_1list_1Annote_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(searchable_list <Annote* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1SuifBrick_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <SuifBrick* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1searchable_1list_1LString_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(searchable_list <LString>);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1Statement_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <Statement* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1ParameterSymbol_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <ParameterSymbol* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1VariableDefinition_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <VariableDefinition* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1ProcedureDefinition_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <ProcedureDefinition* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1indexed_1list_1LString_1SymbolTableObject_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(indexed_list <LString,SymbolTableObject* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1searchable_1list_1SymbolTableObject_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(searchable_list <SymbolTableObject* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1FileBlock_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <FileBlock* >);
 } 

extern "C" JNIEXPORT jint JNICALL
Java_yav_jsuif_nodes_basic_BasicObjectFactory_get_1list_1GlobalInformationBlock_1ptr_1size
(JNIEnv *, jclass)
 { 
  return (jint) sizeof(list <GlobalInformationBlock* >);
 } 

