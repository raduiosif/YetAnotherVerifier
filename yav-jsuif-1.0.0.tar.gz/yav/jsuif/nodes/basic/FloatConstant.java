package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class FloatConstant extends Constant
 {  
  public String _value;
  public static native int get__value_offset();
  
  public String getValue()
  {
    return _value;
  }
  
  public void setValue(String the_value) 
  {
    _value = (String) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "FloatConstant"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FloatConstant}");
    text.startBlock("value=");
    text.setValue(_value);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
