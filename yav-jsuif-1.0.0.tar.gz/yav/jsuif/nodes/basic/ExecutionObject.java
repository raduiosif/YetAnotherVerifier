package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class ExecutionObject extends ScopedObject
 {  
  
  
  
  
  
  
  
  
  // extra accessors for `list source_ops'
  public Iter getSourceOpIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "source_ops");
    return new Iter(i);
  }
  
  public void appendSourceOp(Expression x) 
   {
    Assert.fatal("attempt to access virtual field SourceOp");
  }
  
  public int getSourceOpCount() 
   {
    Assert.fatal("attempt to access virtual field SourceOp");return 0;
  }
  
  public void insertSourceOp(int pos, Expression x) 
   {
    Assert.fatal("attempt to access virtual field SourceOp");
  }
  
  public Expression removeSourceOp(int pos) 
   {
    Assert.fatal("attempt to access virtual field SourceOp");return null;
  }
  
  public Expression getSourceOp(int pos) 
   {
    Assert.fatal("attempt to access virtual field SourceOp");return null;
  }
  
  
  
  // extra accessors for `list source_vars'
  public Iter getSourceVarIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "source_vars");
    return new Iter(i);
  }
  
  public void appendSourceVar(VariableSymbol x) 
   {
    Assert.fatal("attempt to access virtual field SourceVar");
  }
  
  public int getSourceVarCount() 
   {
    Assert.fatal("attempt to access virtual field SourceVar");return 0;
  }
  
  public void insertSourceVar(int pos, VariableSymbol x) 
   {
    Assert.fatal("attempt to access virtual field SourceVar");
  }
  
  public VariableSymbol removeSourceVar(int pos) 
   {
    Assert.fatal("attempt to access virtual field SourceVar");return null;
  }
  
  public VariableSymbol getSourceVar(int pos) 
   {
    Assert.fatal("attempt to access virtual field SourceVar");return null;
  }
  
  
  
  // extra accessors for `list defined_labels'
  public Iter getDefinedLabelIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "defined_labels");
    return new Iter(i);
  }
  
  public void appendDefinedLabel(CodeLabelSymbol x) 
   {
    Assert.fatal("attempt to access virtual field DefinedLabel");
  }
  
  public int getDefinedLabelCount() 
   {
    Assert.fatal("attempt to access virtual field DefinedLabel");return 0;
  }
  
  public void insertDefinedLabel(int pos, CodeLabelSymbol x) 
   {
    Assert.fatal("attempt to access virtual field DefinedLabel");
  }
  
  public CodeLabelSymbol removeDefinedLabel(int pos) 
   {
    Assert.fatal("attempt to access virtual field DefinedLabel");return null;
  }
  
  public CodeLabelSymbol getDefinedLabel(int pos) 
   {
    Assert.fatal("attempt to access virtual field DefinedLabel");return null;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ExecutionObject"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ExecutionObject}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
