package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Type extends SymbolTableObject
 {  
  
  
  public static native int get_size();
  
  private static String _className = "Type"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Type}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
