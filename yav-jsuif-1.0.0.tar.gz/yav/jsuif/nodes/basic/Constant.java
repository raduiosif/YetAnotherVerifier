package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Constant extends Expression
 {  
  
  
  public static native int get_size();
  
  private static String _className = "Constant"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Constant}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
