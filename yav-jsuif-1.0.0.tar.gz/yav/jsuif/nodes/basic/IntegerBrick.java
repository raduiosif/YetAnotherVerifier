package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class IntegerBrick extends SuifBrick
 {  
  public IInteger _value;
  public static native int get__value_offset();
  
  public IInteger getValue()
  {
    return _value;
  }
  
  public void setValue(IInteger the_value) 
  {
    _value = (IInteger) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "IntegerBrick"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{IntegerBrick}");
    text.startBlock("value=");
    text.setValue(_value);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
