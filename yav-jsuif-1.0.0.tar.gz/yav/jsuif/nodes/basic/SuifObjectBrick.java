package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class SuifObjectBrick extends SuifBrick
 {  
  public SuifObject _object;
  public static native int get__object_offset();
  
  public SuifObject getObject()
  {
    return _object;
  }
  
  public void setObject(SuifObject the_value) 
  {
    _object = (SuifObject) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "SuifObjectBrick"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{SuifObjectBrick}");
    text.startBlock("_object");
    text.setValue(_object);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
