package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class SymbolTableObject extends AnnotableObject
 {  
  public String _name;
  public static native int get__name_offset();
  
  public String getName()
  {
    return _name;
  }
  
  public void setName(String the_value) 
  {
    _name = (String) the_value;
  }
  
  
  
  public SymbolTable getSymbolTable() {
        return (SymbolTable) getParent();
      }
    
  
  public static native int get_size();
  
  private static String _className = "SymbolTableObject"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{SymbolTableObject}");
    text.startBlock("name=");
    text.setValue(_name);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
