package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class StatementList extends Statement
 {  
  public List _statements = new List();
  public static native int get__statements_offset();
  
  
  
  // extra accessors for `list statements'
  public Iter getStatementIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_statements");
    Iterator i = new STLIterator(_statements,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendStatement(Statement x) 
   {
    _statements.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getStatementCount() 
   {
    return _statements.length();
  }
  
  public void insertStatement(int pos, Statement x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _statements.length(), "index too large " + pos); 
    _statements.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public Statement removeStatement(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _statements.length(), "index too large " + pos);
    Statement tmp = (Statement) _statements.at(pos);
    _statements.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public Statement getStatement(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _statements.length(), "index too large " + pos);
    return (Statement) _statements.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "StatementList"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{StatementList}");
    
     { 
      int i = 0;
      List.Iterator iter = _statements.begin();
      while (iter.notEqual(_statements.end())) 
       { 
        Statement item = (Statement) iter.get();
        text.startBlock(text.pointerHeader("_statements[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
