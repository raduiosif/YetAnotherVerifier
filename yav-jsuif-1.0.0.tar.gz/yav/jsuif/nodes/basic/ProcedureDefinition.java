package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class ProcedureDefinition extends ScopedObject
 {  
  public ProcedureSymbol _procedure_symbol;
  public static native int get__procedure_symbol_offset();
  
  public ProcedureSymbol getProcedureSymbol()
  {
    return _procedure_symbol;
  }
  
  public void setProcedureSymbol(ProcedureSymbol the_value) 
  {
    _procedure_symbol = (ProcedureSymbol) the_value;
  }
  
  public ExecutionObject _body;
  public static native int get__body_offset();
  
  public ExecutionObject getBody()
  {
    return _body;
  }
  
  public ExecutionObject setBody(ExecutionObject the_value) 
  {
    ExecutionObject old_value = _body;
    if (old_value != null) old_value.setParent(null);
    _body = (ExecutionObject) the_value;
    if (the_value != null) the_value.setParent(this);
    return (ExecutionObject) old_value;
  }
  
  public SymbolTable _symbol_table;
  public static native int get__symbol_table_offset();
  
  public SymbolTable getSymbolTable()
  {
    return _symbol_table;
  }
  
  public SymbolTable setSymbolTable(SymbolTable the_value) 
  {
    SymbolTable old_value = _symbol_table;
    if (old_value != null) old_value.setParent(null);
    _symbol_table = (SymbolTable) the_value;
    if (the_value != null) the_value.setParent(this);
    return (SymbolTable) old_value;
  }
  
  public DefinitionBlock _definition_block;
  public static native int get__definition_block_offset();
  
  public DefinitionBlock getDefinitionBlock()
  {
    return _definition_block;
  }
  
  public DefinitionBlock setDefinitionBlock(DefinitionBlock the_value) 
  {
    DefinitionBlock old_value = _definition_block;
    if (old_value != null) old_value.setParent(null);
    _definition_block = (DefinitionBlock) the_value;
    if (the_value != null) the_value.setParent(this);
    return (DefinitionBlock) old_value;
  }
  
  public List _formal_parameters = new List();
  public static native int get__formal_parameters_offset();
  
  
  
  // extra accessors for `list formal_parameters'
  public Iter getFormalParameterIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_formal_parameters");
    Iterator i = new STLIterator(_formal_parameters,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendFormalParameter(ParameterSymbol x) 
   {
    _formal_parameters.pushBack(x);
  }
  
  public int getFormalParameterCount() 
   {
    return _formal_parameters.length();
  }
  
  public void insertFormalParameter(int pos, ParameterSymbol x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _formal_parameters.length(), "index too large " + pos); 
    _formal_parameters.insert(pos, x);
  }
  
  public ParameterSymbol removeFormalParameter(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _formal_parameters.length(), "index too large " + pos);
    ParameterSymbol tmp = (ParameterSymbol) _formal_parameters.at(pos);
    _formal_parameters.erase(pos);
    return tmp;
  }
  
  public ParameterSymbol getFormalParameter(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _formal_parameters.length(), "index too large " + pos);
    return (ParameterSymbol) _formal_parameters.at(pos);
  }
  
  
  
  public void notifier(boolean created, DefinitionBlock d)
        {
          if (_procedure_symbol != null)
          {
            if (created)
              _procedure_symbol.setDefinition(this);
            else
              _procedure_symbol.setDefinition(null);
          }
        }
      
  
  public static native int get_size();
  
  private static String _className = "ProcedureDefinition"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ProcedureDefinition}");
    text.startBlock("_procedure_symbol");
    text.setValue(_procedure_symbol);
    text.endBlock();
    text.startBlock(text.pointerHeader("_body", _body));
    if (_body != null)
      _body.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_symbol_table", _symbol_table));
    if (_symbol_table != null)
      _symbol_table.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_definition_block", _definition_block));
    if (_definition_block != null)
      _definition_block.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    
     { 
      int i = 0;
      List.Iterator iter = _formal_parameters.begin();
      while (iter.notEqual(_formal_parameters.end())) 
       { 
        ParameterSymbol item = (ParameterSymbol) iter.get();
        text.startBlock("_formal_parameters[" + i + "]");
        text.setValue(item);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
