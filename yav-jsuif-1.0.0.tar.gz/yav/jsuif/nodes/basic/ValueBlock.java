package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class ValueBlock extends ScopedObject
 {  
  
  
  public DataType getType()
  {
    return null; 
  }
  
  public void setType(DataType the_value) 
  {
    
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "ValueBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{ValueBlock}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
