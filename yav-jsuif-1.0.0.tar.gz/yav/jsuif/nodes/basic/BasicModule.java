package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;


public class BasicModule extends Module
 {  
  public BasicModule(SuifEnv env)
   {  
    super(env, "basic"); 
   } 
  
  public void initialize()
   {  
    _suif_env.addObjectFactory(new BasicObjectFactory()); 
   } 
  
  public static void init(SuifEnv env)
   {  
    ModuleSubSystem mSubSystem = env.getModuleSubSystem();
    if (mSubSystem.retrieveModule("basic") == null) { 
      mSubSystem.registerModule(new BasicModule(env)); 
     } 
   } 
  
  public Object clone() { return this; } 
 } 

