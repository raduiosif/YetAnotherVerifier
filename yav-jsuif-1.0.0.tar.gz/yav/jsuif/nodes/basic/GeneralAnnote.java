package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class GeneralAnnote extends Annote
 {  
  public String _name;
  public static native int get__name_offset();
  
  public String getName()
  {
    return _name;
  }
  
  public void setName(String the_value) 
  {
    _name = (String) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "GeneralAnnote"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{GeneralAnnote}");
    text.startBlock("name=");
    text.setValue(_name);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
