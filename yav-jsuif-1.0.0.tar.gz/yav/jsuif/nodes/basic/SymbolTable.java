package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class SymbolTable extends AnnotableObject
 {  
  
  
  public IndexedList _lookup_table = new IndexedList();
  public static native int get__lookup_table_offset();
  
  
  
  public SymbolTable getExplicitSuperScope()
  {
    Assert.fatal("trying to get virtual field");return null;
  }
  
  public void setExplicitSuperScope(SymbolTable the_value) 
  {
    Assert.fatal("trying to set virtual field");
  }
  
  
  
  // extra accessors for `searchable_list symbol_table_objects'
  public Iter getSymbolTableObjectIterator() 
  {
    Iterator i = getAggregateMetaClass().getVirtualIterator(this, "symbol_table_objects");
    return new Iter(i);
  }
  
  public void appendSymbolTableObject(SymbolTableObject key) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
  }
  
  public int getSymbolTableObjectCount() 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
    return 0;
  }
  
  public void removeSymbolTableObject(SymbolTableObject key) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
  }
  
  public boolean hasSymbolTableObjectMember(SymbolTableObject key) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
    return false;
  }
  
  public void insertSymbolTableObject(int pos, SymbolTableObject x) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
  }
  
  public SymbolTableObject removeSymbolTableObject(int pos) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
    return null;
  }
  
  public SymbolTableObject getSymbolTableObject(int pos) 
  {
    Assert.fatal("attempt to access virtual field SymbolTableObject");
    return null;
  }
  
  // extra accessors for `indexed_list lookup_table'
  public Iter getLookupTableIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_lookup_table");
    Iterator i = new STLIterator(_lookup_table,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void addLookupTable(String key, SymbolTableObject value)
  {
    _lookup_table.pushBack(key, value);
  }
  
  public void insertLookupTable(String key, SymbolTableObject value)
  {
    List.Iterator iter = _lookup_table.begin();
    while (iter.notEqual(_lookup_table.end()) && ((IndexedList.Pair) iter.get()).first.hashCode() < key.hashCode()) iter.inc();
    _lookup_table.insert(iter, new IndexedList.Pair(key, value));
  }
  
  public SymbolTableObject removeLookupTable(String key) 
  {
    List.Iterator iter = _lookup_table.find(key);
    Assert.condition(iter.notEqual(_lookup_table.end()), "removing up a non-existant value");
    return (SymbolTableObject) _lookup_table.remove(iter);
  }
  
  public boolean hasLookupTableMember(String key) 
  {
    return _lookup_table.isMember(key);
  }
  
  public SymbolTableObject lookupLookupTable(String key) 
  {
    List.Iterator iter = _lookup_table.find(key);
    if (iter.isEqual(_lookup_table.end())) return null;
    return (SymbolTableObject) ((IndexedList.Pair) iter.get()).second;
  }
  
  public int numLookupTableWithKey(String key) 
  {
    return _lookup_table.numWithKey(key);
  }
  
  public SymbolTableObject lookupLookupTable(String key, int no) 
  {
    List.Iterator iter = _lookup_table.find(key, no);
    Assert.condition(iter.notEqual(_lookup_table.end()), "looking up a non-existant value");
    return (SymbolTableObject) ((IndexedList.Pair) iter.get()).second;
  }
  
   public SymbolTableObject removeLookupTable(String key, int no) 
  {
    List.Iterator iter = _lookup_table.find(key, no);
    Assert.condition(iter.notEqual(_lookup_table.end()), "removing up a non-existant value");
    return (SymbolTableObject) _lookup_table.remove(iter);
  }
  
  public void removeAllFromLookupTable(SymbolTableObject value) 
  {
    List.Iterator iter = _lookup_table.begin();
    List.Iterator end = _lookup_table.end();
    while (iter.notEqual(end)) 
    {
      if (((IndexedList.Pair) iter.get()).second.equals(value)) 
      {
        List.Iterator iter1 = new List.Iterator(iter);
        iter.inc();
        _lookup_table.remove(iter1);
      }
      else 
      {
        iter.inc();
      }
      
    }
    
  }
  
  public int getLookupTableCount() 
  {
    return _lookup_table.length();
  }
  
  public IndexedList.Pair getLookupTable(int pos) 
  {
    return (IndexedList.Pair) _lookup_table.at(pos);
  }
  
  public void addSymbol(String name, SymbolTableObject x)
	{
	  Assert.condition(x.getName() == null);
	  x.setName(name);
	  appendSymbolTableObject(x);
	  addLookupTable(name, x);
	}

        public void addSymbol(SymbolTableObject x)
	{
	  appendSymbolTableObject(x);
	  if (x.getName() != null)
	    {
	      addLookupTable(x.getName(), x);
	    }
	}

	public void removeSymbol(SymbolTableObject x)
	{
	  removeAllFromLookupTable(x);
	  removeSymbolTableObject(x);
	}

	public void changeName(SymbolTableObject x, String name)
	{
	  removeAllFromLookupTable(x);
	  x.setName(name);
	  if (name != null)
	    {
	      addLookupTable(name, x);
	    }
	}
      
  
  public static native int get_size();
  
  private static String _className = "SymbolTable"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{SymbolTable}");
    
     { 
      int i = 0;
      List.Iterator iter = _lookup_table.begin();
      while (iter.notEqual(_lookup_table.end())) 
       { 
        String item_first = (String) ((IndexedList.Pair) iter.get()).first;
        text.startBlock("_lookup_table[" + i + "].");
        text.setValue(item_first);
        text.endBlock();
        
        SymbolTableObject item_second = (SymbolTableObject) ((IndexedList.Pair) iter.get()).second;
        text.startBlock("_lookup_table[" + i + "]");
        text.setValue(item_second);
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
