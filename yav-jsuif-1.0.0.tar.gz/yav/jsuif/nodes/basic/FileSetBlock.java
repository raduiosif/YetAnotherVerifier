package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class FileSetBlock extends AnnotableObject
 {  
  public BasicSymbolTable _external_symbol_table;
  public static native int get__external_symbol_table_offset();
  
  public BasicSymbolTable getExternalSymbolTable()
  {
    return _external_symbol_table;
  }
  
  public BasicSymbolTable setExternalSymbolTable(BasicSymbolTable the_value) 
  {
    BasicSymbolTable old_value = _external_symbol_table;
    if (old_value != null) old_value.setParent(null);
    _external_symbol_table = (BasicSymbolTable) the_value;
    if (the_value != null) the_value.setParent(this);
    return (BasicSymbolTable) old_value;
  }
  
  public BasicSymbolTable _file_set_symbol_table;
  public static native int get__file_set_symbol_table_offset();
  
  public BasicSymbolTable getFileSetSymbolTable()
  {
    return _file_set_symbol_table;
  }
  
  public BasicSymbolTable setFileSetSymbolTable(BasicSymbolTable the_value) 
  {
    BasicSymbolTable old_value = _file_set_symbol_table;
    if (old_value != null) old_value.setParent(null);
    _file_set_symbol_table = (BasicSymbolTable) the_value;
    if (the_value != null) the_value.setParent(this);
    return (BasicSymbolTable) old_value;
  }
  
  public List _file_blocks = new List();
  public static native int get__file_blocks_offset();
  
  public List _information_blocks = new List();
  public static native int get__information_blocks_offset();
  
  
  
  // extra accessors for `list file_blocks'
  public Iter getFileBlockIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_file_blocks");
    Iterator i = new STLIterator(_file_blocks,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendFileBlock(FileBlock x) 
   {
    _file_blocks.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getFileBlockCount() 
   {
    return _file_blocks.length();
  }
  
  public void insertFileBlock(int pos, FileBlock x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _file_blocks.length(), "index too large " + pos); 
    _file_blocks.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public FileBlock removeFileBlock(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _file_blocks.length(), "index too large " + pos);
    FileBlock tmp = (FileBlock) _file_blocks.at(pos);
    _file_blocks.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public FileBlock getFileBlock(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _file_blocks.length(), "index too large " + pos);
    return (FileBlock) _file_blocks.at(pos);
  }
  
  
  
  // extra accessors for `list information_blocks'
  public Iter getInformationBlockIterator() 
  {
    AggregateMetaClass m = (AggregateMetaClass) getMetaClass();
    FieldDescription f = m.getFieldDescription("_information_blocks");
    Iterator i = new STLIterator(_information_blocks,f.getMemberMetaClass());
    return new Iter(i);
  }
  
  public void appendInformationBlock(GlobalInformationBlock x) 
   {
    _information_blocks.pushBack(x);
    if (x != null) x.setParent(this);
  }
  
  public int getInformationBlockCount() 
   {
    return _information_blocks.length();
  }
  
  public void insertInformationBlock(int pos, GlobalInformationBlock x) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _information_blocks.length(), "index too large " + pos); 
    _information_blocks.insert(pos, x);
    if (x != null) x.setParent(this);
  }
  
  public GlobalInformationBlock removeInformationBlock(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _information_blocks.length(), "index too large " + pos);
    GlobalInformationBlock tmp = (GlobalInformationBlock) _information_blocks.at(pos);
    _information_blocks.erase(pos);
    if (tmp != null) tmp.setParent(null);
    return tmp;
  }
  
  public GlobalInformationBlock getInformationBlock(int pos) 
   {
    Assert.condition(pos >= 0, "invalid index " + pos); 
    Assert.condition(pos <= _information_blocks.length(), "index too large " + pos);
    return (GlobalInformationBlock) _information_blocks.at(pos);
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "FileSetBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{FileSetBlock}");
    text.startBlock(text.pointerHeader("_external_symbol_table", _external_symbol_table));
    if (_external_symbol_table != null)
      _external_symbol_table.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock(text.pointerHeader("_file_set_symbol_table", _file_set_symbol_table));
    if (_file_set_symbol_table != null)
      _file_set_symbol_table.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    
     { 
      int i = 0;
      List.Iterator iter = _file_blocks.begin();
      while (iter.notEqual(_file_blocks.end())) 
       { 
        FileBlock item = (FileBlock) iter.get();
        text.startBlock(text.pointerHeader("_file_blocks[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    
     { 
      int i = 0;
      List.Iterator iter = _information_blocks.begin();
      while (iter.notEqual(_information_blocks.end())) 
       { 
        GlobalInformationBlock item = (GlobalInformationBlock) iter.get();
        text.startBlock(text.pointerHeader("_information_blocks[" + i +"]", item));
        if (item != null)
          item.print(text);
        else
          text.setValue("NULL");
        text.endBlock();
        
        iter.inc();
        i ++;
       }
     } 
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
