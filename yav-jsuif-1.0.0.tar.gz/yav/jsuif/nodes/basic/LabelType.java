package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class LabelType extends Type
 {  
  
  
  public static native int get_size();
  
  private static String _className = "LabelType"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{LabelType}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
