package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class VariableDefinition extends ScopedObject
 {  
  public VariableSymbol _variable_symbol;
  public static native int get__variable_symbol_offset();
  
  public VariableSymbol getVariableSymbol()
  {
    return _variable_symbol;
  }
  
  public void setVariableSymbol(VariableSymbol the_value) 
  {
    _variable_symbol = (VariableSymbol) the_value;
  }
  
  public int _bit_alignment;
  public static native int get__bit_alignment_offset();
  
  public int getBitAlignment()
  {
    return _bit_alignment;
  }
  
  public void setBitAlignment(int the_value) 
  {
    _bit_alignment = (int) the_value;
  }
  
  public ValueBlock _initialization;
  public static native int get__initialization_offset();
  
  public ValueBlock getInitialization()
  {
    return _initialization;
  }
  
  public ValueBlock setInitialization(ValueBlock the_value) 
  {
    ValueBlock old_value = _initialization;
    if (old_value != null) old_value.setParent(null);
    _initialization = (ValueBlock) the_value;
    if (the_value != null) the_value.setParent(this);
    return (ValueBlock) old_value;
  }
  
  public boolean _is_static;
  public static native int get__is_static_offset();
  
  public boolean getIsStatic()
  {
    return _is_static;
  }
  
  public void setIsStatic(boolean the_value) 
  {
    _is_static = (boolean) the_value;
  }
  
  
  
  public void notifier(boolean created, DefinitionBlock d)
        {
          if (_variable_symbol != null)
          {
            if (created) 
              _variable_symbol.setDefinition(this);
            else 
              _variable_symbol.setDefinition(null);
          }
        }
      
  
  public static native int get_size();
  
  private static String _className = "VariableDefinition"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{VariableDefinition}");
    text.startBlock("_variable_symbol");
    text.setValue(_variable_symbol);
    text.endBlock();
    text.startBlock("bit_alignment=");
    text.setValue(_bit_alignment);
    text.endBlock();
    text.startBlock(text.pointerHeader("_initialization", _initialization));
    if (_initialization != null)
      _initialization.print(text);
    else
      text.setValue("NULL");
    text.endBlock();
    text.startBlock("is_static=");
    text.setValue(_is_static);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
