package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Expression extends ExecutionObject
 {  
  public DataType _result_type;
  public static native int get__result_type_offset();
  
  public DataType getResultType()
  {
    return _result_type;
  }
  
  public void setResultType(DataType the_value) 
  {
    _result_type = (DataType) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "Expression"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Expression}");
    text.startBlock("_result_type");
    text.setValue(_result_type);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
