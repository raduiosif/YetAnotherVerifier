package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class VariableSymbol extends Symbol
 {  
  public QualifiedType _type;
  public static native int get__type_offset();
  
  public Type getType()
  {
    return _type;
  }
  
  public void setType(Type the_value) 
  {
    _type = (QualifiedType) the_value;
  }
  
  public VariableDefinition _definition;
  public static native int get__definition_offset();
  
  public VariableDefinition getDefinition()
  {
    return _definition;
  }
  
  public void setDefinition(VariableDefinition the_value) 
  {
    _definition = (VariableDefinition) the_value;
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "VariableSymbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{VariableSymbol}");
    text.startBlock("_type");
    text.setValue(_type);
    text.endBlock();
    text.startBlock("_definition");
    text.setValue(_definition);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
