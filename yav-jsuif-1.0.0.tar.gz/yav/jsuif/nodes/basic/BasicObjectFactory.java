package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class BasicObjectFactory extends RealObjectFactory
 {  
  private static String _className = "BasicObjectFactory"; 
  public static String getClassName() { return _className; } 
  public String getName() { return getClassName(); } 
  
  static { System.loadLibrary("jsuif"); } 
  
  public void initIO(ObjectFactory mcof) 
   {  
    super.initIO(mcof);
    
    AggregateMetaClass meta_AnnotableObject =
      mcof.createObjectMetaClass(AnnotableObject.getClassName(), AnnotableObject.get_size());
    
    AggregateMetaClass meta_Annote =
      mcof.createObjectMetaClass(Annote.getClassName(), Annote.get_size());
    
    AggregateMetaClass meta_GeneralAnnote =
      mcof.createObjectMetaClass(GeneralAnnote.getClassName(), GeneralAnnote.get_size());
    
    AggregateMetaClass meta_BrickAnnote =
      mcof.createObjectMetaClass(BrickAnnote.getClassName(), BrickAnnote.get_size());
    
    AggregateMetaClass meta_SuifBrick =
      mcof.createObjectMetaClass(SuifBrick.getClassName(), SuifBrick.get_size());
    
    AggregateMetaClass meta_StringBrick =
      mcof.createObjectMetaClass(StringBrick.getClassName(), StringBrick.get_size());
    
    AggregateMetaClass meta_IntegerBrick =
      mcof.createObjectMetaClass(IntegerBrick.getClassName(), IntegerBrick.get_size());
    
    AggregateMetaClass meta_SuifObjectBrick =
      mcof.createObjectMetaClass(SuifObjectBrick.getClassName(), SuifObjectBrick.get_size());
    
    AggregateMetaClass meta_OwnedSuifObjectBrick =
      mcof.createObjectMetaClass(OwnedSuifObjectBrick.getClassName(), OwnedSuifObjectBrick.get_size());
    
    AggregateMetaClass meta_SymbolTableObject =
      mcof.createObjectMetaClass(SymbolTableObject.getClassName(), SymbolTableObject.get_size());
    
    AggregateMetaClass meta_Type =
      mcof.createObjectMetaClass(Type.getClassName(), Type.get_size());
    
    AggregateMetaClass meta_QualifiedType =
      mcof.createObjectMetaClass(QualifiedType.getClassName(), QualifiedType.get_size());
    
    AggregateMetaClass meta_DataType =
      mcof.createObjectMetaClass(DataType.getClassName(), DataType.get_size());
    
    AggregateMetaClass meta_ProcedureType =
      mcof.createObjectMetaClass(ProcedureType.getClassName(), ProcedureType.get_size());
    
    AggregateMetaClass meta_LabelType =
      mcof.createObjectMetaClass(LabelType.getClassName(), LabelType.get_size());
    
    AggregateMetaClass meta_Symbol =
      mcof.createObjectMetaClass(Symbol.getClassName(), Symbol.get_size());
    
    AggregateMetaClass meta_VariableSymbol =
      mcof.createObjectMetaClass(VariableSymbol.getClassName(), VariableSymbol.get_size());
    
    AggregateMetaClass meta_ParameterSymbol =
      mcof.createObjectMetaClass(ParameterSymbol.getClassName(), ParameterSymbol.get_size());
    
    AggregateMetaClass meta_ProcedureSymbol =
      mcof.createObjectMetaClass(ProcedureSymbol.getClassName(), ProcedureSymbol.get_size());
    
    AggregateMetaClass meta_CodeLabelSymbol =
      mcof.createObjectMetaClass(CodeLabelSymbol.getClassName(), CodeLabelSymbol.get_size());
    
    AggregateMetaClass meta_ScopedObject =
      mcof.createObjectMetaClass(ScopedObject.getClassName(), ScopedObject.get_size());
    
    AggregateMetaClass meta_ExecutionObject =
      mcof.createObjectMetaClass(ExecutionObject.getClassName(), ExecutionObject.get_size());
    
    AggregateMetaClass meta_Statement =
      mcof.createObjectMetaClass(Statement.getClassName(), Statement.get_size());
    
    AggregateMetaClass meta_Expression =
      mcof.createObjectMetaClass(Expression.getClassName(), Expression.get_size());
    
    AggregateMetaClass meta_StatementList =
      mcof.createObjectMetaClass(StatementList.getClassName(), StatementList.get_size());
    
    AggregateMetaClass meta_Constant =
      mcof.createObjectMetaClass(Constant.getClassName(), Constant.get_size());
    
    AggregateMetaClass meta_IntConstant =
      mcof.createObjectMetaClass(IntConstant.getClassName(), IntConstant.get_size());
    
    AggregateMetaClass meta_FloatConstant =
      mcof.createObjectMetaClass(FloatConstant.getClassName(), FloatConstant.get_size());
    
    AggregateMetaClass meta_ValueBlock =
      mcof.createObjectMetaClass(ValueBlock.getClassName(), ValueBlock.get_size());
    
    AggregateMetaClass meta_VariableDefinition =
      mcof.createObjectMetaClass(VariableDefinition.getClassName(), VariableDefinition.get_size());
    
    AggregateMetaClass meta_ProcedureDefinition =
      mcof.createObjectMetaClass(ProcedureDefinition.getClassName(), ProcedureDefinition.get_size());
    
    AggregateMetaClass meta_DefinitionBlock =
      mcof.createObjectMetaClass(DefinitionBlock.getClassName(), DefinitionBlock.get_size());
    
    AggregateMetaClass meta_FileBlock =
      mcof.createObjectMetaClass(FileBlock.getClassName(), FileBlock.get_size());
    
    AggregateMetaClass meta_SymbolTable =
      mcof.createObjectMetaClass(SymbolTable.getClassName(), SymbolTable.get_size());
    
    AggregateMetaClass meta_BasicSymbolTable =
      mcof.createObjectMetaClass(BasicSymbolTable.getClassName(), BasicSymbolTable.get_size());
    
    AggregateMetaClass meta_GlobalInformationBlock =
      mcof.createObjectMetaClass(GlobalInformationBlock.getClassName(), GlobalInformationBlock.get_size());
    
    AggregateMetaClass meta_FileSetBlock =
      mcof.createObjectMetaClass(FileSetBlock.getClassName(), FileSetBlock.get_size());
    
    PointerMetaClass meta_Annote_owner =
       mcof.getPointerMetaClass(meta_Annote,true, false, true);
    
    STLMetaClass meta_Annote_owner_searchable_list =
      mcof.getSTLMetaClass("LIST:searchable_list<Annote* >", new STLDescriptor(meta_Annote_owner, get_searchable_list_Annote_ptr_size()));
    
    MetaClass meta_LString =
      _object_factory.findMetaClass("LString");
    
    PointerMetaClass meta_SuifBrick_owner =
       mcof.getPointerMetaClass(meta_SuifBrick ,true, false, true);
    
    STLMetaClass meta_SuifBrick_owner_list =
      mcof.getSTLMetaClass("LIST:list<SuifBrick* >", new STLDescriptor(meta_SuifBrick_owner, get_list_SuifBrick_ptr_size()));
    
    MetaClass meta_String =
      _object_factory.findMetaClass("String");
    
    MetaClass meta_IInteger =
      _object_factory.findMetaClass("IInteger");
    
    AggregateMetaClass meta_SuifObject =
       mcof.findAggregateMetaClass(SuifObject.getClassName());
    
    PointerMetaClass meta_SuifObject_ref =
       mcof.getPointerMetaClass(meta_SuifObject ,false, false, false);
    
    PointerMetaClass meta_SuifObject_owner =
       mcof.getPointerMetaClass(meta_SuifObject ,true, false, true);
    
    PointerMetaClass meta_DataType_ref =
       mcof.getPointerMetaClass(meta_DataType ,false, false, false);
    
    STLMetaClass meta_LString_searchable_list =
      mcof.getSTLMetaClass("LIST:searchable_list<LString>", new STLDescriptor(meta_LString, get_searchable_list_LString_size()));
    
    MetaClass meta_int =
      _object_factory.findMetaClass("int");
    
    MetaClass meta_bool =
      _object_factory.findMetaClass("bool");
    
    PointerMetaClass meta_QualifiedType_ref =
       mcof.getPointerMetaClass(meta_QualifiedType,false, false, false);
    
    PointerMetaClass meta_VariableDefinition_ref =
       mcof.getPointerMetaClass(meta_VariableDefinition ,false, false, false);
    
    PointerMetaClass meta_ProcedureType_ref =
       mcof.getPointerMetaClass(meta_ProcedureType,false, false, false);
    
    PointerMetaClass meta_ProcedureDefinition_ref =
       mcof.getPointerMetaClass(meta_ProcedureDefinition ,false, false, false);
    
    PointerMetaClass meta_LabelType_ref =
       mcof.getPointerMetaClass(meta_LabelType,false, false, false);
    
    PointerMetaClass meta_Statement_owner =
       mcof.getPointerMetaClass(meta_Statement,true, false, true);
    
    STLMetaClass meta_Statement_owner_list =
      mcof.getSTLMetaClass("LIST:list<Statement* >", new STLDescriptor(meta_Statement_owner, get_list_Statement_ptr_size()));
    
    PointerMetaClass meta_VariableSymbol_ref =
       mcof.getPointerMetaClass(meta_VariableSymbol,false, false, false);
    
    PointerMetaClass meta_ValueBlock_owner =
       mcof.getPointerMetaClass(meta_ValueBlock,true, false, true);
    
    PointerMetaClass meta_ProcedureSymbol_ref =
       mcof.getPointerMetaClass(meta_ProcedureSymbol,false, false, false);
    
    PointerMetaClass meta_ExecutionObject_owner =
       mcof.getPointerMetaClass(meta_ExecutionObject,true, false, true);
    
    PointerMetaClass meta_SymbolTable_owner =
       mcof.getPointerMetaClass(meta_SymbolTable,true, false, true);
    
    PointerMetaClass meta_DefinitionBlock_owner =
       mcof.getPointerMetaClass(meta_DefinitionBlock,true, false, true);
    
    PointerMetaClass meta_ParameterSymbol_ref =
       mcof.getPointerMetaClass(meta_ParameterSymbol,false, false, false);
    
    STLMetaClass meta_ParameterSymbol_ref_list =
      mcof.getSTLMetaClass("LIST:list<ParameterSymbol* >", new STLDescriptor(meta_ParameterSymbol_ref, get_list_ParameterSymbol_ptr_size()));
    
    PointerMetaClass meta_VariableDefinition_owner =
       mcof.getPointerMetaClass(meta_VariableDefinition,true, false, true);
    
    STLMetaClass meta_VariableDefinition_owner_list =
      mcof.getSTLMetaClass("LIST:list<VariableDefinition* >", new STLDescriptor(meta_VariableDefinition_owner, get_list_VariableDefinition_ptr_size()));
    
    PointerMetaClass meta_ProcedureDefinition_owner =
       mcof.getPointerMetaClass(meta_ProcedureDefinition,true, false, true);
    
    STLMetaClass meta_ProcedureDefinition_owner_list =
      mcof.getSTLMetaClass("LIST:list<ProcedureDefinition* >", new STLDescriptor(meta_ProcedureDefinition_owner, get_list_ProcedureDefinition_ptr_size()));
    
    PointerMetaClass meta_SymbolTableObject_ref =
       mcof.getPointerMetaClass(meta_SymbolTableObject ,false, false, false);
    
    AggregateMetaClass meta_pair_LString_SymbolTableObject_ref =
      mcof.findAggregateMetaClass("meta_pair_LString_SymbolTableObject_ref");
    
    if (meta_pair_LString_SymbolTableObject_ref == null) {
      meta_pair_LString_SymbolTableObject_ref = mcof.createAggregateMetaClass("meta_pair_LString_SymbolTableObject_ref", MetaPairLStringSymbolTableObjectRefType.get_size());
      _object_factory.addField(meta_pair_LString_SymbolTableObject_ref, "_first",meta_LString, MetaPairLStringSymbolTableObjectRefType.get_first_offset());
      _object_factory.addField(meta_pair_LString_SymbolTableObject_ref, "_second",meta_SymbolTableObject_ref, MetaPairLStringSymbolTableObjectRefType.get_second_offset());
      }
    
    STLMetaClass meta_LString_SymbolTableObject_ref_indexed_list =
      _object_factory.getSTLMetaClass("LIST:indexed_list<LString, SymbolTableObject* >", new STLDescriptor(meta_pair_LString_SymbolTableObject_ref, get_indexed_list_LString_SymbolTableObject_ptr_size()));
    
    PointerMetaClass meta_SymbolTableObject_owner =
       mcof.getPointerMetaClass(meta_SymbolTableObject,true, false, true);
    
    STLMetaClass meta_SymbolTableObject_owner_searchable_list =
      mcof.getSTLMetaClass("LIST:searchable_list<SymbolTableObject* >", new STLDescriptor(meta_SymbolTableObject_owner, get_searchable_list_SymbolTableObject_ptr_size()));
    
    PointerMetaClass meta_SymbolTable_ref =
       mcof.getPointerMetaClass(meta_SymbolTable ,false, false, false);
    
    PointerMetaClass meta_BasicSymbolTable_owner =
       mcof.getPointerMetaClass(meta_BasicSymbolTable,true, false, true);
    
    PointerMetaClass meta_FileBlock_owner =
       mcof.getPointerMetaClass(meta_FileBlock,true, false, true);
    
    STLMetaClass meta_FileBlock_owner_list =
      mcof.getSTLMetaClass("LIST:list<FileBlock* >", new STLDescriptor(meta_FileBlock_owner, get_list_FileBlock_ptr_size()));
    
    PointerMetaClass meta_GlobalInformationBlock_owner =
       mcof.getPointerMetaClass(meta_GlobalInformationBlock,true, false, true);
    
    STLMetaClass meta_GlobalInformationBlock_owner_list =
      mcof.getSTLMetaClass("LIST:list<GlobalInformationBlock* >", new STLDescriptor(meta_GlobalInformationBlock_owner, get_list_GlobalInformationBlock_ptr_size()));
    
    meta_AnnotableObject.inheritsFrom(meta_SuifObject);
    
    _object_factory.addField(meta_AnnotableObject, "_annotes", meta_Annote_owner_searchable_list, AnnotableObject.get__annotes_offset());
    meta_Annote.inheritsFrom(meta_AnnotableObject);
    
    meta_GeneralAnnote.inheritsFrom(meta_Annote);
    
    _object_factory.addField(meta_GeneralAnnote, "_name", meta_LString, GeneralAnnote.get__name_offset());
    meta_BrickAnnote.inheritsFrom(meta_Annote);
    
    _object_factory.addField(meta_BrickAnnote, "_name", meta_LString, BrickAnnote.get__name_offset());
    _object_factory.addField(meta_BrickAnnote, "_bricks", meta_SuifBrick_owner_list, BrickAnnote.get__bricks_offset());
    meta_SuifBrick.inheritsFrom(meta_SuifObject);
    
    meta_StringBrick.inheritsFrom(meta_SuifBrick);
    
    _object_factory.addField(meta_StringBrick, "_value", meta_String, StringBrick.get__value_offset());
    meta_IntegerBrick.inheritsFrom(meta_SuifBrick);
    
    _object_factory.addField(meta_IntegerBrick, "_value", meta_IInteger, IntegerBrick.get__value_offset());
    meta_SuifObjectBrick.inheritsFrom(meta_SuifBrick);
    
    _object_factory.addField(meta_SuifObjectBrick, "_object", meta_SuifObject_ref, SuifObjectBrick.get__object_offset());
    meta_OwnedSuifObjectBrick.inheritsFrom(meta_SuifBrick);
    
    _object_factory.addField(meta_OwnedSuifObjectBrick, "_object", meta_SuifObject_owner, OwnedSuifObjectBrick.get__object_offset());
    meta_SymbolTableObject.inheritsFrom(meta_AnnotableObject);
    
    _object_factory.addField(meta_SymbolTableObject, "_name", meta_LString, SymbolTableObject.get__name_offset());
    meta_Type.inheritsFrom(meta_SymbolTableObject);
    
    meta_QualifiedType.inheritsFrom(meta_Type);
    
    _object_factory.addField(meta_QualifiedType, "_base_type", meta_DataType_ref, QualifiedType.get__base_type_offset());
    _object_factory.addField(meta_QualifiedType, "_qualifications", meta_LString_searchable_list, QualifiedType.get__qualifications_offset());
    meta_DataType.inheritsFrom(meta_Type);
    
    _object_factory.addField(meta_DataType, "_bit_size", meta_IInteger, DataType.get__bit_size_offset());
    _object_factory.addField(meta_DataType, "_bit_alignment", meta_int, DataType.get__bit_alignment_offset());
    meta_ProcedureType.inheritsFrom(meta_Type);
    
    _object_factory.addField(meta_ProcedureType, "_qualifications", meta_LString_searchable_list, ProcedureType.get__qualifications_offset());
    meta_LabelType.inheritsFrom(meta_Type);
    
    meta_Symbol.inheritsFrom(meta_SymbolTableObject);
    
    _object_factory.addField(meta_Symbol, "_is_address_taken", meta_bool, Symbol.get__is_address_taken_offset());
    meta_VariableSymbol.inheritsFrom(meta_Symbol);
    
    _object_factory.addField(meta_VariableSymbol, "_type", meta_QualifiedType_ref, VariableSymbol.get__type_offset());
    _object_factory.addField(meta_VariableSymbol, "_definition", meta_VariableDefinition_ref, VariableSymbol.get__definition_offset());
    meta_ParameterSymbol.inheritsFrom(meta_VariableSymbol);
    
    meta_ProcedureSymbol.inheritsFrom(meta_Symbol);
    
    _object_factory.addField(meta_ProcedureSymbol, "_type", meta_ProcedureType_ref, ProcedureSymbol.get__type_offset());
    _object_factory.addField(meta_ProcedureSymbol, "_definition", meta_ProcedureDefinition_ref, ProcedureSymbol.get__definition_offset());
    meta_CodeLabelSymbol.inheritsFrom(meta_Symbol);
    
    _object_factory.addField(meta_CodeLabelSymbol, "_type", meta_LabelType_ref, CodeLabelSymbol.get__type_offset());
    meta_ScopedObject.inheritsFrom(meta_AnnotableObject);
    
    meta_ExecutionObject.inheritsFrom(meta_ScopedObject);
    
    meta_Statement.inheritsFrom(meta_ExecutionObject);
    
    meta_Expression.inheritsFrom(meta_ExecutionObject);
    
    _object_factory.addField(meta_Expression, "_result_type", meta_DataType_ref, Expression.get__result_type_offset());
    meta_StatementList.inheritsFrom(meta_Statement);
    
    _object_factory.addField(meta_StatementList, "_statements", meta_Statement_owner_list, StatementList.get__statements_offset());
    meta_StatementList.addVirtualField("child_statements","_statements");
    meta_Constant.inheritsFrom(meta_Expression);
    
    meta_IntConstant.inheritsFrom(meta_Constant);
    
    _object_factory.addField(meta_IntConstant, "_value", meta_IInteger, IntConstant.get__value_offset());
    meta_FloatConstant.inheritsFrom(meta_Constant);
    
    _object_factory.addField(meta_FloatConstant, "_value", meta_String, FloatConstant.get__value_offset());
    meta_ValueBlock.inheritsFrom(meta_ScopedObject);
    
    meta_VariableDefinition.inheritsFrom(meta_ScopedObject);
    
    _object_factory.addField(meta_VariableDefinition, "_variable_symbol", meta_VariableSymbol_ref, VariableDefinition.get__variable_symbol_offset());
    _object_factory.addField(meta_VariableDefinition, "_bit_alignment", meta_int, VariableDefinition.get__bit_alignment_offset());
    _object_factory.addField(meta_VariableDefinition, "_initialization", meta_ValueBlock_owner, VariableDefinition.get__initialization_offset());
    _object_factory.addField(meta_VariableDefinition, "_is_static", meta_bool, VariableDefinition.get__is_static_offset());
    meta_ProcedureDefinition.inheritsFrom(meta_ScopedObject);
    
    _object_factory.addField(meta_ProcedureDefinition, "_procedure_symbol", meta_ProcedureSymbol_ref, ProcedureDefinition.get__procedure_symbol_offset());
    _object_factory.addField(meta_ProcedureDefinition, "_body", meta_ExecutionObject_owner, ProcedureDefinition.get__body_offset());
    _object_factory.addField(meta_ProcedureDefinition, "_symbol_table", meta_SymbolTable_owner, ProcedureDefinition.get__symbol_table_offset());
    _object_factory.addField(meta_ProcedureDefinition, "_definition_block", meta_DefinitionBlock_owner, ProcedureDefinition.get__definition_block_offset());
    _object_factory.addField(meta_ProcedureDefinition, "_formal_parameters", meta_ParameterSymbol_ref_list, ProcedureDefinition.get__formal_parameters_offset());
    meta_DefinitionBlock.inheritsFrom(meta_ScopedObject);
    
    _object_factory.addField(meta_DefinitionBlock, "_variable_definitions", meta_VariableDefinition_owner_list, DefinitionBlock.get__variable_definitions_offset());
    _object_factory.addField(meta_DefinitionBlock, "_procedure_definitions", meta_ProcedureDefinition_owner_list, DefinitionBlock.get__procedure_definitions_offset());
    meta_FileBlock.inheritsFrom(meta_ScopedObject);
    
    _object_factory.addField(meta_FileBlock, "_source_file_name", meta_LString, FileBlock.get__source_file_name_offset());
    _object_factory.addField(meta_FileBlock, "_symbol_table", meta_SymbolTable_owner, FileBlock.get__symbol_table_offset());
    _object_factory.addField(meta_FileBlock, "_definition_block", meta_DefinitionBlock_owner, FileBlock.get__definition_block_offset());
    meta_SymbolTable.inheritsFrom(meta_AnnotableObject);
    
    _object_factory.addField(meta_SymbolTable, "_lookup_table", meta_LString_SymbolTableObject_ref_indexed_list, SymbolTable.get__lookup_table_offset());
    meta_BasicSymbolTable.inheritsFrom(meta_SymbolTable);
    
    _object_factory.addField(meta_BasicSymbolTable, "_symbol_table_objects", meta_SymbolTableObject_owner_searchable_list, BasicSymbolTable.get__symbol_table_objects_offset());
    _object_factory.addField(meta_BasicSymbolTable, "_explicit_super_scope", meta_SymbolTable_ref, BasicSymbolTable.get__explicit_super_scope_offset());
    meta_GlobalInformationBlock.inheritsFrom(meta_AnnotableObject);
    
    meta_FileSetBlock.inheritsFrom(meta_AnnotableObject);
    
    _object_factory.addField(meta_FileSetBlock, "_external_symbol_table", meta_BasicSymbolTable_owner, FileSetBlock.get__external_symbol_table_offset());
    _object_factory.addField(meta_FileSetBlock, "_file_set_symbol_table", meta_BasicSymbolTable_owner, FileSetBlock.get__file_set_symbol_table_offset());
    _object_factory.addField(meta_FileSetBlock, "_file_blocks", meta_FileBlock_owner_list, FileSetBlock.get__file_blocks_offset());
    _object_factory.addField(meta_FileSetBlock, "_information_blocks", meta_GlobalInformationBlock_owner_list, FileSetBlock.get__information_blocks_offset());
     
   } 
  
  private static native int get_searchable_list_Annote_ptr_size();
  private static native int get_list_SuifBrick_ptr_size();
  private static native int get_searchable_list_LString_size();
  private static native int get_list_Statement_ptr_size();
  private static native int get_list_ParameterSymbol_ptr_size();
  private static native int get_list_VariableDefinition_ptr_size();
  private static native int get_list_ProcedureDefinition_ptr_size();
  private static native int get_indexed_list_LString_SymbolTableObject_ptr_size();
  private static native int get_searchable_list_SymbolTableObject_ptr_size();
  private static native int get_list_FileBlock_ptr_size();
  private static native int get_list_GlobalInformationBlock_ptr_size();
  
  
  public static void addCompatibleNames() 
   {  
    CompatibleNames.addCompatibleName("lookup_table_pair", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_LString_SymbolTableObject_ref", "IndexedList$Pair");
    CompatibleNames.addCompatibleName("meta_pair_LString_SymbolTableObject_ref_type", "IndexedList$Pair");
     
   } 
  
  public AnnotableObject createAnnotableObject() 
   {  
    AnnotableObject obj =
      (AnnotableObject) _object_factory.createEmptyObjectByName(AnnotableObject.getClassName());
     return obj; 
   } 
  
  public static AnnotableObject createAnnotableObject(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createAnnotableObject(); 
   } 
  
  public Annote createAnnote() 
   {  
    Annote obj =
      (Annote) _object_factory.createEmptyObjectByName(Annote.getClassName());
     return obj; 
   } 
  
  public static Annote createAnnote(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createAnnote(); 
   } 
  
  public GeneralAnnote createGeneralAnnote(String name) 
   {  
    GeneralAnnote obj =
      (GeneralAnnote) _object_factory.createEmptyObjectByName(GeneralAnnote.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static GeneralAnnote createGeneralAnnote(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createGeneralAnnote(name); 
   } 
  
  public BrickAnnote createBrickAnnote(String name) 
   {  
    BrickAnnote obj =
      (BrickAnnote) _object_factory.createEmptyObjectByName(BrickAnnote.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static BrickAnnote createBrickAnnote(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createBrickAnnote(name); 
   } 
  
  public SuifBrick createSuifBrick() 
   {  
    SuifBrick obj =
      (SuifBrick) _object_factory.createEmptyObjectByName(SuifBrick.getClassName());
     return obj; 
   } 
  
  public static SuifBrick createSuifBrick(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSuifBrick(); 
   } 
  
  public StringBrick createStringBrick(String value) 
   {  
    StringBrick obj =
      (StringBrick) _object_factory.createEmptyObjectByName(StringBrick.getClassName());
    obj.setValue(value);
     return obj; 
   } 
  
  public static StringBrick createStringBrick(SuifEnv env, String value) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStringBrick(value); 
   } 
  
  public IntegerBrick createIntegerBrick(IInteger value) 
   {  
    IntegerBrick obj =
      (IntegerBrick) _object_factory.createEmptyObjectByName(IntegerBrick.getClassName());
    obj.setValue(value);
     return obj; 
   } 
  
  public static IntegerBrick createIntegerBrick(SuifEnv env, IInteger value) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createIntegerBrick(value); 
   } 
  
  public SuifObjectBrick createSuifObjectBrick(SuifObject object) 
   {  
    SuifObjectBrick obj =
      (SuifObjectBrick) _object_factory.createEmptyObjectByName(SuifObjectBrick.getClassName());
    obj.setObject(object);
     return obj; 
   } 
  
  public static SuifObjectBrick createSuifObjectBrick(SuifEnv env, SuifObject object) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSuifObjectBrick(object); 
   } 
  
  public OwnedSuifObjectBrick createOwnedSuifObjectBrick(SuifObject object) 
   {  
    OwnedSuifObjectBrick obj =
      (OwnedSuifObjectBrick) _object_factory.createEmptyObjectByName(OwnedSuifObjectBrick.getClassName());
    obj.setObject(object);
     return obj; 
   } 
  
  public static OwnedSuifObjectBrick createOwnedSuifObjectBrick(SuifEnv env, SuifObject object) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createOwnedSuifObjectBrick(object); 
   } 
  
  public SymbolTableObject createSymbolTableObject(String name) 
   {  
    SymbolTableObject obj =
      (SymbolTableObject) _object_factory.createEmptyObjectByName(SymbolTableObject.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static SymbolTableObject createSymbolTableObject(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSymbolTableObject(name ); 
   } 
  
  public Type createType(String name) 
   {  
    Type obj =
      (Type) _object_factory.createEmptyObjectByName(Type.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static Type createType(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createType(name ); 
   } 
  
  public QualifiedType createQualifiedType(DataType base_type, String name) 
   {  
    QualifiedType obj =
      (QualifiedType) _object_factory.createEmptyObjectByName(QualifiedType.getClassName());
    obj.setName(name);
    obj.setBaseType(base_type);
     return obj; 
   } 
  
  public static QualifiedType createQualifiedType(SuifEnv env, DataType base_type, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createQualifiedType(base_type, name ); 
   } 
  
  public DataType createDataType(IInteger bit_size, int bit_alignment, String name) 
   {  
    DataType obj =
      (DataType) _object_factory.createEmptyObjectByName(DataType.getClassName());
    obj.setName(name);
    obj.setBitSize(bit_size);
    obj.setBitAlignment(bit_alignment);
     return obj; 
   } 
  
  public static DataType createDataType(SuifEnv env, IInteger bit_size, int bit_alignment, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createDataType(bit_size, bit_alignment, name ); 
   } 
  
  public ProcedureType createProcedureType(String name) 
   {  
    ProcedureType obj =
      (ProcedureType) _object_factory.createEmptyObjectByName(ProcedureType.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static ProcedureType createProcedureType(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createProcedureType(name ); 
   } 
  
  public LabelType createLabelType(String name) 
   {  
    LabelType obj =
      (LabelType) _object_factory.createEmptyObjectByName(LabelType.getClassName());
    obj.setName(name);
     return obj; 
   } 
  
  public static LabelType createLabelType(SuifEnv env, String name) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createLabelType(name ); 
   } 
  
  public Symbol createSymbol(String name, boolean is_address_taken) 
   {  
    Symbol obj =
      (Symbol) _object_factory.createEmptyObjectByName(Symbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
     return obj; 
   } 
  
  public static Symbol createSymbol(SuifEnv env, String name, boolean is_address_taken) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSymbol(name , is_address_taken ); 
   } 
  
  public VariableSymbol createVariableSymbol(QualifiedType type, String name, boolean is_address_taken) 
   {  
    VariableSymbol obj =
      (VariableSymbol) _object_factory.createEmptyObjectByName(VariableSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
    obj.setDefinition(null);
     return obj; 
   } 
  
  public static VariableSymbol createVariableSymbol(SuifEnv env, QualifiedType type, String name, boolean is_address_taken) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVariableSymbol(type, name , is_address_taken ); 
   } 
  
  public ParameterSymbol createParameterSymbol(QualifiedType type, String name, boolean is_address_taken) 
   {  
    ParameterSymbol obj =
      (ParameterSymbol) _object_factory.createEmptyObjectByName(ParameterSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
    obj.setDefinition(null);
     return obj; 
   } 
  
  public static ParameterSymbol createParameterSymbol(SuifEnv env, QualifiedType type, String name, boolean is_address_taken) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createParameterSymbol(type, name , is_address_taken ); 
   } 
  
  public ProcedureSymbol createProcedureSymbol(ProcedureType type, String name, boolean is_address_taken, ProcedureDefinition definition) 
   {  
    ProcedureSymbol obj =
      (ProcedureSymbol) _object_factory.createEmptyObjectByName(ProcedureSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
    obj.setDefinition(definition);
     return obj; 
   } 
  
  public static ProcedureSymbol createProcedureSymbol(SuifEnv env, ProcedureType type, String name, boolean is_address_taken, ProcedureDefinition definition) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createProcedureSymbol(type, name , is_address_taken , definition ); 
   } 
  
  public CodeLabelSymbol createCodeLabelSymbol(LabelType type, String name, boolean is_address_taken) 
   {  
    CodeLabelSymbol obj =
      (CodeLabelSymbol) _object_factory.createEmptyObjectByName(CodeLabelSymbol.getClassName());
    obj.setName(name);
    obj.setIsAddressTaken(is_address_taken);
    obj.setType(type);
     return obj; 
   } 
  
  public static CodeLabelSymbol createCodeLabelSymbol(SuifEnv env, LabelType type, String name, boolean is_address_taken) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createCodeLabelSymbol(type, name , is_address_taken ); 
   } 
  
  public ScopedObject createScopedObject() 
   {  
    ScopedObject obj =
      (ScopedObject) _object_factory.createEmptyObjectByName(ScopedObject.getClassName());
     return obj; 
   } 
  
  public static ScopedObject createScopedObject(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createScopedObject(); 
   } 
  
  public ExecutionObject createExecutionObject() 
   {  
    ExecutionObject obj =
      (ExecutionObject) _object_factory.createEmptyObjectByName(ExecutionObject.getClassName());
     return obj; 
   } 
  
  public static ExecutionObject createExecutionObject(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createExecutionObject(); 
   } 
  
  public Statement createStatement() 
   {  
    Statement obj =
      (Statement) _object_factory.createEmptyObjectByName(Statement.getClassName());
     return obj; 
   } 
  
  public static Statement createStatement(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStatement(); 
   } 
  
  public Expression createExpression(DataType result_type) 
   {  
    Expression obj =
      (Expression) _object_factory.createEmptyObjectByName(Expression.getClassName());
    obj.setResultType(result_type);
     return obj; 
   } 
  
  public static Expression createExpression(SuifEnv env, DataType result_type) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createExpression(result_type); 
   } 
  
  public StatementList createStatementList() 
   {  
    StatementList obj =
      (StatementList) _object_factory.createEmptyObjectByName(StatementList.getClassName());
     return obj; 
   } 
  
  public static StatementList createStatementList(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createStatementList(); 
   } 
  
  public Constant createConstant(DataType result_type) 
   {  
    Constant obj =
      (Constant) _object_factory.createEmptyObjectByName(Constant.getClassName());
    obj.setResultType(result_type);
     return obj; 
   } 
  
  public static Constant createConstant(SuifEnv env, DataType result_type) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createConstant(result_type); 
   } 
  
  public IntConstant createIntConstant(DataType result_type, IInteger value) 
   {  
    IntConstant obj =
      (IntConstant) _object_factory.createEmptyObjectByName(IntConstant.getClassName());
    obj.setResultType(result_type);
    obj.setValue(value);
     return obj; 
   } 
  
  public static IntConstant createIntConstant(SuifEnv env, DataType result_type, IInteger value) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createIntConstant(result_type, value); 
   } 
  
  public FloatConstant createFloatConstant(DataType result_type, String value) 
   {  
    FloatConstant obj =
      (FloatConstant) _object_factory.createEmptyObjectByName(FloatConstant.getClassName());
    obj.setResultType(result_type);
    obj.setValue(value);
     return obj; 
   } 
  
  public static FloatConstant createFloatConstant(SuifEnv env, DataType result_type, String value) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFloatConstant(result_type, value); 
   } 
  
  public ValueBlock createValueBlock() 
   {  
    ValueBlock obj =
      (ValueBlock) _object_factory.createEmptyObjectByName(ValueBlock.getClassName());
     return obj; 
   } 
  
  public static ValueBlock createValueBlock(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createValueBlock(); 
   } 
  
  public VariableDefinition createVariableDefinition(VariableSymbol variable_symbol, int bit_alignment, ValueBlock initialization, boolean is_static) 
   {  
    VariableDefinition obj =
      (VariableDefinition) _object_factory.createEmptyObjectByName(VariableDefinition.getClassName());
    obj.setVariableSymbol(variable_symbol);
    obj.setBitAlignment(bit_alignment);
    obj.setInitialization(initialization);
    obj.setIsStatic(is_static);
     return obj; 
   } 
  
  public static VariableDefinition createVariableDefinition(SuifEnv env, VariableSymbol variable_symbol, int bit_alignment, ValueBlock initialization, boolean is_static) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createVariableDefinition(variable_symbol, bit_alignment, initialization, is_static ); 
   } 
  
  public ProcedureDefinition createProcedureDefinition(ProcedureSymbol procedure_symbol, ExecutionObject body, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    ProcedureDefinition obj =
      (ProcedureDefinition) _object_factory.createEmptyObjectByName(ProcedureDefinition.getClassName());
    obj.setProcedureSymbol(procedure_symbol);
    obj.setBody(body);
    obj.setSymbolTable(symbol_table);
    obj.setDefinitionBlock(definition_block);
     return obj; 
   } 
  
  public static ProcedureDefinition createProcedureDefinition(SuifEnv env, ProcedureSymbol procedure_symbol, ExecutionObject body, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createProcedureDefinition(procedure_symbol , body , symbol_table , definition_block ); 
   } 
  
  public DefinitionBlock createDefinitionBlock() 
   {  
    DefinitionBlock obj =
      (DefinitionBlock) _object_factory.createEmptyObjectByName(DefinitionBlock.getClassName());
     return obj; 
   } 
  
  public static DefinitionBlock createDefinitionBlock(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createDefinitionBlock(); 
   } 
  
  public FileBlock createFileBlock(String source_file_name, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    FileBlock obj =
      (FileBlock) _object_factory.createEmptyObjectByName(FileBlock.getClassName());
    obj.setSourceFileName(source_file_name);
    obj.setSymbolTable(symbol_table);
    obj.setDefinitionBlock(definition_block);
     return obj; 
   } 
  
  public static FileBlock createFileBlock(SuifEnv env, String source_file_name, SymbolTable symbol_table, DefinitionBlock definition_block) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFileBlock(source_file_name, symbol_table , definition_block ); 
   } 
  
  public SymbolTable createSymbolTable() 
   {  
    SymbolTable obj =
      (SymbolTable) _object_factory.createEmptyObjectByName(SymbolTable.getClassName());
     return obj; 
   } 
  
  public static SymbolTable createSymbolTable(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createSymbolTable(); 
   } 
  
  public BasicSymbolTable createBasicSymbolTable(SymbolTable explicit_super_scope) 
   {  
    BasicSymbolTable obj =
      (BasicSymbolTable) _object_factory.createEmptyObjectByName(BasicSymbolTable.getClassName());
    obj.setExplicitSuperScope(explicit_super_scope);
     return obj; 
   } 
  
  public static BasicSymbolTable createBasicSymbolTable(SuifEnv env, SymbolTable explicit_super_scope) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createBasicSymbolTable(explicit_super_scope ); 
   } 
  
  public GlobalInformationBlock createGlobalInformationBlock() 
   {  
    GlobalInformationBlock obj =
      (GlobalInformationBlock) _object_factory.createEmptyObjectByName(GlobalInformationBlock.getClassName());
     return obj; 
   } 
  
  public static GlobalInformationBlock createGlobalInformationBlock(SuifEnv env) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createGlobalInformationBlock(); 
   } 
  
  public FileSetBlock createFileSetBlock(BasicSymbolTable external_symbol_table, BasicSymbolTable file_set_symbol_table) 
   {  
    FileSetBlock obj =
      (FileSetBlock) _object_factory.createEmptyObjectByName(FileSetBlock.getClassName());
    obj.setExternalSymbolTable(external_symbol_table);
    obj.setFileSetSymbolTable(file_set_symbol_table);
     return obj; 
   } 
  
  public static FileSetBlock createFileSetBlock(SuifEnv env, BasicSymbolTable external_symbol_table, BasicSymbolTable file_set_symbol_table) 
   {  
    BasicObjectFactory of =
      (BasicObjectFactory) env.getObjectFactory(_className);
    Assert.condition(of != null, _className + " not registered");
    return of.createFileSetBlock(external_symbol_table , file_set_symbol_table ); 
   } 
  
   
 } 
class LookupTablePair 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairLStringSymbolTableObjectRef 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
class MetaPairLStringSymbolTableObjectRefType 
 {  
  public static native int get_size();
  public static native int get_first_offset();
  public static native int get_second_offset(); 
 } 
 
