package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class Symbol extends SymbolTableObject
 {  
  public boolean _is_address_taken;
  public static native int get__is_address_taken_offset();
  
  public boolean getIsAddressTaken()
  {
    return _is_address_taken;
  }
  
  public void setIsAddressTaken(boolean the_value) 
  {
    _is_address_taken = (boolean) the_value;
  }
  
  
  
  public Type getType()
  {
    Assert.fatal("trying to get virtual field");return null;
  }
  
  public void setType(Type the_value) 
  {
    Assert.fatal("trying to set virtual field");
  }
  
  
  
  public static native int get_size();
  
  private static String _className = "Symbol"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{Symbol}");
    text.startBlock("is_address_taken=");
    text.setValue(_is_address_taken);
    text.endBlock();
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
