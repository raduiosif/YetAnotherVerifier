package yav.jsuif.nodes.basic;

import yav.jsuif.kernel.*;
import yav.jsuif.iokernel.*;
import yav.jsuif.common.*;


public class GlobalInformationBlock extends AnnotableObject
 {  
  
  
  public static native int get_size();
  
  private static String _className = "GlobalInformationBlock"; 
  public static String getClassName() { return _className; } 
  
  public void print(FormattedText text) 
   { 
    text.startBlock("{GlobalInformationBlock}");
    super.print(text);
    text.endBlock();
    
   } 
 } 
 
